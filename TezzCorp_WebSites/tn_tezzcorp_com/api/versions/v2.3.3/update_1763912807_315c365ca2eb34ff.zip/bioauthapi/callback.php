<?php
require '../conn.php';

date_default_timezone_set("Asia/Kolkata");
$date = date("Y-m-d");
$time = date("h:i:sa");

$query = mysqli_query($conn, "SELECT * FROM fingerprint");

if(isset($_REQUEST['type'])) {
    $update = $_REQUEST['type'];
    
    if ($update == "attendancein") {
        $uid = $_REQUEST['uid'];
        
        $status = "In";
        
        $query = "INSERT INTO staff_attendance (staff_id, date, time, status, attendance) VALUES ('$uid', '$date', '$time', '1', '$status')";
        $result = mysqli_query($conn, $query);
        
        if ($result) {
            $response = array("message" => "Attendance updated successfully");
        } else {
            $response = array("message" => "Failed to update attendance");
        }
    } elseif ($update == "register") {
        $user_id = $_REQUEST['user_id'];
        $finger_data = $_REQUEST['finger_data'];
        
        $get_data = mysqli_query($conn, "SELECT uid FROM fingerprint WHERE uid = '$user_id'");
        $data = mysqli_fetch_array($get_data);
        
        if ($data['uid'] == $user_id) {
            $query = "UPDATE fingerprint SET finger_data = '$finger_data'";
        } else {
            $query = "INSERT INTO fingerprint (uid, finger_data) VALUES ('$user_id', '$finger_data')";
        }
        
        $result = mysqli_query($conn, $query);
        
        if ($result) {
            $response = array("message" => "Fingerprint updated/insert successfully");
        } else {
            $response = array("message" => "Failed to update/insert fingerprint");
        }
    } else {
        $uid = $_REQUEST['uid'];
        
        $status = "Out";
        
        $query = "INSERT INTO staff_attendance (staff_id, date, time, status, attendance) VALUES ('$uid', '$date', '$time', '1', '$status')";
        $result = mysqli_query($conn, $query);
        
        if ($result) {
            $response = array("message" => "Attendance updated successfully");
        } else {
            $response = array("message" => "Failed to update attendance");
        }
    }
} else {
    $response = array();  // Create an array to hold all the results
    
    // Fetch all rows from the query
    while ($fetch = mysqli_fetch_array($query)) {
        
        // Fetch the data into variables
        $id = $fetch['id'];
        $uid = $fetch['uid'];
        $name = $fetch['name'];
        $finger_data = $fetch['finger_data'];
        
        // Add the row to the response array
        $response[] = array(
            "id" => $id,
            "uid" => $uid,
            "name" => $name,
            "finger_data" => $finger_data
        );
    }
}

// Set content type as JSON
header('Content-Type: application/json');

// Output the entire response array as JSON
echo json_encode($response);
?>