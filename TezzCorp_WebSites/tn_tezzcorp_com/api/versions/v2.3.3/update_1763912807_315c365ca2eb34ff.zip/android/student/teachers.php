<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Teachers class to handle operations
class Teachers {
    private $pdo;
    private $user_id;

    public function __construct(PDO $pdo, $user_id) {
        $this->pdo = $pdo;
        $this->user_id = $user_id;
    }

    public function getStudentClass() {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT class FROM students 
                WHERE id = :id AND status = "active"'
            );
            $stmt->execute([':id' => $this->user_id]);
            $student = $stmt->fetch();
            return $student ? $student['class'] : null;
        } catch (PDOException $e) {
            error_log('Student class fetch failed: ' . $e->getMessage());
            return null;
        }
    }

    public function getTeachers() {
        try {
            $student_class = $this->getStudentClass();
            if (!$student_class) {
                return [];
            }
    
            // Fetch teachers assigned to the student's class via subject_teacher
            $stmt = $this->pdo->prepare(
                'SELECT DISTINCT st.tid, s.name, s.mobile, s.email
                 FROM subject_teacher st
                 INNER JOIN staff s ON st.tid = s.id
                 WHERE s.role = "Teacher" AND s.status = "active" AND st.class = :class'
            );
            $stmt->execute([':class' => $student_class]);
            $teachers = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    
            // Fetch subjects for each teacher from subject_teacher
            foreach ($teachers as &$teacher) {
                $stmt = $this->pdo->prepare(
                    'SELECT DISTINCT sb.subject
                     FROM subject_teacher st
                     INNER JOIN subject sb ON st.subject = sb.id
                     WHERE st.tid = :tid AND st.class = :class'
                );
                $stmt->execute([
                    ':tid' => $teacher['tid'],
                    ':class' => $student_class
                ]);
                $subjects = $stmt->fetchAll(PDO::FETCH_COLUMN) ?: [];
                $teacher['subjects'] = implode(', ', $subjects);
            }
            unset($teacher); // Unset reference to avoid issues
    
            return $teachers;
        } catch (PDOException $e) {
            error_log('Teachers fetch failed: ' . $e->getMessage());
            return [];
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Initialize Teachers manager
$teachersManager = new Teachers($pdo, $_SESSION['user_id']);

// Fetch teachers data
$teachers = $teachersManager->getTeachers();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Educational App - My Teachers</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px; /* Space for fixed footer */
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }
        
        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .teacher-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .teacher-card {
            display: flex;
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: var(--transition);
            cursor: pointer;
        }
        
        .teacher-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }
        
        .teacher-avatar {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: 600;
            margin-right: 15px;
            flex-shrink: 0;
        }
        
        .teacher-info {
            flex: 1;
        }
        
        .teacher-name {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .teacher-subject {
            font-size: 14px;
            color: var(--primary-color);
            font-weight: 500;
            margin-bottom: 5px;
        }
        
        .teacher-meta {
            display: flex;
            gap: 15px;
            font-size: 13px;
            color: var(--light-text);
        }
        
        .teacher-meta-item {
            display: flex;
            align-items: center;
        }
        
        .teacher-meta-item i {
            margin-right: 5px;
        }
        
        .teacher-actions {
            display: flex;
            margin-top: 10px;
            gap: 10px;
        }
        
        .action-button {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background-color: #f0f2f5;
            color: var(--primary-color);
            transition: var(--transition);
        }
        
        .action-button:hover {
            background-color: var(--primary-color);
            color: white;
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Empty state */
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
            text-align: center;
        }
        
        .empty-icon {
            font-size: 50px;
            color: #ccc;
            margin-bottom: 15px;
        }
        
        .empty-text {
            font-size: 16px;
            color: var(--light-text);
            margin-bottom: 20px;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }
            
            .teacher-name {
                font-size: 16px;
            }
            
            .teacher-avatar {
                width: 60px;
                height: 60px;
                font-size: 20px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" id="back-button"></i>
        My Teachers
    </div>
    
    <div class="section">
        <div class="section-title">Subject Teachers</div>
        <div class="teacher-list" id="teacher-list">
            <?php if (empty($teachers)): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-user-slash"></i>
                    </div>
                    <div class="empty-text">No teachers found for your class.</div>
                </div>
            <?php else: ?>
                <?php foreach ($teachers as $teacher): ?>
                    <?php
                    // Get initials for avatar
                    $nameParts = explode(' ', $teacher['name']);
                    $initials = '';
                    if (count($nameParts) >= 2) {
                        $initials = strtoupper(substr($nameParts[0], 0, 1) . substr($nameParts[1], 0, 1));
                    } else {
                        $initials = strtoupper(substr($nameParts[0], 0, 1));
                    }
                    ?>
                    <div class="teacher-card">
                        <div class="teacher-avatar"><?php echo htmlspecialchars($initials); ?></div>
                        <div class="teacher-info">
                            <div class="teacher-name"><?php echo htmlspecialchars($teacher['name']); ?></div>
                            <div class="teacher-subject"><?php echo htmlspecialchars($teacher['subjects'] ?: 'N/A'); ?></div>
                            <div class="teacher-actions">
                                <div class="action-button" title="Email" data-email="<?php echo htmlspecialchars($teacher['email']); ?>">
                                    <i class="fas fa-envelope"></i>
                                </div>
                                <div class="action-button" title="Message" data-name="<?php echo htmlspecialchars($teacher['name']); ?>">
                                    <i class="fas fa-comment"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="fee_dues.php" class="footer-item ripple">
            <i class="fas fa-inr footer-icon"></i>
            <span class="footer-text">Fees</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            // Back button functionality
            document.getElementById('back-button').addEventListener('click', function() {
                showLoader();
                window.location.href = 'index.php';
            });
            
            // Add event listeners to action buttons
            const actionButtons = document.querySelectorAll('.action-button');
            actionButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const action = this.getAttribute('title');
                    const teacherName = this.getAttribute('data-name') || this.closest('.teacher-card').querySelector('.teacher-name').textContent;
                    const teacherEmail = this.getAttribute('data-email');
                    const teacherPhone = this.getAttribute('data-phone');
                    
                    if (action === 'Call' && teacherPhone) {
                        window.location.href = `tel:${teacherPhone}`;
                    } else if (action === 'Email' && teacherEmail) {
                        window.location.href = `mailto:${teacherEmail}`;
                    } else if (action === 'Message') {
                        alert(`Message functionality for ${teacherName} will be implemented soon.`);
                    }
                });
            });

            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }

            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>