// js/fee_collection.js - FULL FEE LOGIC (same as previous full collection.js)
$(document).ready(function () {
    loadStudentName();
    loadApplicableFees(STUDENT_ID);
    loadPaymentHistory(STUDENT_ID);
    loadStudentCredits(STUDENT_ID);
});

function loadStudentName() {
    $.get("api/student_api.php", { action: "get", id: STUDENT_ID }, res => {
        if (res.status === "success") {
            $("#student_name_display").text(`${res.data.full_name} - ${res.data.father_name}`);
        }
    });
}

// Paste your **full collection.js logic** here (renderFeeCards, modal, history, etc.)
// From your previous full version