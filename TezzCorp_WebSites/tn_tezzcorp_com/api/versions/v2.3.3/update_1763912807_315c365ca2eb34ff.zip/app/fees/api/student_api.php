<?php
// =====================================
// DEBUG MODE
// =====================================
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php-error.log');

// JSON header
header('Content-Type: application/json');

session_start();

$response = [
    'status' => 'error',
    'message' => '',
    'debug' => []
];

// =====================================
// CONFIG FILE CHECK
// =====================================
$configPath = $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
if (!file_exists($configPath)) {
    $response['message'] = 'Config file not found';
    $response['debug']['path'] = $configPath;
    echo json_encode($response, JSON_PRETTY_PRINT);
    exit;
}

require_once $configPath;

// =====================================
// DATABASE CONNECTION
// =====================================
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    $response['message'] = 'Database connection failed';
    $response['debug']['error'] = $e->getMessage();
    echo json_encode($response, JSON_PRETTY_PRINT);
    exit;
}

// =====================================
// MAIN LOGIC
// =====================================
$action = $_GET['action'] ?? '';
$response['debug']['action'] = $action;

try {
    if ($action === 'list_all') {
        $stmt = $pdo->query("
            SELECT s.id, s.uid, s.full_name, s.father_name, c.class_name, s.class
            FROM students s
            JOIN class c ON s.class = c.id
            WHERE s.status = 'active'
            ORDER BY c.class_name, s.full_name
        ");

        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['status' => 'success', 'data' => $data], JSON_PRETTY_PRINT);
        exit;
    }
    $response['message'] = 'Invalid action';

} catch (Exception $e) {
    $response['message'] = 'Exception occurred';
    $response['debug']['exception'] = $e->getMessage();
}

echo json_encode($response, JSON_PRETTY_PRINT);
?>