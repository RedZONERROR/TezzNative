<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- Select2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" />
    <!-- Select2 Bootstrap 5 Theme -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">

    <title>Pending Fees Management - AI-ERP 2.0</title>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }

        .card-header {
            background-color: #fff;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            padding: 1rem 1.5rem;
        }

        .table {
            margin-bottom: 0;
        }

        .table thead th {
            background-color: #e9ecef;
            text-transform: uppercase;
            font-size: 0.85rem;
            font-weight: 600;
            color: #495057;
        }

        .table tbody tr:hover {
            background-color: #f1f3f5;
        }

        .table td, .table th {
            vertical-align: middle;
            padding: 0.75rem;
        }

        .badge {
            font-size: 0.75rem;
            padding: 0.35em 0.65em;
        }

        .btn {
            border-radius: 0.375rem;
            transition: all 0.2s ease;
        }

        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }

        .btn i {
            margin-right: 0.25rem;
        }

        .form-label {
            font-weight: 500;
            color: #495057;
        }

        .form-select, .form-control {
            border-radius: 0.375rem;
            transition: all 0.2s ease;
        }

        .form-select:focus, .form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }

        .modal-content {
            border-radius: 0.75rem;
        }

        .modal-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }

        .modal-footer {
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }

        .select2-container {
            width: 100% !important;
            z-index: 1055 !important;
        }

        .select2-container--bootstrap-5 .select2-selection {
            border-radius: 0.375rem;
            border: 1px solid #ced4da;
            min-height: 38px;
            display: flex;
            align-items: center;
        }

        .select2-container .select2-dropdown {
            z-index: 1056 !important;
        }

        .pending-preview {
            background-color: #e7f3ff;
            border: 1px solid #b3d9ff;
            border-radius: 0.375rem;
            padding: 1rem;
            margin-top: 1rem;
        }

        .pending-preview h6 {
            color: #0066cc;
            margin-bottom: 0.5rem;
        }

        .pending-preview .row {
            margin-bottom: 0.5rem;
        }

        .pending-preview .row:last-child {
            margin-bottom: 0;
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card mb-3">
                        <div class="card-body py-3">
                            <div class="d-flex align-items-center justify-content-between flex-wrap">
                                <h4 class="card-title mb-0">Pending Fees Management</h4>
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb mb-0">
                                        <li class="breadcrumb-item d-flex align-items-center">
                                            <a class="text-muted text-decoration-none d-flex" href="/app" aria-label="Home">
                                                <iconify-icon icon="solar:home-2-line-duotone" class="fs-5"></iconify-icon>
                                            </a>
                                        </li>
                                        <li class="breadcrumb-item">
                                            <span class="badge bg-primary-subtle text-primary fw-medium">Pending Fees</span>
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>

                    <!-- Pending Fees Management Section -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h4 class="card-title mb-0">Manage Pending Fees</h4>
                                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPendingFeesModal">
                                        <i class="fas fa-plus"></i> Add Pending Fee
                                    </button>
                                </div>
                                <div class="card-body">
                                    <!-- Filter Section -->
                                    <div class="row g-3 mb-4">
                                        <div class="col-md-4">
                                            <label for="filter_class" class="form-label">Filter by Class</label>
                                            <select class="form-select" id="filter_class" name="filter_class">
                                                <option value="">All Classes</option>
                                                <!-- Classes will be loaded dynamically -->
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="filter_particular" class="form-label">Filter by Particular</label>
                                            <select class="form-select" id="filter_particular" name="filter_particular">
                                                <option value="">All Particulars</option>
                                                <!-- Particulars will be loaded dynamically -->
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="filter_status" class="form-label">Filter by Status</label>
                                            <select class="form-select" id="filter_status" name="filter_status">
                                                <option value="">All Status</option>
                                                <option value="pending">Pending</option>
                                                <option value="partially_paid">Partially Paid</option>
                                                <option value="fully_paid">Fully Paid</option>
                                            </select>
                                        </div>
                                    </div>

                                    <!-- Pending Fees Table -->
                                    <div class="table-responsive">
                                        <table class="table table-hover" id="pending_fees_table">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Student</th>
                                                    <th scope="col">Class</th>
                                                    <th scope="col">Particular</th>
                                                    <th scope="col">Pending Amount</th>
                                                    <th scope="col">Due Months</th>
                                                    <th scope="col">Due Session</th>
                                                    <th scope="col">Status</th>
                                                    <th scope="col">Created On</th>
                                                    <th scope="col">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody id="pending_fees_body">
                                                <!-- Pending fees will load dynamically -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Add Pending Fee Modal -->
                    <div class="modal fade" id="addPendingFeesModal" tabindex="-1" aria-labelledby="addPendingFeesModalTitle">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="addPendingFeesModalTitle">Add Pending Fee</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form id="addPendingFeesForm" class="needs-validation" novalidate>
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label for="student_class_add" class="form-label">Class <span class="text-danger">*</span></label>
                                                <select class="form-select" id="student_class_add" name="student_class_add" required>
                                                    <option value="">Select Class</option>
                                                    <!-- Classes will be loaded dynamically -->
                                                </select>
                                                <div class="invalid-feedback">Please select a class.</div>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="student_info_add" class="form-label">Student <span class="text-danger">*</span></label>
                                                <select class="form-select" id="student_info_add" name="student_info_add" required disabled>
                                                    <option value="">Select Student</option>
                                                    <!-- Students will be loaded dynamically -->
                                                </select>
                                                <div class="invalid-feedback">Please select a student.</div>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="particular_add" class="form-label">Particular <span class="text-danger">*</span></label>
                                                <select class="form-select" id="particular_add" name="particular_add" required disabled>
                                                    <option value="">Select Particular</option>
                                                    <!-- Particulars will be loaded dynamically -->
                                                </select>
                                                <div class="invalid-feedback">Please select a particular.</div>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="pending_amount" class="form-label">Pending Amount <span class="text-danger">*</span></label>
                                                <input type="number" step="0.01" class="form-control" id="pending_amount" name="pending_amount" required>
                                                <div class="invalid-feedback">Please enter a pending amount.</div>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="due_months_add" class="form-label">Due Months</label>
                                                <select class="form-control" id="due_months_add" name="due_months_add" multiple>
                                                    <option value="1">January</option>
                                                    <option value="2">February</option>
                                                    <option value="3">March</option>
                                                    <option value="4">April</option>
                                                    <option value="5">May</option>
                                                    <option value="6">June</option>
                                                    <option value="7">July</option>
                                                    <option value="8">August</option>
                                                    <option value="9">September</option>
                                                    <option value="10">October</option>
                                                    <option value="11">November</option>
                                                    <option value="12">December</option>
                                                </select>
                                                <small class="form-text text-muted">Leave empty for all months</small>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="due_session" class="form-label">Due Session <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control" id="due_session" name="due_session" required placeholder="e.g., 2024-2025">
                                                <div class="invalid-feedback">Please enter a due session.</div>
                                            </div>
                                            <div class="col-12">
                                                <label for="reason_add" class="form-label">Reason for Pending Fee</label>
                                                <textarea class="form-control" id="reason_add" name="reason_add" rows="3" placeholder="Enter reason for pending fee..."></textarea>
                                            </div>
                                        </div>

                                        <!-- Pending Fee Preview -->
                                        <div class="pending-preview" id="pending_preview" style="display: none;">
                                            <h6><i class="fas fa-calculator"></i> Pending Fee Preview</h6>
                                            <div class="row">
                                                <div class="col-6"><strong>Pending Amount:</strong></div>
                                                <div class="col-6" id="preview_pending">₹0.00</div>
                                            </div>
                                            <div class="row">
                                                <div class="col-6"><strong>Due Months:</strong></div>
                                                <div class="col-6" id="preview_months">All</div>
                                            </div>
                                            <div class="row">
                                                <div class="col-6"><strong>Due Session:</strong></div>
                                                <div class="col-6" id="preview_session">-</div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button id="btn-add-pending" class="btn btn-primary">
                                        <i class="fas fa-spinner fa-spin" style="display: none;"></i>
                                        <span class="btn-text">Add Pending Fee</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Edit Pending Fee Modal -->
                    <div class="modal fade" id="editPendingFeesModal" tabindex="-1" aria-labelledby="editPendingFeesModalTitle">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editPendingFeesModalTitle">Edit Pending Fee</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form id="editPendingFeesForm" class="needs-validation" novalidate>
                                        <input type="hidden" id="edit_pending_id">
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label for="edit_student_name" class="form-label">Student</label>
                                                <input type="text" class="form-control" id="edit_student_name" readonly>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="edit_particular_name" class="form-label">Particular</label>
                                                <input type="text" class="form-control" id="edit_particular_name" readonly>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="edit_pending_amount" class="form-label">Pending Amount <span class="text-danger">*</span></label>
                                                <input type="number" step="0.01" class="form-control" id="edit_pending_amount" name="edit_pending_amount" required>
                                                <div class="invalid-feedback">Please enter a pending amount.</div>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="edit_due_session" class="form-label">Due Session <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control" id="edit_due_session" name="edit_due_session" required>
                                                <div class="invalid-feedback">Please enter a due session.</div>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="edit_due_months" class="form-label">Due Months</label>
                                                <select class="form-control" id="edit_due_months" name="edit_due_months" multiple>
                                                    <option value="1">January</option>
                                                    <option value="2">February</option>
                                                    <option value="3">March</option>
                                                    <option value="4">April</option>
                                                    <option value="5">May</option>
                                                    <option value="6">June</option>
                                                    <option value="7">July</option>
                                                    <option value="8">August</option>
                                                    <option value="9">September</option>
                                                    <option value="10">October</option>
                                                    <option value="11">November</option>
                                                    <option value="12">December</option>
                                                </select>
                                                <small class="form-text text-muted">Leave empty for all months</small>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="edit_status" class="form-label">Status <span class="text-danger">*</span></label>
                                                <select class="form-select" id="edit_status" name="edit_status" required>
                                                    <option value="pending">Pending</option>
                                                    <option value="partially_paid">Partially Paid</option>
                                                    <option value="fully_paid">Fully Paid</option>
                                                </select>
                                                <div class="invalid-feedback">Please select a status.</div>
                                            </div>
                                            <div class="col-12">
                                                <label for="edit_reason" class="form-label">Reason for Pending Fee</label>
                                                <textarea class="form-control" id="edit_reason" name="edit_reason" rows="3"></textarea>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button id="btn-update-pending" class="btn btn-primary">
                                        <i class="fas fa-spinner fa-spin" style="display: none;"></i>
                                        <span class="btn-text">Update Pending Fee</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="dark-transparent sidebartoggler"></div>
    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>

    <script>
        $(document).ready(function() {
            // Initialize Select2 only once
            const select2Config = {
                theme: 'bootstrap-5',
                placeholder: 'Select an option',
                allowClear: true
            };
            $('#student_info_add').select2({ ...select2Config, dropdownParent: $('#addPendingFeesModal') });
            $('#particular_add').select2({ ...select2Config, dropdownParent: $('#addPendingFeesModal') });
            $('#due_months_add').select2({ ...select2Config, dropdownParent: $('#addPendingFeesModal') });
            $('#edit_due_months').select2({ ...select2Config, dropdownParent: $('#editPendingFeesModal') });

            // Initialize DataTable
            let pendingFeesTable = $('#pending_fees_table').DataTable({
                responsive: true,
                pageLength: 25,
                dom: 'Bfrtip',
                buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
                order: [[7, 'desc']],
                columnDefs: [{ targets: [8], orderable: false }]
            });

            // Cache for students and particulars
            const studentCache = {};
            const particularCache = {};

            // Debounce function
            function debounce(func, wait) {
                let timeout;
                return function executedFunction(...args) {
                    const later = () => {
                        clearTimeout(timeout);
                        func(...args);
                    };
                    clearTimeout(timeout);
                    timeout = setTimeout(later, wait);
                };
            }

            // Handle modal show/hide
            $('#addPendingFeesModal, #editPendingFeesModal').on('show.bs.modal', function() {
                $('#main-wrapper').removeAttr('aria-hidden');
            }).on('hidden.bs.modal', function() {
                $('#main-wrapper').removeAttr('aria-hidden');
                $('#addPendingFeesForm')[0].reset();
                $('#editPendingFeesForm')[0].reset();
                $('#student_info_add, #particular_add, #due_months_add, #edit_due_months').val(null).trigger('change');
                $('#student_info_add, #particular_add').prop('disabled', true).html('<option value="">Select Student/Particular</option>');
                $('#pending_amount, #due_session').val('');
                $('#pending_preview').hide();
            });

            // Load initial data
            loadClasses();
            loadParticulars();
            loadPendingFees();

            // Load classes
            function loadClasses() {
                $.ajax({
                    url: 'api/class_master.php',
                    method: 'GET',
                    data: { perPage: 100, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Classes response:', response);
                        if (response && response.data && Array.isArray(response.data)) {
                            let options = '<option value="">Select Class</option>';
                            response.data.forEach(function(item) {
                                options += `<option value="${item.id}">${item.class_name}</option>`;
                            });
                            $('#student_class_add, #filter_class').html(options).trigger('change');
                        } else {
                            console.warn('No classes found or invalid response:', response);
                            Swal.fire('Warning', 'No active classes found', 'warning');
                            $('#student_class_add, #filter_class').html('<option value="">No Classes Available</option>');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Classes load error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to load classes', 'error');
                        $('#student_class_add, #filter_class').html('<option value="">No Classes Available</option>');
                    }
                });
            }

            // Load particulars for filter
            function loadParticulars() {
                if (particularCache['all']) {
                    updateParticularsSelect(particularCache['all'], '#filter_particular');
                    return;
                }
                $.ajax({
                    url: 'api/particulars_master.php',
                    method: 'GET',
                    data: { status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Particulars response:', response);
                        if (response && response.data && Array.isArray(response.data)) {
                            particularCache['all'] = response.data;
                            updateParticularsSelect(response.data, '#filter_particular');
                        } else {
                            console.warn('No particulars found or invalid response:', response);
                            Swal.fire('Warning', 'No particulars found', 'warning');
                            $('#filter_particular').html('<option value="">No Particulars Available</option>');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Particulars load error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to load particulars', 'error');
                        $('#filter_particular').html('<option value="">No Particulars Available</option>');
                    }
                });
            }

            // Update particulars select
            function updateParticularsSelect(data, selector) {
                let options = '<option value="">Select Particular</option>';
                data.forEach(function(item) {
                    options += `<option value="${item.id}">${item.particular}</option>`;
                });
                $(selector).html(options).trigger('change');
                if (selector === '#particular_add') {
                    $(selector).prop('disabled', false);
                }
            }

            // Load students for selected class
            function loadStudents(classId) {
                if (studentCache[classId]) {
                    updateStudentsSelect(studentCache[classId]);
                    return;
                }
                $.ajax({
                    url: `api/student_api.php?action=list_all&personal_class=${classId}`,
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        console.log('Students response:', response);
                        if (response && response.status === 'success' && Array.isArray(response.data)) {
                            studentCache[classId] = response.data;
                            updateStudentsSelect(response.data);
                        } else {
                            console.warn('No students found or invalid response:', response);
                            Swal.fire('Warning', 'No students found for this class', 'warning');
                            $('#student_info_add').prop('disabled', true).html('<option value="">No Students Available</option>');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Students load error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to load students', 'error');
                        $('#student_info_add').prop('disabled', true).html('<option value="">No Students Available</option>');
                    }
                });
            }

            // Update students select
            function updateStudentsSelect(data) {
                let options = '<option value="">Select Student</option>';
                data.forEach(function(student) {
                    options += `<option value="${student.id}">${student.full_name} (${student.father_name})</option>`;
                });
                $('#student_info_add').html(options).prop('disabled', false).trigger('change');
            }

            // Load particulars for selected class
            function loadClassParticulars(classId) {
                if (particularCache['all']) {
                    updateParticularsSelect(particularCache['all'], '#particular_add');
                    return;
                }
                $.ajax({
                    url: `api/particulars_master.php`,
                    method: 'GET',
                    data: { status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Class particulars response:', response);
                        if (response && response.data && Array.isArray(response.data)) {
                            particularCache['all'] = response.data;
                            updateParticularsSelect(response.data, '#particular_add');
                        } else {
                            console.warn('No particulars found for class or invalid response:', response);
                            Swal.fire('Warning', 'No particulars found', 'warning');
                            $('#particular_add').prop('disabled', true).html('<option value="">No Particulars Available</option>');
                            $('#pending_amount, #due_session').val('');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Class particulars load error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to load particulars for class', 'error');
                        $('#particular_add').prop('disabled', true).html('<option value="">No Particulars Available</option>');
                        $('#pending_amount, #due_session').val('');
                    }
                });
            }

            // Debounced class change handler
            const debouncedClassChange = debounce(function(classId) {
                if (classId) {
                    loadStudents(classId);
                    loadClassParticulars(classId);
                } else {
                    $('#student_info_add, #particular_add').prop('disabled', true).html('<option value="">Select Student/Particular</option>').val(null).trigger('change');
                    $('#pending_amount, #due_session').val('');
                }
            }, 300);

            // Class change event
            $('#student_class_add').change(function() {
                debouncedClassChange($(this).val());
            });

            // Update preview
            $('#pending_amount, #due_months_add, #due_session').on('input change', function() {
                updatePendingPreview();
            });

            // Update pending fee preview
            function updatePendingPreview() {
                const pendingAmount = parseFloat($('#pending_amount').val()) || 0;
                const dueMonths = $('#due_months_add').val();
                const dueSession = $('#due_session').val();

                if (pendingAmount > 0) {
                    $('#preview_pending').text('₹' + pendingAmount.toFixed(2));
                    $('#preview_months').text(dueMonths.length > 0 ? dueMonths.map(m => ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][m-1]).join(', ') : 'All');
                    $('#preview_session').text(dueSession || '-');
                    $('#pending_preview').show();
                } else {
                    $('#pending_preview').hide();
                }
            }

            // Load pending fees
            function loadPendingFees() {
                const classFilter = $('#filter_class').val();
                const particularFilter = $('#filter_particular').val();
                const statusFilter = $('#filter_status').val();
                
                $.ajax({
                    url: 'api/pending_fees_master.php',
                    method: 'GET',
                    data: {
                        class_id: classFilter,
                        particular_id: particularFilter,
                        status: statusFilter
                    },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Pending fees response:', response);
                        if (response && response.status === 'success') {
                            updatePendingFeesTable(response.data || []);
                        } else {
                            console.warn('Invalid pending fees response:', response);
                            updatePendingFeesTable([]);
                            Swal.fire('Warning', response?.message || 'No pending fees found', 'warning');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Pending fees load error:', xhr.responseText);
                        updatePendingFeesTable([]);
                        Swal.fire('Error', 'Failed to load pending fees', 'error');
                    }
                });
            }

            // Update pending fees table
            function updatePendingFeesTable(data) {
                pendingFeesTable.clear();
                
                if (!Array.isArray(data) || data.length === 0) {
                    pendingFeesTable.draw();
                    return;
                }

                data.forEach(function(fee) {
                    const statusBadge = fee.status === 'pending' 
                        ? '<span class="badge bg-warning">Pending</span>'
                        : fee.status === 'partially_paid' 
                        ? '<span class="badge bg-info">Partially Paid</span>'
                        : '<span class="badge bg-success">Fully Paid</span>';

                    const pendingAmount = fee.pending_amount != null 
                        ? '₹' + parseFloat(fee.pending_amount).toFixed(2)
                        : 'N/A';

                    const dueMonths = fee.due_months && fee.due_months !== 'all' 
                        ? fee.due_months.split(',').map(m => ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][parseInt(m)-1]).join(', ')
                        : 'All';

                    const createdOn = fee.created_on 
                        ? new Date(fee.created_on).toLocaleDateString()
                        : 'N/A';

                    const actions = `
                        <div class="btn-group btn-group-sm" role="group">
                            <button class="btn btn-outline-primary btn-edit" data-id="${fee.id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-outline-danger btn-delete" data-id="${fee.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    `;

                    pendingFeesTable.row.add([
                        fee.student_name || 'N/A',
                        fee.class_name || 'N/A',
                        fee.particular || 'N/A',
                        pendingAmount,
                        dueMonths,
                        fee.due_session || 'N/A',
                        statusBadge,
                        createdOn,
                        actions
                    ]);
                });
                
                pendingFeesTable.draw();
            }

            // Add pending fee
            $('#btn-add-pending').click(function() {
                if (!$('#addPendingFeesForm')[0].checkValidity()) {
                    $('#addPendingFeesForm')[0].reportValidity();
                    return;
                }

                const formData = {
                    student_id: $('#student_info_add').val(),
                    particular_id: $('#particular_add').val(),
                    pending_amount: $('#pending_amount').val(),
                    due_months: $('#due_months_add').val(),
                    due_session: $('#due_session').val(),
                    reason: $('#reason_add').val()
                };

                $(this).prop('disabled', true).find('.fa-spinner').show();

                $.ajax({
                    url: 'api/pending_fees_master.php',
                    method: 'POST',
                    data: JSON.stringify(formData),
                    contentType: 'application/json',
                    dataType: 'json',
                    success: function(response) {
                        console.log('Add pending fee response:', response);
                        if (response.status === 'success') {
                            Swal.fire('Success', response.message, 'success');
                            $('#addPendingFeesModal').modal('hide');
                            loadPendingFees();
                        } else {
                            Swal.fire('Error', response.message || 'Failed to add pending fee', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Add pending fee error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to add pending fee', 'error');
                    },
                    complete: function() {
                        $('#btn-add-pending').prop('disabled', false).find('.fa-spinner').hide();
                    }
                });
            });

            // Edit pending fee
            $(document).on('click', '.btn-edit', function() {
                const pendingId = $(this).data('id');
                
                $.ajax({
                    url: `api/pending_fees_master.php?id=${pendingId}`,
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        console.log('Edit pending fee response:', response);
                        if (response && response.status === 'success' && response.data) {
                            const fee = response.data;
                            $('#edit_pending_id').val(fee.id);
                            $('#edit_student_name').val(fee.student_name || '');
                            $('#edit_particular_name').val(fee.particular || '');
                            $('#edit_pending_amount').val(fee.pending_amount != null ? parseFloat(fee.pending_amount).toFixed(2) : '');
                            $('#edit_due_session').val(fee.due_session || '');
                            $('#edit_status').val(fee.status || 'pending');
                            $('#edit_reason').val(fee.reason || '');
                            const dueMonths = fee.due_months && fee.due_months !== 'all' ? fee.due_months.split(',') : [];
                            $('#edit_due_months').val(dueMonths).trigger('change');
                            
                            $('#editPendingFeesModal').modal('show');
                        } else {
                            Swal.fire('Error', response?.message || 'Invalid pending fee data', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Edit pending fee error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to load pending fee details', 'error');
                    }
                });
            });

            // Update pending fee
            $('#btn-update-pending').click(function() {
                if (!$('#editPendingFeesForm')[0].checkValidity()) {
                    $('#editPendingFeesForm')[0].reportValidity();
                    return;
                }

                const formData = {
                    id: $('#edit_pending_id').val(),
                    pending_amount: $('#edit_pending_amount').val(),
                    due_months: $('#edit_due_months').val(),
                    due_session: $('#edit_due_session').val(),
                    status: $('#edit_status').val(),
                    reason: $('#edit_reason').val()
                };

                $(this).prop('disabled', true).find('.fa-spinner').show();

                $.ajax({
                    url: 'api/pending_fees_master.php',
                    method: 'PUT',
                    data: JSON.stringify(formData),
                    contentType: 'application/json',
                    dataType: 'json',
                    success: function(response) {
                        console.log('Update pending fee response:', response);
                        if (response.status === 'success') {
                            Swal.fire('Success', response.message, 'success');
                            $('#editPendingFeesModal').modal('hide');
                            loadPendingFees();
                        } else {
                            Swal.fire('Error', response.message || 'Failed to update pending fee', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Update pending fee error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to update pending fee', 'error');
                    },
                    complete: function() {
                        $('#btn-update-pending').prop('disabled', false).find('.fa-spinner').hide();
                    }
                });
            });

            // Delete pending fee
            $(document).on('click', '.btn-delete', function() {
                const pendingId = $(this).data('id');
                
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'This will permanently delete the pending fee!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: `api/pending_fees_master.php?id=${pendingId}`,
                            method: 'DELETE',
                            dataType: 'json',
                            success: function(response) {
                                console.log('Delete pending fee response:', response);
                                if (response.status === 'success') {
                                    Swal.fire('Deleted!', response.message, 'success');
                                    loadPendingFees();
                                } else {
                                    Swal.fire('Error', response.message || 'Failed to delete pending fee', 'error');
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error('Delete pending fee error:', xhr.responseText);
                                Swal.fire('Error', 'Failed to delete pending fee', 'error');
                            }
                        });
                    }
                });
            });

            // Filter functionality
            $('#filter_class, #filter_particular, #filter_status').change(function() {
                loadPendingFees();
            });
        });
    </script>
</body>
</html>