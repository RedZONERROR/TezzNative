<?php
session_start();
include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');
$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Demand Slip Generation - AI-ERP 2.0</title>
    <style>
        .btn-loading .spinner-border { display: inline-block; }
        .spinner-border { display: none; width: 1rem; height: 1rem; }
        .slip-preview-row { cursor: pointer; transition: background 0.1s; }
        .slip-preview-row:hover { background-color: #f8f9fa; }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!-- Sidebar End -->
        <div class="page-wrapper">
            <!-- Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!-- Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Generate Demand Slips</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Demand Slips
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Demand Slip Generation Form -->
                    <div class="card card-body">
                        <form id="demandSlipForm">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="class_id" class="form-label">Select Class</label>
                                    <select id="class_id" name="class_id" class="form-control" required>
                                        <option value="">Select a class</option>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="month" class="form-label">Select Current Month</label>
                                    <select id="month" name="month" class="form-control" required>
                                        <option value="4">April</option>
                                        <option value="5">May</option>
                                        <option value="6">June</option>
                                        <option value="7">July</option>
                                        <option value="8">August</option>
                                        <option value="9">September</option>
                                        <option value="10">October</option>
                                        <option value="11">November</option>
                                        <option value="12">December</option>
                                        <option value="1">January</option>
                                        <option value="2">February</option>
                                        <option value="3">March</option>
                                    </select>
                                    <small class="text-muted">Will calculate all dues up to this month</small>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="issue_date" class="form-label">Issue Date</label>
                                    <input type="date" id="issue_date" name="issue_date" class="form-control" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="due_date" class="form-label">Due Date</label>
                                    <input type="date" id="due_date" name="due_date" class="form-control" required>
                                </div>
                            </div>

                            <div class="text-end mt-4">
                                <button type="submit" class="btn btn-success px-4" id="generate-demand-slips" disabled>
                                    <i class="ti ti-file-type-pdf me-2"></i> Generate PDF
                                    <div class="spinner-border text-light btn-loading" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- Student List Preview -->
                    <div class="card">
                        <div class="card-header bg-white d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Preview Students <span id="student_count_badge" class="badge bg-primary rounded-pill ms-2">0</span></h5>
                            <input type="text" class="form-control w-25 form-control-sm" id="input-search" placeholder="Search list..." />
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Roll No</th>
                                            <th>Student's Name</th>
                                            <th>Father's Name</th>
                                            <th class="text-end">Total Due (₹)</th>
                                        </tr>
                                    </thead>
                                    <tbody id="student_list_table_body">
                                        <tr><td colspan="4" class="text-center py-4 text-muted">Select class and month to view details</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="../assets/js/vendor.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>

    <script>
        $(document).ready(function() {
            let GLOBAL_SLIP_DATA = []; // Stores the calculated data from API
            let SCHOOL_SETTINGS = {};

            // 1. Load classes
            function loadClasses() {
                $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { status: 'active', perPage: 100 },
                    dataType: 'json',
                    success: function(response) {
                        const classes = response.data || [];
                        $('#class_id').empty().append('<option value="">Select a class</option>');
                        classes.forEach(cls => {
                            $('#class_id').append(`<option value="${cls.id}">${cls.class_name}</option>`);
                        });
                    }
                });
            }

            // 2. Load Student Data
            function loadStudentPreview() {
                const classId = $('#class_id').val();
                const month = $('#month').val();

                if (!classId || !month) {
                    $('#student_list_table_body').html('<tr><td colspan="4" class="text-center py-4 text-muted">Select class and month</td></tr>');
                    $('#student_count_badge').text('0');
                    $('#generate-demand-slips').prop('disabled', true);
                    GLOBAL_SLIP_DATA = [];
                    return;
                }

                $('#student_list_table_body').html('<tr><td colspan="4" class="text-center py-4"><div class="spinner-border text-primary display-inline-block"></div> Calculating dues up to selected month...</td></tr>');

                $.ajax({
                    url: 'api/demand_slip_api.php?action=fetch',
                    type: 'POST',
                    data: { class_id: classId, month: month },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            GLOBAL_SLIP_DATA = response.data || [];
                            SCHOOL_SETTINGS = response.school || {};
                            renderTable(GLOBAL_SLIP_DATA);
                        } else {
                            Swal.fire('Error', response.message, 'error');
                            $('#student_list_table_body').empty();
                        }
                    },
                    error: function() {
                        $('#student_list_table_body').html('<tr><td colspan="4" class="text-center text-danger py-4">Failed to load data.</td></tr>');
                    }
                });
            }

            function renderTable(data) {
                const tbody = $('#student_list_table_body');
                tbody.empty();
                $('#student_count_badge').text(data.length);

                if (data.length === 0) {
                    tbody.html('<tr><td colspan="4" class="text-center py-4 text-success">No pending dues found up to selected month.</td></tr>');
                    $('#generate-demand-slips').prop('disabled', true);
                    return;
                }

                $('#generate-demand-slips').prop('disabled', false);

                data.forEach(student => {
                    tbody.append(`
                        <tr class="slip-preview-row">
                            <td>${student.roll_no || '-'}</td>
                            <td class="fw-bold">${student.student_name}</td>
                            <td>${student.father_name}</td>
                            <td class="text-end fw-bold text-danger">₹${parseFloat(student.total_amount).toFixed(2)}</td>
                        </tr>
                    `);
                });
            }

            // Listeners
            $('#class_id, #month').on('change', loadStudentPreview);

            // 3. Search Filter (Client Side)
            $('#input-search').on('input', function() {
                const term = $(this).val().toLowerCase();
                const filtered = GLOBAL_SLIP_DATA.filter(s => 
                    s.student_name.toLowerCase().includes(term) || 
                    s.father_name.toLowerCase().includes(term) ||
                    (s.roll_no && s.roll_no.toString().includes(term))
                );
                renderTable(filtered);
            });

            // 4. Generate PDF
            $('#demandSlipForm').on('submit', function(e) {
                e.preventDefault();
                
                if (GLOBAL_SLIP_DATA.length === 0) {
                    Swal.fire('Warning', 'No student data to generate.', 'warning');
                    return;
                }

                const issueDate = $('#issue_date').val();
                const dueDate = $('#due_date').val();

                // Inject dates into the global data objects
                const pdfData = GLOBAL_SLIP_DATA.map(slip => ({
                    ...slip,
                    issue_date: issueDate,
                    due_date: dueDate
                }));

                generatePDF(pdfData, SCHOOL_SETTINGS);
            });

            function generatePDF(demandSlips, schoolSettings) {
                // Group slips into sets of 6 for 2x3 Grid
                const slipGroups = [];
                for (let i = 0; i < demandSlips.length; i += 6) {
                    slipGroups.push(demandSlips.slice(i, i + 6));
                }

                let htmlContent = `
                    <!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="UTF-8">
                        <title>School Demand Slip</title>
                        <style>
                            * { margin: 0; padding: 0; box-sizing: border-box; }
                            @page { size: A4; margin: 10mm; }
                            body { font-family: 'Arial', sans-serif; font-size: 10px; line-height: 1.2; color: #333; background: white; }
                            
                            /* 2 Columns x 3 Rows Grid */
                            .page-container { 
                                width: 190mm; 
                                height: 277mm; 
                                display: grid; 
                                grid-template-columns: 1fr 1fr; /* 2 Columns */
                                grid-template-rows: 1fr 1fr 1fr; /* 3 Rows */
                                gap: 5mm; 
                                margin: 0 auto; 
                                page-break-after: always; 
                            }
                            .page-container:last-child { page-break-after: auto; }
                            
                            /* Adjusted for ~90mm height to fit 3 rows */
                            .demand-slip { 
                                border: 2px solid #2563eb; 
                                border-radius: 4px; 
                                padding: 5px; 
                                background: white; 
                                position: relative; 
                                height: 88mm; /* Reduced height for 3 rows */
                                overflow: hidden;
                            }
                            
                            .slip-header { text-align: center; border-bottom: 2px solid #2563eb; margin: -5px -5px 4px -5px; padding: 4px; background: #f1f5f9; }
                            .school-name { font-size: 11px; font-weight: bold; color: #1e40af; margin-bottom: 1px; text-transform: uppercase; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
                            .school-address { font-size: 7px; color: #64748b; margin-bottom: 2px; }
                            .slip-title { font-size: 9px; font-weight: bold; color: #dc2626; background: #fef2f2; padding: 1px 6px; border-radius: 8px; display: inline-block; border: 1px solid #fecaca; }
                            .slip-number { position: absolute; top: 4px; right: 4px; background: #2563eb; color: white; padding: 1px 4px; border-radius: 3px; font-size: 7px; font-weight: bold; }
                            
                            .form-section { margin-bottom: 2px; }
                            .form-row { display: flex; margin-bottom: 2px; align-items: center; }
                            .form-row.two-col { justify-content: space-between; }
                            .form-field { display: flex; align-items: center; flex: 1; }
                            .form-field.half { flex: 0 0 48%; }
                            .form-label { font-weight: bold; color: #374151; margin-right: 3px; min-width: fit-content; font-size: 9px; }
                            .form-input { border-bottom: 1px solid #9ca3af; flex: 1; padding: 0 3px; height: 12px; margin-left: 2px; font-weight: 600; font-size: 9px; white-space: nowrap; overflow: hidden; }
                            
                            .items-table { width: 100%; border-collapse: collapse; margin: 3px 0; font-size: 8px; }
                            .items-table th { background: #f8fafc; border: 1px solid #cbd5e1; padding: 2px; text-align: left; font-weight: bold; color: #475569; }
                            .items-table td { border: 1px solid #cbd5e1; padding: 2px; height: 14px; }
                            .items-table .amount-col { text-align: right; width: 45px; }
                            
                            .total-section { background: #fffbeb; border: 1px solid #fcd34d; border-radius: 4px; padding: 2px 6px; margin: 3px 0; }
                            .total-row { display: flex; justify-content: space-between; align-items: center; font-weight: bold; color: #92400e; font-size: 9px; }
                            .total-amount { font-size: 11px; color: #dc2626; }
                            
                            .footer-note { position: absolute; bottom: 4px; left: 4px; right: 4px; font-size: 6px; color: #6b7280; text-align: center; border-top: 1px dashed #e5e7eb; padding-top: 2px; }
                            
                            @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
                        </style>
                    </head>
                    <body>`;

                slipGroups.forEach((group, pageIndex) => {
                    htmlContent += `<div class="page-container">`;
                    group.forEach((slip, index) => {
                        const slipNumber = `DS-${(pageIndex * 6 + index + 1).toString().padStart(3, '0')}`;
                        
                        // Generate Fee Rows
                        const feeRows = slip.fees.map(fee => `
                            <tr>
                                <td>${fee.description}</td>
                                <td style="text-align:center;">${fee.qty}</td>
                                <td class="amount-col">${fee.amount.toFixed(2)}</td>
                            </tr>
                        `).join('');

                        // Limit rows to prevent overflow in 90mm height (approx 4 rows max)
                        const emptyRows = Array.from({length: Math.max(0, 4 - slip.fees.length)}).map(() => `
                            <tr><td></td><td></td><td class="amount-col"></td></tr>
                        `).join('');

                        htmlContent += `
                            <div class="demand-slip">
                                <div class="slip-number">${slipNumber}</div>
                                <div class="slip-header">
                                    <div class="school-name">${schoolSettings.school_name}</div>
                                    <div class="school-address">${schoolSettings.address} | ${schoolSettings.phone}</div>
                                    <div class="slip-title">DEMAND SLIP</div>
                                </div>
                                <div class="form-section">
                                    <div class="form-row">
                                        <div class="form-field">
                                            <span class="form-label">Name:</span>
                                            <div class="form-input">${slip.student_name}</div>
                                        </div>
                                    </div>
                                    <div class="form-row two-col">
                                        <div class="form-field half">
                                            <span class="form-label">Class:</span>
                                            <div class="form-input">${slip.class_name}</div>
                                        </div>
                                        <div class="form-field half">
                                            <span class="form-label">Roll:</span>
                                            <div class="form-input">${slip.roll_no || ''}</div>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-field">
                                            <span class="form-label">Father:</span>
                                            <div class="form-input">${slip.father_name}</div>
                                        </div>
                                    </div>
                                </div>
                                <table class="items-table">
                                    <thead>
                                        <tr>
                                            <th>Description</th>
                                            <th style="width:25px; text-align:center;">Qty</th>
                                            <th class="amount-col">Amt(₹)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${feeRows}
                                        ${emptyRows}
                                    </tbody>
                                </table>
                                <div class="total-section">
                                    <div class="total-row">
                                        <span>TOTAL:</span>
                                        <span class="total-amount">₹ ${parseFloat(slip.total_amount).toFixed(2)}</span>
                                    </div>
                                </div>
                                <div class="form-row two-col">
                                    <div class="form-field half">
                                        <span class="form-label">Issue:</span>
                                        <div class="form-input">${new Date(slip.issue_date).toLocaleDateString('en-GB')}</div>
                                    </div>
                                    <div class="form-field half">
                                        <span class="form-label">Due:</span>
                                        <div class="form-input">${new Date(slip.due_date).toLocaleDateString('en-GB')}</div>
                                    </div>
                                </div>
                                <div class="footer-note">
                                    Please pay before due date to avoid late fees. Computer generated slip.
                                </div>
                            </div>
                        `;
                    });
                    htmlContent += `</div>`;
                });

                htmlContent += `</body></html>`;

                const popup = window.open('', 'DemandSlipPDF', 'width=1000,height=800');
                if(popup) {
                    popup.document.write(htmlContent);
                    popup.document.close();
                    popup.focus();
                } else {
                    Swal.fire('Error', 'Popup blocked. Please allow popups.', 'error');
                }
            }

            // Init
            loadClasses();
            const d = new Date();
            $('#month').val(d.getMonth() + 1); // Auto select current month
            
            const today = new Date().toISOString().split('T')[0];
            const due = new Date(); due.setDate(due.getDate() + 7);
            $('#issue_date').val(today);
            $('#due_date').val(due.toISOString().split('T')[0]);
        });
    </script>
</body>
</html>