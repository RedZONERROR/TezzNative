<?php
header('Content-Type: application/json');
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Helper to get month name
function getMonthName($m) {
    return date("F", mktime(0, 0, 0, $m, 10));
}

$action = $_GET['action'] ?? 'fetch';

if ($action === 'fetch' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo = getDBConnection();
        $class_id = $_POST['class_id'] ?? null;
        $current_month_input = $_POST['month'] ?? null; // Single month input
        
        if (!$class_id) {
            throw new Exception("Class ID is required");
        }
        if (!$current_month_input) {
            throw new Exception("Current Month must be selected");
        }

        $current_month_input = intval($current_month_input);

        // 1. Determine Session (Assuming April Start)
        $current_year = date('Y');
        $current_month_real = date('n');
        $session_start = ($current_month_real < 4) ? ($current_year - 1) : $current_year;
        $session = $session_start . '-' . ($session_start + 1);

        // 2. Fetch School Settings
        $settings = $pdo->query("SELECT school_name, address, phone FROM site_settings LIMIT 1")->fetch(PDO::FETCH_ASSOC);
        if (!$settings) {
            $settings = [
                'school_name' => 'School Name',
                'address' => 'Address',
                'phone' => 'Phone'
            ];
        }

        // 3. Fetch Students
        $stmt = $pdo->prepare("SELECT id, full_name, father_name, roll_no, transport_id, uid FROM students WHERE class = ? AND status = 'active' ORDER BY roll_no ASC");
        $stmt->execute([$class_id]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 4. Class Info
        $stmt = $pdo->prepare("SELECT class_name FROM class WHERE id = ?");
        $stmt->execute([$class_id]);
        $class_info = $stmt->fetch(PDO::FETCH_ASSOC);
        $class_name = $class_info['class_name'] ?? '';

        // 5. Fee Structure (Monthly)
        $stmt = $pdo->prepare("SELECT amount FROM fee_structure WHERE class_id = ? AND frequency = 'monthly' AND session = ?");
        $stmt->execute([$class_id, $session]);
        $monthly_fees = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $base_academic_monthly = array_sum($monthly_fees);

        $demand_slips = [];
        
        // Standard Academic Year Order (April to March)
        $SESSION_MONTH_ORDER = [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3];
        
        // Determine which months to check (Accumulate from April up to Current Month)
        $target_months = [];
        foreach ($SESSION_MONTH_ORDER as $m) {
            $target_months[] = $m;
            if ($m == $current_month_input) {
                break; // Stop collecting months once we hit the selected current month
            }
        }

        foreach ($students as $student) {
            $student_id = $student['id'];
            $student_uid = $student['uid'];
            $transport_id = $student['transport_id'];

            // A. Transport Fee
            $transport_monthly = 0;
            if ($transport_id) {
                 $stmt = $pdo->prepare("SELECT transport_fees FROM transport WHERE id = ? AND session = ?");
                 $stmt->execute([$transport_id, $session]);
                 $transport_monthly = $stmt->fetchColumn() ?: 0;
            }

            // B. Special Structure (Discounts)
            $stmt = $pdo->prepare("SELECT special_amount FROM special_structure WHERE student_uid = ? AND status = 'active'");
            $stmt->execute([$student_uid]);
            $special_adjustments = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $total_discount_monthly = array_sum($special_adjustments);

            // Net Monthly Fee Calculation
            $net_monthly_fee = max(0, $base_academic_monthly + $transport_monthly - $total_discount_monthly);

            // C. Fetch Payments (Current Session)
            $stmt = $pdo->prepare("SELECT id, amount_collected, discount, payment_month FROM fee_collections WHERE student_id = ? AND session = ?");
            $stmt->execute([$student_id, $session]);
            $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // D. Fetch Pending Fees (Previous Session)
            $stmt = $pdo->prepare("SELECT id, pending_amount, status, collection_id, particular_id, (SELECT particular FROM particulars WHERE id = pending_fees.particular_id) as particular_name FROM pending_fees WHERE student_uid = ?");
            $stmt->execute([$student_uid]);
            $pending_rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $pending_collection_ids = [];
            foreach($pending_rows as $pr) {
                if ($pr['collection_id']) {
                    $pending_collection_ids[] = $pr['collection_id'];
                }
            }

            // E. Calculate Available Funds (Waterfall Pool)
            $total_paid_available = 0;
            foreach ($payments as $p) {
                 if (in_array($p['id'], $pending_collection_ids) || $p['payment_month'] == '0') {
                     continue;
                 }
                 $total_paid_available += ($p['amount_collected'] + $p['discount']);
            }

            // F. Determine Unpaid Months (Waterfall Logic) for ALL months in session
            $cumulative_fee = 0;
            $unpaid_months_data = [];

            foreach ($SESSION_MONTH_ORDER as $m_id) {
                $month_cost = $net_monthly_fee;
                $cumulative_fee += $month_cost;
                
                $prev_cost = $cumulative_fee - $month_cost;
                $paid_here = max(0, min($month_cost, $total_paid_available - $prev_cost));
                $due = $month_cost - $paid_here;

                if ($due > 0.01) {
                    $unpaid_months_data[$m_id] = $due;
                }
            }

            // G. Build Demand Slip Items (Pending + Target Months)
            $slip_items = [];
            $total_slip_amount = 0;

            // 1. Add Pending Fees (Previous Session)
            foreach ($pending_rows as $pr) {
                if ($pr['status'] === 'pending' && $pr['pending_amount'] > 0) {
                    $item_amount = floatval($pr['pending_amount']);
                    $slip_items[] = [
                        'description' => ($pr['particular_name'] ?: 'Pending Fee') . ' (Prev. Session)',
                        'qty' => 1,
                        'amount' => $item_amount
                    ];
                    $total_slip_amount += $item_amount;
                }
            }

            // 2. Add Monthly Fees (Only if they fall within our target range: April -> Current Month)
            foreach ($target_months as $tm) {
                if (isset($unpaid_months_data[$tm])) {
                    $amount = $unpaid_months_data[$tm];
                    $slip_items[] = [
                        'description' => 'Tuition & Transport (' . getMonthName($tm) . ')',
                        'qty' => 1,
                        'amount' => floatval($amount)
                    ];
                    $total_slip_amount += $amount;
                }
            }

            if ($total_slip_amount > 0) {
                $demand_slips[] = [
                    'student_id' => $student_id,
                    'student_name' => $student['full_name'],
                    'father_name' => $student['father_name'],
                    'class_name' => $class_name,
                    'roll_no' => $student['roll_no'],
                    'fees' => $slip_items,
                    'total_amount' => $total_slip_amount
                ];
            }
        }

        echo json_encode([
            'status' => 'success', 
            'school' => $settings, 
            'data' => $demand_slips
        ]);

    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
    exit;
}
?>