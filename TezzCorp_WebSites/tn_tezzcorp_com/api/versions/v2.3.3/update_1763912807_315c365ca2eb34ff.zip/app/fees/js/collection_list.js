// js/collection_list.js
$(document).ready(function () {
    let allStudents = [];
    let filteredStudents = [];

    loadClasses();

    $("#class_id").on("change", filterStudents);
    $("#search_student").on("input", filterStudents);

    function loadClasses() {
        $.get("api/class_api.php", { action: "list" }, res => {
            const sel = $("#class_id");
            (res.data || []).forEach(c => sel.append(`<option value="${c.id}">${c.class_name}</option>`));
            loadAllStudents();
        });
    }

    function loadAllStudents() {
        $("#spinner").show();
        $.get("api/student_api.php", { action: "list_all" }, res => {
            if (res.status === "success") {
                allStudents = res.data || [];
                filteredStudents = allStudents;
                renderStudents();
            }
        }).always(() => $("#spinner").hide());
    }

    function filterStudents() {
        const classId = $("#class_id").val();
        const term = $("#search_student").val().toLowerCase();

        filteredStudents = allStudents.filter(s => {
            const matchesClass = !classId || s.class == classId;
            const matchesSearch = !term || 
                s.full_name.toLowerCase().includes(term) ||
                s.uid.toLowerCase().includes(term) ||
                s.father_name.toLowerCase().includes(term);
            return matchesClass && matchesSearch;
        });

        renderStudents();
    }

    function renderStudents() {
        const container = $("#students_container").empty();
        if (!filteredStudents.length) {
            container.html('<div class="col-12 text-center text-muted py-5"><p>No students found.</p></div>');
            return;
        }

        filteredStudents.forEach(s => {
            container.append(`
                <div class="col-lg-4 col-md-6 mb-3">
                    <div class="student-card">
                        <div class="student-card-header">
                            <h6>${escapeHtml(s.full_name)}</h6>
                            <span class="badge bg-primary-subtle text-primary">${s.class_name}</span>
                        </div>
                        <div class="student-card-body">
                            <div class="detail"><span>UID:</span><strong>${s.uid}</strong></div>
                            <div class="detail"><span>Father:</span><strong>${escapeHtml(s.father_name)}</strong></div>
                        </div>
                        <div class="student-card-footer">
                            <button class="btn btn-sm btn-primary collect-fee-btn" data-uid="${s.uid}">
                                <i class="fas fa-money-bill-wave"></i> Collect Fee
                            </button>
                        </div>
                    </div>
                </div>
            `);
        });

        $(".collect-fee-btn").on("click", function () {
            const uid = $(this).data("uid");
            window.location.href = `collect?uid=${uid}`;
        });
    }

    function escapeHtml(str) {
        return String(str).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
    }
});