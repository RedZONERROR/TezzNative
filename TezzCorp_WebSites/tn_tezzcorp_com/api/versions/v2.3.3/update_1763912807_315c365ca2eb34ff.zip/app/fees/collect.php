<?php
session_start();
include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');
$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

if (!isset($_GET['uid']) || empty($_GET['uid'])) {
    header("Location: collection.php");
    exit;
}

$student_url_uid = $_GET['uid'];
$pdo = getDBConnection();

// Fetch Student Basic Info
$stmt = $pdo->prepare("SELECT id, uid, full_name, father_name, class, roll_no FROM students WHERE uid = ? AND status = 'active'");
$stmt->execute([$student_url_uid]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) die("Student not found.");

$student_id = $student['id'];
$student_uid = $student['uid'];
$student_name = $student['full_name'];

$class_id = $student['class'];

$stmt = $pdo->prepare("SELECT class_name FROM class WHERE id = ? AND status = 'active'");
$stmt->execute([$class_id]);
$class = $stmt->fetch(PDO::FETCH_ASSOC);

$class_name = $class['class_name'];

$stmt = $pdo->prepare("SELECT student_photo FROM documents WHERE uid = ?");
$stmt->execute([$student_url_uid]);
$document = $stmt->fetch(PDO::FETCH_ASSOC);

$student_photo = $document['student_photo'];

// Helper for Session Dropdown
function getSessionOptions() {
    $current_year = (int)date('Y');
    $current_month = (int)date('m');
    $session_start_year = ($current_month >= 4) ? $current_year : $current_year - 1;
    $sessions = [];
    for ($i = 1; $i >= -1; $i--) {
        $start_year = $session_start_year + $i;
        $sessions[] = $start_year . '-' . ($start_year + 1);
    }
    $options = '';
    foreach ($sessions as $session) {
        $selected = ($session == ($session_start_year . '-' . ($session_start_year + 1))) ? 'selected' : '';
        $options .= "<option value=\"$session\" $selected>$session</option>";
    }
    return $options;
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">
    <title>Collect Fee - <?php echo htmlspecialchars($student_name); ?></title>
    
    <style>
        .month-row { transition: all 0.2s; border-left: 4px solid transparent; }
        .month-row.selected { background-color: #eef2ff; border-left-color: var(--bs-primary); }
        .month-row.paid { background-color: #d1e7dd; opacity: 0.7; cursor: not-allowed; }
        .month-row.partial { background-color: #fff3cd; border-left-color: var(--bs-warning); }
        .fee-input-group { max-width: 200px; }
        .calc-btn { height: 100%; border-radius: 0 5px 5px 0; }
    </style>
</head>

<body>
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    
    <input type="hidden" id="hdn_student_id" value="<?php echo $student_id; ?>">
    <input type="hidden" id="hdn_student_uid" value="<?php echo $student_uid; ?>">
    
    <div id="main-wrapper">
        <?php include 'util/sidebar.php'; ?>
        <div class="page-wrapper">
            <?php include 'util/topbar.php'; ?>
            <div class="body-wrapper">
                <div class="container-fluid pt-4">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="card shadow-sm">
                                <div class="card-body text-center">
                                    <div class="mb-3">
                                        <span class="avatar rounded-circle fs-2 p-3">
                                            <img style="width: 100px; height: 100px; border-radius: 50%;" src="/<?php echo $student_photo ?>" alt="<?php echo htmlspecialchars($student_name); ?>">
                                        </span>
                                    </div>
                                    <h5 class="card-title"><?php echo htmlspecialchars($student_name); ?></h5>
                                    <p class="text-muted"><?php echo htmlspecialchars($student['father_name']); ?></p>
                                    <div class="d-flex justify-content-center gap-2 mb-3">
                                        <span class="badge bg-light text-dark border">Class: <?php echo htmlspecialchars($class_name) ?></span>
                                        <span class="badge bg-light text-dark border">Roll: <?php echo htmlspecialchars($student['roll_no']); ?></span>
                                    </div>
                                    <hr>
                                    <div class="text-start">
                                        <label class="form-label fw-bold">Current Session</label>
                                        <select id="session_filter" class="form-select">
                                            <?php echo getSessionOptions(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="card bg-primary-subtle">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <span>Total Due (Year)</span>
                                        <strong id="widget_total_due">₹0.00</strong>
                                    </div>
                                    <div class="d-flex justify-content-between mt-2">
                                        <span>Total Paid</span>
                                        <strong id="widget_total_paid" class="text-success">₹0.00</strong>
                                    </div>
                                    <div class="d-flex justify-content-between mt-2 border-top pt-2">
                                        <span>Outstanding</span>
                                        <strong id="widget_outstanding" class="text-danger">₹0.00</strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div class="card shadow-sm">
                                <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                                    <h5 class="mb-0">Fee Collection</h5>
                                    <span class="badge bg-info">Serial Mode Active</span>
                                </div>
                                <div class="card-body">
                                    <form id="collectionForm">
                                        <div class="row g-3 mb-4 bg-light p-3 rounded border">
                                            <div class="col-md-4">
                                                <label class="form-label fw-bold">Payment Date</label>
                                                <input type="date" id="payment_date" class="form-control" value="<?php echo date('Y-m-d'); ?>">
                                            </div>
                                            <div class="col-md-4">
                                                <label class="form-label fw-bold">Payment Method</label>
                                                <select id="payment_method" class="form-select">
                                                    <option value="cash">Cash</option>
                                                    <option value="online">Online/UPI</option>
                                                    <option value="cheque">Cheque</option>
                                                    <option value="dd">DD</option>
                                                </select>
                                            </div>
                                            <div class="col-md-4" id="ref_box" style="display:none;">
                                                <label class="form-label fw-bold">Ref No / Transaction ID</label>
                                                <input type="text" id="reference_no" class="form-control" placeholder="Cheque/UPI No">
                                            </div>
                                        </div>
        
                                        <div class="row g-3 mb-4 align-items-end">
                                            <div class="col-md-6">
                                                <label class="form-label fw-bold text-primary">Received Amount (₹)</label>
                                                <div class="input-group">
                                                    <span class="input-group-text">₹</span>
                                                    <input type="number" id="received_amount" class="form-control form-control-lg fw-bold text-success" placeholder="0.00" step="0.01" min="0">
                                                    <button type="button" id="btn_calculate" class="btn btn-primary px-4"><i class="fa-solid fa-calculator"></i> Calculate</button>
                                                </div>
                                                <div class="form-text text-muted"><span style="color: green;">#</span> Enter amount and click calculate to auto-select months.</div>
                                            </div>
                                            <div class="col-md-3">
                                                 <label class="form-label">Discount (Optional)</label>
                                                 <input type="number" id="discount_amount" class="form-control" placeholder="0.00">
                                                 <div class="form-text text-muted"><span style="color: green;">#</span> Concession</div>
                                            </div>
                                            <div class="col-md-3">
                                                <label class="form-label">Remarks</label>
                                                <input type="text" id="remarks" class="form-control" placeholder="Optional">
                                                <div class="form-text text-muted"><span style="color: green;">#</span> Reason</div>
                                            </div>
                                        </div>
        
                                        <div class="table-responsive border rounded mb-3">
                                            <table class="table table-hover mb-0 align-middle">
                                                <thead>
                                                    <tr>
                                                        <th width="50">#</th>
                                                        <th>Month</th>
                                                        <th class="text-end">Fee (A+T+O)</th>
                                                        <th class="text-end">Paid</th>
                                                        <th class="text-end">Due</th>
                                                        <th width="50">Select</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="month_list_body">
                                                    <tr><td colspan="6" class="text-center py-4"><i class="fa fa-spinner fa-spin"></i> Loading Fee Structure...</td></tr>
                                                </tbody>
                                                <tfoot class="fw-bold">
                                                    <tr>
                                                        <td colspan="2" class="text-start"><span style="font-size: 11px;">A -> Academic, T -> Transport, O -> Other</span></td>
                                                        <td colspan="2" class="text-end">Total To Collect:</td>
                                                        <td class="text-end text-primary fs-5" id="lbl_final_total">₹0.00</td>
                                                        <td></td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
        
                                        <div class="d-flex justify-content-end gap-2">
                                            <button type="reset" class="btn btn-light" id="btn_reset">Reset</button>
                                            <button type="submit" class="btn btn-success px-4 py-2" id="btn_submit_fee" disabled>
                                                <i class="fa-solid fa-check-circle me-2"></i> Submit Collection
                                            </button>
                                        </div>
        
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="card shadow-sm">
                                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">Payment History</h5>
                                    <button class="btn btn-sm btn-outline-primary" id="refresh_history"><i class="fa fa-sync"></i> Refresh</button>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="history_table" class="table table-striped table-bordered w-100">
                                            <thead>
                                                <tr>
                                                    <th>Receipt No</th>
                                                    <th>Months</th>
                                                    <th>Paid Amount</th>
                                                    <th>Balance</th>
                                                    <th>Date</th>
                                                    <th>Mode</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody></tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        
                </div>
            </div>
        </div>
    </div>
    <div class="dark-transparent sidebartoggler"></div>
  
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.0/pdfmake.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script src="../assets/js/index.global.min.js"></script>
    <script src="collect.js?v=<?php echo time(); ?>"></script>
</body>
</html>