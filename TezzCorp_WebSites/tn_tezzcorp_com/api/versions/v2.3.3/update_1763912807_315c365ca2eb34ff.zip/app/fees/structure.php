<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- Select2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" />
    <!-- Select2 Bootstrap 5 Theme -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />

    <title>Fee Structure - AI-ERP 2.0</title>
    <style>
        .card {
            border-radius: 0.75rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        .table th, .table td {
            vertical-align: middle;
            padding: 0.75rem;
        }
        .table th {
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.85rem;
            color: #6c757d;
        }
        .table tbody tr:hover {
            background-color: #f8f9fa;
        }
        .badge {
            font-size: 0.8rem;
            padding: 0.4em 0.8em;
            border-radius: 0.5rem;
        }
        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.85rem;
        }
        .btn i {
            font-size: 1rem;
        }
        .btn:hover i {
            transform: scale(1.1);
            transition: transform 0.2s ease;
        }
        .action-buttons {
            display: none;
        }
        .btn-loading .fa-spinner {
            display: inline-block;
        }
        .btn-loading .btn-text, .btn-loading .ti {
            display: none;
        }
        .fa-spinner {
            display: none;
            font-size: 0.9rem;
        }
        .table-loader {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        .table-container {
            position: relative;
        }
        .pagination {
            margin-top: 1rem;
        }
        .form-control:focus {
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.1);
            border-color: #007bff;
        }
        .modal-content {
            border-radius: 0.75rem;
        }
        .modal-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        .select2-container--default .select2-selection--multiple {
            border: 1px solid #ced4da;
            border-radius: 0.375rem;
            padding: 0.375rem 0.75rem;
        }
        .select2-container--default .select2-selection--multiple .select2-selection__choice {
            background-color: #007bff;
            color: white;
            border-radius: 0.25rem;
        }
        #custom_frequency_container {
            display: none;
        }
        @media (max-width: 576px) {
            .table-responsive {
                font-size: 0.9rem;
            }
            .btn-sm {
                padding: 0.2rem 0.4rem;
            }
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Fee Structure</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Fee Structure
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Fee Structure Table -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-3 col-xl-2">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Fee Structures..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-3 col-xl-2">
                                    <select class="form-select" id="sessionFilter">
                                        <option value="">Select</option>
                                        <?php
                                        $currentYear = date('Y'); // e.g., 2025
                                        $startYear = $currentYear - 5; // show last 5 years
                                        $currentSession = $currentYear . '-' . ($currentYear + 1);
                                    
                                        for ($year = $startYear; $year <= $currentYear; $year++) {
                                            $nextYear = $year + 1;
                                            $session = "$year-$nextYear";
                                            $selected = ($session === $currentSession) ? 'selected' : '';
                                            echo "<option value='$session' $selected>$session</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-6 col-xl-9 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div class="action-buttons me-2">
                                        <button class="delete-multiple btn bg-danger-subtle text-danger">
                                            <i class="fas fa-spinner fa-spin"></i>
                                            <span class="btn-text">Delete</span>
                                        </button>
                                    </div>
                                    <button id="btn-add-fee" class="btn btn-primary d-flex align-items-center">
                                        <i class="ti ti-plus text-white me-1 fs-5"></i> Add Fee Structure
                                    </button>
                                </div>
                            </div>
                        </div>
                        <!-- Modal -->
                        <div class="modal fade" id="addFeeModal" tabindex="-1" role="dialog"
                            aria-labelledby="addFeeModalTitle" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="modal-title">Add Fee Structure</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="add-fee-box">
                                            <div class="add-fee-content">
                                                <form id="addFeeForm">
                                                    <input type="hidden" id="fee_id">
                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <label for="particular_id" class="form-label">Particular *</label>
                                                            <select class="form-control" id="particular_id" name="particular_id" required>
                                                                <option value="">Select Particular</option>
                                                                <!-- Populated dynamically -->
                                                            </select>
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="class_id" class="form-label">Class *</label>
                                                            <select class="form-control" id="class_id" name="class_id" required>
                                                                <option value="">Select Class</option>
                                                                <!-- Populated dynamically -->
                                                            </select>
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="amount" class="form-label">Amount *</label>
                                                            <input type="number" step="0.01" id="amount" name="amount" class="form-control" placeholder="Enter amount" required />
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="frequency" class="form-label">Frequency *</label>
                                                            <select class="form-control" id="frequency" name="frequency" required>
                                                                <option value="monthly">Monthly</option>
                                                                <option value="annual">Annual (Once a Year)</option>
                                                                <option value="other">Other (Custom)</option>
                                                            </select>
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                        <div class="col-md-6 mb-3" id="custom_frequency_container">
                                                            <label for="custom_frequency" class="form-label">Custom Frequency (Months) *</label>
                                                            <input type="number" id="custom_frequency" name="custom_frequency" class="form-control" placeholder="Enter interval in months (e.g., 2 for every 2 months)" min="1" />
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="applicable_months" class="form-label">Applicable Months *</label>
                                                            <select class="form-control" id="applicable_months" name="applicable_months[]" multiple required>
                                                                <option value="all">All Months</option>
                                                                <option value="1">January</option>
                                                                <option value="2">February</option>
                                                                <option value="3">March</option>
                                                                <option value="4">April</option>
                                                                <option value="5">May</option>
                                                                <option value="6">June</option>
                                                                <option value="7">July</option>
                                                                <option value="8">August</option>
                                                                <option value="9">September</option>
                                                                <option value="10">October</option>
                                                                <option value="11">November</option>
                                                                <option value="12">December</option>
                                                            </select>
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="status" class="form-label">Status *</label>
                                                            <select class="form-control" id="status" name="status" required>
                                                                <option value="active">Active</option>
                                                                <option value="inactive">Inactive</option>
                                                            </select>
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="session" class="form-label">Session *</label>
                                                            <select class="form-control" id="session" name="session" required>
                                                                <option value="">Select</option>
                                                                <?php
                                                                $currentYear = date('Y'); // e.g., 2025
                                                                $startYear = $currentYear - 5; // show last 5 years
                                                                $currentSession = $currentYear . '-' . ($currentYear + 1);
                                                            
                                                                for ($year = $startYear; $year <= $currentYear; $year++) {
                                                                    $nextYear = $year + 1;
                                                                    $session = "$year-$nextYear";
                                                                    $selected = ($session === $currentSession) ? 'selected' : '';
                                                                    echo "<option value='$session' $selected>$session</option>";
                                                                }
                                                                ?>
                                                            </select>
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button id="btn-add" class="btn btn-success">
                                            <i class="fas fa-spinner fa-spin btn-loading"></i>
                                            <span class="btn-text">Add</span>
                                        </button>
                                        <button id="btn-edit" class="btn btn-success" style="display:none;">
                                            <i class="fas fa-spinner fa-spin btn-loading"></i>
                                            <span class="btn-text">Save</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Table -->
                        <div class="card card-body table-container">
                            <div class="table-loader">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <tr>
                                            <th>
                                                <div class="n-chk align-self-center text-center">
                                                    <div class="form-check">
                                                        <input type="checkbox" class="form-check-input primary"
                                                            id="fee-check-all" />
                                                        <label class="form-check-label" for="fee-check-all"></label>
                                                        <span class="new-control-indicator"></span>
                                                    </div>
                                                </div>
                                            </th>
                                            <th>S.N.</th>
                                            <th>Particular</th>
                                            <th>Amount</th>
                                            <th>Class</th>
                                            <th>Frequency</th>
                                            <th>Applicable Months</th>
                                            <th>Status</th>
                                            <th>Session</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="fee_list_table_body">
                                        <!-- Table will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <nav aria-label="Page navigation" id="pagination-nav">
                                <ul class="pagination justify-content-center">
                                    <!-- Pagination controls -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="dark-transparent sidebartoggler"></div>
    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script src="../assets/js/index.global.min.js"></script>
    <script>
        $(document).ready(function() {
            // Initialize Select2 for multi-select
            $('#applicable_months').select2({
                placeholder: "Select applicable months",
                allowClear: true,
                width: '100%',
                theme: 'bootstrap-5'
            });
            
            var fees, meta;

            // Pagination state
            let currentPage = 1;
            const perPage = 10;

            // Hide table loader initially
            $('.table-loader').hide();

            // Handle frequency change
            $('#frequency').on('change', function() {
                const frequency = $(this).val();
                const applicableMonthsSelect = $('#applicable_months');
                const customFrequencyContainer = $('#custom_frequency_container');
                const customFrequencyInput = $('#custom_frequency');

                if (frequency === 'annual') {
                    applicableMonthsSelect.val('all').trigger('change');
                    applicableMonthsSelect.prop('disabled', true);
                    customFrequencyContainer.hide();
                    customFrequencyInput.removeAttr('required');
                } else if (frequency === 'other') {
                    applicableMonthsSelect.prop('disabled', false);
                    customFrequencyContainer.show();
                    customFrequencyInput.attr('required', true);
                } else {
                    applicableMonthsSelect.prop('disabled', false);
                    customFrequencyContainer.hide();
                    customFrequencyInput.removeAttr('required');
                }
            });

            // Load particulars for dropdown
            function loadParticularsDropdown() {
                $.ajax({
                    url: 'api/particulars_master.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        const particulars = response.data || [];
                        const select = $('#particular_id');
                        select.empty();
                        select.append('<option value="">Select Particular</option>');
                        particulars.forEach(particular => {
                            select.append(`<option value="${particular.id}">${particular.particular}</option>`);
                        });
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load particulars: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Load classes for dropdown
            function loadClassesDropdown() {
                $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 100, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        const classes = response.data || [];
                        const select = $('#class_id');
                        select.empty();
                        select.append('<option value="">Select Class</option>');
                        classes.forEach(cls => {
                            select.append(`<option value="${cls.id}">${cls.class_name}</option>`);
                        });
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load classes: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Load fee structures with pagination
            function loadFeeStructures(page = 1) {
                $('.table-loader').show();
                $.ajax({
                    url: 'api/fee_structure_master.php',
                    type: 'GET',
                    data: { page: page, perPage: perPage },
                    dataType: 'json',
                    success: function(response) {
                        fees = response.data || [];
                        meta = response.meta || { page: 1, totalPages: 1, totalItems: fees.length };
                        renderFeeTable(fees, page);
                        renderPagination(meta);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load fee structures: ' + (xhr.responseJSON?.error || error)
                        });
                        renderPagination({ page: 1, totalPages: 1, totalItems: 0 });
                    },
                    complete: function() {
                        $('.table-loader').hide();
                    }
                });
            }
            
            // Handle session change
            $("#sessionFilter").on("change", function() {
                const fsession = $(this).val();
                renderFeeTable(fees, currentPage, fsession);
            });
            
            // Render fee table
            function renderFeeTable(fees, page = 1, fsession = null) {
                const tbody = $('#fee_list_table_body');
                tbody.empty();
            
                // Filter by session if applicable
                const filteredFees = fsession ? fees.filter(fee => fee.session === fsession) : fees;
            
                if (filteredFees.length === 0) {
                    tbody.append('<tr><td colspan="10" class="text-center">No fee structures found.</td></tr>');
                    return;
                }
            
                filteredFees.forEach((fee, index) => {
                    const serialNumber = (page - 1) * perPage + index + 1;
                    const statusBadge = fee.status === 'active'
                        ? '<span class="badge bg-success-subtle text-success">Active</span>'
                        : '<span class="badge bg-danger-subtle text-danger">Inactive</span>';
                    const updatedOn = fee.updated_on
                        ? new Date(fee.updated_on).toLocaleString()
                        : 'N/A';
                    const applicableMonths = fee.applicable_months === 'all'
                        ? 'All Months'
                        : fee.applicable_months.split(',').map(m => {
                            const months = [
                                'January', 'February', 'March', 'April', 'May', 'June',
                                'July', 'August', 'September', 'October', 'November', 'December'
                            ];
                            return months[parseInt(m) - 1];
                        }).join(', ');
            
                    let frequencyText = fee.frequency.charAt(0).toUpperCase() + fee.frequency.slice(1);
                    if (fee.frequency === 'other') {
                        frequencyText = `Every ${fee.custom_frequency} Month${fee.custom_frequency > 1 ? 's' : ''}`;
                    }
            
                    tbody.append(`
                        <tr data-id="${fee.id}">
                            <td>
                                <div class="n-chk align-self-center text-center">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input primary fee-check" data-id="${fee.id}" />
                                        <label class="form-check-label"></label>
                                        <span class="new-control-indicator"></span>
                                    </div>
                                </div>
                            </td>
                            <td>${serialNumber}</td>
                            <td>${fee.particular_name || '-'}</td>
                            <td>${fee.amount || '-'}</td>
                            <td>${fee.class_name || '-'}</td>
                            <td>${frequencyText}</td>
                            <td>${applicableMonths}</td>
                            <td>${statusBadge}</td>
                            <td>${fee.session}</td>
                            <td>
                                <button class="edit-fee btn btn-sm btn-primary me-1" data-id="${fee.id}">
                                    <i class="ti ti-edit"></i>
                                </button>
                                <button class="delete-fee btn btn-sm btn-danger" data-id="${fee.id}">
                                    <i class="ti ti-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `);
                });
            }

            // Render pagination
            function renderPagination(meta) {
                const pagination = $('#pagination-nav ul');
                pagination.empty();

                const currentPage = meta.page || 1;
                const totalPages = meta.totalPages || 1;

                pagination.append(`
                    <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
                    </li>
                `);

                for (let p = 1; p <= totalPages; p++) {
                    pagination.append(`
                        <li class="page-item ${p === currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${p}">${p}</a>
                        </li>
                    `);
                }

                pagination.append(`
                    <li class="page-item ${currentPage >= totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
                    </li>
                `);
            }

            // Pagination click
            $(document).on('click', '#pagination-nav a', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && page !== currentPage) {
                    currentPage = page;
                    loadFeeStructures(page);
                }
            });

            // Show add modal
            $('#btn-add-fee').on('click', function() {
                $('#modal-title').text('Add Fee Structure');
                $('#addFeeForm')[0].reset();
                $('#fee_id').val('');
                $('#applicable_months').val('all').trigger('change');
                $('#frequency').val('monthly').trigger('change');
                $('#custom_frequency_container').hide();
                $('#custom_frequency').removeAttr('required');
                $('#btn-add').show();
                $('#btn-edit').hide();
                $('#addFeeModal').modal('show');
            });

            // Add fee structure
            $('#btn-add').on('click', function() {
                const form = $('#addFeeForm')[0];
                if (!form.checkValidity()) {
                    form.reportValidity();
                    return;
                }

                const formData = new FormData(form);
                const applicableMonths = $('#applicable_months').val();
                formData.set('applicable_months', applicableMonths.includes('all') ? 'all' : applicableMonths.join(','));
                if ($('#frequency').val() === 'other') {
                    const customFrequency = $('#custom_frequency').val();
                    if (!customFrequency || customFrequency < 1) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Please enter a valid custom frequency (minimum 1 month)'
                        });
                        return;
                    }
                    formData.set('custom_frequency', customFrequency);
                } else {
                    formData.delete('custom_frequency');
                }

                $(this).addClass('btn-loading');

                $.ajax({
                    url: 'api/fee_structure_master.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Fee structure added successfully'
                        });
                        $('#addFeeModal').modal('hide');
                        loadFeeStructures(currentPage);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to add fee structure: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('#btn-add').removeClass('btn-loading');
                    }
                });
            });

            // Show edit modal
            $(document).on('click', '.edit-fee', function() {
                const id = $(this).data('id');
                $(this).addClass('btn-loading');
                $.ajax({
                    url: 'api/fee_structure_master.php',
                    type: 'GET',
                    data: { id: id },
                    dataType: 'json',
                    success: function(response) {
                        const fee = response.data && response.data.length > 0 ? response.data[0] : null;
                        if (fee) {
                            $('#modal-title').text('Edit Fee Structure');
                            $('#fee_id').val(fee.id);
                            $('#particular_id').val(fee.particular_id);
                            $('#class_id').val(fee.class_id);
                            $('#amount').val(fee.amount);
                            const applicableMonths = fee.applicable_months === 'all' ? ['all'] : fee.applicable_months.split(',');
                            $('#applicable_months').val(applicableMonths).trigger('change');
                            $('#frequency').val(fee.frequency).trigger('change');
                            if (fee.frequency === 'other') {
                                $('#custom_frequency').val(fee.custom_frequency);
                            }
                            $('#status').val(fee.status);
                            $('#btn-add').hide();
                            $('#btn-edit').show();
                            $('#addFeeModal').modal('show');
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Fee structure not found'
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to fetch fee structure: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('.edit-fee[data-id="' + id + '"]').removeClass('btn-loading');
                    }
                });
            });

            // Update fee structure
            $('#btn-edit').on('click', function() {
                const form = $('#addFeeForm')[0];
                if (!form.checkValidity()) {
                    form.reportValidity();
                    return;
                }

                const formData = new FormData(form);
                formData.append('id', $('#fee_id').val());
                formData.append('_method', 'PUT');
                const applicableMonths = $('#applicable_months').val();
                formData.set('applicable_months', applicableMonths.includes('all') ? 'all' : applicableMonths.join(','));
                if ($('#frequency').val() === 'other') {
                    const customFrequency = $('#custom_frequency').val();
                    if (!customFrequency || customFrequency < 1) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Please enter a valid custom frequency (minimum 1 month)'
                        });
                        return;
                    }
                    formData.set('custom_frequency', customFrequency);
                } else {
                    formData.delete('custom_frequency');
                }

                $(this).addClass('btn-loading');

                $.ajax({
                    url: 'api/fee_structure_master.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Fee structure updated successfully'
                        });
                        $('#addFeeModal').modal('hide');
                        loadFeeStructures(currentPage);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to update fee structure: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('#btn-edit').removeClass('btn-loading');
                    }
                });
            });

            // Delete fee structure
            $(document).on('click', '.delete-fee', function() {
                const id = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/fee_structure_master.php',
                            type: 'DELETE',
                            data: JSON.stringify({ ids: [id] }),
                            contentType: 'application/json',
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted',
                                    text: response.message || 'Fee structure deleted successfully'
                                });
                                loadFeeStructures(currentPage);
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to delete fee structure: ' + (xhr.responseJSON?.error || error)
                                });
                            },
                            complete: function() {
                                $('.delete-fee[data-id="' + id + '"]').removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // Handle select all checkbox
            $('#fee-check-all').on('change', function() {
                $('.fee-check').prop('checked', this.checked);
                $('.action-buttons').toggle($('.fee-check:checked').length > 0);
            });

            // Handle individual checkboxes
            $(document).on('change', '.fee-check', function() {
                const anyChecked = $('.fee-check:checked').length > 0;
                $('#fee-check-all').prop('checked', $('.fee-check').length === $('.fee-check:checked').length);
                $('.action-buttons').toggle(anyChecked);
            });

            // Bulk delete
            $('.delete-multiple').on('click', function() {
                const selectedIds = $('.fee-check:checked').map(function() {
                    return $(this).data('id');
                }).get();

                if (selectedIds.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Selection',
                        text: 'Please select at least one fee structure to delete.'
                    });
                    return;
                }

                Swal.fire({
                    title: 'Are you sure?',
                    text: `Delete ${selectedIds.length} fee structures?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete them!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/fee_structure_master.php',
                            type: 'DELETE',
                            data: JSON.stringify({ ids: selectedIds }),
                            contentType: 'application/json',
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted',
                                    text: response.message || 'Selected fee structures deleted successfully'
                                });
                                loadFeeStructures(currentPage);
                                $('.action-buttons').hide();
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to delete fee structures: ' + (xhr.responseJSON?.error || error)
                                });
                            },
                            complete: function() {
                                $('.delete-multiple').removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // Search functionality
            $('#input-search').on('keyup', function() {
                const searchText = $(this).val().toLowerCase();
                $('#fee_list_table_body tr').filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(searchText) > -1);
                });
            });

            // Initial load
            loadParticularsDropdown();
            loadClassesDropdown();
            loadFeeStructures(currentPage);
        });
    </script>
</body>
</html>