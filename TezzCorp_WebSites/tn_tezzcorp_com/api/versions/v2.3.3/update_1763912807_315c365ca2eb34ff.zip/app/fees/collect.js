/* collect.js - Optimized for Serial Collection */

let STUDENT_ID = $('#hdn_student_id').val();
let STUDENT_UID = $('#hdn_student_uid').val();
let CURRENT_SESSION = $('#session_filter').val();
let FEE_DATA = []; // Stores the loaded month structure
let HISTORY_TABLE = null;

$(document).ready(function() {
    loadData();

    // Listeners
    $('#session_filter').change(function() {
        CURRENT_SESSION = $(this).val();
        loadData();
    });

    $('#payment_method').change(function() {
        const method = $(this).val();
        if(method === 'cheque' || method === 'dd' || method === 'online') {
            $('#ref_box').show().find('input').prop('required', true);
        } else {
            $('#ref_box').hide().find('input').prop('required', false);
        }
    });

    $('#btn_calculate').click(calculateAllocation);
    
    // Allow Enter key in amount box to trigger calc
    $('#received_amount').keypress(function(e) {
        if(e.which == 13) {
            e.preventDefault();
            calculateAllocation();
        }
    });

    $('#collectionForm').submit(submitCollection);
    $('#refresh_history').click(loadHistory);
    
    // Reset
    $('#btn_reset').click(function() {
        setTimeout(renderMonthTable, 100); // Re-render to clear selections
        $('#lbl_final_total').text('₹0.00');
        $('#btn_submit_fee').prop('disabled', true);
        $('#received_amount').val(''); // Added to clear amount field on reset
        $('#discount_amount').val(''); // Added to clear discount field on reset
        $('#remarks').val(''); // Added to clear remarks field on reset
    });
});

function loadData() {
    loadFeeStructure();
    loadHistory();
}

// 1. Load Fee Structure (GET)
// ... (loadFeeStructure remains unchanged)
function loadFeeStructure() {
    $('#month_list_body').html('<tr><td colspan="6" class="text-center"><i class="fa fa-spinner fa-spin"></i> Loading...</td></tr>');
    
    $.ajax({
        url: 'api/fee_collection_master.php',
        method: 'GET',
        data: {
            action: 'get_dues',
            student_id: STUDENT_ID,
            session: CURRENT_SESSION
        },
        dataType: 'json',
        success: function(res) {
            if(res.status === 'success') {
                FEE_DATA = res.data; // Store globally
                updateWidgetSummary(res.summary);
                renderMonthTable();
            } else {
                Swal.fire('Error', res.message, 'error');
            }
        },
        error: function() {
            Swal.fire('Error', 'Failed to fetch fees', 'error');
        }
    });
}

function updateWidgetSummary(sum) {
    $('#widget_total_due').text('₹' + parseFloat(sum.total_fee).toFixed(2));
    $('#widget_total_paid').text('₹' + parseFloat(sum.total_paid).toFixed(2));
    $('#widget_outstanding').text('₹' + parseFloat(sum.total_outstanding).toFixed(2));
}

// 2. Render the Month List
function renderMonthTable() {
    const tbody = $('#month_list_body');
    tbody.empty();

    let allPaid = true;

    FEE_DATA.forEach((month, index) => {
        const isPaid = month.status === 'fully_paid';
        const isPartial = month.status === 'partial';
        const rowClass = isPaid ? 'paid' : (isPartial ? 'partial' : '');
        
        // If it's paid, we don't show the checkbox active
        const checkbox = isPaid ? 
            `<i class="fa fa-check-circle text-success"></i>` : 
            `<input type="checkbox" class="form-check-input month-chk" data-index="${index}" data-month-id="${month.month_id}" readonly>`; // Added month_id for clarity

        if (!isPaid) allPaid = false;
        
        // Special rendering for Pending Dues
        const monthDisplayName = month.month_id === 0 ? 
            `<span class="badge bg-danger text-white">(${month.month_name})</span>` : 
            month.month_name;

        const html = `
            <tr class="month-row ${rowClass}" id="row_${index}">
                <td>${index + 1}</td>
                <td class="fw-bold">${monthDisplayName}</td>
                <td class="text-end text-muted">₹${parseFloat(month.total_fee).toFixed(2)}</td>
                <td class="text-end text-success">₹${parseFloat(month.paid_amount).toFixed(2)}</td>
                <td class="text-end fw-bold ${month.due_amount > 0 ? 'text-danger' : 'text-success'}">₹${parseFloat(month.due_amount).toFixed(2)}</td>
                <td class="text-center">${checkbox}</td>
            </tr>
        `;
        tbody.append(html);
    });

    if (allPaid && FEE_DATA.length > 0) {
        tbody.html('<tr><td colspan="6" class="text-center text-success fw-bold py-4">All fees for this session (including Pending Dues) are fully paid!</td></tr>');
        $('#received_amount').prop('disabled', true);
        $('#btn_calculate').prop('disabled', true);
    } else if (FEE_DATA.length === 0) {
         tbody.html('<tr><td colspan="6" class="text-center text-info fw-bold py-4">No monthly fee structure found for this class and session.</td></tr>');
    } else {
        $('#received_amount').prop('disabled', false);
        $('#btn_calculate').prop('disabled', false);
    }
}

// 3. Core Logic: Calculate Allocation based on Received Amount
// ... (calculateAllocation remains unchanged as it iterates over FEE_DATA)
function calculateAllocation() {
    const received = parseFloat($('#received_amount').val()) || 0;
    const discount = parseFloat($('#discount_amount').val()) || 0;
    let amountLeft = received + discount; // Logic: Discount effectively adds to purchasing power for the fee
    let totalAllocated = 0;
    let monthsSelected = [];
    
    // Reset UI first
    $('.month-chk').prop('checked', false);
    $('.month-row').removeClass('selected');
    
    // Waterfall Logic
    for (let i = 0; i < FEE_DATA.length; i++) {
        const m = FEE_DATA[i];
        
        // Skip fully paid
        if (m.status === 'fully_paid') continue;

        // Stop if ran out of money
        if (amountLeft <= 0.01) break;

        // How much is needed for this month?
        const needed = parseFloat(m.due_amount);
        
        // Allocate
        let allocatedHere = 0;
        if (amountLeft >= needed) {
            allocatedHere = needed; // Full payment for this month
        } else {
            allocatedHere = amountLeft; // Partial payment
        }

        // Update counters
        amountLeft -= allocatedHere;
        totalAllocated += allocatedHere;

        // UI Update
        const $chk = $(`.month-chk[data-index="${i}"]`);
        $chk.prop('checked', true);
        $(`#row_${i}`).addClass('selected');
        
        monthsSelected.push({
            month_id: m.month_id,
            amount: allocatedHere
        });
    }

    // Visual Feedback
    const displayTotal = totalAllocated - discount; // Actual money collected
    $('#lbl_final_total').text('₹' + displayTotal.toFixed(2));

    if (monthsSelected.length > 0 && displayTotal > 0) {
        $('#btn_submit_fee').prop('disabled', false).html(`<i class="fa-solid fa-check-circle me-2"></i> Collect ₹${displayTotal.toFixed(2)}`);
    } else {
        $('#btn_submit_fee').prop('disabled', true).text('Submit Collection');
    }
}

// 4. Submit Logic
function submitCollection(e) {
    e.preventDefault();

    // Re-run calc to be safe
    calculateAllocation();
    
    const received = parseFloat($('#received_amount').val()) || 0;
    if (received <= 0) {
        Swal.fire('Warning', 'Please enter a valid amount.', 'warning');
        return;
    }

    const months = [];
    $('.month-chk:checked').each(function() {
        const idx = $(this).data('index');
        // Push the month_id from FEE_DATA, which can be 0 (Pending Dues)
        months.push(FEE_DATA[idx].month_id); 
    });

    if(months.length === 0) {
        Swal.fire('Error', 'No months selected based on amount.', 'error');
        return;
    }
    
    // Final check for payment method requiring reference
    const method = $('#payment_method').val();
    if((method === 'cheque' || method === 'dd' || method === 'online') && !$('#reference_no').val()) {
        Swal.fire('Warning', 'Please enter a Reference No / Transaction ID for the selected payment method.', 'warning');
        return;
    }


    const formData = {
        action: 'collect_fee',
        student_id: STUDENT_ID,
        session: CURRENT_SESSION,
        amount_collected: received,
        discount: $('#discount_amount').val(),
        remarks: $('#remarks').val(),
        payment_date: $('#payment_date').val(),
        payment_method: $('#payment_method').val(),
        ref_no: $('#reference_no').val(),
        months: months
    };

    $('#btn_submit_fee').prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Processing...');

    $.ajax({
        url: 'api/fee_collection_master.php',
        method: 'POST',
        data: formData,
        dataType: 'json',
        success: function(res) {
            if(res.status === 'success') {
                // Open Receipt
                printReceipt(res.payment_id);
                
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Fee Collected Successfully!',
                    timer: 1500
                }).then(() => {
                    // Reset Form
                    $('#received_amount').val('');
                    $('#discount_amount').val('');
                    $('#remarks').val('');
                    $('#reference_no').val('');
                    $('#ref_box').hide();
                    loadData(); // Reloads table with new balances
                    $('#btn_submit_fee').prop('disabled', true).text('Submit Collection');
                    $('#lbl_final_total').text('₹0.00');
                });
            } else {
                Swal.fire('Error', res.message, 'error');
                $('#btn_submit_fee').prop('disabled', false).text('Submit Collection');
            }
        },
        error: function() {
            Swal.fire('Error', 'Server error occurred.', 'error');
            $('#btn_submit_fee').prop('disabled', false).text('Submit Collection');
        }
    });
}
// ... (loadHistory, deletePayment, printReceipt remain unchanged, using the updated API logic)
// ... (The rest of collect.js code is assumed to follow the original structure, with the above modifications)

// 5. History & Receipt
function loadHistory() {
    if (HISTORY_TABLE) HISTORY_TABLE.destroy();

    HISTORY_TABLE = $('#history_table').DataTable({
        ajax: {
            url: 'api/fee_collection_master.php',
            type: 'GET',
            data: {
                action: 'get_history',
                student_id: STUDENT_ID,
                session: CURRENT_SESSION
            }
        },
        columns: [
            { data: 'id', render: (data) => `#${data}` },
            { data: 'months_covered' },
            { data: 'amount_collected', render: (data) => `₹${parseFloat(data).toFixed(2)}` },
            { data: 'remaining_balance', render: (data) => {
                const val = parseFloat(data);
                // Note: The history API now returns remaining_balance 0, but keeping the rendering flexible.
                return val > 0 ? `<span class="badge bg-warning text-dark">₹${val.toFixed(2)} due</span>` : '<span class="badge bg-success">Clear</span>';
            }},
            { data: 'payment_date' },
            { data: 'payment_method' },
            { data: 'id', render: (data) => `
                <button class="btn btn-sm btn-info me-1" onclick="printReceipt(${data})"><i class="fa fa-print"></i></button>
                <button class="btn btn-sm btn-danger" onclick="deletePayment(${data})"><i class="fa fa-trash"></i></button>
            `}
        ],
        order: [[0, 'desc']]
    });
}

function deletePayment(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "Delete this payment? Balances will revert.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: 'api/fee_collection_master.php',
                method: 'POST',
                data: { action: 'delete_payment', payment_id: id },
                success: function(res) {
                    if(res.status === 'success') {
                        loadData();
                        Swal.fire('Deleted!', 'Payment has been deleted.', 'success');
                    } else {
                        Swal.fire('Error', res.message, 'error');
                    }
                }
            });
        }
    });
}

function printReceipt(id) {
    const url = `print_receipt.php?id=${id}`; 
    window.open(`api/fee_collection_master.php?action=print_receipt&payment_id=${id}`, '_blank', 'width=900,height=600');
}