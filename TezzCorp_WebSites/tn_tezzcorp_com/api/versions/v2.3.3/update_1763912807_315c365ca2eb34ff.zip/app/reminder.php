<?php
function fetchPaymentsFromAPI($userEmail) {
    $apiUrl = 'https://www.bthdevelopers.com/api/payments.php';
    
    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200 && $response) {
        $data = json_decode($response, true);
        
        if ($data && isset($data['success']) && $data['success'] && isset($data['data'])) {
            // Filter payments by user email
            $userPayments = array_filter($data['data'], function($payment) use ($userEmail) {
                return isset($payment['client_email']) && $payment['client_email'] === $userEmail;
            });
            
            return array_values($userPayments); // Re-index array
        }
    }
    
    return [];
}

$paymentsData = fetchPaymentsFromAPI($email);
?>