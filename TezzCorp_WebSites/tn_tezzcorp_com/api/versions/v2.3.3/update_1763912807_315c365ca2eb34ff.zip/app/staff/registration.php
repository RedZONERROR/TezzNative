<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">

<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/additional-methods.min.js"></script>
    <script src="../assets/js/jquery.steps.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Staff Registration - AI-ERP 2.0</title>
    <style>
        .btn-loading .fa-spinner {
            display: inline-block;
        }
        .btn-loading .btn-text {
            display: none;
        }
        .fa-spinner {
            display: none;
            font-size: 0.9rem;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar -->
        <?php include 'util/sidebar.php'; ?>
        <div class="page-wrapper">
            <!-- Header -->
            <?php include 'util/topbar.php'; ?>

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Staff Registration Form</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Registration Form
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Admission Form -->
                    <div class="card">
                        <div class="card-body wizard-content">
                            <h4 class="card-title">Step Wizard with Validation</h4>
                            <p class="card-subtitle mb-3">Complete the form step-by-step</p>
                            <div id="error-message" class="alert alert-danger d-none"></div>
                            <form id="admission-form" class="validation-wizard wizard-circle mt-5" enctype="multipart/form-data">
                                <!-- Step 1 -->
                                <h6>Personal Information</h6>
                                <section id="section_1">
                                    <div class="d-flex justify-content-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                    </div>
                                    <div class="row" id="personal_fields"></div>
                                </section>
                                <!-- Step 2 -->
                                <h6>Academic & Identity</h6>
                                <section id="section_2">
                                    <div class="d-flex justify-content-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                    </div>
                                    <div class="row" id="academic_identity_fields"></div>
                                </section>
                                <!-- Step 3 -->
                                <h6>Address & Employment</h6>
                                <section id="section_3">
                                    <div class="d-flex justify-content-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                    </div>
                                    <div class="row" id="address_employment_fields"></div>
                                </section>
                                <!-- Step 4 -->
                                <h6>Documents</h6>
                                <section id="section_4">
                                    <div class="d-flex justify-content-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                    </div>
                                    <div class="row" id="document_fields"></div>
                                </section>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>

    <script>
        $(document).ready(function() {
            // Initialize jQuery Steps
            const form = $("#admission-form").show();
            form.steps({
                headerTag: "h6",
                bodyTag: "section",
                transitionEffect: "fade",
                titleTemplate: '<span class="step">#index#</span> #title#',
                labels: {
                    finish: '<span class="btn-text">Submit</span><i class="fas fa-spinner fa-spin"></i>',
                    next: '<span class="btn-text">Next</span><i class="fas fa-spinner fa-spin"></i>',
                    previous: '<span class="btn-text">Previous</span><i class="fas fa-spinner fa-spin"></i>'
                },
                onStepChanging: function(event, currentIndex, newIndex) {
                    if (currentIndex < newIndex) {
                        // Show loader on Next button
                        $('.actions a[href="#next"]').addClass('btn-loading');
                        
                        // Validate only current step
                        const currentStep = $(form.steps('getCurrentStep'));
                        const inputs = currentStep.find(':input').not(':hidden');
                        let isValid = true;

                        inputs.each(function() {
                            if (!form.validate().element(this)) {
                                isValid = false;
                            }
                        });

                        console.log('Validation Errors:', form.validate().errorList); // Debug

                        if (!isValid) {
                            $('.actions a[href="#next"]').removeClass('btn-loading');
                            $('#error-message')
                                .text('Please correct the errors in the current step.')
                                .removeClass('d-none');
                            return false;
                        }

                        $('.actions a[href="#next"]').removeClass('btn-loading');
                        $('#error-message').addClass('d-none');
                        return true;
                    } else {
                        // Show loader on Previous button
                        $('.actions a[href="#previous"]').addClass('btn-loading');
                        setTimeout(() => {
                            $('.actions a[href="#previous"]').removeClass('btn-loading');
                        }, 500); // Simulate loading
                        return true; // Allow Previous
                    }
                },
                onFinishing: function(event, currentIndex) {
                    $('.actions a[href="#finish"]').addClass('btn-loading');
                    return form.valid();
                },
                onFinished: function(event, currentIndex) {
                    submitForm();
                }
            });

            // Store required fields metadata
            let requiredFields = {};

            // Initialize jQuery Validation
            const validator = form.validate({
                ignore: "input[type=hidden]",
                errorElement: "div",
                errorClass: "invalid-feedback",
                errorPlacement: function(error, element) {
                    error.appendTo(element.closest('.mb-3'));
                },
                highlight: function(element) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element) {
                    $(element).removeClass('is-invalid');
                },
                rules: {
                    name: { required: true, maxlength: 255 },
                    mobile: { required: true, digits: true, minlength: 10, maxlength: 15 },
                    email: { required: true, email: true, maxlength: 255 },
                    password: { required: true, minlength: 6, maxlength: 255 },
                    dob: { date: true },
                    aadhaar: { digits: true, minlength: 12, maxlength: 12 },
                    pan: { pattern: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/, required: false },
                    account_no: { maxlength: 20 },
                    ifsc: { maxlength: 11 },
                    bank_name: { maxlength: 100 },
                    residential_address: { maxlength: 65535 },
                    permanent_address: { maxlength: 65535 },
                    role: { required: function(element) { return requiredFields['role'] || false; } },
                    status: { required: function(element) { return requiredFields['status'] || false; } },
                    doj: { date: true },
                    doe: { date: true },
                    photo: { 
                        required: function(element) { return requiredFields['photo'] || false; },
                        extension: "jpg|jpeg|png" 
                    },
                    tenth_marksheet: { 
                        required: function(element) { return requiredFields['tenth_marksheet'] || false; },
                        extension: "jpg|jpeg|png|pdf" 
                    },
                    twelfth_marksheet: { 
                        required: function(element) { return requiredFields['twelfth_marksheet'] || false; },
                        extension: "jpg|jpeg|png|pdf" 
                    },
                    graduation: { 
                        required: function(element) { return requiredFields['graduation'] || false; },
                        extension: "jpg|jpeg|png|pdf" 
                    },
                    b_ed: { 
                        required: function(element) { return requiredFields['b_ed'] || false; },
                        extension: "jpg|jpeg|png|pdf" 
                    },
                    d_el_ed: { 
                        required: function(element) { return requiredFields['d_el_ed'] || false; },
                        extension: "jpg|jpeg|png|pdf" 
                    },
                    ntt: { 
                        required: function(element) { return requiredFields['ntt'] || false; },
                        extension: "jpg|jpeg|png|pdf" 
                    },
                    exp_certificate: { 
                        required: function(element) { return requiredFields['exp_certificate'] || false; },
                        extension: "jpg|jpeg|png|pdf" 
                    },
                    signature: { 
                        required: function(element) { return requiredFields['signature'] || false; },
                        extension: "jpg|jpeg|png" 
                    },
                    aadhaar_image: { 
                        required: function(element) { return requiredFields['aadhaar_image'] || false; },
                        extension: "jpg|jpeg|png|pdf" 
                    },
                    pan_image: { 
                        required: function(element) { return requiredFields['pan_image'] || false; },
                        extension: "jpg|jpeg|png|pdf" 
                    },
                    bank_document: { 
                        required: function(element) { return requiredFields['bank_document'] || false; },
                        extension: "jpg|jpeg|png|pdf" 
                    },
                    resume: { 
                        required: function(element) { return requiredFields['resume'] || false; },
                        extension: "pdf|doc|docx" 
                    }
                },
                messages: {
                    name: { required: "Please enter full name" },
                    mobile: { required: "Please enter mobile number", digits: "Please enter a valid number" },
                    email: { required: "Please enter email", email: "Please enter a valid email" },
                    password: { required: "Please enter password", minlength: "Password must be at least 6 characters" },
                    aadhaar: { digits: "Aadhaar must be 12 digits" },
                    pan: { pattern: "PAN must be 5 letters, 4 digits, 1 letter (e.g., ABCDE1234F)" },
                    role: { required: "Please select a role" },
                    status: { required: "Please select a status" },
                    photo: { extension: "Please upload a JPG, JPEG, or PNG file" },
                    resume: { extension: "Please upload a PDF, DOC, or DOCX file" }
                }
            });

            // Show section loaders
            $('.spinner-border').show();

            // Fetch form fields (only active)
            $.ajax({
                url: 'api/staff_form_element_master.php',
                type: 'GET',
                data: { perPage: 100, status: 'active' },
                dataType: 'json',
                success: function(response) {
                    console.log('API Response:', response);
                    const fields = response.data || response.staff_form_elements || [];
                    console.log('Fields Loaded:', fields.length, fields);
                    // Log role, status, bank_document
                    console.log('Role Field:', fields.find(f => f.column_name === 'role'));
                    console.log('Status Field:', fields.find(f => f.column_name === 'status'));
                    console.log('Bank Document Field:', fields.find(f => f.column_name === 'bank_document'));
                    renderFormFields(fields);
                    $('.spinner-border').hide();
                    validator.resetForm();
                    form.validate().form();
                },
                error: function(xhr, status, error) {
                    $('.spinner-border').hide();
                    console.error('AJAX Error:', xhr.responseJSON, status, error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to load form fields: ' + (xhr.responseJSON?.error || error)
                    });
                }
            });

            // Render form fields
            function renderFormFields(fields) {
                const sectionMap = {
                    'Personal Details': '#personal_fields',
                    'Academic Details': '#academic_identity_fields',
                    'Identity Details': '#academic_identity_fields',
                    'Address Details': '#address_employment_fields',
                    'Employment Details': '#address_employment_fields',
                    'Documents': '#document_fields',
                    'System': '#document_fields'
                };

                // Populate requiredFields
                fields.forEach(field => {
                    requiredFields[field.column_name] = field.is_required;
                });

                fields.forEach(field => {
                    const targetSection = sectionMap[field.section] || '#personal_fields';
                    const container = $(targetSection);
                    let inputHtml = '';

                    const isRequired = field.is_required ? 'required' : '';
                    const fieldName = field.column_name;
                    const label = `<label class="form-label">${field.field_name}${field.is_required ? ' *' : ''}</label>`;

                    switch (field.field_type) {
                        case 'text':
                        case 'email':
                        case 'password':
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <input type="${field.field_type}" class="form-control" name="${fieldName}" id="${fieldName}"
                                        placeholder="${field.placeholder || ''}" ${isRequired}>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        case 'date':
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <input type="date" class="form-control" name="${fieldName}" id="${fieldName}" ${isRequired}>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        case 'select':
                            const options = field.options ? field.options.split(',').map(opt => 
                                `<option value="${opt.trim()}">${opt.trim()}</option>`
                            ).join('') : '';
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <select class="form-select" name="${fieldName}" id="${fieldName}" ${isRequired}>
                                        <option value="">Select ${field.field_name}</option>
                                        ${options}
                                    </select>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        case 'file':
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <input type="file" class="form-control" name="${fieldName}" id="${fieldName}" ${isRequired}>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        case 'textarea':
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <textarea class="form-control" name="${fieldName}" id="${fieldName}" rows="4" ${isRequired}></textarea>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        default:
                            console.warn('Skipped field due to unsupported type:', field);
                            return;
                    }

                    container.append(inputHtml);
                });

                console.log('Personal Fields:', $('#personal_fields').children().length);
                console.log('Academic & Identity Fields:', $('#academic_identity_fields').children().length);
                console.log('Address & Employment Fields:', $('#address_employment_fields').children().length);
                console.log('Document Fields:', $('#document_fields').children().length);
            }

            // Submit form
            function submitForm() {
                if (!form.valid()) {
                    $('.actions a[href="#finish"]').removeClass('btn-loading');
                    Swal.fire({
                        icon: 'error',
                        title: 'Validation Error',
                        text: 'Please correct the errors in the form'
                    });
                    return;
                }

                const formData = new FormData(form[0]);
                const fileFields = ['photo', 'tenth_marksheet', 'twelfth_marksheet', 'graduation', 'b_ed', 
                    'd_el_ed', 'ntt', 'exp_certificate', 'signature', 'aadhaar_image', 'pan_image', 
                    'bank_document', 'resume'];

                // Upload files only if they are provided (skip if not required and empty)
                Promise.all(fileFields.map(field => {
                    const file = formData.get(field);
                    const isRequired = requiredFields[field] || false;
                    if (file && file.size > 0) { // Only upload if file is provided
                        const uploadData = new FormData();
                        uploadData.append('file', file);
                        uploadData.append('field', field);
                        return $.ajax({
                            url: 'api/upload.php',
                            type: 'POST',
                            data: uploadData,
                            processData: false,
                            contentType: false,
                            dataType: 'json'
                        }).then(response => {
                            if (response.path) {
                                formData.set(field, response.path);
                            } else {
                                throw new Error(`Failed to upload ${field}`);
                            }
                        });
                    } else if (isRequired && (!file || file.size === 0)) {
                        // If required and no file is provided, throw an error
                        return Promise.reject(new Error(`${field} is required but no file was uploaded`));
                    }
                    return Promise.resolve();
                })).then(() => {
                    // Prepare JSON data
                    const jsonData = {};
                    formData.forEach((value, key) => {
                        if (value && key !== 'tsv') {
                            jsonData[key] = key === 'tsv' ? (value === '1' || value === 'true') : value;
                        }
                    });

                    // Submit to staff_master.php
                    $.ajax({
                        url: 'api/staff_master.php',
                        type: 'POST',
                        contentType: 'application/json',
                        data: JSON.stringify(jsonData),
                        dataType: 'json',
                        success: function(response) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success',
                                text: response.message || 'Staff registered successfully'
                            }).then(() => {
                                form[0].reset();
                                form.steps('reset');
                                location.reload();
                            });
                        },
                        error: function(xhr, status, error) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to register staff: ' + (xhr.responseJSON?.error || error)
                            });
                        },
                        complete: function() {
                            $('.actions a[href="#finish"]').removeClass('btn-loading');
                        }
                    });
                }).catch(error => {
                    $('.actions a[href="#finish"]').removeClass('btn-loading');
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: error.message || 'Failed to upload files'
                    });
                });
            }
        });
    </script>
</body>
</html>