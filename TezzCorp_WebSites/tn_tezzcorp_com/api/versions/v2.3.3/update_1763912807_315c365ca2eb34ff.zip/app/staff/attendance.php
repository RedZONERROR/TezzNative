<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Staff Attendance - AI-ERP 2.0</title>
    <style>
        /* Toggle Button Style */
        .switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
        }
        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 24px;
        }
        .slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        .round {
            width: 50px !important;
            height: auto !important;
        }
        input:checked + .slider {
            background-color: #4CAF50;
        }
        input:checked + .slider:before {
            transform: translateX(26px);
        }
        /* Spinner Styles */
        .btn-loading .fa-spinner {
            display: inline-block;
        }
        .btn-loading .btn-text, .btn-loading .ti {
            display: none;
        }
        .fa-spinner {
            display: none;
            font-size: 0.9rem;
        }
        .action-buttons {
            display: none;
        }
        .pagination {
            margin-top: 1rem;
        }
        .in-time-cell, .out-time-cell {
            white-space: nowrap;
            font-size: 0.85rem;
        }
        .action-btn-group .btn {
            margin-right: 0.5rem;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!-- Sidebar End -->
        <div class="page-wrapper">
            <!-- Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!-- Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Manage Staff Attendance</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Attendance
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Attendance Management -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-4 col-xl-3">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Staff..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-8 col-xl-9 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div class="action-buttons me-2">
                                        <button class="mark-in btn bg-success-subtle text-success btn-sm me-1">
                                            <i class="fas fa-spinner fa-spin"></i>
                                            <span class="btn-text">Mark In</span>
                                        </button>
                                        <button class="mark-out btn bg-warning-subtle text-warning btn-sm me-1">
                                            <i class="fas fa-spinner fa-spin"></i>
                                            <span class="btn-text">Mark Out</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card card-body">
                            <div class="d-flex justify-content-center">
                                <div class="spinner-border text-primary" role="status" id="table-loader">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <th>
                                            <div class="n-chk align-self-center text-center">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input primary" id="contact-check-all" />
                                                    <label class="form-check-label" for="contact-check-all"></label>
                                                    <span class="new-control-indicator"></span>
                                                </div>
                                            </div>
                                        </th>
                                        <th>Staff's Name</th>
                                        <th>Attendance Date</th>
                                        <th>In Time</th>
                                        <th>Out Time</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody id="staff_attendance_table_body">
                                        <!-- Data will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <nav aria-label="Page navigation" id="pagination-nav">
                                <ul class="pagination justify-content-center">
                                    <!-- Pagination controls -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="dark-transparent sidebartoggler"></div>
    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        hljs.initHighlightingOnLoad();
        document.querySelectorAll("pre.code-view > code").forEach((codeBlock) => {
            codeBlock.textContent = codeBlock.innerHTML;
        });

        $(document).ready(function() {
            // Pagination state
            let currentPage = 1;
            const perPage = 10;
            const currentDate = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

            // Fetch staff and attendance data with pagination
            function fetchAttendance(page = 1) {
                $('#table-loader').show();
                $('#staff_attendance_table_body').empty();

                $.ajax({
                    url: 'api/staff_master.php',
                    type: 'GET',
                    data: { page: page, perPage: perPage },
                    dataType: 'json',
                    success: function(staffResponse) {
                        const staff = staffResponse.data || [];
                        const meta = staffResponse.meta || { page: 1, totalPages: 1, totalItems: staff.length };
                        if (staff.length === 0) {
                            $('#staff_attendance_table_body').html('<tr><td colspan="7" class="text-center">No staff found.</td></tr>');
                            renderPagination(meta);
                            $('#table-loader').hide();
                            return;
                        }

                        // Fetch attendance for today for the current page of staff
                        const attendancePromises = staff.map(s => 
                            $.ajax({
                                url: 'api/staff_attendance_master.php',
                                type: 'GET',
                                data: { staff_id: s.id, date: currentDate },
                                dataType: 'json'
                            }).then(res => ({ staff_id: s.id, attendance: res.data || [] }))
                        );

                        Promise.all(attendancePromises).then(results => {
                            renderAttendanceTable(staff, results);
                            renderPagination(meta);
                            $('#table-loader').hide();
                        }).catch(error => {
                            $('#table-loader').hide();
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to load attendance data.'
                            });
                            console.error('Attendance Error:', error);
                            renderPagination(meta);
                        });
                    },
                    error: function(xhr, status, error) {
                        $('#table-loader').hide();
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load staff data: ' + (xhr.responseJSON?.error || error)
                        });
                        renderPagination({ page: 1, totalPages: 1, totalItems: 0 });
                    }
                });
            }

            // Render attendance table
            function renderAttendanceTable(staff, attendanceResults) {
                const tbody = $('#staff_attendance_table_body');
                tbody.empty();
                staff.forEach(s => {
                    const attRecords = attendanceResults.find(r => r.staff_id === s.id)?.attendance || [];
                    const inRecord = attRecords.find(a => a.attendance === 'In') || {};
                    const outRecord = attRecords.find(a => a.attendance === 'Out') || {};
                    const inId = inRecord.id || '';
                    const outId = outRecord.id || '';
                    const attDate = inRecord.date || outRecord.date || '-';
                    const inTime = inRecord.time ? inRecord.time.substring(0, 5) : '-';
                    const outTime = outRecord.time ? outRecord.time.substring(0, 5) : '-';
                    const inTimeFull = inRecord.time || ''; // Full HH:MM:SS
                    const outTimeFull = outRecord.time || ''; // Full HH:MM:SS
                    const attStatus = inRecord.status === '1' || outRecord.status === '1' ? '1' : '0';
                    const row = `
                        <tr data-staff-id="${s.id}" data-in-id="${inId}" data-out-id="${outId}" data-in-time="${inTimeFull}" data-out-time="${outTimeFull}">
                            <td>
                                <div class="n-chk align-self-center text-center">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input staff-check" value="${s.id}" />
                                        <label class="form-check-label"></label>
                                    </div>
                                </div>
                            </td>
                            <td>${s.name || '-'}</td>
                            <td>${attDate}</td>
                            <td class="in-time-cell">${inTime}</td>
                            <td class="out-time-cell">${outTime}</td>
                            <td>
                                <label class="switch">
                                    <input type="checkbox" class="attendance-toggle" ${attStatus === '1' ? 'checked' : ''}>
                                    <span class="slider round"></span>
                                </label>
                            </td>
                            <td>
                                <div class="action-btn-group">
                                    <button class="mark-in-row btn btn-sm bg-success-subtle text-success" ${inId ? 'disabled' : ''}>
                                        <i class="fas fa-spinner fa-spin"></i>
                                        <span class="btn-text">In</span>
                                    </button>
                                    <button class="mark-out-row btn btn-sm bg-warning-subtle text-warning" ${outId || !inId ? 'disabled' : ''}>
                                        <i class="fas fa-spinner fa-spin"></i>
                                        <span class="btn-text">Out</span>
                                    </button>
                                    <button class="delete-attendance btn btn-sm btn-danger" data-in-id="${inId}" data-out-id="${outId}" ${inId || outId ? '' : 'disabled'}>
                                        <i class="fas fa-spinner fa-spin"></i>
                                        <i class="ti ti-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>`;
                    tbody.append(row);
                });
            }

            // Render pagination
            function renderPagination(meta) {
                const pagination = $('#pagination-nav ul');
                pagination.empty();

                // Fallback values
                const currentPage = meta.page || 1;
                const totalPages = meta.totalPages || 1;

                // Always render pagination
                pagination.append(`
                    <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
                    </li>
                `);

                for (let p = 1; p <= totalPages; p++) {
                    pagination.append(`
                        <li class="page-item ${p === currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${p}">${p}</a>
                        </li>
                    `);
                }

                pagination.append(`
                    <li class="page-item ${currentPage >= totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
                    </li>
                `);
            }

            // Pagination click
            $(document).on('click', '#pagination-nav a', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && page !== currentPage) {
                    currentPage = page;
                    fetchAttendance(page);
                }
            });

            // Toggle action buttons
            function toggleActionButtons() {
                const checked = $('.staff-check:checked').length;
                $('.action-buttons').toggle(checked > 0);
            }

            // Select all checkboxes
            $('#contact-check-all').on('change', function() {
                $('.staff-check').prop('checked', this.checked);
                toggleActionButtons();
            });

            // Individual checkbox change
            $(document).on('change', '.staff-check', toggleActionButtons);

            // Search functionality
            $('#input-search').on('keyup', function() {
                const search = $(this).val().toLowerCase();
                $('#staff_attendance_table_body tr').each(function() {
                    const text = $(this).find('td:eq(1)').text().toLowerCase();
                    $(this).toggle(text.includes(search));
                });
            });

            // Mark In or Out (bulk)
            function markAttendance(attendanceType, staffIds, button) {
                if (staffIds.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Selection',
                        text: `Please select at least one staff to mark ${attendanceType}.`
                    });
                    return;
                }

                Swal.fire({
                    title: `Mark ${attendanceType}`,
                    text: `Mark ${staffIds.length} staff as ${attendanceType} for today?`,
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: `Yes, mark ${attendanceType}!`,
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        button.addClass('btn-loading');
                        const now = new Date();
                        const date = now.toISOString().split('T')[0];
                        const time = now.toTimeString().split(' ')[0];

                        const promises = staffIds.map(staff_id => {
                            // Check if attendance record exists
                            return $.ajax({
                                url: 'api/staff_attendance_master.php',
                                type: 'GET',
                                data: { staff_id: staff_id, date: date }
                            }).then(res => {
                                const existing = res.data.find(a => a.attendance === attendanceType);
                                if (existing) {
                                    return Promise.resolve(); // Skip if exists
                                }
                                // For Mark Out, ensure In exists
                                if (attendanceType === 'Out' && !res.data.find(a => a.attendance === 'In')) {
                                    return Promise.resolve(); // Skip if no In record
                                }
                                return $.ajax({
                                    url: 'api/staff_attendance_master.php',
                                    type: 'POST',
                                    contentType: 'application/json',
                                    data: JSON.stringify({
                                        staff_id: staff_id,
                                        date: date,
                                        time: time,
                                        status: '1',
                                        attendance: attendanceType
                                    }),
                                    dataType: 'json'
                                });
                            });
                        });

                        Promise.all(promises).then(() => {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success',
                                text: `${attendanceType} marked successfully`
                            });
                            fetchAttendance(currentPage); // Refresh table
                        }).catch(xhr => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: `Failed to mark ${attendanceType}: ` + (xhr.responseJSON?.error || xhr.statusText)
                            });
                        }).finally(() => {
                            button.removeClass('btn-loading');
                        });
                    }
                });
            }

            $('.mark-in').on('click', function() {
                const selected = $('.staff-check:checked').map(function() { return $(this).val(); }).get();
                markAttendance('In', selected, $(this));
            });

            $('.mark-out').on('click', function() {
                const selected = $('.staff-check:checked').map(function() { return $(this).val(); }).get();
                markAttendance('Out', selected, $(this));
            });

            // Mark In or Out (per row)
            $(document).on('click', '.mark-in-row, .mark-out-row', function() {
                const row = $(this).closest('tr');
                const staffId = row.data('staff-id');
                const attendanceType = $(this).hasClass('mark-in-row') ? 'In' : 'Out';
                const button = $(this);

                Swal.fire({
                    title: `Mark ${attendanceType}`,
                    text: `Mark ${row.find('td:eq(1)').text()} as ${attendanceType} for today?`,
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: `Yes, mark ${attendanceType}!`,
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        button.addClass('btn-loading');
                        const now = new Date();
                        const date = now.toISOString().split('T')[0];
                        const time = now.toTimeString().split(' ')[0];

                        // Check if attendance record exists
                        $.ajax({
                            url: 'api/staff_attendance_master.php',
                            type: 'GET',
                            data: { staff_id: staffId, date: date }
                        }).then(res => {
                            const existing = res.data.find(a => a.attendance === attendanceType);
                            if (existing) {
                                Swal.fire({
                                    icon: 'info',
                                    title: 'Already Marked',
                                    text: `${attendanceType} already marked for this staff.`
                                });
                                button.removeClass('btn-loading');
                                return;
                            }
                            // For Mark Out, ensure In exists
                            if (attendanceType === 'Out' && !res.data.find(a => a.attendance === 'In')) {
                                Swal.fire({
                                    icon: 'warning',
                                    title: 'Cannot Mark Out',
                                    text: 'Please mark In first.'
                                });
                                button.removeClass('btn-loading');
                                return;
                            }
                            return $.ajax({
                                url: 'api/staff_attendance_master.php',
                                type: 'POST',
                                contentType: 'application/json',
                                data: JSON.stringify({
                                    staff_id: staffId,
                                    date: date,
                                    time: time,
                                    status: '1',
                                    attendance: attendanceType
                                }),
                                dataType: 'json'
                            }).then(response => {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Success',
                                    text: `${attendanceType} marked successfully`
                                });
                                fetchAttendance(currentPage); // Refresh table
                            });
                        }).catch(xhr => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: `Failed to mark ${attendanceType}: ` + (xhr.responseJSON?.error || xhr.statusText)
                            });
                        }).finally(() => {
                            button.removeClass('btn-loading');
                        });
                    }
                });
            });

            // Toggle attendance status (affects both In and Out records)
            $(document).on('change', '.attendance-toggle', function() {
                const row = $(this).closest('tr');
                const staffId = row.data('staff-id');
                const inId = row.data('in-id');
                const outId = row.data('out-id');
                const inTimeFull = row.data('in-time') || new Date().toTimeString().split(' ')[0];
                const outTimeFull = row.data('out-time') || new Date().toTimeString().split(' ')[0];
                const status = $(this).is(':checked') ? '1' : '0';
                const date = row.find('td:eq(2)').text() !== '-' ? row.find('td:eq(2)').text() : new Date().toISOString().split('T')[0];

                const promises = [];

                // Handle In record
                if (inId) {
                    promises.push(
                        $.ajax({
                            url: 'api/staff_attendance_master.php',
                            type: 'PUT',
                            contentType: 'application/json',
                            data: JSON.stringify({
                                id: inId,
                                staff_id: staffId,
                                date: date,
                                time: inTimeFull,
                                status: status,
                                attendance: 'In'
                            }),
                            dataType: 'json'
                        })
                    );
                } else if (status === '1') {
                    promises.push(
                        $.ajax({
                            url: 'api/staff_attendance_master.php',
                            type: 'POST',
                            contentType: 'application/json',
                            data: JSON.stringify({
                                staff_id: staffId,
                                date: date,
                                time: inTimeFull,
                                status: status,
                                attendance: 'In'
                            }),
                            dataType: 'json'
                        })
                    );
                }

                // Handle Out record
                if (outId) {
                    promises.push(
                        $.ajax({
                            url: 'api/staff_attendance_master.php',
                            type: 'PUT',
                            contentType: 'application/json',
                            data: JSON.stringify({
                                id: outId,
                                staff_id: staffId,
                                date: date,
                                time: outTimeFull,
                                status: status,
                                attendance: 'Out'
                            }),
                            dataType: 'json'
                        })
                    );
                } else if (status === '1' && row.find('td:eq(3)').text() !== '-') {
                    // Only create Out record if In exists
                    promises.push(
                        $.ajax({
                            url: 'api/staff_attendance_master.php',
                            type: 'POST',
                            contentType: 'application/json',
                            data: JSON.stringify({
                                staff_id: staffId,
                                date: date,
                                time: outTimeFull,
                                status: status,
                                attendance: 'Out'
                            }),
                            dataType: 'json'
                        })
                    );
                }

                Promise.all(promises).then(results => {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Attendance updated'
                    });
                    fetchAttendance(currentPage); // Refresh table
                }).catch(xhr => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to update attendance: ' + (xhr.responseJSON?.error || xhr.statusText)
                    });
                    $(this).prop('checked', !$(this).is(':checked')); // Revert toggle
                });
            });

            // Delete attendance
            $(document).on('click', '.delete-attendance', function() {
                const inId = $(this).data('in-id');
                const outId = $(this).data('out-id');
                if (!inId && !outId) return;

                Swal.fire({
                    title: 'Are you sure?',
                    text: 'Delete this attendance record?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        const promises = [];
                        if (inId) {
                            promises.push(
                                $.ajax({
                                    url: 'api/staff_attendance_master.php',
                                    type: 'DELETE',
                                    contentType: 'application/json',
                                    data: JSON.stringify({ id: inId }),
                                    dataType: 'json'
                                })
                            );
                        }
                        if (outId) {
                            promises.push(
                                $.ajax({
                                    url: 'api/staff_attendance_master.php',
                                    type: 'DELETE',
                                    contentType: 'application/json',
                                    data: JSON.stringify({ id: outId }),
                                    dataType: 'json'
                                })
                            );
                        }

                        Promise.all(promises).then(() => {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted',
                                text: 'Attendance record(s) deleted'
                            });
                            fetchAttendance(currentPage); // Refresh table
                        }).catch(xhr => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to delete attendance: ' + (xhr.responseJSON?.error || xhr.statusText)
                            });
                        }).finally(() => {
                            $(this).removeClass('btn-loading');
                        });
                    }
                });
            });

            // Initial load
            fetchAttendance(currentPage);
        });
    </script>
</body>
</html>