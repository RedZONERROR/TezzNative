<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- jsPDF and AutoTable -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js"></script>
    <!-- SheetJS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <!-- Highlight.js (fallback) -->
    <script src="https://cdn.jsdelivr.net/npm/highlight.js@11.9.0/lib/highlight.min.js"></script>

    <title>Staff Attendance Report - AI-ERP 2.0</title>
    <style>
        #table-loader {
            display: none;
        }
        .pagination {
            margin-top: 1rem;
        }
        .export-btn {
            margin-right: 0.5rem;
        }
        .btn-spinner {
            display: none;
            font-size: 0.8rem; /* Match button text size */
        }
        .btn-outline-primary .btn-spinner {
            color: #0d6efd; /* Match primary color */
        }
        .btn-outline-success .btn-spinner {
            color: #198754; /* Match success color */
        }
        .in-out-cell {
            white-space: nowrap;
            font-size: 0.85rem;
        }
        th {
            white-space: nowrap;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!-- Sidebar End -->
        <div class="page-wrapper">
            <!-- Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!-- Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Staff Attendance Report</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Attendance Report
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Attendance Report -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-4 col-xl-3">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Staff..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-8 col-xl-9 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div class="form-group me-2">
                                        <input type="month" class="form-control" id="monthPicker">
                                    </div>
                                    <button class="btn btn-outline-primary btn-sm export-btn" id="export-pdf">
                                        <span class="btn-content"><i class="fas fa-file-pdf"></i> PDF</span>
                                        <span class="btn-spinner" role="status" aria-hidden="true"><i class="fas fa-spinner fa-spin"></i></span>
                                    </button>
                                    <button class="btn btn-outline-success btn-sm export-btn" id="export-excel">
                                        <span class="btn-content"><i class="fas fa-file-excel"></i> Excel</span>
                                        <span class="btn-spinner" role="status" aria-hidden="true"><i class="fas fa-spinner fa-spin"></i></span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="card card-body" id="attendance-table">
                            <div class="d-flex justify-content-center">
                                <div class="spinner-border text-primary" role="status" id="table-loader">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <tr id="header-row">
                                            <th>SN</th>
                                            <th>Staff Name</th>
                                            <!-- Days added dynamically -->
                                        </tr>
                                    </thead>
                                    <tbody id="staff_attendance_table_body">
                                        <!-- Data will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <nav aria-label="Page navigation" id="pagination-nav">
                                <ul class="pagination justify-content-center">
                                    <!-- Pagination controls -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="dark-transparent sidebartoggler"></div>
    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        $(document).ready(function() {
            // Set month picker to March 2025 to match sample data
            $('#monthPicker').val('2025-03');

            // Pagination state
            let currentPage = 1;
            const perPage = 10;

            // Fetch attendance report
            function fetchAttendanceReport(year, month, page = 1) {
                $('#table-loader').show();
                $('#staff_attendance_table_body').empty();
                $('#header-row').html('<th>SN</th><th>Staff Name</th>');

                // Ensure month is string
                month = String(month).padStart(2, '0');

                // Get days in month
                const daysInMonth = new Date(year, parseInt(month), 0).getDate();
                const days = [];
                for (let d = 1; d <= daysInMonth; d++) {
                    const date = `${year}-${month}-${String(d).padStart(2, '0')}`;
                    days.push(date);
                }

                // Fetch staff with pagination
                $.ajax({
                    url: 'api/staff_master.php',
                    type: 'GET',
                    data: { page: page, perPage: perPage },
                    dataType: 'json',
                    success: function(staffResponse) {
                        console.log('Staff Response:', staffResponse);
                        const staff = staffResponse.data || [];
                        const meta = staffResponse.meta || { page: 1, totalPages: 1, totalItems: staff.length };
                        console.log('Meta:', meta);
                        if (staff.length === 0) {
                            $('#staff_attendance_table_body').html('<tr><td colspan="2" class="text-center">No staff found.</td></tr>');
                            $('#table-loader').hide();
                            renderPagination(meta);
                            return;
                        }

                        // Fetch all attendance for month
                        $.ajax({
                            url: 'api/staff_attendance_master.php',
                            type: 'GET',
                            data: { date_like: `${year}-${month}%` },
                            dataType: 'json',
                            success: function(attResponse) {
                                console.log('Attendance Response:', attResponse);
                                const attendance = attResponse.data || [];
                                const workingDays = [...new Set(attendance.map(a => a.date))].length;
                                renderAttendanceTable(staff, attendance, days, workingDays);
                                renderPagination(meta);
                                $('#table-loader').hide();
                            },
                            error: function(xhr) {
                                console.log('Attendance Error:', xhr.responseJSON || xhr.statusText);
                                $('#table-loader').hide();
                                renderPagination(meta);
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to load attendance: ' + (xhr.responseJSON?.error || xhr.statusText)
                                });
                            }
                        });
                    },
                    error: function(xhr) {
                        console.log('Staff Error:', xhr.responseJSON || xhr.statusText);
                        $('#table-loader').hide();
                        renderPagination({ page: 1, totalPages: 1, totalItems: 0 });
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load staff: ' + (xhr.responseJSON?.error || xhr.statusText)
                        });
                    }
                });
            }

            // Render attendance table
            function renderAttendanceTable(staff, attendance, days, workingDays) {
                const headerRow = $('#header-row');
                const tbody = $('#staff_attendance_table_body');

                // Add day columns
                days.forEach(date => {
                    const d = new Date(date);
                    const day = d.getDate();
                    const th = $('<th>').text(`${day} ${d.toLocaleString('default', { month: 'short' })}`);
                    headerRow.append(th);
                });
                headerRow.append('<th>Present</th><th>Absent</th><th>Working Days</th><th>Average</th>');

                // Check if no attendance records exist
                if (attendance.length === 0) {
                    const colspan = days.length + 4; // SN, Staff Name, days, Present, Absent, Working Days, Average
                    tbody.html(`<tr><td colspan="${colspan}" class="text-center">No attendance records found for this month.</td></tr>`);
                    return;
                }

                // Build rows
                staff.forEach((s, index) => {
                    const tr = $('<tr>');
                    tr.append(`<td>${(currentPage - 1) * perPage + index + 1}</td><td>${s.name || '-'}</td>`);
                    let present = 0;

                    days.forEach(date => {
                        const attRecords = attendance.filter(a => a.staff_id === s.id && a.date === date);
                        const inRecord = attRecords.find(a => a.attendance === 'In' && a.status === '1');
                        const outRecord = attRecords.find(a => a.attendance === 'Out' && a.status === '1');
                        const inTime = inRecord ? inRecord.time.substring(0, 5) : '-';
                        const outTime = outRecord ? outRecord.time.substring(0, 5) : '-';
                        const display = inRecord ? `In: ${inTime} / Out: ${outTime}` : '✗';
                        const colorClass = inRecord ? 'present' : 'absent';
                        if (inRecord) present++;
                        tr.append(`<td class="${colorClass} in-out-cell">${display}</td>`);
                    });

                    const absent = workingDays - present;
                    const average = workingDays > 0 ? ((present / workingDays) * 100).toFixed(1) : '0.0';
                    tr.append(`<td>${present}</td><td>${absent}</td><td>${workingDays}</td><td>${average}%</td>`);
                    tbody.append(tr);
                });
            }

            // Render pagination
            function renderPagination(meta) {
                const pagination = $('#pagination-nav ul');
                pagination.empty();

                // Fallback values
                const currentPage = meta.page || 1;
                const totalPages = meta.totalPages || 1;

                // Always render pagination
                pagination.append(`
                    <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
                    </li>
                `);

                for (let p = 1; p <= totalPages; p++) {
                    pagination.append(`
                        <li class="page-item ${p === currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${p}">${p}</a>
                        </li>
                    `);
                }

                pagination.append(`
                    <li class="page-item ${currentPage >= totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
                    </li>
                `);
            }

            // Pagination click
            $(document).on('click', '#pagination-nav a', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && page !== currentPage) {
                    currentPage = page;
                    const [year, month] = $('#monthPicker').val().split('-').map(Number);
                    fetchAttendanceReport(year, month, page);
                }
            });

            // Month picker change
            $('#monthPicker').on('change', function() {
                const value = $(this).val();
                const [year, month] = value.split('-').map(Number);
                currentPage = 1;
                fetchAttendanceReport(year, month);
            });

            // Search functionality
            $('#input-search').on('keyup', function() {
                const search = $(this).val().toLowerCase();
                $('#staff_attendance_table_body tr').each(function() {
                    const text = $(this).find('td:eq(1)').text().toLowerCase();
                    $(this).toggle(text.includes(search));
                });
            });

            // Export PDF
            $('#export-pdf').on('click', function() {
                const $btn = $(this);
                $btn.find('.btn-content').hide();
                $btn.find('.btn-spinner').show();
                const { jsPDF } = window.jspdf;
                const doc = new jsPDF('l', 'mm', 'a3');
                const [year, month] = $('#monthPicker').val().split('-').map(Number);
                const monthStr = String(month).padStart(2, '0');

                // Fetch all staff
                $.ajax({
                    url: 'api/staff_master.php',
                    type: 'GET',
                    data: { perPage: 1000 },
                    dataType: 'json',
                    success: function(staffResponse) {
                        console.log('PDF Staff Response:', staffResponse);
                        const staff = staffResponse.data || [];
                        if (staff.length === 0) {
                            doc.text('No staff data available.', 14, 20);
                            doc.save(`attendance_report_${year}_${monthStr}.pdf`);
                            $btn.find('.btn-spinner').hide();
                            $btn.find('.btn-content').show();
                            return;
                        }

                        // Fetch all attendance for month
                        $.ajax({
                            url: 'api/staff_attendance_master.php',
                            type: 'GET',
                            data: { date_like: `${year}-${monthStr}%` },
                            dataType: 'json',
                            success: function(attResponse) {
                                console.log('PDF Attendance Response:', attResponse);
                                const attendance = attResponse.data || [];
                                if (attendance.length === 0) {
                                    doc.text('No attendance data available for this period.', 14, 20);
                                    doc.save(`attendance_report_${year}_${monthStr}.pdf`);
                                    $btn.find('.btn-spinner').hide();
                                    $btn.find('.btn-content').show();
                                    return;
                                }

                                const daysInMonth = new Date(year, month, 0).getDate();
                                const days = [];
                                for (let d = 1; d <= daysInMonth; d++) {
                                    days.push(`${year}-${monthStr}-${String(d).padStart(2, '0')}`);
                                }
                                const workingDays = [...new Set(attendance.map(a => a.date))].length;

                                // Prepare table data
                                const headers = ['SN', 'Staff Name'];
                                days.forEach(date => {
                                    const d = new Date(date);
                                    headers.push(`${d.getDate()} ${d.toLocaleString('default', { month: 'short' })}`);
                                });
                                headers.push('Present', 'Absent', 'Working Days', 'Average');

                                const rows = staff.map((s, index) => {
                                    const row = [(index + 1), s.name || '-'];
                                    let present = 0;
                                    days.forEach(date => {
                                        const attRecords = attendance.filter(a => a.staff_id === s.id && a.date === date);
                                        const inRecord = attRecords.find(a => a.attendance === 'In' && a.status === '1');
                                        const outRecord = attRecords.find(a => a.attendance === 'Out' && a.status === '1');
                                        const inTime = inRecord ? inRecord.time.substring(0, 5) : '-';
                                        const outTime = outRecord ? outRecord.time.substring(0, 5) : '-';
                                        const display = inRecord ? `In: ${inTime}/Out: ${outTime}` : 'A';
                                        if (inRecord) present++;
                                        row.push(display);
                                    });
                                    const absent = workingDays - present;
                                    const average = workingDays > 0 ? ((present / workingDays) * 100).toFixed(1) : '0.0';
                                    row.push(present, absent, workingDays, `${average}%`);
                                    return row;
                                });

                                console.log('PDF Headers:', headers);
                                console.log('PDF Rows:', rows);

                                // Calculate dynamic font size and column width
                                const totalColumns = headers.length;
                                const fontSize = Math.max(6, Math.min(8, 300 / totalColumns));
                                const columnWidth = Math.max(8, 380 / totalColumns);

                                // Generate PDF
                                doc.setFontSize(12);
                                doc.text(`Staff Attendance Report - ${year}-${monthStr}`, 14, 10);
                                doc.autoTable({
                                    head: [headers],
                                    body: rows,
                                    theme: 'grid',
                                    headStyles: { fillColor: [41, 128, 185], fontSize: fontSize, textColor: [255, 255, 255] },
                                    styles: { fontSize: fontSize, cellPadding: 1, overflow: 'linebreak' },
                                    columnStyles: {
                                        0: { cellWidth: 15 },
                                        1: { cellWidth: 40 },
                                    },
                                    margin: { top: 20 },
                                    pageBreak: 'auto',
                                    tableWidth: 'auto',
                                    startY: 20
                                });
                                doc.save(`attendance_report_${year}_${monthStr}.pdf`);
                                $btn.find('.btn-spinner').hide();
                                $btn.find('.btn-content').show();
                            },
                            error: function(xhr) {
                                console.log('PDF Attendance Error:', xhr.responseJSON || xhr.statusText);
                                doc.text('Error fetching attendance data.', 14, 20);
                                doc.save(`attendance_report_${year}_${monthStr}.pdf`);
                                $btn.find('.btn-spinner').hide();
                                $btn.find('.btn-content').show();
                            }
                        });
                    },
                    error: function(xhr) {
                        console.log('PDF Staff Error:', xhr.responseJSON || xhr.statusText);
                        doc.text('Error fetching staff data.', 14, 20);
                        doc.save(`attendance_report_${year}_${monthStr}.pdf`);
                        $btn.find('.btn-spinner').hide();
                        $btn.find('.btn-content').show();
                    }
                });
            });

            // Export Excel
            $('#export-excel').on('click', function() {
                const $btn = $(this);
                $btn.find('.btn-content').hide();
                $btn.find('.btn-spinner').show();
                const [year, month] = $('#monthPicker').val().split('-').map(Number);
                const monthStr = String(month).padStart(2, '0');

                // Fetch all staff
                $.ajax({
                    url: 'api/staff_master.php',
                    type: 'GET',
                    data: { perPage: 1000 },
                    dataType: 'json',
                    success: function(staffResponse) {
                        const staff = staffResponse.data || [];
                        $.ajax({
                            url: 'api/staff_attendance_master.php',
                            type: 'GET',
                            data: { date_like: `${year}-${monthStr}%` },
                            dataType: 'json',
                            success: function(attResponse) {
                                const attendance = attResponse.data || [];
                                const daysInMonth = new Date(year, month, 0).getDate();
                                const days = [];
                                for (let d = 1; d <= daysInMonth; d++) {
                                    days.push(`${year}-${monthStr}-${String(d).padStart(2, '0')}`);
                                }
                                const workingDays = [...new Set(attendance.map(a => a.date))].length;

                                // Prepare table data
                                const headers = ['SN', 'Staff Name'];
                                days.forEach(date => {
                                    const d = new Date(date);
                                    headers.push(`${d.getDate()} ${d.toLocaleString('default', { month: 'short' })}`);
                                });
                                headers.push('Present', 'Absent', 'Working Days', 'Average');

                                const rows = staff.map((s, index) => {
                                    const row = [(index + 1), s.name || '-'];
                                    let present = 0;
                                    days.forEach(date => {
                                        const attRecords = attendance.filter(a => a.staff_id === s.id && a.date === date);
                                        const inRecord = attRecords.find(a => a.attendance === 'In' && a.status === '1');
                                        const outRecord = attRecords.find(a => a.attendance === 'Out' && a.status === '1');
                                        const inTime = inRecord ? inRecord.time.substring(0, 5) : '-';
                                        const outTime = outRecord ? outRecord.time.substring(0, 5) : '-';
                                        const display = inRecord ? `In: ${inTime}/Out: ${outTime}` : '✗';
                                        if (inRecord) present++;
                                        row.push(display);
                                    });
                                    const absent = workingDays - present;
                                    const average = workingDays > 0 ? ((present / workingDays) * 100).toFixed(1) : '0.0';
                                    row.push(present, absent, workingDays, `${average}%`);
                                    return row;
                                });

                                // Generate Excel
                                const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
                                ws['!cols'] = headers.map((_, i) => ({ wch: i === 1 ? 20 : i < 2 ? 10 : 15 }));
                                const wb = XLSX.utils.book_new();
                                XLSX.utils.book_append_sheet(wb, ws, 'Attendance');
                                XLSX.writeFile(wb, `attendance_report_${year}_${monthStr}.xlsx`);
                                $btn.find('.btn-spinner').hide();
                                $btn.find('.btn-content').show();
                            },
                            error: function(xhr) {
                                console.log('Excel Attendance Error:', xhr.responseJSON || xhr.statusText);
                                $btn.find('.btn-spinner').hide();
                                $btn.find('.btn-content').show();
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to export Excel: ' + (xhr.responseJSON?.error || xhr.statusText)
                                });
                            }
                        });
                    },
                    error: function(xhr) {
                        console.log('Excel Staff Error:', xhr.responseJSON || xhr.statusText);
                        $btn.find('.btn-spinner').hide();
                        $btn.find('.btn-content').show();
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to export Excel: ' + (xhr.responseJSON?.error || xhr.statusText)
                        });
                    }
                });
            });

            // Initial load
            fetchAttendanceReport(2025, 3);
        });
    </script>
</body>
</html>