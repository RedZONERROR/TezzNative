<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- Select2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">

    <title>Fee Reports - AI-ERP 2.0</title>
    <style>
        /* Reference UI Styling Integration */
        .card {
            border-radius: 0.75rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            border: none;
            margin-bottom: 1.5rem;
        }
        .card-header {
            /*background-color: #f8f9fa;*/
            border-bottom: 1px solid #e9ecef;
            padding: 1rem 1.5rem;
        }
        
        /* Stats Cards Special Styling */
        .stats-card {
            background: white;
            position: relative;
            overflow: hidden;
            transition: transform 0.2s;
        }
        .stats-card:hover {
            transform: translateY(-2px);
        }
        .stats-card::after {
            content: '';
            position: absolute;
            top: 0; right: 0; width: 100px; height: 100%;
            background: linear-gradient(90deg, transparent, rgba(99, 102, 241, 0.05));
            pointer-events: none;
        }
        .stats-label { 
            font-size: 0.75rem; 
            color: #64748b; 
            font-weight: 600; 
            text-transform: uppercase; 
            letter-spacing: 0.5px; 
            margin-bottom: 0.5rem;
        }
        .stats-value { 
            font-size: 1.5rem; 
            font-weight: 700; 
            color: #0f172a; 
            margin-bottom: 0;
        }
        .stats-icon { 
            position: absolute; 
            right: 1.5rem; 
            top: 50%; 
            transform: translateY(-50%); 
            font-size: 2rem; 
            opacity: 0.15; 
        }
        
        /* Search Input Styling */
        .product-search {
            border-radius: 0.5rem;
            border: 1px solid #dfe5ef;
            padding: 0.5rem 1rem 0.5rem 2.5rem;
            font-size: 0.875rem;
        }
        .product-search:focus {
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.1);
            border-color: #007bff;
        }

        /* Badge & Button Tweaks */
        .badge {
            font-size: 0.75rem;
            padding: 0.4em 0.8em;
            border-radius: 0.5rem;
        }
        .bg-success-subtle { background-color: #dcfce7 !important; color: #166534 !important; }
        .bg-danger-subtle { background-color: #fee2e2 !important; color: #991b1b !important; }
        .bg-warning-subtle { background-color: #fef9c3 !important; color: #854d0e !important; }

        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.85rem;
        }

        /* Select2 Overrides */
        .select2-container--bootstrap-5 .select2-selection {
            border-color: #dfe5ef;
            padding: 0.4rem 0.75rem;
            border-radius: 0.375rem;
        }

        .loading-overlay {
            position: absolute; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(255, 255, 255, 0.8);
            display: flex; align-items: center; justify-content: center;
            z-index: 10; backdrop-filter: blur(1px);
            border-radius: 0.75rem;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->
            
            <div class="body-wrapper">
                <div class="container-fluid">
                    
                    <!-- Header Section -->
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Fee Reports</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Fee Reports
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Statistics Section -->
                    <div class="row g-3 mb-4">
                        <div class="col-md-3">
                            <div class="card primary-gradient h-100 p-4">
                                <div class="stats-label">Total Transactions</div>
                                <div class="stats-value text-success" id="totalCollections">0</div>
                                <i class="fas fa-receipt stats-icon text-primary"></i>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card secondary-gradient h-100 p-4">
                                <div class="stats-label">Total Collected</div>
                                <div class="stats-value text-success" id="totalAmount">₹0.00</div>
                                <i class="fas fa-coins stats-icon text-success"></i>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card success-gradient h-100 p-4">
                                <div class="stats-label">Total Discount</div>
                                <div class="stats-value text-warning" id="totalDiscount">₹0.00</div>
                                <i class="fas fa-tags stats-icon text-warning"></i>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card danger-gradient h-100 p-4">
                                <div class="stats-label">Outstanding</div>
                                <div class="stats-value text-danger" id="pendingAmount">₹0.00</div>
                                <i class="fas fa-exclamation-circle stats-icon text-danger"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Filters Card -->
                    <div class="card mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center cursor-pointer" data-bs-toggle="collapse" data-bs-target="#filterCollapse">
                            <h5 class="card-title mb-0 text-primary"><i class="ti ti-filter me-2"></i>Advanced Filters</h5>
                            <i class="ti ti-chevron-down"></i>
                        </div>
                        <div id="filterCollapse" class="collapse show">
                            <div class="card-body">
                                <form id="filterForm" class="row g-3">
                                    <div class="col-md-3">
                                        <label class="form-label small text-muted">Class</label>
                                        <select class="form-select" id="filter_class" name="filter_class"><option value="">All Classes</option></select>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small text-muted">Student</label>
                                        <select class="form-select" id="filter_student" name="filter_student"><option value="">All Students</option></select>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small text-muted">Fee Type</label>
                                        <select class="form-select" id="filter_particular" name="filter_particular"><option value="">All Types</option></select>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small text-muted">Session</label>
                                        <select class="form-select" id="filter_session" name="filter_session"><option value="">All Sessions</option></select>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small text-muted">Method</label>
                                        <select class="form-select" id="filter_payment_method" name="filter_payment_method">
                                            <option value="">All</option>
                                            <option value="cash">Cash</option>
                                            <option value="online">Online/UPI</option>
                                            <option value="cheque">Cheque</option>
                                            <option value="card">Card</option>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small text-muted">Status</label>
                                        <select class="form-select" id="filter_status" name="filter_status">
                                            <option value="">All Status</option>
                                            <option value="completed">Completed</option>
                                            <option value="pending">Pending/Failed</option>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small text-muted">Date From</label>
                                        <input type="date" class="form-control" id="filter_date_from" name="filter_date_from">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small text-muted">Date To</label>
                                        <div class="input-group">
                                            <input type="date" class="form-control" id="filter_date_to" name="filter_date_to">
                                        </div>
                                    </div>
                                    <div class="col-12 text-end mt-3 border-top pt-3">
                                        <button type="button" id="clearFilters" class="btn btn-light border me-2"><i class="ti ti-refresh me-1"></i> Reset</button>
                                        <button type="button" id="applyFilters" class="btn btn-primary px-4"><i class="ti ti-search me-1"></i> Apply Filters</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Main Report Table -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row mb-3">
                                <div class="col-md-4 col-xl-3">
                                    <!-- Custom Search Input linked to DataTable -->
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search" placeholder="Search Receipt, Name..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-8 col-xl-9 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div id="tableExportButtons" class="d-none"></div> <!-- Hidden default DT buttons -->
                                    <button type="button" id="exportReport" class="btn btn-success d-flex align-items-center">
                                        <i class="ti ti-file-spreadsheet text-white me-2 fs-5"></i> Export CSV
                                    </button>
                                </div>
                            </div>

                            <div class="position-relative">
                                <div id="loadingOverlay" class="loading-overlay" style="display: none;">
                                    <div class="spinner-border text-primary" role="status"></div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-hover" id="feeReportTable">
                                        <thead>
                                            <tr>
                                                <th>Receipt</th>
                                                <th>Student Name</th>
                                                <th>Class</th>
                                                <th>Fee Type</th>
                                                <th>Paid</th>
                                                <th>Disc.</th>
                                                <th>Bal.</th>
                                                <th>Date</th>
                                                <th>Mode</th>
                                                <th>Status</th>
                                                <th class="text-end">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="reportTableBody">
                                            <!-- Data loaded via JS -->
                                        </tbody>
                                    </table>
                                </div>
                                
                                <!-- Custom Pagination Container if needed, DataTables handles this mostly -->
                                <div class="mt-3" id="dt-pagination-container"></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    
    <div class="dark-transparent sidebartoggler"></div>

    <!-- JS Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- Core JS -->
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script src="../assets/js/index.global.min.js"></script>

    <script>
        $(document).ready(function() {
            // Init Select2
            $('.form-select').select2({ theme: 'bootstrap-5', width: '100%' });

            let reportTable;
            
            // Load Initial Data
            loadDropdowns();
            loadReportData();

            // Events
            $('#applyFilters').click(loadReportData);
            $('#clearFilters').click(function() {
                $('#filterForm')[0].reset();
                $('.form-select').val('').trigger('change');
                loadReportData();
            });
            
            $('#filter_class').change(function() {
                const cid = $(this).val();
                if(cid) loadStudents(cid);
            });

            // Custom Search binding to DataTables
            $('#input-search').on('keyup', function() {
                if(reportTable) {
                    reportTable.search(this.value).draw();
                }
            });

            // Custom Export Button Logic
            $('#exportReport').click(function() {
                const params = $('#filterForm').serialize();
                const form = $('<form>', {
                    action: 'api/fee_report_master.php',
                    method: 'POST',
                    target: '_blank'
                }).append($('<input>', { type: 'hidden', name: 'action', value: 'export_report' }));

                // Append all filter fields
                $('#filterForm').find(':input').each(function() {
                    if(this.name) {
                        form.append($('<input>', { type: 'hidden', name: this.name, value: $(this).val() }));
                    }
                });

                $('body').append(form);
                form.submit();
                form.remove();
            });

            function loadDropdowns() {
                $.get('api/class_master.php', { status: 'active', perPage: 100 }, function(res) {
                    if(res.data) {
                        res.data.forEach(c => $('#filter_class').append(new Option(c.class_name, c.id)));
                    }
                });
                $.get('api/fee_report_master.php', { action: 'get_particulars' }, function(res) {
                    if(res.data) {
                        res.data.forEach(p => $('#filter_particular').append(new Option(p.particular, p.id)));
                    }
                });
                $.get('api/fee_report_master.php', { action: 'get_sessions' }, function(res) {
                    if(res.data) {
                        res.data.forEach(s => $('#filter_session').append(new Option(s, s)));
                    }
                });
            }

            function loadStudents(classId) {
                $.get('api/fee_report_master.php', { action: 'get_students_by_class', class_id: classId }, function(res) {
                    $('#filter_student').empty().append(new Option('All Students', ''));
                    if(res.data) {
                        res.data.forEach(s => $('#filter_student').append(new Option(s.full_name, s.id)));
                    }
                });
            }

            function loadReportData() {
                $('#loadingOverlay').show();
                const filters = $('#filterForm').serialize() + '&action=get_report';
                
                $.ajax({
                    url: 'api/fee_report_master.php',
                    data: filters,
                    method: 'GET',
                    dataType: 'json',
                    success: function(res) {
                        if(res.status === 'success') {
                            updateStats(res.statistics);
                            initTable(res.data);
                        }
                    },
                    error: function() {
                         $('#loadingOverlay').hide();
                         Swal.fire('Error', 'Failed to load data', 'error');
                    },
                    complete: function() { $('#loadingOverlay').hide(); }
                });
            }

            function updateStats(stats) {
                if(!stats) return;
                $('#totalCollections').text(stats.total_collections);
                $('#totalAmount').text('₹' + parseFloat(stats.total_amount).toLocaleString('en-IN', {minimumFractionDigits:2}));
                $('#totalDiscount').text('₹' + parseFloat(stats.total_discount).toLocaleString('en-IN', {minimumFractionDigits:2}));
                $('#pendingAmount').text('₹' + parseFloat(stats.pending_amount).toLocaleString('en-IN', {minimumFractionDigits:2}));
            }

            function initTable(data) {
                if(reportTable) reportTable.destroy();
                
                reportTable = $('#feeReportTable').DataTable({
                    data: data,
                    columns: [
                        { data: 'id', render: d => `<span class="text-muted">#${d}</span>` },
                        { data: 'student_name', render: (d, t, r) => `<div class="d-flex flex-column"><span class="fw-bold text-dark">${d}</span><small class="text-muted">${r.father_name}</small></div>` },
                        { data: 'class_name' },
                        { data: 'particular' },
                        { data: 'amount_collected', render: d => `<span class="text-success fw-bold">₹${parseFloat(d).toFixed(2)}</span>` },
                        { data: 'discount', render: d => parseFloat(d) > 0 ? `<span class="text-warning">₹${parseFloat(d).toFixed(2)}</span>` : '<span class="text-muted">-</span>' },
                        { data: 'remaining_balance', render: d => parseFloat(d) > 0 ? `<span class="badge bg-danger-subtle text-danger">₹${parseFloat(d).toFixed(2)}</span>` : '<span class="badge bg-success-subtle text-success">Cleared</span>' },
                        { data: 'payment_date', render: d => d ? new Date(d).toLocaleDateString('en-IN') : '-' },
                        { data: 'payment_method', render: d => d ? `<span class="badge bg-light text-dark border">${d.toUpperCase()}</span>` : '-' },
                        { data: 'status', render: d => d === 'completed' ? '<span class="badge bg-success-subtle text-success">Completed</span>' : '<span class="badge bg-danger-subtle text-danger">Pending</span>' },
                        { data: 'id', className: 'text-end', render: d => `<button class="btn btn-sm btn-outline-primary" onclick="printReceipt(${d})" title="Print Receipt"><i class="ti ti-printer"></i></button>` }
                    ],
                    order: [[0, 'desc']],
                    pageLength: 10,
                    responsive: true,
                    dom: 'tp', // Hide default search, use custom one
                    language: {
                        paginate: { next: '<i class="ti ti-chevron-right"></i>', previous: '<i class="ti ti-chevron-left"></i>' }
                    }
                });
            }

            window.printReceipt = function(id) {
                window.open(`/app/fees/api/fee_collection_master.php?action=print_receipt&payment_id=${id}`, '_blank', 'width=900,height=600');
            };
        });
    </script>
</body>
</html>