<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Enable error logging for production debugging
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', $_SERVER['DOCUMENT_ROOT'] . '/logs/error.log');

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

class FeeReportMaster {
    private $pdo;
    private $months = [
        1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June',
        7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
    ];

    public function __construct() {
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Database connection failed');
            exit();
        }
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        
        if ($method === 'GET') {
            $this->handleGet();
        } elseif ($method === 'POST') {
            $this->handlePost();
        } else {
            $this->sendResponse(405, 'error', 'Method not allowed');
        }
    }

    private function handleGet() {
        $action = $_GET['action'] ?? '';

        switch ($action) {
            case 'get_particulars':
                $this->getParticulars();
                break;
            case 'get_sessions':
                $this->getSessions();
                break;
            case 'get_students_by_class':
                $this->getStudentsByClass();
                break;
            case 'get_report':
                $this->getReport();
                break;
            default:
                $this->sendResponse(400, 'error', 'Invalid action');
                break;
        }
    }

    private function handlePost() {
        $action = $_POST['action'] ?? '';

        if ($action === 'export_report') {
            $this->exportReport();
        } else {
            $this->sendResponse(400, 'error', 'Invalid action');
        }
    }

    private function getParticulars() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT DISTINCT p.id, p.particular 
                FROM particulars p
                JOIN fee_structure fs ON p.id = fs.particular_id
                WHERE fs.status = 'active'
                ORDER BY p.particular
            ");
            $stmt->execute();
            $particulars = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $this->sendResponse(200, 'success', 'Particulars fetched successfully', $particulars);
        } catch (PDOException $e) {
            error_log("Failed to fetch particulars: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch particulars');
        }
    }

    private function getSessions() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT DISTINCT session 
                FROM fee_collections 
                WHERE session IS NOT NULL AND session != ''
                ORDER BY session DESC
            ");
            $stmt->execute();
            $sessions = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $this->sendResponse(200, 'success', 'Sessions fetched successfully', $sessions);
        } catch (PDOException $e) {
            error_log("Failed to fetch sessions: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch sessions');
        }
    }

    private function getStudentsByClass() {
        $class_id = filter_var($_GET['class_id'] ?? '', FILTER_VALIDATE_INT);
        
        if (!$class_id) {
            $this->sendResponse(400, 'error', 'Invalid class ID');
            return;
        }

        try {
            $stmt = $this->pdo->prepare("
                SELECT id, full_name, father_name 
                FROM students 
                WHERE class = ? AND status = 'active'
                ORDER BY full_name
            ");
            $stmt->execute([$class_id]);
            $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $this->sendResponse(200, 'success', 'Students fetched successfully', $students);
        } catch (PDOException $e) {
            error_log("Failed to fetch students: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch students');
        }
    }

    private function getReport() {
        try {
            // Build the query to include all students with fee structures, not just those who paid
            $query = "
                SELECT 
                    fc.id,
                    COALESCE(fc.amount_collected, 0) as amount_collected,
                    COALESCE(fc.discount, 0) as discount,
                    fc.payment_month,
                    fc.payment_date,
                    fc.payment_method,
                    COALESCE(fc.status, 'pending') as status,
                    COALESCE(fc.session, ?) as session,
                    fc.remarks,
                    s.id as student_id,
                    s.full_name AS student_name,
                    s.father_name,
                    s.class as class_id,
                    c.class_name,
                    p.particular,
                    fs.amount AS fee_amount,
                    fs.frequency,
                    fs.particular_id,
                    fs.applicable_months
                FROM students s
                JOIN class c ON s.class = c.id
                JOIN fee_structure fs ON s.class = fs.class_id
                JOIN particulars p ON fs.particular_id = p.id
                LEFT JOIN fee_collections fc ON (fc.student_id = s.id)
                WHERE s.status = 'active' AND fs.status = 'active'
            ";

            $params = [];
            $conditions = [];
            
            // Default session if not provided
            $default_session = date('Y') . '-' . (date('Y') + 1);
            $params[] = $default_session;

            // Apply filters
            if (!empty($_GET['class_id'])) {
                $conditions[] = "s.class = ?";
                $params[] = $_GET['class_id'];
            }

            if (!empty($_GET['student_id'])) {
                $conditions[] = "s.id = ?";
                $params[] = $_GET['student_id'];
            }

            if (!empty($_GET['particular_id'])) {
                $conditions[] = "fs.particular_id = ?";
                $params[] = $_GET['particular_id'];
            }

            if (!empty($_GET['session'])) {
                $conditions[] = "(fc.session = ? OR fc.session IS NULL)";
                $params[] = $_GET['session'];
                // Update default session parameter
                $params[0] = $_GET['session'];
            }

            if (!empty($_GET['payment_method'])) {
                $conditions[] = "fc.payment_method = ?";
                $params[] = $_GET['payment_method'];
            }

            if (!empty($_GET['status'])) {
                if ($_GET['status'] === 'pending') {
                    $conditions[] = "(fc.status IS NULL OR fc.status = 'pending')";
                } else {
                    $conditions[] = "fc.status = ?";
                    $params[] = $_GET['status'];
                }
            }

            if (!empty($_GET['date_from'])) {
                $conditions[] = "(fc.payment_date >= ? OR fc.payment_date IS NULL)";
                $params[] = $_GET['date_from'];
            }

            if (!empty($_GET['date_to'])) {
                $conditions[] = "(fc.payment_date <= ? OR fc.payment_date IS NULL)";
                $params[] = $_GET['date_to'];
            }

            if (!empty($conditions)) {
                $query .= " AND " . implode(" AND ", $conditions);
            }

            $query .= " ORDER BY c.class_name, s.full_name, p.particular, fc.payment_date DESC";

            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data as &$record) {
                // Handle payment months for paid fees
                if (!empty($record['payment_month'])) {
                    $months_arr = array_map('intval', explode(',', $record['payment_month']));
                    $month_names = array_map(function($m) { return $this->months[$m]; }, $months_arr);
                    $record['payment_month_name'] = implode(', ', $month_names);
                } else {
                    $record['payment_month_name'] = 'Not Paid';
                }
                
                // Calculate proper remaining balance for all students
                $record['remaining_balance'] = $this->calculateRemainingBalance(
                    $record['student_id'], 
                    $record['class_id'], 
                    $record['particular_id'],
                    $record['session']
                );
                
                // Set payment date to current date if not paid
                if (empty($record['payment_date'])) {
                    $record['payment_date'] = null;
                }
            }

            // Calculate statistics including all pending amounts
            $statistics = $this->calculateStatistics($data);

            $this->sendResponse(200, 'success', 'Report data fetched successfully', $data, $statistics);
        } catch (PDOException $e) {
            error_log("Failed to fetch report data: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch report data');
        }
    }

    private function calculateRemainingBalance($student_id, $class_id, $particular_id, $session) {
        try {
            // Get total fee amount from fee_structure for this class and particular
            $stmt = $this->pdo->prepare("
                SELECT amount, frequency, applicable_months 
                FROM fee_structure 
                WHERE class_id = ? AND particular_id = ? AND status = 'active'
            ");
            $stmt->execute([$class_id, $particular_id]);
            $fee_structure = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$fee_structure) {
                return 0;
            }
            
            $total_fee_amount = (float)$fee_structure['amount'];
            
            $filtered_months = $this->getFilteredMonths($fee_structure);
            
            if ($fee_structure['frequency'] === 'monthly') {
                if ($fee_structure['applicable_months'] === 'all') {
                    $total_fee_amount *= count($filtered_months);
                } else {
                    $applicable_months = array_map('intval', explode(',', $fee_structure['applicable_months']));
                    $valid_months = array_intersect($applicable_months, $filtered_months);
                    $total_fee_amount *= count($valid_months);
                }
            } elseif ($fee_structure['frequency'] === 'other') {
                if (empty($filtered_months)) {
                    $total_fee_amount = 0;
                }
            }
            // For annual fees, check if the year falls within the date range
            elseif ($fee_structure['frequency'] === 'annual') {
                if (!$this->isYearInDateRange()) {
                    $total_fee_amount = 0;
                }
            }
            
            // Get total amount collected for this student, particular, and session
            $collection_query = "
                SELECT COALESCE(SUM(amount_collected), 0) as total_collected
                FROM fee_collections fc
                JOIN fee_structure fs ON fc.fee_structure_id = fs.id
                WHERE fc.student_id = ? 
                AND fs.particular_id = ? 
                AND fc.session = ?
                AND fc.status = 'completed'
            ";
            
            $collection_params = [$student_id, $particular_id, $session];
            
            if (!empty($_GET['date_from'])) {
                $collection_query .= " AND fc.payment_date >= ?";
                $collection_params[] = $_GET['date_from'];
            }
            
            if (!empty($_GET['date_to'])) {
                $collection_query .= " AND fc.payment_date <= ?";
                $collection_params[] = $_GET['date_to'];
            }
            
            $stmt = $this->pdo->prepare($collection_query);
            $stmt->execute($collection_params);
            $total_collected = (float)$stmt->fetchColumn();
            
            // Calculate remaining balance (total fee - amount collected)
            $remaining_balance = $total_fee_amount - $total_collected;
            
            return max(0, $remaining_balance);
            
        } catch (PDOException $e) {
            error_log("Failed to calculate remaining balance: " . $e->getMessage());
            return 0;
        }
    }

    private function calculateStatistics($data) {
        $stats = [
            'total_collections' => 0,
            'total_amount' => 0,
            'total_discount' => 0,
            'pending_amount' => 0
        ];

        $unique_combinations = [];
        $actual_collections = 0;

        foreach ($data as $record) {
            // Only count as collection if payment was actually made
            if (!empty($record['id']) && $record['amount_collected'] > 0) {
                $actual_collections++;
                $stats['total_amount'] += (float)$record['amount_collected'];
                $stats['total_discount'] += (float)$record['discount'];
            }
            
            // Create unique key for student-particular-session combination for pending amounts
            $unique_key = $record['student_id'] . '_' . $record['particular_id'] . '_' . $record['session'];
            
            if (!isset($unique_combinations[$unique_key])) {
                $unique_combinations[$unique_key] = (float)$record['remaining_balance'];
            }
        }

        $stats['total_collections'] = $actual_collections;
        $stats['pending_amount'] = array_sum($unique_combinations);

        return $stats;
    }

    private function exportReport() {
        try {
            // Get the same data as the report
            $_GET = $_POST; // Copy POST data to GET for reuse
            $this->getReport();
        } catch (Exception $e) {
            error_log("Failed to export report: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to export report');
        }
    }

    private function sendResponse($statusCode, $status, $message, $data = null, $statistics = null) {
        http_response_code($statusCode);
        $response = ['status' => $status, 'message' => $message];
        
        if ($data !== null) {
            $response['data'] = $data;
        }
        
        if ($statistics !== null) {
            $response['statistics'] = $statistics;
        }
        
        echo json_encode($response);
        exit();
    }

    private function getFilteredMonths($fee_structure) {
        $date_from = $_GET['date_from'] ?? null;
        $date_to = $_GET['date_to'] ?? null;
        
        // If no date filter is applied, return all applicable months
        if (empty($date_from) && empty($date_to)) {
            if ($fee_structure['applicable_months'] === 'all') {
                return range(1, 12);
            } else {
                return array_map('intval', explode(',', $fee_structure['applicable_months']));
            }
        }
        
        $filtered_months = [];
        
        // Determine the month range from date filters
        $start_month = $date_from ? (int)date('n', strtotime($date_from)) : 1;
        $end_month = $date_to ? (int)date('n', strtotime($date_to)) : 12;
        
        // Get applicable months
        if ($fee_structure['applicable_months'] === 'all') {
            $applicable_months = range(1, 12);
        } else {
            $applicable_months = array_map('intval', explode(',', $fee_structure['applicable_months']));
        }
        
        // Find intersection of applicable months and date range months
        if ($start_month <= $end_month) {
            // Same year range
            $date_range_months = range($start_month, $end_month);
        } else {
            // Cross year range (e.g., Nov to Feb)
            $date_range_months = array_merge(range($start_month, 12), range(1, $end_month));
        }
        
        $filtered_months = array_intersect($applicable_months, $date_range_months);
        
        return array_values($filtered_months);
    }
    
    private function isYearInDateRange() {
        $date_from = $_GET['date_from'] ?? null;
        $date_to = $_GET['date_to'] ?? null;
        
        if (empty($date_from) && empty($date_to)) {
            return true;
        }
        
        $current_year = (int)date('Y');
        $start_year = $date_from ? (int)date('Y', strtotime($date_from)) : $current_year;
        $end_year = $date_to ? (int)date('Y', strtotime($date_to)) : $current_year;
        
        return ($current_year >= $start_year && $current_year <= $end_year);
    }
}

// Instantiate and handle the request
try {
    $feeReportMaster = new FeeReportMaster();
    $feeReportMaster->handleRequest();
} catch (Exception $e) {
    error_log("Failed to handle request: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Internal server error']);
}
?>