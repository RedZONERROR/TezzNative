<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Student Admission - AI-ERP 2.0</title>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-space-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Student Form</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex"
                                                    href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone"
                                                        class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Student Form
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- start Basic Example -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row mb-3">
                                <div class="col-md-4 col-xl-3">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Contacts..." />
                                        <i
                                            class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-4 col-xl-3">
                                    <select class="form-select" id="status-filter">
                                        <option value="">All Status</option>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Modal -->
                        <div class="modal fade" id="addContactModal" tabindex="-1" aria-labelledby="modalTitle" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="modalTitle">Update Form Element</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="add-contact-box">
                                            <div class="add-contact-content">
                                                <form id="addFormElement">
                                                    <input type="hidden" id="id" name="id">
                                                    <div class="row">
                                                        <div class="col-md-12 mb-3">
                                                            <label class="form-label">Required Field</label>
                                                            <select class="form-select" id="is_required" name="is_required" required>
                                                                <option value="">Select Required</option>
                                                                <option value="1">Yes</option>
                                                                <option value="0">No</option>
                                                            </select>
                                                            <div class="invalid-feedback">Please select if this field is required</div>
                                                        </div>
                                                        <div class="col-md-12 mb-3">
                                                            <label class="form-label">Status</label>
                                                            <select class="form-select" id="status" name="status" required>
                                                                <option value="">Select Status</option>
                                                                <option value="active">Active</option>
                                                                <option value="inactive">Inactive</option>
                                                            </select>
                                                            <div class="invalid-feedback">Please select a status</div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <div class="d-flex gap-2">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <button type="button" id="btn-edit" class="btn btn-primary">Save changes</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Table -->
                        <div class="card card-body">
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <th>Field Name</th>
                                        <th>Placeholder</th>
                                        <th>Section</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody id="student_list_table_body">
                                        <!-- Table rows will be populated via AJAX -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <nav aria-label="Page navigation">
                                <ul class="pagination justify-content-center" id="pagination">
                                    <!-- Pagination links will be populated dynamically -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="dark-transparent sidebartoggler"></div>
    <script src="../assets/js/vendor.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
 <script>
        hljs.initHighlightingOnLoad();
        document.querySelectorAll("pre.code-view > code").forEach((codeBlock) => {
            codeBlock.textContent = codeBlock.innerHTML;
        });

        // AJAX functionality for fetching and updating form elements
        $(document).ready(function() {
            // Initialize Bootstrap modal
            const addContactModal = new bootstrap.Modal(document.getElementById('addContactModal'), {
                backdrop: 'static',
                keyboard: false
            });

            let currentPage = 1;
            let perPage = 10;
            let searchQuery = '';
            let statusFilter = '';

            // Function to fetch form elements and populate the table
            function fetchFormElements(page = 1) {
                const params = new URLSearchParams({
                    page: page,
                    perPage: perPage
                });
                if (statusFilter) {
                    params.append('status', statusFilter);
                }

                $.ajax({
                    url: 'api/staff_form_element_master.php?' + params.toString(),
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        const tbody = $('#student_list_table_body');
                        tbody.empty();
                        const data = response.data || [];
                        let filteredData = data;

                        // Client-side search
                        if (searchQuery) {
                            const query = searchQuery.toLowerCase();
                            filteredData = data.filter(element =>
                                (element.field_name || '').toLowerCase().includes(query) ||
                                (element.placeholder || '').toLowerCase().includes(query) ||
                                (element.section || '').toLowerCase().includes(query)
                            );
                        }

                        if (filteredData.length === 0) {
                            tbody.append('<tr><td colspan="5" class="text-center">No form elements found</td></tr>');
                        } else {
                            filteredData.forEach(function(element) {
                                const statusColor = element.status === 'active' ? 'color: green;' : 'color: red;';
                                const row = `
                                    <tr class="search-items">
                                        <td>
                                            <span class="usr-email-addr">${element.field_name || ''}</span>
                                        </td>
                                        <td>
                                            <span class="usr-location">${element.placeholder || ''}</span>
                                        </td>
                                        <td>
                                            <span class="usr-ph-no">${element.section || ''}</span>
                                        </td>
                                        <td>
                                            <span class="usr-ph-no" style="${statusColor}">${element.status || ''}</span>
                                        </td>
                                        <td data-studentid="${element.id}">
                                            <div class="action-btn">
                                                <a href="javascript:void(0)" class="text-primary edit-field"
                                                   data-id="${element.id}"
                                                   data-status="${element.status || ''}"
                                                   data-required="${element.is_required || 0}">
                                                    <i class="ti ti-pencil fs-5"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>`;
                                tbody.append(row);
                            });
                        }

                        // Update pagination
                        updatePagination(response.meta);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to fetch form elements: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Function to update pagination controls
            function updatePagination(meta) {
                const pagination = $('#pagination');
                pagination.empty();

                if (!meta || meta.totalPages <= 1) {
                    return;
                }

                const prevDisabled = meta.page <= 1 ? 'disabled' : '';
                const nextDisabled = meta.page >= meta.totalPages ? 'disabled' : '';

                // Previous button
                pagination.append(`
                    <li class="page-item ${prevDisabled}">
                        <a class="page-link" href="javascript:void(0)" data-page="${meta.page - 1}">Previous</a>
                    </li>
                `);

                // Page numbers (show limited range)
                const startPage = Math.max(1, meta.page - 2);
                const endPage = Math.min(meta.totalPages, meta.page + 2);
                for (let i = startPage; i <= endPage; i++) {
                    const active = i === meta.page ? 'active' : '';
                    pagination.append(`
                        <li class="page-item ${active}">
                            <a class="page-link" href="javascript:void(0)" data-page="${i}">${i}</a>
                        </li>
                    `);
                }

                // Next button
                pagination.append(`
                    <li class="page-item ${nextDisabled}">
                        <a class="page-link" href="javascript:void(0)" data-page="${meta.page + 1}">Next</a>
                    </li>
                `);
            }

            // Initial fetch
            fetchFormElements();

            // Handle pagination clicks
            $(document).on('click', '.page-link', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && !$(this).parent().hasClass('disabled')) {
                    currentPage = page;
                    fetchFormElements(currentPage);
                }
            });

            // Handle search input
            $('#input-search').on('input', function() {
                searchQuery = $(this).val().trim();
                fetchFormElements(currentPage);
            });

            // Handle status filter
            $('#status-filter').on('change', function() {
                statusFilter = $(this).val();
                currentPage = 1; // Reset to first page
                fetchFormElements(currentPage);
            });

            // Handle edit button click
            $(document).on('click', '.edit-field', function(e) {
                e.preventDefault();
                const id = $(this).data('id');
                const status = $(this).data('status');
                const is_required = $(this).data('required');

                $('#addFormElement #id').val(id);
                $('#addFormElement #status').val(status);
                $('#addFormElement #is_required').val(is_required);
                $('#modalTitle').text('Update Form Element');

                addContactModal.show();
            });

            // Handle save changes
            $('#btn-edit').on('click', function() {
                const id = $('#addFormElement #id').val();
                const status = $('#addFormElement #status').val();
                const is_required = $('#addFormElement #is_required').val();

                if (!status || is_required === '') {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Validation Error',
                        text: 'Please fill all required fields'
                    });
                    return;
                }

                $.ajax({
                    url: 'api/staff_form_element_master.php',
                    type: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        id: parseInt(id),
                        is_required: parseInt(is_required),
                        status: status
                    }),
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Form element updated successfully'
                        });
                        addContactModal.hide();
                        fetchFormElements(currentPage);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to update form element: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            });

            // Clear modal form
            $('#addContactModal').on('hidden.bs.modal', function() {
                $('#addFormElement')[0].reset();
                $('#addFormElement #id').val('');
                $('#modalTitle').text('Update Form Element');
            });
        });
    </script>
</body>
</html>