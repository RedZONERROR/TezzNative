<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Subjects - AI-ERP 2.0</title>
    <style>
        .action-buttons {
            display: none;
        }
        .btn-loading .fa-spinner {
            display: inline-block;
        }
        .btn-loading .btn-text, .btn-loading .ti {
            display: none;
        }
        .fa-spinner {
            display: none;
            font-size: 0.9rem;
        }
        .pagination {
            margin-top: 1rem;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar -->
        <?php include 'util/sidebar.php'; ?>
        <div class="page-wrapper">
            <!-- Header -->
            <?php include 'util/topbar.php'; ?>

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Subjects</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Subjects
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Subject Management -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-4 col-xl-3">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Subjects..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-8 col-xl-9 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div class="action-buttons me-2">
                                        <button class="delete-multiple btn bg-danger-subtle text-danger">
                                            <i class="fas fa-spinner fa-spin"></i>
                                            <span class="btn-text">Delete</span>
                                        </button>
                                    </div>
                                    <button id="btn-add-subject" class="btn btn-primary d-flex align-items-center">
                                        <i class="ti ti-book text-white me-1 fs-5"></i> Add Subject
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Add/Edit Modal -->
                        <div class="modal fade" id="addSubjectModal" tabindex="-1" aria-labelledby="addSubjectModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="addSubjectModalLabel">Add Subject</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form id="subjectForm">
                                            <input type="hidden" id="subjectId">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="class" class="form-label">Class *</label>
                                                        <select class="form-control" id="class" name="class" required>
                                                            <option value="">Select Class</option>
                                                            <!-- Classes will be populated dynamically -->
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="subject" class="form-label">Subject Name *</label>
                                                        <input type="text" id="subject" class="form-control" name="subject" required />
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="full_marks" class="form-label">Full Marks *</label>
                                                        <input type="number" id="full_marks" class="form-control" name="full_marks" min="1" required />
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="passing_marks" class="form-label">Passing Marks *</label>
                                                        <input type="number" id="passing_marks" class="form-control" name="passing_marks" min="1" required />
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="status" class="form-label">Status *</label>
                                                        <select class="form-control" id="status" name="status" required>
                                                            <option value="active">Active</option>
                                                            <option value="inactive">Inactive</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button id="btn-add" class="btn btn-success"> Add
                                            <i class="fas fa-spinner fa-spin btn-loading"></i>
                                        </button>
                                        <button id="btn-edit" class="btn btn-success" style="display: none;"> Save
                                            <i class="fas fa-spinner fa-spin btn-loading"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- View Modal -->
                        <div class="modal fade" id="viewSubjectModal" tabindex="-1" aria-labelledby="viewSubjectModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="viewSubjectModalLabel">Subject Details</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>ID:</strong> <span id="view-id"></span></p>
                                        <p><strong>Class:</strong> <span id="view-class"></span></p>
                                        <p><strong>Subject:</strong> <span id="view-subject"></span></p>
                                        <p><strong>Full Marks:</strong> <span id="view-full_marks"></span></p>
                                        <p><strong>Passing Marks:</strong> <span id="view-passing_marks"></span></p>
                                        <p><strong>Status:</strong> <span id="view-status"></span></p>
                                        <p><strong>Updated On:</strong> <span id="view-updated_on"></span></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card card-body">
                            <div class="d-flex justify-content-center">
                                <div class="spinner-border text-primary" role="status" id="table-loader">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <tr>
                                            <th>
                                                <div class="n-chk align-self-center text-center">
                                                    <div class="form-check">
                                                        <input type="checkbox" class="form-check-input primary" id="subject-check-all" />
                                                        <label class="form-check-label" for="subject-check-all"></label>
                                                        <span class="new-control-indicator"></span>
                                                    </div>
                                                </div>
                                            </th>
                                            <th>S.N.</th>
                                            <th>Class</th>
                                            <th>Subject</th>
                                            <th>Full Marks</th>
                                            <th>Passing Marks</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="subject_list_table_body">
                                        <!-- Data will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <nav aria-label="Page navigation" id="pagination-nav">
                                <ul class="pagination justify-content-center">
                                    <!-- Pagination controls -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        hljs.initHighlightingOnLoad();
        document.querySelectorAll("pre.code-view > code").forEach((codeBlock) => {
            codeBlock.textContent = codeBlock.innerHTML;
        });

        $(document).ready(function() {
            // Pagination state
            let currentPage = 1;
            const perPage = 10;
            let classesMap = {};

            // Fetch classes for mapping class_id to class_name
            function fetchClassesForMapping(callback) {
                $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 100 }, // Fetch all classes
                    dataType: 'json',
                    success: function(response) {
                        const classes = response.data || [];
                        classesMap = {};
                        classes.forEach(c => {
                            classesMap[c.id] = c.class_name;
                        });
                        if (callback) callback();
                    },
                    error: function(xhr, status, error) {
                        console.error('Fetch Classes Error:', xhr.responseJSON, status, error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load classes: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Fetch classes for dropdown
            function fetchClassesForDropdown(callback) {
                $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 100 }, // Fetch all classes
                    dataType: 'json',
                    success: function(response) {
                        const classes = response.data || [];
                        const dropdown = $('#class');
                        dropdown.empty();
                        dropdown.append('<option value="">Select Class</option>');
                        classes.forEach(c => {
                            dropdown.append(`<option value="${c.id}">${c.class_name}</option>`);
                        });
                        if (callback) callback();
                    },
                    error: function(xhr, status, error) {
                        console.error('Fetch Classes Error:', xhr.responseJSON, status, error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load classes: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Fetch subject data with pagination
            function fetchSubjects(page = 1) {
                $('#table-loader').show();
                $('#subject_list_table_body').empty();

                $.ajax({
                    url: 'api/subject_master.php',
                    type: 'GET',
                    data: { page: page, perPage: perPage },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Subject API Response:', response);
                        const subjects = response.data || [];
                        const meta = response.meta || { page: 1, totalPages: 1, totalItems: subjects.length };
                        console.log('Meta:', meta);
                        renderSubjectTable(subjects, page);
                        renderPagination(meta);
                        $('#table-loader').hide();
                    },
                    error: function(xhr, status, error) {
                        $('#table-loader').hide();
                        console.error('Subject AJAX Error:', xhr.responseJSON, status, error);
                        renderPagination({ page: 1, totalPages: 1, totalItems: 0 });
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load subject data: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Render subject table
            function renderSubjectTable(subjects, page) {
                const tbody = $('#subject_list_table_body');
                tbody.empty();
                if (subjects.length === 0) {
                    tbody.append('<tr><td colspan="8" class="text-center">No subjects found.</td></tr>');
                    return;
                }
                subjects.forEach((s, index) => {
                    const serialNumber = (page - 1) * perPage + index + 1;
                    const className = classesMap[s.class] || s.class || '-'; // Map class_id to class_name
                    const row = `
                        <tr data-id="${s.id}">
                            <td>
                                <div class="n-chk align-self-center text-center">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input subject-check" value="${s.id}" />
                                        <label class="form-check-label"></label>
                                    </div>
                                </div>
                            </td>
                            <td>${serialNumber}</td>
                            <td>${className}</td>
                            <td>${s.subject || '-'}</td>
                            <td>${s.full_marks || '-'}</td>
                            <td>${s.passing_marks || '-'}</td>
                            <td>
                                <span class="badge ${
                                    s.status === 'active' ? 'bg-success' :
                                    s.status === 'inactive' ? 'bg-warning' :
                                    'bg-secondary'
                                }">
                                    ${s.status || '-'}
                                </span>
                            </td>
                            <td>
                                <button class="view-subject btn btn-sm btn-info" data-id="${s.id}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-eye"></i>
                                </button>
                                <button class="edit-subject btn btn-sm btn-primary" data-id="${s.id}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-edit"></i>
                                </button>
                                <button class="delete-subject btn btn-sm btn-danger" data-id="${s.id}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-trash"></i>
                                </button>
                            </td>
                        </tr>`;
                    tbody.append(row);
                });
            }

            // Render pagination
            function renderPagination(meta) {
                const pagination = $('#pagination-nav ul');
                pagination.empty();

                // Fallback values
                const currentPage = meta.page || 1;
                const totalPages = meta.totalPages || 1;

                // Always render pagination
                pagination.append(`
                    <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
                    </li>
                `);

                for (let p = 1; p <= totalPages; p++) {
                    pagination.append(`
                        <li class="page-item ${p === currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${p}">${p}</a>
                        </li>
                    `);
                }

                pagination.append(`
                    <li class="page-item ${currentPage >= totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
                    </li>
                `);
            }

            // Pagination click
            $(document).on('click', '#pagination-nav a', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && page !== currentPage) {
                    currentPage = page;
                    fetchSubjects(page);
                }
            });

            // Toggle action buttons
            function toggleActionButtons() {
                const checked = $('.subject-check:checked').length;
                $('.action-buttons').toggle(checked > 0);
            }

            // Select all checkboxes
            $('#subject-check-all').on('change', function() {
                $('.subject-check').prop('checked', this.checked);
                toggleActionButtons();
            });

            // Individual checkbox change
            $(document).on('change', '.subject-check', toggleActionButtons);

            // Search functionality
            $('#input-search').on('keyup', function() {
                const search = $(this).val().toLowerCase();
                $('#subject_list_table_body tr').each(function() {
                    const text = $(this).text().toLowerCase();
                    $(this).toggle(text.includes(search));
                });
            });

            // Delete multiple
            $('.delete-multiple').on('click', function() {
                const selected = $('.subject-check:checked').map(function() {
                    return $(this).val();
                }).get();
                if (selected.length === 0) {
                    Swal.fire({
                        title: 'No Selection',
                        text: 'Please select at least one subject to delete.',
                        icon: 'warning'
                    });
                    return;
                }
                Swal.fire({
                    title: 'Are you sure?',
                    text: `Delete ${selected.length} subjects?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        Promise.all(selected.map(id =>
                            $.ajax({
                                url: 'api/subject_master.php',
                                type: 'DELETE',
                                contentType: 'application/json',
                                data: JSON.stringify({ id: id })
                            })
                        )).then(() => {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted',
                                text: 'Subjects deleted successfully'
                            });
                            fetchSubjects(currentPage);
                            $('.subject-check').prop('checked', false);
                            toggleActionButtons();
                        }).catch(xhr => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to delete subjects: ' + (xhr.responseJSON?.error || xhr.statusText)
                            });
                        }).finally(() => {
                            $('.delete-multiple').removeClass('btn-loading');
                        });
                    }
                });
            });

            // Open add modal
            $('#btn-add-subject').on('click', function() {
                $('#addSubjectModalLabel').text('Add Subject');
                $('#subjectForm')[0].reset();
                $('#subjectId').val('');
                $('#btn-add').show();
                $('#btn-edit').hide();
                fetchClassesForDropdown(() => {
                    $('#addSubjectModal').modal('show');
                });
            });

            // Add subject
            $('#btn-add').on('click', function() {
                if (!$('#subjectForm')[0].checkValidity()) {
                    $('#subjectForm')[0].reportValidity();
                    return;
                }

                const data = {
                    class: parseInt($('#class').val()),
                    subject: $('#subject').val(),
                    full_marks: parseInt($('#full_marks').val()),
                    passing_marks: parseInt($('#passing_marks').val()),
                    status: $('#status').val()
                };

                $(this).addClass('btn-loading');

                $.ajax({
                    url: 'api/subject_master.php',
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(data),
                    dataType: 'json',
                    success: function(response) {
                        $('#addSubjectModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Subject added successfully'
                        });
                        fetchSubjects(currentPage);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to add subject: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('#btn-add').removeClass('btn-loading');
                    }
                });
            });

            // View subject
            $(document).on('click', '.view-subject', function() {
                const id = $(this).data('id');
                $(this).addClass('btn-loading');
                $.ajax({
                    url: 'api/subject_master.php',
                    type: 'GET',
                    data: { id: id },
                    dataType: 'json',
                    success: function(response) {
                        const subject = response.data && response.data[0] || {};
                        const className = classesMap[subject.class] || subject.class || '-';
                        $('#view-id').text(subject.id || '-');
                        $('#view-class').text(className);
                        $('#view-subject').text(subject.subject || '-');
                        $('#view-full_marks').text(subject.full_marks || '-');
                        $('#view-passing_marks').text(subject.passing_marks || '-');
                        $('#view-status').text(subject.status || '-');
                        $('#view-updated_on').text(subject.updated_on || '-');
                        $('#viewSubjectModal').modal('show');
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load subject details: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('.view-subject[data-id="' + id + '"]').removeClass('btn-loading');
                    }
                });
            });

            // Edit subject
            $(document).on('click', '.edit-subject', function() {
                const id = $(this).data('id');
                $(this).addClass('btn-loading');
                $.ajax({
                    url: 'api/subject_master.php',
                    type: 'GET',
                    data: { id: id },
                    dataType: 'json',
                    success: function(response) {
                        const subject = response.data && response.data[0] || {};
                        fetchClassesForDropdown(() => {
                            $('#addSubjectModalLabel').text('Edit Subject');
                            $('#subjectId').val(id);
                            $('#class').val(subject.class || '');
                            $('#subject').val(subject.subject || '');
                            $('#full_marks').val(subject.full_marks || '');
                            $('#passing_marks').val(subject.passing_marks || '');
                            $('#status').val(subject.status || 'active');
                            $('#btn-add').hide();
                            $('#btn-edit').show();
                            $('#addSubjectModal').modal('show');
                        });
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load subject details: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('.edit-subject[data-id="' + id + '"]').removeClass('btn-loading');
                    }
                });
            });

            // Save edited subject
            $('#btn-edit').on('click', function() {
                if (!$('#subjectForm')[0].checkValidity()) {
                    $('#subjectForm')[0].reportValidity();
                    return;
                }

                const data = {
                    id: $('#subjectId').val(),
                    class: parseInt($('#class').val()),
                    subject: $('#subject').val(),
                    full_marks: parseInt($('#full_marks').val()),
                    passing_marks: parseInt($('#passing_marks').val()),
                    status: $('#status').val()
                };

                $(this).addClass('btn-loading');

                $.ajax({
                    url: 'api/subject_master.php',
                    type: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify(data),
                    dataType: 'json',
                    success: function(response) {
                        $('#addSubjectModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Subject updated successfully'
                        });
                        fetchSubjects(currentPage);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to update subject: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('#btn-edit').removeClass('btn-loading');
                    }
                });
            });

            // Delete single subject
            $(document).on('click', '.delete-subject', function() {
                const id = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'Delete this subject?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/subject_master.php',
                            type: 'DELETE',
                            contentType: 'application/json',
                            data: JSON.stringify({ id: id }),
                            dataType: 'json',
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted',
                                    text: response.message || 'Subject deleted successfully'
                                });
                                fetchSubjects(currentPage);
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to delete subject: ' + (xhr.responseJSON?.error || error)
                                });
                            },
                            complete: function() {
                                $('.delete-subject[data-id="' + id + '"]').removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // Initial load: Fetch classes first, then subjects
            fetchClassesForMapping(() => {
                fetchSubjects(currentPage);
            });
        });
    </script>
</body>
</html>