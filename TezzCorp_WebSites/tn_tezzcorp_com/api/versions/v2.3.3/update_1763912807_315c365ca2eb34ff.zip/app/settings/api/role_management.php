<?php
session_start();
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class RoleController {
    private $pdo;
    private $logger;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    // Generate 16-character alphanumeric UID
    private function generateCustomUid() {
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $uid = '';
        for ($i = 0; $i < 16; $i++) {
            $uid .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $uid;
    }

    // Validate input data for roles
    private function validateInput(array $data, bool $isUpdate = false): array {
        $errors = [];
        $validData = [];

        $fields = [
            'role_name' => ['type' => 'string', 'max' => 50, 'required' => !$isUpdate],
            'description' => ['type' => 'string', 'max' => 255, 'required' => false],
            'status' => ['type' => 'string', 'enum' => ['active', 'inactive'], 'required' => !$isUpdate],
        ];

        if ($isUpdate) {
            if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT) || $data['id'] <= 0) {
                $errors[] = "id must be a valid integer";
            } else {
                $validData['id'] = (int)$data['id'];
            }
        }

        foreach ($fields as $field => $rules) {
            if (isset($data[$field])) {
                $value = $data[$field];

                switch ($rules['type']) {
                    case 'string':
                        if (!is_string($value)) {
                            $errors[] = "$field must be a string";
                        } elseif (isset($rules['max']) && strlen($value) > $rules['max']) {
                            $errors[] = "$field exceeds maximum length of {$rules['max']} characters";
                        }
                        break;
                }

                if (isset($rules['enum']) && !in_array($value, $rules['enum'], true)) {
                    $errors[] = "$field must be one of: " . implode(', ', $rules['enum']);
                }

                $validData[$field] = $value;
            } elseif ($rules['required']) {
                $errors[] = "$field is required";
            }
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return $validData;
    }

    // Validate staff role assignment input
    private function validateStaffRoleInput(array $data): array {
        $errors = [];
        $validData = [];

        if (!isset($data['staff_id']) || !filter_var($data['staff_id'], FILTER_VALIDATE_INT) || $data['staff_id'] <= 0) {
            $errors[] = "staff_id must be a valid integer";
        } else {
            $validData['staff_id'] = (int)$data['staff_id'];
        }

        if (!isset($data['role_id']) || !filter_var($data['role_id'], FILTER_VALIDATE_INT) || $data['role_id'] <= 0) {
            $errors[] = "role_id must be a valid integer";
        } else {
            $validData['role_id'] = (int)$data['role_id'];
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return $validData;
    }

    // Validate permission assignment input
    private function validatePermissionInput(array $data): array {
        $errors = [];
        $validData = [];

        if (!isset($data['role_id']) || !filter_var($data['role_id'], FILTER_VALIDATE_INT) || $data['role_id'] <= 0) {
            $errors[] = "role_id must be a valid integer";
        } else {
            $validData['role_id'] = (int)$data['role_id'];
        }

        if (!isset($data['permission_ids']) || !is_array($data['permission_ids'])) {
            $errors[] = "permission_ids must be an array";
        } else {
            foreach ($data['permission_ids'] as $perm_id) {
                if (!filter_var($perm_id, FILTER_VALIDATE_INT) || $perm_id <= 0) {
                    $errors[] = "permission_ids contains invalid integer: $perm_id";
                }
            }
            $validData['permission_ids'] = array_map('intval', $data['permission_ids']);
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return $validData;
    }

    // Validate user role assignment input
    private function validateUserRoleInput(array $data): array {
        $errors = [];
        $validData = [];

        if (!isset($data['user_id']) || !filter_var($data['user_id'], FILTER_VALIDATE_INT) || $data['user_id'] <= 0) {
            $errors[] = "user_id must be a valid integer";
        } else {
            $validData['user_id'] = (int)$data['user_id'];
        }

        if (!isset($data['role_id']) || !filter_var($data['role_id'], FILTER_VALIDATE_INT) || $data['role_id'] <= 0) {
            $errors[] = "role_id must be a valid integer";
        } else {
            $validData['role_id'] = (int)$data['role_id'];
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return $validData;
    }

    // Send JSON error response
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    // Send JSON success response
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Check admin access
    private function checkAdminAccess() {
        if (!isset($_SESSION['uid'])) {
            $this->sendError(403, 'Unauthorized access');
        }
    }

    // Handle GET requests
    public function get($request) {
        $this->checkAdminAccess();

        if (isset($request['action'])) {
            switch ($request['action']) {
                case 'roles':
                    $this->getRoles($request);
                    break;
                case 'permissions':
                    $this->getPermissions($request);
                    break;
                case 'role_permissions':
                    $this->getRolePermissions($request);
                    break;
                case 'staff':
                    $this->getStaff($request);
                    break;
                case 'role_users':
                    $this->getRoleUsers($request);
                    break;
                default:
                    $this->sendError(400, 'Invalid action');
            }
        } else {
            $this->sendError(400, 'Action parameter is required');
        }
    }

    private function getRoles($request) {
        $page = isset($request['page']) ? max(1, (int)$request['page']) : 1;
        $perPage = isset($request['perPage']) ? max(1, min(100, (int)$request['perPage'])) : 10;
        $offset = ($page - 1) * $perPage;

        $query = "
            SELECT r.id, r.role_name, r.description, r.status,
                   GROUP_CONCAT(p.permission_name) as permissions,
                   GROUP_CONCAT(CONCAT(u.id, ':', u.name, ':', u.email)) as users
            FROM roles r
            LEFT JOIN role_permissions rp ON r.id = rp.role_id
            LEFT JOIN permissions p ON rp.permission_id = p.id
            LEFT JOIN user_roles ur ON r.id = ur.role_id
            LEFT JOIN users u ON ur.user_id = u.id
        ";
        $countQuery = "SELECT COUNT(*) FROM roles";
        $params = [];

        if (isset($request['status'])) {
            $query .= " WHERE r.status = ?";
            $countQuery .= " WHERE status = ?";
            $params[] = $request['status'];
        }

        $query .= " GROUP BY r.id ORDER BY r.id LIMIT ? OFFSET ?";
        $params[] = $perPage;
        $params[] = $offset;

        try {
            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            $roles = $stmt->fetchAll();
            foreach ($roles as &$role) {
                $role['permissions'] = $role['permissions'] ? explode(',', $role['permissions']) : [];
                $role['users'] = $role['users'] ? array_map(function($user) {
                    list($id, $name, $email) = explode(':', $user);
                    return ['id' => (int)$id, 'name' => $name, 'email' => $email];
                }, explode(',', $role['users'])) : [];
            }

            $countStmt = $this->pdo->prepare($countQuery);
            $countStmt->execute(array_slice($params, 0, count($params) - 2));
            $total = $countStmt->fetchColumn();

            $this->sendSuccess(200, [
                'data' => $roles,
                'meta' => [
                    'page' => $page,
                    'perPage' => $perPage,
                    'total' => $total,
                    'totalPages' => ceil($total / $perPage)
                ]
            ]);
        } catch (PDOException $e) {
            $this->logError('Fetch roles failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to fetch roles');
        }
    }

    private function getPermissions($request) {
        $query = "SELECT id, permission_name FROM permissions ORDER BY permission_name";
        try {
            $stmt = $this->pdo->prepare($query);
            $stmt->execute();
            $permissions = $stmt->fetchAll();
            $this->sendSuccess(200, ['data' => $permissions]);
        } catch (PDOException $e) {
            $this->logError('Fetch permissions failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to fetch permissions');
        }
    }

    private function getRolePermissions($request) {
        if (!isset($request['role_id']) || !filter_var($request['role_id'], FILTER_VALIDATE_INT)) {
            $this->sendError(400, 'Invalid or missing role_id');
        }

        $role_id = (int)$request['role_id'];
        try {
            $stmt = $this->pdo->prepare("
                SELECT p.id, p.permission_name 
                FROM permissions p 
                JOIN role_permissions rp ON p.id = rp.permission_id 
                WHERE rp.role_id = ?
            ");
            $stmt->execute([$role_id]);
            $permissions = $stmt->fetchAll();
            $this->sendSuccess(200, ['data' => $permissions]);
        } catch (PDOException $e) {
            $this->logError('Fetch role permissions failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to fetch role permissions');
        }
    }

    private function getStaff($request) {
        $page = isset($request['page']) ? max(1, (int)$request['page']) : 1;
        $perPage = isset($request['perPage']) ? max(1, min(100, (int)$request['perPage'])) : 10;
        $offset = ($page - 1) * $perPage;

        $query = "SELECT id, name, email FROM staff WHERE status = 'active' AND email NOT IN (SELECT email FROM users WHERE email IS NOT NULL)";
        $countQuery = "SELECT COUNT(*) FROM staff WHERE status = 'active' AND email NOT IN (SELECT email FROM users WHERE email IS NOT NULL)";

        try {
            $stmt = $this->pdo->prepare($query . " LIMIT ? OFFSET ?");
            $stmt->execute([$perPage, $offset]);
            $staff = $stmt->fetchAll();

            $countStmt = $this->pdo->prepare($countQuery);
            $countStmt->execute();
            $total = $countStmt->fetchColumn();

            $this->sendSuccess(200, [
                'data' => $staff,
                'meta' => [
                    'page' => $page,
                    'perPage' => $perPage,
                    'total' => $total,
                    'totalPages' => ceil($total / $perPage)
                ]
            ]);
        } catch (PDOException $e) {
            $this->logError('Fetch staff failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to fetch staff');
        }
    }

    private function getRoleUsers($request) {
        if (!isset($request['role_id']) || !filter_var($request['role_id'], FILTER_VALIDATE_INT)) {
            $this->sendError(400, 'Invalid or missing role_id');
        }

        $role_id = (int)$request['role_id'];
        try {
            $stmt = $this->pdo->prepare("
                SELECT u.id, u.name, u.email
                FROM users u
                JOIN user_roles ur ON u.id = ur.user_id
                WHERE ur.role_id = ?
            ");
            $stmt->execute([$role_id]);
            $users = $stmt->fetchAll();
            $this->sendSuccess(200, ['data' => $users]);
        } catch (PDOException $e) {
            $this->logError('Fetch role users failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to fetch role users');
        }
    }

    // Handle POST requests
    public function post($data) {
        $this->checkAdminAccess();

        if (!isset($data['action'])) {
            $this->sendError(400, 'Action parameter is required');
        }

        switch ($data['action']) {
            case 'create_role':
                $this->createRole($data);
                break;
            case 'assign_permissions':
                $this->assignPermissions($data);
                break;
            case 'assign_staff_role':
                $this->assignStaffRole($data);
                break;
            case 'edit_user_role':
                $this->editUserRole($data);
                break;
            default:
                $this->sendError(400, 'Invalid action');
        }
    }

    private function createRole($data) {
        $validData = $this->validateInput($data);

        $fields = ['role_name', 'description', 'status'];
        $placeholders = array_fill(0, count($fields), '?');
        $sql = "INSERT INTO roles (" . implode(',', $fields) . ", created_at) VALUES (" . implode(',', $placeholders) . ", NOW())";

        try {
            $stmt = $this->pdo->prepare($sql);
            $values = [];
            foreach ($fields as $field) {
                $values[] = $validData[$field] ?? ($field === 'description' ? null : 'active');
            }
            $stmt->execute($values);
            $this->sendSuccess(201, ['message' => 'Role created', 'id' => $this->pdo->lastInsertId()]);
        } catch (PDOException $e) {
            $this->logError('Create role failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to create role');
        }
    }

    private function assignPermissions($data) {
        $validData = $this->validatePermissionInput($data);

        try {
            $this->pdo->beginTransaction();
            $stmt = $this->pdo->prepare("DELETE FROM role_permissions WHERE role_id = ?");
            $stmt->execute([$validData['role_id']]);

            foreach ($validData['permission_ids'] as $permission_id) {
                $stmt = $this->pdo->prepare("INSERT INTO role_permissions (role_id, permission_id, created_at) VALUES (?, ?, NOW())");
                $stmt->execute([$validData['role_id'], $permission_id]);
            }

            $this->pdo->commit();
            $this->sendSuccess(200, ['message' => 'Permissions assigned successfully']);
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            $this->logError('Assign permissions failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to assign permissions');
        }
    }

    private function assignStaffRole($data) {
        $validData = $this->validateStaffRoleInput($data);

        try {
            // Fetch staff details
            $stmt = $this->pdo->prepare("SELECT * FROM staff WHERE id = ? AND status = 'active'");
            $stmt->execute([$validData['staff_id']]);
            $staff = $stmt->fetch();

            if (!$staff) {
                $this->sendError(404, 'Staff not found');
            }

            // Check if staff is already in users
            $checkStmt = $this->pdo->prepare("SELECT 1 FROM users WHERE email = ?");
            $checkStmt->execute([$staff['email']]);
            if ($checkStmt->fetch()) {
                $this->sendError(400, 'Staff already in users');
            }

            // Generate custom UID
            $uid = $this->generateCustomUid();
            $checkUidStmt = $this->pdo->prepare("SELECT 1 FROM users WHERE uid = ?");
            $attempts = 0;
            while ($checkUidStmt->execute([$uid]) && $checkUidStmt->fetch() && $attempts < 10) {
                $uid = $this->generateCustomUid();
                $attempts++;
            }
            if ($attempts >= 10) {
                $this->sendError(500, 'Failed to generate unique UID');
            }

            // Insert into users
            $insertStmt = $this->pdo->prepare("
                INSERT INTO users (uid, name, email, password, mobile, role, photo, otp, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
            ");
            $insertStmt->execute([
                $uid,
                $staff['name'],
                $staff['email'],
                $staff['password'],
                $staff['mobile'],
                $staff['role'],
                '/' . $staff['photo'],
                $staff['otp']
            ]);
            $user_id = $this->pdo->lastInsertId();

            // Assign role to user
            $roleStmt = $this->pdo->prepare("INSERT INTO user_roles (user_id, role_id, created_at) VALUES (?, ?, NOW())");
            $roleStmt->execute([$user_id, $validData['role_id']]);

            $this->sendSuccess(201, ['message' => 'Staff assigned to role and added to users', 'uid' => $uid]);
        } catch (PDOException $e) {
            $this->logError('Assign staff role failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to assign role to staff');
        }
    }

    private function editUserRole($data) {
        $validData = $this->validateUserRoleInput($data);

        try {
            // Check if user and role exist
            $stmt = $this->pdo->prepare("SELECT 1 FROM users WHERE id = ?");
            $stmt->execute([$validData['user_id']]);
            if (!$stmt->fetch()) {
                $this->sendError(404, 'User not found');
            }

            $stmt = $this->pdo->prepare("SELECT 1 FROM roles WHERE id = ?");
            $stmt->execute([$validData['role_id']]);
            if (!$stmt->fetch()) {
                $this->sendError(404, 'Role not found');
            }

            // Update user role
            $stmt = $this->pdo->prepare("
                UPDATE user_roles 
                SET role_id = ?, created_at = NOW() 
                WHERE user_id = ? AND role_id = ?
            ");
            $stmt->execute([$validData['role_id'], $validData['user_id'], $validData['old_role_id'] ?? $validData['role_id']]);
            if ($stmt->rowCount() === 0) {
                // If no existing assignment, insert new
                $stmt = $this->pdo->prepare("
                    INSERT INTO user_roles (user_id, role_id, created_at) 
                    VALUES (?, ?, NOW())
                ");
                $stmt->execute([$validData['user_id'], $validData['role_id']]);
            }

            $this->sendSuccess(200, ['message' => 'User role updated']);
        } catch (PDOException $e) {
            $this->logError('Edit user role failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to update user role');
        }
    }

    // Handle POST for deleting user role
    public function postDelete($data) {
        $this->checkAdminAccess();

        if (!isset($data['user_id']) || !filter_var($data['user_id'], FILTER_VALIDATE_INT) || $data['user_id'] <= 0) {
            $this->sendError(400, 'Invalid or missing user_id');
        }

        if (!isset($data['role_id']) || !filter_var($data['role_id'], FILTER_VALIDATE_INT) || $data['role_id'] <= 0) {
            $this->sendError(400, 'Invalid or missing role_id');
        }

        try {
            // Prevent removing Admin role from users if it's their only role
            $stmt = $this->pdo->prepare("SELECT COUNT(*) as role_count FROM user_roles WHERE user_id = ?");
            $stmt->execute([(int)$data['user_id']]);
            $roleCount = $stmt->fetchColumn();

            if ($roleCount <= 1 && (int)$data['role_id'] === 1) {
                $this->sendError(403, 'Cannot remove Admin role as it is the user\'s only role');
            }

            $stmt = $this->pdo->prepare("DELETE FROM user_roles WHERE user_id = ? AND role_id = ?");
            $stmt->execute([(int)$data['user_id'], (int)$data['role_id']]);
            if ($stmt->rowCount()) {
                $this->sendSuccess(200, ['message' => 'User role assignment deleted']);
            } else {
                $this->sendError(404, 'User role assignment not found');
            }
        } catch (PDOException $e) {
            $this->logError('Delete user role failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to delete user role');
        }
    }

    // Handle PUT requests
    public function put($data) {
        $this->checkAdminAccess();
        $validData = $this->validateInput($data, true);

        if (!isset($validData['id'])) {
            $this->sendError(400, 'ID is required');
        }

        $stmt = $this->pdo->prepare("SELECT * FROM roles WHERE id = ?");
        $stmt->execute([$validData['id']]);
        $existing = $stmt->fetch();

        if (!$existing) {
            $this->sendError(404, 'Role not found');
        }

        $fields = ['role_name', 'description', 'status'];
        $updateFields = [];
        $values = [];
        foreach ($fields as $field) {
            if (isset($validData[$field])) {
                $updateFields[] = "$field = ?";
                $values[] = $validData[$field];
            } else {
                $updateFields[] = "$field = ?";
                $values[] = $existing[$field];
            }
        }
        $values[] = $validData['id'];

        $sql = "UPDATE roles SET " . implode(', ', $updateFields) . ", updated_at = NOW() WHERE id = ?";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($values);
            $this->sendSuccess(200, ['message' => 'Role updated']);
        } catch (PDOException $e) {
            $this->logError('Update role failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to update role');
        }
    }

    // Handle DELETE requests
    public function delete($data) {
        $this->checkAdminAccess();

        if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT)) {
            $this->sendError(400, 'Invalid or missing ID');
        }

        if ((int)$data['id'] === 1) {
            $this->sendError(403, 'Default Admin role cannot be deleted');
        }

        try {
            $stmt = $this->pdo->prepare("DELETE FROM roles WHERE id = ?");
            $stmt->execute([(int)$data['id']]);
            if ($stmt->rowCount()) {
                $this->sendSuccess(200, ['message' => 'Role deleted']);
            } else {
                $this->sendError(404, 'Role not found');
            }
        } catch (PDOException $e) {
            $this->logError('Delete role failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to delete role');
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $data = json_decode(file_get_contents('php://input'), true) ?: [];

        switch ($method) {
            case 'GET':
                $this->get($_GET);
                break;
            case 'POST':
                if (isset($data['action']) && $data['action'] === 'delete_user_role') {
                    $this->postDelete($data);
                } else {
                    $this->post($data);
                }
                break;
            case 'PUT':
                $this->put($data);
                break;
            case 'DELETE':
                $this->delete($data);
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new RoleController();
$controller->handleRequest();
?>