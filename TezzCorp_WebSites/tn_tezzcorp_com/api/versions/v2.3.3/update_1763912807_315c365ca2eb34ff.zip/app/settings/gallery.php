<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Gallery Management - AI-ERP 2.0</title>
    <style>
        .btn-loading .spinner-border {
            display: inline-block;
        }
        .spinner-border {
            display: none;
            width: 1rem;
            height: 1rem;
        }
        .gallery-item {
            position: relative;
            overflow: hidden;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .gallery-item img, .gallery-item video {
            width: 100%;
            height: 200px;
            object-fit: cover;
            transition: transform 0.3s ease;
        }
        .gallery-item:hover img, .gallery-item:hover video {
            transform: scale(1.05);
        }
        .gallery-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        .gallery-item:hover .gallery-overlay {
            opacity: 1;
        }
        .category-badge {
            position: absolute;
            top: 10px;
            left: 10px;
            z-index: 2;
        }
        .preview-container {
            max-height: 200px;
            overflow: hidden;
            border-radius: 8px;
            margin-top: 10px;
        }
        .preview-container img, .preview-container video {
            width: 100%;
            height: auto;
            max-height: 200px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Gallery Management</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Gallery
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Add New Gallery Item -->
                    <div class="card card-body mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0">Add New Gallery Item</h5>
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#galleryModal">
                                <i class="ti ti-plus"></i> Add Item
                            </button>
                        </div>
                    </div>

                    <!-- Filter Tabs -->
                    <div class="card card-body">
                        <ul class="nav nav-pills mb-4" id="categoryTabs">
                            <li class="nav-item">
                                <button class="nav-link active" id="all-tab" type="button">
                                    All Items
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="photos-tab" type="button">
                                    Photos
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="events-tab" type="button">
                                    Events
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="facilities-tab" type="button">
                                    Facilities
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="achievements-tab" type="button">
                                    Achievements
                                </button>
                            </li>
                        </ul>

                        <!-- Gallery Grid -->
                        <div class="row" id="galleryGrid">
                            <!-- Gallery items will be loaded here -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Gallery Modal -->
    <div class="modal fade" id="galleryModal" tabindex="-1" aria-labelledby="galleryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="galleryModalLabel">Add Gallery Item</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="galleryForm" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" id="gallery_id" name="id">
                        <input type="hidden" name="_method" value="POST">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="category" class="form-label">Category <span class="text-danger">*</span></label>
                                <select id="category" name="category" class="form-control" required>
                                    <option value="">Select Category</option>
                                    <option value="Photos">Photos</option>
                                    <option value="Events">Events</option>
                                    <option value="Facilities">Facilities</option>
                                    <option value="Achievements">Achievements</option>
                                </select>
                                <span class="validation-text text-danger"></span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="image" class="form-label">Image</label>
                                <input type="file" id="image" name="image" class="form-control" accept="image/*" />
                                <div id="image_preview" class="preview-container" style="display: none;">
                                    <img id="image_preview_img" src="/placeholder.svg" alt="Image Preview" />
                                </div>
                                <span class="validation-text text-danger"></span>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="videos" class="form-label">Video</label>
                                <input type="file" id="videos" name="videos" class="form-control" accept="video/*" />
                                <div id="video_preview" class="preview-container" style="display: none;">
                                    <video id="video_preview_video" controls>
                                        <source src="" type="video/mp4">
                                        Your browser does not support the video tag.
                                    </video>
                                </div>
                                <span class="validation-text text-danger"></span>
                            </div>
                        </div>

                        <div class="alert alert-info">
                            <i class="ti ti-info-circle"></i>
                            You can upload either an image or a video, or both for each gallery item.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="save-gallery-btn">
                            Save Item
                            <div class="spinner-border text-light btn-loading" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        $(document).ready(function() {
            let currentCategory = 'all';
            let allGalleryItems = []; // Store all items for filtering

            // Load gallery items
            function loadGallery(category = 'all') {
                $.ajax({
                    url: 'api/gallery_master.php',
                    type: 'GET',
                    data: {}, // Always load all items
                    dataType: 'json',
                    success: function(response) {
                        allGalleryItems = response.data || []; // Store all items
                        filterAndDisplayItems(category); // Filter items based on category
                    },
                    error: function(xhr, status, error) {
                        console.error('Error loading gallery:', xhr.responseText);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load gallery items: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            function filterAndDisplayItems(category) {
                
                let filteredItems = allGalleryItems;
                
                if (category !== 'all') {
                    filteredItems = allGalleryItems.filter(item => {
                        return item.category === category; // Direct comparison without toLowerCase
                    });
                }
                
                displayGalleryItems(filteredItems);
            }

            // Display gallery items
            function displayGalleryItems(items) {
                const grid = $('#galleryGrid');
                grid.empty();

                if (items.length === 0) {
                    grid.html('<div class="col-12 text-center py-5"><p class="text-muted">No gallery items found.</p></div>');
                    return;
                }

                items.forEach(function(item) {
                    const categoryClass = item.category.toLowerCase();
                    const categoryColor = {
                        'photos': 'primary',
                        'events': 'success',
                        'facilities': 'info',
                        'achievements': 'warning'
                    }[categoryClass] || 'secondary';

                    let mediaContent = '';
                    if (item.image) {
                        mediaContent = `<img src="${item.image}" alt="Gallery Image" />`;
                    } else if (item.videos) {
                        mediaContent = `<video controls><source src="${item.videos}" type="video/mp4">Your browser does not support the video tag.</video>`;
                    } else {
                        mediaContent = `<div class="d-flex align-items-center justify-content-center bg-light" style="height: 200px;"><i class="ti ti-photo fs-1 text-muted"></i></div>`;
                    }

                    const itemHtml = `
                        <div class="col-md-4 col-lg-3">
                            <div class="gallery-item">
                                <span class="badge bg-${categoryColor} category-badge">${item.category}</span>
                                ${mediaContent}
                                <div class="gallery-overlay">
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-light" onclick="editGalleryItem(${item.id})" title="Edit">
                                            <i class="ti ti-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger" onclick="deleteGalleryItem(${item.id})" title="Delete">
                                            <i class="ti ti-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                    grid.append(itemHtml);
                });
            }

            // Handle category tab clicks
            $('#categoryTabs button').on('click', function() {
                $('#categoryTabs button').removeClass('active');
                $(this).addClass('active');
                
                const tabId = $(this).attr('id').replace('-tab', '');
                let category;
                
                switch(tabId) {
                    case 'all':
                        category = 'all';
                        break;
                    case 'photos':
                        category = 'Photos';
                        break;
                    case 'events':
                        category = 'Events';
                        break;
                    case 'facilities':
                        category = 'Facilities';
                        break;
                    case 'achievements':
                        category = 'Achievements';
                        break;
                    default:
                        category = 'all';
                }
                
                currentCategory = category;
                filterAndDisplayItems(category);
            });

            // Preview image before upload
            $('#image').on('change', function(event) {
                const file = event.target.files[0];
                if (file) {
                    $('#image_preview_img').attr('src', URL.createObjectURL(file));
                    $('#image_preview').show();
                } else {
                    $('#image_preview').hide();
                }
            });

            // Preview video before upload
            $('#videos').on('change', function(event) {
                const file = event.target.files[0];
                if (file) {
                    $('#video_preview_video source').attr('src', URL.createObjectURL(file));
                    $('#video_preview_video')[0].load();
                    $('#video_preview').show();
                } else {
                    $('#video_preview').hide();
                }
            });

            // Handle form submission
            $('#galleryForm').on('submit', function(e) {
                e.preventDefault();

                if (!this.checkValidity()) {
                    this.reportValidity();
                    return;
                }

                const formData = new FormData(this);
                const isEdit = $('#gallery_id').val() !== '';

                if (isEdit) {
                    formData.set('_method', 'PUT');
                }

                $('#save-gallery-btn').addClass('btn-loading');

                $.ajax({
                    url: 'api/gallery_master.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || (isEdit ? 'Gallery item updated successfully' : 'Gallery item added successfully')
                        });
                        $('#galleryModal').modal('hide');
                        loadGallery(currentCategory);
                        resetForm();
                    },
                    error: function(xhr, status, error) {
                        console.error('Error saving gallery item:', xhr.responseText);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to save gallery item: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('#save-gallery-btn').removeClass('btn-loading');
                    }
                });
            });

            // Reset form
            function resetForm() {
                $('#galleryForm')[0].reset();
                $('#gallery_id').val('');
                $('#galleryModalLabel').text('Add Gallery Item');
                $('#image_preview, #video_preview').hide();
                $('.validation-text').text('');
            }

            // Edit gallery item
            window.editGalleryItem = function(id) {
                $.ajax({
                    url: 'api/gallery_master.php',
                    type: 'GET',
                    data: { id: id },
                    dataType: 'json',
                    success: function(response) {
                        const item = response.data[0];
                        $('#gallery_id').val(item.id);
                        $('#category').val(item.category);
                        
                        if (item.image) {
                            $('#image_preview_img').attr('src', item.image);
                            $('#image_preview').show();
                        }
                        if (item.videos) {
                            $('#video_preview_video source').attr('src', item.videos);
                            $('#video_preview_video')[0].load();
                            $('#video_preview').show();
                        }

                        $('#galleryModalLabel').text('Edit Gallery Item');
                        $('#galleryModal').modal('show');
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load gallery item: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            };

            // Delete gallery item
            window.deleteGalleryItem = function(id) {
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'api/gallery_master.php',
                            type: 'POST',
                            data: { id: id, _method: 'DELETE' },
                            dataType: 'json',
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted!',
                                    text: response.message || 'Gallery item has been deleted.'
                                });
                                loadGallery(currentCategory);
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to delete gallery item: ' + (xhr.responseJSON?.error || error)
                                });
                            }
                        });
                    }
                });
            };

            // Reset form when modal is hidden
            $('#galleryModal').on('hidden.bs.modal', function() {
                resetForm();
            });

            // Initial load
            loadGallery();
        });
    </script>
</body>
</html>