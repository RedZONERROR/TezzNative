<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Template Settings - AI-ERP 2.0</title>
    <style>
        .btn-loading .spinner-border {
            display: inline-block;
        }
        .spinner-border {
            display: none;
            width: 1rem;
            height: 1rem;
        }
        .preview-frame {
            width: 100%;
            height: 400px;
            border: 1px solid #dee2e6;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Template Settings</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Template Settings
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Template Selection Form -->
                    <div class="card card-body">
                        <form id="templateSettingsForm">
                            <input type="hidden" id="admit_card_id">
                            <input type="hidden" id="marksheet_id">
                            <input type="hidden" id="id_card_id">
                            <input type="hidden" name="_method" value="PUT">

                            <!-- Admit Card Template -->
                            <h5 class="mb-3">Admit Card Template</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="admit_card_template" class="form-label">Select Template</label>
                                    <select id="admit_card_template" name="admit_card_template" class="form-control">
                                        <option value="">Select a template</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Preview</label>
                                    <iframe id="admit_card_preview" class="preview-frame" src=""></iframe>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="admit_card_status" class="form-label">Status</label>
                                    <select id="admit_card_status" name="admit_card_status" class="form-control">
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                            </div>

                            <!-- Marksheet Template -->
                            <h5 class="mt-4 mb-3">Marksheet Template</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="marksheet_template" class="form-label">Select Template</label>
                                    <select id="marksheet_template" name="marksheet_template" class="form-control">
                                        <option value="">Select a template</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Preview</label>
                                    <iframe id="marksheet_preview" class="preview-frame" src=""></iframe>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="marksheet_status" class="form-label">Status</label>
                                    <select id="marksheet_status" name="marksheet_status" class="form-control">
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                            </div>

                            <!-- ID Card Template -->
                            <h5 class="mt-4 mb-3">ID Card Template</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="id_card_template" class="form-label">Select Template</label>
                                    <select id="id_card_template" name="id_card_template" class="form-control">
                                        <option value="">Select a template</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Preview</label>
                                    <iframe id="id_card_preview" class="preview-frame" src=""></iframe>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="id_card_status" class="form-label">Status</label>
                                    <select id="id_card_status" name="id_card_status" class="form-control">
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                            </div>

                            <div class="text-end mt-4">
                                <button type="submit" class="btn btn-success" id="save-template-btn">Save Templates
                                    <div class="spinner-border text-light btn-loading" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        $(document).ready(function() {
            // Load existing templates and available templates
            function loadTemplates() {
                $.ajax({
                    url: 'api/template_master.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        console.log('API Response:', response);
                        const templates = response.data || [];
                        const availableTemplates = response.available_templates || {};

                        // Populate admit card templates
                        $('#admit_card_template').empty().append('<option value="">Select a template</option>');
                        if (availableTemplates['admit-card']) {
                            availableTemplates['admit-card'].forEach(file => {
                                $('#admit_card_template').append(`<option value="${file}">${file}</option>`);
                            });
                        }

                        // Populate marksheet templates
                        $('#marksheet_template').empty().append('<option value="">Select a template</option>');
                        if (availableTemplates['marksheet']) {
                            availableTemplates['marksheet'].forEach(file => {
                                $('#marksheet_template').append(`<option value="${file}">${file}</option>`);
                            });
                        }

                        // Populate id card templates
                        $('#id_card_template').empty().append('<option value="">Select a template</option>');
                        if (availableTemplates['id-card']) {
                            availableTemplates['id-card'].forEach(file => {
                                $('#id_card_template').append(`<option value="${file}">${file}</option>`);
                            });
                        }

                        // Set current selections
                        templates.forEach(template => {
                            if (template.template_type === 'admit-card') {
                                $('#admit_card_id').val(template.id || '');
                                $('#admit_card_template').val(template.template_file || '');
                                $('#admit_card_status').val(template.status || 'active');
                                $('#admit_card_preview').attr('src', template.template_file ? `/app/settings/templates/admit-card/${template.template_file}` : '');
                            } else if (template.template_type === 'marksheet') {
                                $('#marksheet_id').val(template.id || '');
                                $('#marksheet_template').val(template.template_file || '');
                                $('#marksheet_status').val(template.status || 'active');
                                $('#marksheet_preview').attr('src', template.template_file ? `/app/settings/templates/marksheet/${template.template_file}` : '');
                            } else if (template.template_type === 'id-card') {
                                $('#id_card_id').val(template.id || '');
                                $('#id_card_template').val(template.template_file || '');
                                $('#id_card_status').val(template.status || 'active');
                                $('#id_card_preview').attr('src', template.template_file ? `/app/settings/templates/id-card/${template.template_file}` : '');
                            }
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error('Error loading templates:', xhr.responseText);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load templates: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Update preview on template selection
            $('#admit_card_template').on('change', function() {
                const file = $(this).val();
                $('#admit_card_preview').attr('src', file ? `/app/settings/templates/admit-card/${file}` : '');
            });

            $('#marksheet_template').on('change', function() {
                const file = $(this).val();
                $('#marksheet_preview').attr('src', file ? `/app/settings/templates/marksheet/${file}` : '');
            });

            $('#id_card_template').on('change', function() {
                const file = $(this).val();
                $('#id_card_preview').attr('src', file ? `/app/settings/templates/id-card/${file}` : '');
            });

            // Handle form submission
            $('#templateSettingsForm').on('submit', function(e) {
                e.preventDefault();

                // Collect selected templates
                const requests = [
                    {
                        id: $('#admit_card_id').val(),
                        template_type: 'admit-card',
                        template_file: $('#admit_card_template').val(),
                        status: $('#admit_card_status').val()
                    },
                    {
                        id: $('#marksheet_id').val(),
                        template_type: 'marksheet',
                        template_file: $('#marksheet_template').val(),
                        status: $('#marksheet_status').val()
                    },
                    {
                        id: $('#id_card_id').val(),
                        template_type: 'id-card',
                        template_file: $('#id_card_template').val(),
                        status: $('#id_card_status').val()
                    }
                ].filter(req => req.template_file); // Only include templates with selected files

                if (requests.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Templates Selected',
                        text: 'Please select at least one template to save.'
                    });
                    return;
                }

                $('#save-template-btn').addClass('btn-loading');

                let completedRequests = 0;
                let errors = [];

                requests.forEach(request => {
                    const formData = new FormData();
                    for (const [key, value] of Object.entries(request)) {
                        formData.append(key, value);
                    }
                    formData.append('_method', request.id ? 'PUT' : 'POST');

                    $.ajax({
                        url: 'api/template_master.php',
                        type: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function(response) {
                            completedRequests++;
                            // Update hidden ID field if new template was created
                            if (!request.id && response.id) {
                                if (request.template_type === 'admit-card') {
                                    $('#admit_card_id').val(response.id);
                                } else if (request.template_type === 'marksheet') {
                                    $('#marksheet_id').val(response.id);
                                } else if (request.template_type === 'id-card') {
                                    $('#id_card_id').val(response.id);
                                }
                            }
                            if (completedRequests === requests.length) {
                                $('#save-template-btn').removeClass('btn-loading');
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Success',
                                    text: 'Templates updated successfully'
                                });
                                loadTemplates();
                            }
                        },
                        error: function(xhr, status, error) {
                            completedRequests++;
                            errors.push(xhr.responseJSON?.error || error);
                            if (completedRequests === requests.length) {
                                $('#save-template-btn').removeClass('btn-loading');
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to update some templates: ' + errors.join('; ')
                                });
                            }
                        }
                    });
                });
            });

            // Initial load
            loadTemplates();
        });
    </script>
</body>
</html>