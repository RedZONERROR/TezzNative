<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Role Management - AI-ERP 2.0</title>
    <style>
        .btn-loading .spinner-border {
            display: inline-block;
        }
        .spinner-border {
            display: none;
            width: 1rem;
            height: 1rem;
        }
        #permissions_list .form-check {
            margin-bottom: 10px;
        }
        .permissions-cell {
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .permissions-cell:hover {
            overflow: visible;
            white-space: normal;
            z-index: 1;
            position: relative;
            background: #fff;
            border: 1px solid #ddd;
            padding: 5px;
        }
    </style>
</head>
<body>
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <?php include 'util/sidebar.php'; ?>
        <div class="page-wrapper">
            <?php include 'util/topbar.php'; ?>
            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Role Management</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Role Management
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Roles Table -->
                        <div class="col-lg-12">
                            <div class="card card-body">
                                <div class="d-flex justify-content-end mb-3">
                                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#roleModal">
                                        Add New Role
                                    </button>
                                </div>
                                <h5 class="card-title">Roles</h5>
                                <div class="table-responsive">
                                    <table class="table table-striped align-middle text-nowrap">
                                        <thead>
                                            <tr>
                                                <th>Role Name</th>
                                                <th>Description</th>
                                                <th>Permissions</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody id="role_table_body">
                                            <!-- Roles will load dynamically -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- Assigned Users Table -->
                        <div class="col-lg-12">
                            <div class="card card-body">
                                <div class="d-flex justify-content-end mb-3">
                                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staffRoleModal">
                                        Assign Role to Staff
                                    </button>
                                </div>
                                <h5 class="card-title">Assigned Users</h5>
                                <div class="table-responsive">
                                    <table class="table table-striped align-middle text-nowrap">
                                        <thead>
                                            <tr>
                                                <th>User Name</th>
                                                <th>Email</th>
                                                <th>Role</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody id="user_roles_list">
                                            <!-- Users will load dynamically -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Role Modal -->
    <div class="modal fade" id="roleModal" tabindex="-1" aria-labelledby="roleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="roleModalLabel">Add Role</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="roleForm">
                        <input type="hidden" id="role_id">
                        <div class="mb-3">
                            <label for="role_name" class="form-label">Role Name</label>
                            <input type="text" class="form-control" id="role_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" rows="4"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-control" id="status">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="saveRole">
                        Save Role
                        <div class="spinner-border text-light btn-loading" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Permissions Modal -->
    <div class="modal fade" id="permissionsModal" tabindex="-1" aria-labelledby="permissionsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="permissionsModalLabel">Assign Permissions</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="permission_role_id">
                    <div class="row" id="permissions_list">
                        <!-- Permissions will load dynamically -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="savePermissions">
                        Save Permissions
                        <div class="spinner-border text-light btn-loading" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Staff Role Assignment Modal -->
    <div class="modal fade" id="staffRoleModal" tabindex="-1" aria-labelledby="staffRoleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staffRoleModalLabel">Assign Role to Staff</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="staffRoleForm">
                        <div class="mb-3">
                            <label for="staff_id" class="form-label">Select Staff</label>
                            <select class="form-control" id="staff_id" required>
                                <option value="">Select a staff</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="staff_role_id" class="form-label">Select Role</label>
                            <select class="form-control" id="staff_role_id" required>
                                <option value="">Select a role</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="saveStaffRole">
                        Assign Role
                        <div class="spinner-border text-light btn-loading" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit User Role Modal -->
    <div class="modal fade" id="editUserRoleModal" tabindex="-1" aria-labelledby="editUserRoleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editUserRoleModalLabel">Edit User Role</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editUserRoleForm">
                        <input type="hidden" id="edit_user_id">
                        <input type="hidden" id="edit_old_role_id">
                        <div class="mb-3">
                            <label for="edit_user_name" class="form-label">User Name</label>
                            <input type="text" class="form-control" id="edit_user_name" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="edit_user_email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="edit_user_email" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="edit_role_id" class="form-label">Select Role</label>
                            <select class="form-control" id="edit_role_id" required>
                                <option value="">Select a role</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="saveUserRole">
                        Save Role
                        <div class="spinner-border text-light btn-loading" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/vendor.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        $(document).ready(function() {
            // Load roles
            function loadRoles() {
                $.ajax({
                    url: 'api/role_management.php?action=roles&status=active',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        const roles = response.data || [];
                        $('#role_table_body').empty();
                        roles.forEach(role => {
                            const isAdmin = role.id === 1;
                            const permissions = role.permissions.join(', ') || 'None';
                            $('#role_table_body').append(`
                                <tr data-role-id="${role.id}">
                                    <td>${role.role_name}</td>
                                    <td>${role.description || 'N/A'}</td>
                                    <td class="permissions-cell">${permissions}</td>
                                    <td>${role.status.charAt(0).toUpperCase() + role.status.slice(1)}</td>
                                    <td>
                                        <button class="btn btn-sm btn-info edit-role" title="Edit Role">
                                            <i class="ti ti-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-primary assign-permissions" title="Assign Permissions">
                                            <i class="ti ti-key"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger delete-role" title="Delete Role" ${isAdmin ? 'disabled' : ''}>
                                            <i class="ti ti-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            `);
                        });
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load roles: ' + (xhr.responseJSON?.error || 'Unknown error')
                        });
                    }
                });
            }

            // Load assigned users
            function loadAssignedUsers() {
                $.ajax({
                    url: 'api/role_management.php?action=roles',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        const roles = response.data || [];
                        const userRoleMap = {};
                        $('#user_roles_list').empty();

                        // Deduplicate user-role pairs
                        roles.forEach(role => {
                            role.users.forEach(user => {
                                const key = `${user.id}-${role.id}`;
                                if (!userRoleMap[key]) {
                                    userRoleMap[key] = {
                                        userId: user.id,
                                        roleId: role.id,
                                        name: user.name,
                                        email: user.email,
                                        roleName: role.role_name
                                    };
                                }
                            });
                        });

                        // Populate table with unique user-role pairs
                        Object.values(userRoleMap).forEach(entry => {
                            $('#user_roles_list').append(`
                                <tr data-user-id="${entry.userId}" data-role-id="${entry.roleId}">
                                    <td>${entry.name}</td>
                                    <td>${entry.email}</td>
                                    <td>${entry.roleName}</td>
                                    <td>
                                        <button class="btn btn-sm btn-info edit-user-role" title="Edit User Role">
                                            <i class="ti ti-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger delete-user-role" title="Delete User Role">
                                            <i class="ti ti-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            `);
                        });
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load users: ' + (xhr.responseJSON?.error || 'Unknown error')
                        });
                    }
                });
            }

            // Load permissions for assignment modal
            function loadPermissions(roleId) {
                $.ajax({
                    url: `api/role_management.php?action=permissions`,
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        const permissions = response.data || [];
                        $('#permissions_list').empty();
                        permissions.forEach(perm => {
                            $('#permissions_list').append(`
                                <div class="col-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input permission-checkbox" 
                                               type="checkbox" 
                                               value="${perm.id}" 
                                               id="perm_${perm.id}">
                                        <label class="form-check-label" for="perm_${perm.id}">
                                            ${perm.permission_name}
                                        </label>
                                    </div>
                                </div>
                            `);
                        });

                        $.ajax({
                            url: `api/role_management.php?action=role_permissions&role_id=${roleId}`,
                            type: 'GET',
                            dataType: 'json',
                            success: function(resp) {
                                const rolePermissions = resp.data || [];
                                rolePermissions.forEach(perm => {
                                    $(`#perm_${perm.id}`).prop('checked', true);
                                });
                            },
                            error: function(xhr) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to load role permissions: ' + (xhr.responseJSON?.error || 'Unknown error')
                                });
                            }
                        });
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load permissions: ' + (xhr.responseJSON?.error || 'Unknown error')
                        });
                    }
                });
            }

            // Load staff and roles for staff role assignment
            function loadStaffAndRoles() {
                $.ajax({
                    url: 'api/role_management.php?action=staff',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        const staff = response.data || [];
                        $('#staff_id').empty().append('<option value="">Select a staff</option>');
                        staff.forEach(s => {
                            $('#staff_id').append(`<option value="${s.id}">${s.name} (${s.email})</option>`);
                        });
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load staff: ' + (xhr.responseJSON?.error || 'Unknown error')
                        });
                    }
                });

                $.ajax({
                    url: 'api/role_management.php?action=roles&status=active',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        const roles = response.data || [];
                        $('#staff_role_id').empty().append('<option value="">Select a role</option>');
                        $('#edit_role_id').empty().append('<option value="">Select a role</option>');
                        roles.forEach(role => {
                            $('#staff_role_id').append(`<option value="${role.id}">${role.role_name}</option>`);
                            $('#edit_role_id').append(`<option value="${role.id}">${role.role_name}</option>`);
                        });
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load roles: ' + (xhr.responseJSON?.error || 'Unknown error')
                        });
                    }
                });
            }

            // Add/Edit role
            $('#role_table_body').on('click', '.edit-role', function() {
                const row = $(this).closest('tr');
                const roleId = row.data('role-id');
                if (roleId) {
                    $.ajax({
                        url: `api/role_management.php?action=roles`,
                        type: 'GET',
                        dataType: 'json',
                        success: function(response) {
                            const role = response.data.find(r => r.id === roleId);
                            if (role) {
                                $('#roleModalLabel').text('Edit Role');
                                $('#role_id').val(role.id);
                                $('#role_name').val(role.role_name);
                                $('#description').val(role.description || '');
                                $('#status').val(role.status);
                                $('#roleModal').modal('show');
                            }
                        },
                        error: function(xhr) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to load role: ' + (xhr.responseJSON?.error || 'Unknown error')
                            });
                        }
                    });
                } else {
                    $('#roleModalLabel').text('Add Role');
                    $('#roleForm')[0].reset();
                    $('#role_id').val('');
                    $('#roleModal').modal('show');
                }
            });

            $('#saveRole').on('click', function() {
                if (!$('#roleForm')[0].checkValidity()) {
                    $('#roleForm')[0].reportValidity();
                    return;
                }

                const roleId = $('#role_id').val();
                const data = {
                    action: roleId ? 'update_role' : 'create_role',
                    id: roleId,
                    role_name: $('#role_name').val(),
                    description: $('#description').val(),
                    status: $('#status').val()
                };

                $('#saveRole').addClass('btn-loading');
                $.ajax({
                    url: 'api/role_management.php',
                    type: roleId ? 'PUT' : 'POST',
                    data: JSON.stringify(data),
                    contentType: 'application/json',
                    dataType: 'json',
                    success: function(response) {
                        $('#saveRole').removeClass('btn-loading');
                        $('#roleModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message
                        });
                        loadRoles();
                    },
                    error: function(xhr) {
                        $('#saveRole').removeClass('btn-loading');
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to save role: ' + (xhr.responseJSON?.error || 'Unknown error')
                        });
                    }
                });
            });

            // Assign permissions
            $('#role_table_body').on('click', '.assign-permissions', function() {
                const roleId = $(this).closest('tr').data('role-id');
                $('#permission_role_id').val(roleId);
                loadPermissions(roleId);
                $('#permissionsModal').modal('show');
            });

            $('#savePermissions').on('click', function() {
                const roleId = $('#permission_role_id').val();
                const permissionIds = $('.permission-checkbox:checked').map(function() {
                    return $(this).val();
                }).get();

                $('#savePermissions').addClass('btn-loading');
                $.ajax({
                    url: 'api/role_management.php',
                    type: 'POST',
                    data: JSON.stringify({
                        action: 'assign_permissions',
                        role_id: roleId,
                        permission_ids: permissionIds
                    }),
                    contentType: 'application/json',
                    dataType: 'json',
                    success: function(response) {
                        $('#savePermissions').removeClass('btn-loading');
                        $('#permissionsModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message
                        });
                        loadRoles();
                    },
                    error: function(xhr) {
                        $('#savePermissions').removeClass('btn-loading');
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to assign permissions: ' + (xhr.responseJSON?.error || 'Unknown error')
                        });
                    }
                });
            });

            // Delete role
            $('#role_table_body').on('click', '.delete-role', function() {
                const roleId = $(this).closest('tr').data('role-id');
                Swal.fire({
                    icon: 'warning',
                    title: 'Are you sure?',
                    text: 'This will delete the role and its associated permissions and user assignments.',
                    showCancelButton: true,
                    confirmButtonText: 'Delete',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'api/role_management.php',
                            type: 'DELETE',
                            data: JSON.stringify({ id: roleId }),
                            contentType: 'application/json',
                            dataType: 'json',
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Success',
                                    text: response.message
                                });
                                loadRoles();
                                loadAssignedUsers();
                            },
                            error: function(xhr) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to delete role: ' + (xhr.responseJSON?.error || 'Unknown error')
                                });
                            }
                        });
                    }
                });
            });

            // Edit user role
            $('#user_roles_list').on('click', '.edit-user-role', function() {
                const row = $(this).closest('tr');
                const userId = row.data('user-id');
                const roleId = row.data('role-id');
                $.ajax({
                    url: `api/role_management.php?action=role_users&role_id=${roleId}`,
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        const user = response.data.find(u => u.id === userId);
                        if (user) {
                            $('#edit_user_id').val(user.id);
                            $('#edit_old_role_id').val(roleId);
                            $('#edit_user_name').val(user.name);
                            $('#edit_user_email').val(user.email);
                            $('#edit_role_id').val(roleId);
                            $('#editUserRoleModal').modal('show');
                        }
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load user: ' + (xhr.responseJSON?.error || 'Unknown error')
                        });
                    }
                });
            });

            $('#saveUserRole').on('click', function() {
                if (!$('#editUserRoleForm')[0].checkValidity()) {
                    $('#editUserRoleForm')[0].reportValidity();
                    return;
                }

                const data = {
                    action: 'edit_user_role',
                    user_id: $('#edit_user_id').val(),
                    role_id: $('#edit_role_id').val(),
                    old_role_id: $('#edit_old_role_id').val()
                };

                $('#saveUserRole').addClass('btn-loading');
                $.ajax({
                    url: 'api/role_management.php',
                    type: 'POST',
                    data: JSON.stringify(data),
                    contentType: 'application/json',
                    dataType: 'json',
                    success: function(response) {
                        $('#saveUserRole').removeClass('btn-loading');
                        $('#editUserRoleModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message
                        });
                        loadAssignedUsers();
                    },
                    error: function(xhr) {
                        $('#saveUserRole').removeClass('btn-loading');
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to update user role: ' + (xhr.responseJSON?.error || 'Unknown error')
                        });
                    }
                });
            });

            // Delete user role
            $('#user_roles_list').on('click', '.delete-user-role', function() {
                const row = $(this).closest('tr');
                const userId = row.data('user-id');
                const roleId = row.data('role-id');
                Swal.fire({
                    icon: 'warning',
                    title: 'Are you sure?',
                    text: 'This will remove the role from the user.',
                    showCancelButton: true,
                    confirmButtonText: 'Delete',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'api/role_management.php',
                            type: 'POST',
                            data: JSON.stringify({
                                action: 'delete_user_role',
                                user_id: userId,
                                role_id: roleId
                            }),
                            contentType: 'application/json',
                            dataType: 'json',
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Success',
                                    text: response.message
                                });
                                loadAssignedUsers();
                            },
                            error: function(xhr) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to delete user role: ' + (xhr.responseJSON?.error || 'Unknown error')
                                });
                            }
                        });
                    }
                });
            });

            // Assign role to staff
            $('#staffRoleModal').on('shown.bs.modal', function() {
                loadStaffAndRoles();
            });

            $('#saveStaffRole').on('click', function() {
                if (!$('#staffRoleForm')[0].checkValidity()) {
                    $('#staffRoleForm')[0].reportValidity();
                    return;
                }

                const data = {
                    action: 'assign_staff_role',
                    staff_id: $('#staff_id').val(),
                    role_id: $('#staff_role_id').val()
                };

                $('#saveStaffRole').addClass('btn-loading');
                $.ajax({
                    url: 'api/role_management.php',
                    type: 'POST',
                    data: JSON.stringify(data),
                    contentType: 'application/json',
                    dataType: 'json',
                    success: function(response) {
                        $('#saveStaffRole').removeClass('btn-loading');
                        $('#staffRoleModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message
                        });
                        loadAssignedUsers();
                    },
                    error: function(xhr) {
                        $('#saveStaffRole').removeClass('btn-loading');
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to assign role to staff: ' + (xhr.responseJSON?.error || 'Unknown error')
                        });
                    }
                });
            });

            // Initialize
            loadRoles();
            loadAssignedUsers();
        });
    </script>
</body>
</html>