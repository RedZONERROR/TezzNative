<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- Flatpickr CSS for time picker with AM/PM -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Flatpickr JS -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    <title>Timetable - AI-ERP 2.0</title>
    <style>
        .action-buttons {
            display: none;
        }
        .btn-loading .fa-spinner {
            display: inline-block;
        }
        .btn-loading .btn-text, .btn-loading .ti {
            display: none;
        }
        .fa-spinner {
            display: none;
            font-size: 0.9rem;
        }
        .pagination {
            margin-top: 1rem;
        }
        #days-table input, #days-table select {
            font-size: 0.9rem;
        }
        #days-table th, #days-table td {
            vertical-align: middle;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar -->
        <?php include 'util/sidebar.php'; ?>
        <div class="page-wrapper">
            <!-- Header -->
            <?php include 'util/topbar.php'; ?>

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Timetable</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Timetable
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Timetable Management -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-4 col-xl-3">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Timetable..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-8 col-xl-9 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div class="action-buttons me-2">
                                        <button class="delete-multiple btn bg-danger-subtle text-danger">
                                            <i class="fas fa-spinner fa-spin"></i>
                                            <span class="btn-text">Delete</span>
                                        </button>
                                    </div>
                                    <button id="btn-add-timetable" class="btn btn-primary d-flex align-items-center">
                                        <i class="ti ti-calendar text-white me-1 fs-5"></i> Add Timetable Entry
                                        <span style="margin-left: 3px;"><i class="fas fa-spinner fa-spin"></i></span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Add/Edit Modal -->
                        <div class="modal fade" id="addTimetableModal" tabindex="-1" aria-labelledby="addTimetableModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-xl">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="addTimetableModalLabel">Add Bulk Timetable Entries</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form id="timetableForm">
                                            <input type="hidden" id="timetableId">
                                            <div class="row">
                                                <div class="col-md-6 d-none" id="day-container">
                                                    <div class="mb-3">
                                                        <label for="day" class="form-label">Day *</label>
                                                        <select class="form-control" id="day" name="day" required>
                                                            <option value="Monday">Monday</option>
                                                            <option value="Tuesday">Tuesday</option>
                                                            <option value="Wednesday">Wednesday</option>
                                                            <option value="Thursday">Thursday</option>
                                                            <option value="Friday">Friday</option>
                                                            <option value="Saturday">Saturday</option>
                                                            <option value="Sunday">Sunday</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="class" class="form-label">Class *</label>
                                                        <select class="form-control" id="class" name="class" required>
                                                            <option value="">Select Class</option>
                                                            <!-- Classes will be populated dynamically -->
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="single-entry-fields" class="row d-none">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="period_number" class="form-label">Period Number *</label>
                                                        <input type="number" id="period_number" class="form-control" name="period_number" min="1" required />
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="start_time" class="form-label">Start Time *</label>
                                                        <input type="text" id="start_time" class="form-control timepicker" name="start_time" required />
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="end_time" class="form-label">End Time *</label>
                                                        <input type="text" id="end_time" class="form-control timepicker" name="end_time" required />
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="subject" class="form-label">Subject</label>
                                                        <select class="form-control" id="subject" name="subject">
                                                            <option value="">Select Subject</option>
                                                            <!-- Subjects will be populated dynamically -->
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="tid" class="form-label">Teacher</label>
                                                        <select class="form-control" id="tid" name="tid">
                                                            <option value="">Select Teacher</option>
                                                            <!-- Teachers will be populated dynamically -->
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="is_break" class="form-label">Is Break</label>
                                                        <select class="form-control" id="is_break" name="is_break">
                                                            <option value="0">No</option>
                                                            <option value="1">Yes</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="bulk-entry-fields">
                                                <p><small><em>Enter details for Monday to autofill Tuesday–Friday. Saturday and Sunday must be entered separately.</em></small></p>
                                                <table class="table" id="days-table">
                                                    <thead>
                                                        <tr>
                                                            <th>Day</th>
                                                            <th>Period Number *</th>
                                                            <th>Start Time *</th>
                                                            <th>End Time *</th>
                                                            <th>Subject</th>
                                                            <th>Teacher</th>
                                                            <th>Is Break</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <!-- Rows populated dynamically -->
                                                    </tbody>
                                                </table>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button id="btn-add" class="btn btn-success"> Add
                                            <i class="fas fa-spinner fa-spin btn-loading"></i>
                                        </button>
                                        <button id="btn-edit" class="btn btn-success" style="display: none;"> Save
                                            <i class="fas fa-spinner fa-spin btn-loading"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- View Modal -->
                        <div class="modal fade" id="viewTimetableModal" tabindex="-1" aria-labelledby="viewTimetableModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="viewTimetableModalLabel">Timetable Details</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>ID:</strong> <span id="view-id"></span></p>
                                        <p><strong>Day:</strong> <span id="view-day"></span></p>
                                        <p><strong>Class:</strong> <span id="view-class"></span></p>
                                        <p><strong>Period Number:</strong> <span id="view-period_number"></span></p>
                                        <p><strong>Start Time:</strong> <span id="view-start_time"></span></p>
                                        <p><strong>End Time:</strong> <span id="view-end_time"></span></p>
                                        <p><strong>Subject:</strong> <span id="view-subject"></span></p>
                                        <p><strong>Teacher:</strong> <span id="view-tid"></span></p>
                                        <p><strong>Is Break:</strong> <span id="view-is_break"></span></p>
                                        <p><strong>Created At:</strong> <span id="view-created_at"></span></p>
                                        <p><strong>Updated At:</strong> <span id="view-updated_at"></span></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card card-body">
                            <div class="d-flex justify-content-center">
                                <div class="spinner-border text-primary" role="status" id="table-loader">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <tr>
                                            <th>
                                                <div class="n-chk align-self-center text-center">
                                                    <div class="form-check">
                                                        <input type="checkbox" class="form-check-input primary" id="timetable-check-all" />
                                                        <label class="form-check-label" for="timetable-check-all"></label>
                                                        <span class="new-control-indicator"></span>
                                                    </div>
                                                </div>
                                            </th>
                                            <th>S.N.</th>
                                            <th>Day</th>
                                            <th>Class</th>
                                            <th>Period</th>
                                            <th>Time</th>
                                            <th>Subject</th>
                                            <th>Teacher</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="timetable_list_table_body">
                                        <!-- Data will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <nav aria-label="Page navigation" id="pagination-nav">
                                <ul class="pagination justify-content-center">
                                    <!-- Pagination controls -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        hljs.initHighlightingOnLoad();
        document.querySelectorAll("pre.code-view > code").forEach((codeBlock) => {
            codeBlock.textContent = codeBlock.innerHTML;
        });

        $(document).ready(function() {
            // Initialize Flatpickr for time inputs with AM/PM
            flatpickr(".timepicker", {
                enableTime: true,
                noCalendar: true,
                dateFormat: "h:i K", // 12-hour format with AM/PM
                time_24hr: false,
                minuteIncrement: 5
            });

            // Pagination state
            let currentPage = 1;
            const perPage = 10;
            let teachersMap = {};
            let classesMap = {};
            let subjectsMap = {};

            // Define applicable days and period limits
            const applicableDays = {
                'Monday': { maxPeriods: 8 },
                'Tuesday': { maxPeriods: 8 },
                'Wednesday': { maxPeriods: 8 },
                'Thursday': { maxPeriods: 8 },
                'Friday': { maxPeriods: 8 },
                'Saturday': { maxPeriods: 4 },
                'Sunday': { maxPeriods: 0 }
            };

            const days = Object.keys(applicableDays);
            const autoFillDays = ['Tuesday', 'Wednesday', 'Thursday', 'Friday'];

            // Helper function to convert 24-hour time to 12-hour format with AM/PM
            function to12HourFormat(time) {
                if (!time || time === '-') return '-';
                const [hours, minutes, seconds = '00'] = time.split(':');
                let hour = parseInt(hours, 10);
                const period = hour >= 12 ? 'PM' : 'AM';
                hour = hour % 12 || 12; // Convert 0 or 12 to 12 AM/PM
                return `${hour}:${minutes} ${period}`;
            }

            // Helper function to convert 12-hour format with AM/PM to 24-hour format
            function to24HourFormat(time) {
                if (!time) return '';
                const [timePart, period] = time.split(' ');
                let [hours, minutes] = timePart.split(':').map(Number);
                if (period === 'PM' && hours !== 12) hours += 12;
                if (period === 'AM' && hours === 12) hours = 0;
                return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:00`;
            }

            // Fetch teachers for mapping tid to teacher_name
            function fetchTeachersForMapping(callback) {
                $.ajax({
                    url: 'api/staff_master.php',
                    type: 'GET',
                    data: { perPage: 100 },
                    dataType: 'json',
                    success: function(response) {
                        const teachers = response.data || [];
                        teachersMap = {};
                        teachers.forEach(t => {
                            teachersMap[t.id] = t.name || t.first_name || '-';
                        });
                        if (callback) callback();
                    },
                    error: function(xhr, status, error) {
                        console.error('Fetch Teachers Error:', xhr.responseJSON, status, error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load teachers: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Fetch classes for mapping class_id to class_name
            function fetchClassesForMapping(callback) {
                $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 100 },
                    dataType: 'json',
                    success: function(response) {
                        const classes = response.data || [];
                        classesMap = {};
                        classes.forEach(c => {
                            classesMap[c.id] = c.class_name;
                        });
                        if (callback) callback();
                    },
                    error: function(xhr, status, error) {
                        console.error('Fetch Classes Error:', xhr.responseJSON, status, error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load classes: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Fetch subjects for mapping subject_id to subject_name
            function fetchSubjectsForMapping(callback) {
                $.ajax({
                    url: 'api/subject_master.php',
                    type: 'GET',
                    data: { perPage: 100 },
                    dataType: 'json',
                    success: function(response) {
                        const subjects = response.data || [];
                        subjectsMap = {};
                        subjects.forEach(s => {
                            subjectsMap[s.id] = s.subject;
                        });
                        if (callback) callback();
                    },
                    error: function(xhr, status, error) {
                        console.error('Fetch Subjects Error:', xhr.responseJSON, status, error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load subjects: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Fetch classes for dropdown
            function fetchClassesForDropdown(callback) {
                $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 100 },
                    dataType: 'json',
                    success: function(response) {
                        const classes = response.data || [];
                        const dropdown = $('#class');
                        dropdown.empty();
                        dropdown.append('<option value="">Select Class</option>');
                        classes.forEach(c => {
                            dropdown.append(`<option value="${c.id}">${c.class_name}</option>`);
                        });
                        if (callback) callback();
                    },
                    error: function(xhr, status, error) {
                        console.error('Fetch Classes Error:', xhr.responseJSON, status, error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load classes: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Fetch subjects for dropdown
            function fetchSubjectsForDropdown(callback) {
                $.ajax({
                    url: 'api/subject_master.php',
                    type: 'GET',
                    data: { perPage: 100 },
                    dataType: 'json',
                    success: function(response) {
                        const subjects = response.data || [];
                        const dropdown = $('#subject');
                        dropdown.empty();
                        dropdown.append('<option value="">Select Subject</option>');
                        subjects.forEach(s => {
                            dropdown.append(`<option value="${s.id}">${s.subject}</option>`);
                        });
                        // Update bulk table subject dropdowns
                        $('#days-table .subject').each(function() {
                            const currentVal = $(this).val();
                            $(this).html(dropdown.html());
                            if (currentVal) $(this).val(currentVal);
                        });
                        if (callback) callback();
                    },
                    error: function(xhr, status, error) {
                        console.error('Fetch Subjects Error:', xhr.responseJSON, status, error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load subjects: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Fetch teachers for dropdown
            function fetchTeachersForDropdown(callback) {
                $.ajax({
                    url: 'api/staff_master.php',
                    type: 'GET',
                    data: { perPage: 100 },
                    dataType: 'json',
                    success: function(response) {
                        const teachers = response.data || [];
                        const dropdown = $('#tid');
                        dropdown.empty();
                        dropdown.append('<option value="">Select Teacher</option>');
                        teachers.forEach(t => {
                            const teacherName = t.name || t.first_name || '-';
                            dropdown.append(`<option value="${t.id}">${teacherName}</option>`);
                        });
                        // Update bulk table teacher dropdowns
                        $('#days-table .tid').each(function() {
                            const currentVal = $(this).val();
                            $(this).html(dropdown.html());
                            if (currentVal) $(this).val(currentVal);
                        });
                        if (callback) callback();
                    },
                    error: function(xhr, status, error) {
                        console.error('Fetch Teachers Error:', xhr.responseJSON, status, error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load teachers: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Fetch timetable data with pagination
            function fetchTimetable(page = 1) {
                $('#table-loader').show();
                $('#timetable_list_table_body').empty();

                $.ajax({
                    url: 'api/timetable_master.php',
                    type: 'GET',
                    data: { page: page, perPage: perPage },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Timetable API Response:', response);
                        const timetable = response.data || [];
                        const meta = response.meta || { page: 1, totalPages: 1, totalItems: timetable.length };
                        renderTimetableTable(timetable, page);
                        renderPagination(meta);
                        $('#table-loader').hide();
                    },
                    error: function(xhr, status, error) {
                        $('#table-loader').hide();
                        console.error('Timetable AJAX Error:', xhr.responseJSON, status, error);
                        renderPagination({ page: 1, totalPages: 1, totalItems: 0 });
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load timetable data: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Render timetable table
            function renderTimetableTable(timetable, page) {
                const tbody = $('#timetable_list_table_body');
                tbody.empty();
                if (timetable.length === 0) {
                    tbody.append('<tr><td colspan="9" class="text-center">No timetable entries found.</td></tr>');
                    return;
                }
                timetable.forEach((t, index) => {
                    const serialNumber = (page - 1) * perPage + index + 1;
                    const teacherName = teachersMap[t.tid] || t.tid || '-';
                    const className = classesMap[t.class] || t.class || '-';
                    const subjectName = subjectsMap[t.subject] || t.subject || '-';
                    const startTime = to12HourFormat(t.start_time);
                    const endTime = to12HourFormat(t.end_time);
                    const row = `
                        <tr data-id="${t.id}">
                            <td>
                                <div class="n-chk align-self-center text-center">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input timetable-check" value="${t.id}" />
                                        <label class="form-check-label"></label>
                                    </div>
                                </div>
                            </td>
                            <td>${serialNumber}</td>
                            <td>${t.day || '-'}</td>
                            <td>${className}</td>
                            <td>${t.period_number || '-'}</td>
                            <td>${startTime} - ${endTime}</td>
                            <td>${subjectName}</td>
                            <td>${teacherName}</td>
                            <td>
                                <button class="view-timetable btn btn-sm btn-info" data-id="${t.id}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-eye"></i>
                                </button>
                                <button class="edit-timetable btn btn-sm btn-primary" data-id="${t.id}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-edit"></i>
                                </button>
                                <button class="delete-timetable btn btn-sm btn-danger" data-id="${t.id}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-trash"></i>
                                </button>
                            </td>
                        </tr>`;
                    tbody.append(row);
                });
            }

            // Render pagination
            function renderPagination(meta) {
                const pagination = $('#pagination-nav ul');
                pagination.empty();

                const currentPage = meta.page || 1;
                const totalPages = meta.totalPages || 1;

                pagination.append(`
                    <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
                    </li>
                `);

                for (let p = 1; p <= totalPages; p++) {
                    pagination.append(`
                        <li class="page-item ${p === currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${p}">${p}</a>
                        </li>
                    `);
                }

                pagination.append(`
                    <li class="page-item ${currentPage >= totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
                    </li>
                `);
            }

            // Pagination click
            $(document).on('click', '#pagination-nav a', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && page !== currentPage) {
                    currentPage = page;
                    fetchTimetable(page);
                }
            });

            // Toggle action buttons
            function toggleActionButtons() {
                const checked = $('.timetable-check:checked').length;
                $('.action-buttons').toggle(checked > 0);
            }

            // Select all checkboxes
            $('#timetable-check-all').on('change', function() {
                $('.timetable-check').prop('checked', this.checked);
                toggleActionButtons();
            });

            // Individual checkbox change
            $(document).on('change', '.timetable-check', toggleActionButtons);

            // Search functionality
            $('#input-search').on('keyup', function() {
                const search = $(this).val().toLowerCase();
                $('#timetable_list_table_body tr').each(function() {
                    const text = $(this).text().toLowerCase();
                    $(this).toggle(text.includes(search));
                });
            });

            // Delete multiple
            $('.delete-multiple').on('click', function() {
                const selected = $('.timetable-check:checked').map(function() {
                    return $(this).val();
                }).get();
                if (selected.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Selection',
                        text: 'Please select at least one timetable entry to delete.'
                    });
                    return;
                }
                Swal.fire({
                    title: 'Are you sure?',
                    text: `Delete ${selected.length} timetable entries?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        Promise.all(selected.map(id =>
                            $.ajax({
                                url: 'api/timetable_master.php',
                                type: 'DELETE',
                                contentType: 'application/json',
                                data: JSON.stringify({ id: id })
                            })
                        )).then(() => {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted',
                                text: 'Timetable entries deleted successfully'
                            });
                            fetchTimetable(currentPage);
                            $('.timetable-check').prop('checked', false);
                            toggleActionButtons();
                        }).catch(xhr => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to delete timetable entries: ' + (xhr.responseJSON?.error || xhr.statusText)
                            });
                        }).finally(() => {
                            $('.delete-multiple').removeClass('btn-loading');
                        });
                    }
                });
            });

            // Open add modal and populate dropdowns
            $('#btn-add-timetable').on('click', function() {
                $(this).addClass('btn-loading');
                $('#addTimetableModalLabel').text('Add Bulk Timetable Entries');
                $('#timetableForm')[0].reset();
                $('#timetableId').val('');
                $('#btn-add').show();
                $('#btn-edit').hide();
                $('#day-container').addClass('d-none');
                $('#single-entry-fields').addClass('d-none');
                $('#bulk-entry-fields').removeClass('d-none');
                $('#days-table tbody').empty();

                // Fetch data for dropdowns
                fetchClassesForDropdown(() => {
                    fetchSubjectsForDropdown(() => {
                        fetchTeachersForDropdown(() => {
                            // Populate days table
                            days.forEach(day => {
                                const subjectOptions = $('#subject').html();
                                const teacherOptions = $('#tid').html();
                                const row = `
                                    <tr data-day="${day}">
                                        <td>${day}</td>
                                        <td><input type="number" class="form-control period_number" min="1"></td>
                                        <td><input type="text" class="form-control timepicker start_time"></td>
                                        <td><input type="text" class="form-control timepicker end_time"></td>
                                        <td><select class="form-control subject">${subjectOptions}</select></td>
                                        <td><select class="form-control tid">${teacherOptions}</select></td>
                                        <td>
                                            <select class="form-control is_break">
                                                <option value="0">No</option>
                                                <option value="1">Yes</option>
                                            </select>
                                        </td>
                                    </tr>`;
                                $('#days-table tbody').append(row);
                            });
                            // Disable Sunday row
                            $('#days-table tbody tr[data-day="Sunday"] input, #days-table tbody tr[data-day="Sunday"] select').prop('disabled', true);
                            // Initialize timepickers
                            flatpickr(".timepicker", {
                                enableTime: true,
                                noCalendar: true,
                                dateFormat: "h:i K",
                                time_24hr: false,
                                minuteIncrement: 5
                            });
                            $(this).removeClass('btn-loading');
                            $('#addTimetableModal').modal('show');
                        });
                    });
                });
            });

            // Autofill Tuesday–Friday from Monday
            $(document).on('change input', '#days-table tr[data-day="Monday"] input, #days-table tr[data-day="Monday"] select', function() {
                const mondayRow = $('#days-table tr[data-day="Monday"]');
                const periodNumber = mondayRow.find('.period_number').val();
                const startTime = mondayRow.find('.start_time').val();
                const endTime = mondayRow.find('.end_time').val();
                const subject = mondayRow.find('.subject').val();
                const tid = mondayRow.find('.tid').val();
                const isBreak = mondayRow.find('.is_break').val();

                autoFillDays.forEach(day => {
                    const row = $(`#days-table tr[data-day="${day}"]`);
                    // Only autofill if fields are empty or not yet interacted with
                    if (!row.find('.period_number').data('user-changed')) {
                        row.find('.period_number').val(periodNumber);
                    }
                    if (!row.find('.start_time').data('user-changed')) {
                        row.find('.start_time').val(startTime);
                    }
                    if (!row.find('.end_time').data('user-changed')) {
                        row.find('.end_time').val(endTime);
                    }
                    if (!row.find('.subject').data('user-changed')) {
                        row.find('.subject').val(subject);
                    }
                    if (!row.find('.tid').data('user-changed')) {
                        row.find('.tid').val(tid);
                    }
                    if (!row.find('.is_break').data('user-changed')) {
                        row.find('.is_break').val(isBreak);
                        row.find('.subject, .tid').prop('disabled', parseInt(isBreak) === 1);
                    }
                });
            });

            // Mark fields as user-changed to prevent autofill overwrite
            $(document).on('change input', '#days-table tr:not([data-day="Monday"]) input, #days-table tr:not([data-day="Monday"]) select', function() {
                $(this).data('user-changed', true);
            });

            // Handle is_break change in bulk rows
            $(document).on('change', '.is_break', function() {
                const row = $(this).closest('tr');
                if (parseInt($(this).val()) === 1) {
                    row.find('.subject, .tid').prop('disabled', true).val('');
                } else {
                    row.find('.subject, .tid').prop('disabled', false);
                }
            });

            // Add timetable entries (bulk)
            $('#btn-add').on('click', function() {
                const entries = [];
                const classId = parseInt($('#class').val());
                if (!classId) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Class is required'
                    });
                    return;
                }

                let valid = true;
                const affectedDays = [];
                $('#days-table tbody tr').each(function() {
                    const row = $(this);
                    const day = row.data('day');
                    const period_number = parseInt(row.find('.period_number').val());
                    const start_time = to24HourFormat(row.find('.start_time').val());
                    const end_time = to24HourFormat(row.find('.end_time').val());
                    const subject = row.find('.subject').val() ? parseInt(row.find('.subject').val()) : null;
                    const tid = row.find('.tid').val() ? parseInt(row.find('.tid').val()) : null;
                    const is_break = parseInt(row.find('.is_break').val());

                    if (period_number) {
                        if (day !== 'Sunday' && period_number > applicableDays[day].maxPeriods) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: `Period number for ${day} cannot exceed ${applicableDays[day].maxPeriods}`
                            });
                            valid = false;
                            return false;
                        }
                        if (!start_time || !end_time) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: `Start and end times are required for ${day}`
                            });
                            valid = false;
                            return false;
                        }
                        if (is_break === 0 && (!subject || !tid)) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: `Subject and Teacher are required for non-break periods on ${day}`
                            });
                            valid = false;
                            return false;
                        }
                        entries.push({
                            day,
                            class: classId,
                            period_number,
                            start_time,
                            end_time,
                            subject,
                            tid,
                            is_break
                        });
                        affectedDays.push(day);
                    }
                });

                if (!valid || entries.length === 0) {
                    if (valid) {
                        Swal.fire({
                            icon: 'warning',
                            title: 'No Entries',
                            text: 'At least one day must have a period number set'
                        });
                    }
                    return;
                }

                $(this).addClass('btn-loading');

                $.ajax({
                    url: 'api/timetable_master.php',
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({ entries: entries }),
                    dataType: 'json',
                    success: function(response) {
                        $('#addTimetableModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: `Timetable entries added for ${affectedDays.join(', ')}`
                        });
                        fetchTimetable(currentPage);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to add timetable entries: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('#btn-add').removeClass('btn-loading');
                    }
                });
            });

            // View timetable entry
            $(document).on('click', '.view-timetable', function() {
                const id = $(this).data('id');
                $(this).addClass('btn-loading');
                $.ajax({
                    url: 'api/timetable_master.php',
                    type: 'GET',
                    data: { id: id },
                    dataType: 'json',
                    success: function(response) {
                        const timetable = response.data && response.data[0] || {};
                        const className = classesMap[timetable.class] || timetable.class || '-';
                        const subjectName = subjectsMap[timetable.subject] || timetable.subject || '-';
                        const teacherName = teachersMap[timetable.tid] || timetable.tid || '-';
                        const startTime = to12HourFormat(timetable.start_time);
                        const endTime = to12HourFormat(timetable.end_time);
                        $('#view-id').text(timetable.id || '-');
                        $('#view-day').text(timetable.day || '-');
                        $('#view-class').text(className);
                        $('#view-period_number').text(timetable.period_number || '-');
                        $('#view-start_time').text(startTime);
                        $('#view-end_time').text(endTime);
                        $('#view-subject').text(subjectName);
                        $('#view-tid').text(teacherName);
                        $('#view-is_break').text(timetable.is_break ? 'Yes' : 'No');
                        $('#view-created_at').text(timetable.created_at || '-');
                        $('#view-updated_at').text(timetable.updated_at || '-');
                        $('#viewTimetableModal').modal('show');
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load timetable details: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('.view-timetable[data-id="' + id + '"]').removeClass('btn-loading');
                    }
                });
            });

            // Edit timetable entry
            $(document).on('click', '.edit-timetable', function() {
                const id = $(this).data('id');
                $(this).addClass('btn-loading');
                $.ajax({
                    url: 'api/timetable_master.php',
                    type: 'GET',
                    data: { id: id },
                    dataType: 'json',
                    success: function(response) {
                        const timetable = response.data && response.data[0] || {};
                        fetchClassesForDropdown(() => {
                            fetchSubjectsForDropdown(() => {
                                fetchTeachersForDropdown(() => {
                                    $('#addTimetableModalLabel').text('Edit Timetable Entry');
                                    $('#timetableId').val(timetable.id || '');
                                    $('#day-container').removeClass('d-none');
                                    $('#day').val(timetable.day || 'Monday');
                                    $('#class').val(timetable.class || '');
                                    $('#period_number').val(timetable.period_number || 1);
                                    $('#start_time').val(to12HourFormat(timetable.start_time));
                                    $('#end_time').val(to12HourFormat(timetable.end_time));
                                    $('#subject').val(timetable.subject || '');
                                    $('#tid').val(timetable.tid || '');
                                    $('#is_break').val(timetable.is_break ? '1' : '0');
                                    $('#single-entry-fields').removeClass('d-none');
                                    $('#bulk-entry-fields').addClass('d-none');
                                    $('#btn-add').hide();
                                    $('#btn-edit').show();
                                    $('#addTimetableModal').modal('show');
                                });
                            });
                        });
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load timetable details: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('.edit-timetable[data-id="' + id + '"]').removeClass('btn-loading');
                    }
                });
            });

            // Save edited timetable entry
            $('#btn-edit').on('click', function() {
                if (!$('#timetableForm')[0].checkValidity()) {
                    $('#timetableForm')[0].reportValidity();
                    return;
                }

                const data = {
                    id: $('#timetableId').val(),
                    day: $('#day').val(),
                    class: parseInt($('#class').val()),
                    period_number: parseInt($('#period_number').val()),
                    start_time: to24HourFormat($('#start_time').val()),
                    end_time: to24HourFormat($('#end_time').val()),
                    subject: $('#subject').val() ? parseInt($('#subject').val()) : null,
                    tid: $('#tid').val() ? parseInt($('#tid').val()) : null,
                    is_break: parseInt($('#is_break').val())
                };

                $(this).addClass('btn-loading');

                $.ajax({
                    url: 'api/timetable_master.php',
                    type: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify(data),
                    dataType: 'json',
                    success: function(response) {
                        $('#addTimetableModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Timetable entry updated successfully'
                        });
                        fetchTimetable(currentPage);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to update timetable entry: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('#btn-edit').removeClass('btn-loading');
                    }
                });
            });

            // Delete single timetable entry
            $(document).on('click', '.delete-timetable', function() {
                const id = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'Delete this timetable entry?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/timetable_master.php',
                            type: 'DELETE',
                            contentType: 'application/json',
                            data: JSON.stringify({ id: id }),
                            dataType: 'json',
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted',
                                    text: response.message || 'Timetable entry deleted successfully'
                                });
                                fetchTimetable(currentPage);
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to delete timetable entry: ' + (xhr.responseJSON?.error || error)
                                });
                            },
                            complete: function() {
                                $('.delete-timetable[data-id="' + id + '"]').removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // Initial load: Fetch teachers, classes, and subjects first, then timetable
            fetchTeachersForMapping(() => {
                fetchClassesForMapping(() => {
                    fetchSubjectsForMapping(() => {
                        fetchTimetable(currentPage);
                    });
                });
            });
        });
    </script>
</body>
</html>