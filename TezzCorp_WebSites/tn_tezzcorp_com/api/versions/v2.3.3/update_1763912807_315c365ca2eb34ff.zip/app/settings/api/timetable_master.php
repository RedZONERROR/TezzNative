<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class TimetableController {
    private $pdo;
    private $logger;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    // Define day-specific period limits
    private $dayPeriodLimits = [
        'Monday' => 8,
        'Tuesday' => 8,
        'Wednesday' => 8,
        'Thursday' => 8,
        'Friday' => 8,
        'Saturday' => 4,
        'Sunday' => 0
    ];

    // Validate input data
    private function validateInput($data, bool $isUpdate = false): array {
        $errors = [];
        $validData = [];

        // Define validation rules
        $fields = [
            'day' => ['type' => 'string', 'enum' => array_keys($this->dayPeriodLimits), 'required' => !$isUpdate],
            'class' => ['type' => 'integer', 'min' => 1, 'required' => !$isUpdate],
            'period_number' => ['type' => 'integer', 'min' => 1, 'required' => !$isUpdate],
            'start_time' => ['type' => 'time', 'required' => !$isUpdate],
            'end_time' => ['type' => 'time', 'required' => !$isUpdate],
            'subject' => ['type' => 'integer', 'min' => 1, 'required' => false],
            'tid' => ['type' => 'integer', 'min' => 1, 'required' => false],
            'is_break' => ['type' => 'boolean', 'required' => false],
        ];

        // Validate id separately for updates
        if ($isUpdate) {
            if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT) || $data['id'] <= 0) {
                $errors[] = "id must be a valid integer";
            } else {
                $validData['id'] = (int)$data['id'];
            }
        }

        // Validate other fields
        foreach ($fields as $field => $rules) {
            if (isset($data[$field])) {
                $value = $data[$field];

                // Type checking
                switch ($rules['type']) {
                    case 'string':
                        if (!is_string($value)) {
                            $errors[] = "$field must be a string";
                        }
                        break;
                    case 'boolean':
                        $value = filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                        if ($value === null) {
                            $errors[] = "$field must be a boolean (0, 1, true, false)";
                        }
                        break;
                    case 'integer':
                        $value = filter_var($value, FILTER_VALIDATE_INT);
                        if ($value === false || ($rules['min'] && $value < $rules['min'])) {
                            $errors[] = "$field must be an integer >= {$rules['min']}";
                        }
                        break;
                    case 'time':
                        if (!preg_match("/^([01]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$/", $value)) {
                            $errors[] = "$field must be a valid time in HH:MM or HH:MM:SS format";
                        }
                        break;
                }

                // Enum validation
                if (isset($rules['enum']) && !in_array($value, $rules['enum'], true)) {
                    $errors[] = "$field must be one of: " . implode(', ', $rules['enum']);
                }

                $validData[$field] = $value;
            } elseif ($rules['required']) {
                $errors[] = "$field is required";
            }
        }

        // Validate period number against day-specific limits
        if (isset($validData['day']) && isset($validData['period_number'])) {
            $day = $validData['day'];
            $periodNumber = $validData['period_number'];
            if (isset($this->dayPeriodLimits[$day]) && $periodNumber > $this->dayPeriodLimits[$day]) {
                $errors[] = "period_number for $day cannot exceed {$this->dayPeriodLimits[$day]}";
            }
        }

        // Additional validation for time
        if (isset($validData['start_time']) && isset($validData['end_time'])) {
            $start = strtotime($validData['start_time']);
            $end = strtotime($validData['end_time']);
            if ($start >= $end) {
                $errors[] = "end_time must be after start_time";
            }
        }

        // If is_break is true, subject and tid are not required
        if (isset($validData['is_break']) && $validData['is_break']) {
            $validData['subject'] = $validData['subject'] ?? null;
            $validData['tid'] = $validData['tid'] ?? null;
        } elseif (!$isUpdate && !isset($validData['subject']) && !isset($validData['tid'])) {
            $errors[] = "subject and tid are required when is_break is not set";
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return $validData;
    }

    // Send JSON error response
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    // Send JSON success response
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Handle GET requests
    public function get($request) {
        if (isset($request['id'])) {
            $id = filter_var($request['id'], FILTER_VALIDATE_INT);
            if (!$id) {
                $this->sendError(400, 'Invalid ID');
            }

            $stmt = $this->pdo->prepare("SELECT * FROM timetable WHERE id = ?");
            $stmt->execute([$id]);
            $entry = $stmt->fetch();

            if ($entry) {
                $this->sendSuccess(200, ['data' => [$entry]]);
            } else {
                $this->sendError(404, 'Timetable entry not found');
            }
        } else {
            // Pagination
            $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
            $perPage = isset($_GET['perPage']) ? max(1, min(100, (int)$_GET['perPage'])) : 10;
            $offset = ($page - 1) * $perPage;

            $query = "SELECT * FROM timetable";
            $countQuery = "SELECT COUNT(*) FROM timetable";
            $params = [];

            // Filtering
            $conditions = [];
            if (isset($_GET['day'])) {
                $conditions[] = "day = ?";
                $params[] = $_GET['day'];
            }
            if (isset($_GET['class'])) {
                $conditions[] = "class = ?";
                $params[] = (int)$_GET['class'];
            }

            if ($conditions) {
                $query .= " WHERE " . implode(' AND ', $conditions);
                $countQuery .= " WHERE " . implode(' AND ', $conditions);
            }

            $query .= " ORDER BY day, class, period_number LIMIT ? OFFSET ?";
            $params[] = $perPage;
            $params[] = $offset;

            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            $entries = $stmt->fetchAll();

            $countStmt = $this->pdo->prepare($countQuery);
            $countStmt->execute(array_slice($params, 0, count($params) - 2));
            $total = $countStmt->fetchColumn();

            $this->sendSuccess(200, [
                'data' => $entries,
                'meta' => [
                    'page' => $page,
                    'perPage' => $perPage,
                    'total' => $total,
                    'totalPages' => ceil($total / $perPage)
                ]
            ]);
        }
    }

    // Handle POST requests
    public function post($data) {
        if (isset($data['entries']) && is_array($data['entries'])) {
            // Handle bulk insertion
            $validEntries = [];
            foreach ($data['entries'] as $entry) {
                $validEntries[] = $this->validateInput($entry);
            }

            $fields = ['day', 'class', 'period_number', 'start_time', 'end_time', 'subject', 'tid', 'is_break'];
            $placeholders = array_fill(0, count($fields), '?');
            $sql = "INSERT INTO timetable (" . implode(',', $fields) . ", created_at) VALUES (" . implode(',', $placeholders) . ", NOW())";
            $insertedIds = [];

            try {
                $this->pdo->beginTransaction();
                $stmt = $this->pdo->prepare($sql);

                foreach ($validEntries as $entry) {
                    $values = [];
                    foreach ($fields as $field) {
                        $values[] = $entry[$field] ?? null;
                    }
                    $stmt->execute($values);
                    $insertedIds[] = $this->pdo->lastInsertId();
                }

                $this->pdo->commit();
                $this->sendSuccess(201, ['message' => 'Timetable entries created', 'ids' => $insertedIds]);
            } catch (PDOException $e) {
                $this->pdo->rollBack();
                $this->logError('Bulk create failed: ' . $e->getMessage());
                $this->sendError(500, 'Failed to create timetable entries');
            }
        } else {
            // Handle single entry (for backward compatibility)
            $validData = $this->validateInput($data);

            $fields = ['day', 'class', 'period_number', 'start_time', 'end_time', 'subject', 'tid', 'is_break'];
            $placeholders = array_fill(0, count($fields), '?');
            $sql = "INSERT INTO timetable (" . implode(',', $fields) . ", created_at) VALUES (" . implode(',', $placeholders) . ", NOW())";

            try {
                $stmt = $this->pdo->prepare($sql);
                $values = [];
                foreach ($fields as $field) {
                    $values[] = $validData[$field] ?? null;
                }
                $stmt->execute($values);
                $this->sendSuccess(201, ['message' => 'Timetable entry created', 'id' => $this->pdo->lastInsertId()]);
            } catch (PDOException $e) {
                $this->logError('Create failed: ' . $e->getMessage());
                $this->sendError(500, 'Failed to create timetable entry');
            }
        }
    }

    // Handle PUT requests
    public function put($data) {
        $validData = $this->validateInput($data, true);

        if (!isset($validData['id'])) {
            $this->sendError(400, 'ID is required');
        }

        // Fetch existing record to preserve unchanged fields
        $stmt = $this->pdo->prepare("SELECT * FROM timetable WHERE id = ?");
        $stmt->execute([$validData['id']]);
        $existing = $stmt->fetch();

        if (!$existing) {
            $this->sendError(404, 'Timetable entry not found');
        }

        $fields = ['day', 'class', 'period_number', 'start_time', 'end_time', 'subject', 'tid', 'is_break'];
        $updateFields = [];
        $values = [];
        foreach ($fields as $field) {
            if (isset($validData[$field])) {
                $updateFields[] = "$field = ?";
                $values[] = $validData[$field];
            } else {
                $updateFields[] = "$field = ?";
                $values[] = $existing[$field];
            }
        }
        $values[] = $validData['id'];

        $sql = "UPDATE timetable SET " . implode(', ', $updateFields) . ", updated_at = NOW() WHERE id = ?";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($values);
            $this->sendSuccess(200, ['message' => 'Timetable entry updated']);
        } catch (PDOException $e) {
            $this->logError('Update failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to update timetable entry');
        }
    }

    // Handle DELETE requests
    public function delete($data) {
        if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT)) {
            $this->sendError(400, 'Invalid or missing ID');
        }

        try {
            $stmt = $this->pdo->prepare("DELETE FROM timetable WHERE id = ?");
            $stmt->execute([$data['id']]);
            if ($stmt->rowCount()) {
                $this->sendSuccess(200, ['message' => 'Timetable entry deleted']);
            } else {
                $this->sendError(404, 'Timetable entry not found');
            }
        } catch (PDOException $e) {
            $this->logError('Delete failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to delete timetable entry');
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $data = json_decode(file_get_contents('php://input'), true) ?: [];

        switch ($method) {
            case 'GET':
                $this->get($_GET);
                break;
            case 'POST':
                $this->post($data);
                break;
            case 'PUT':
                $this->put($data);
                break;
            case 'DELETE':
                $this->delete($data);
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new TimetableController();
$controller->handleRequest();
?>