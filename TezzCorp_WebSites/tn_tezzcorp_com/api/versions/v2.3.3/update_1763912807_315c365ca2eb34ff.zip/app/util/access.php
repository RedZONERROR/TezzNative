<?php
require $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

$pdo = getDBConnection();

function hasPermission($pdo, $user_id, $permission_name) {
    try {
        $stmt = $pdo->prepare("
            SELECT 1 
            FROM user_roles ur 
            JOIN role_permissions rp ON ur.role_id = rp.role_id 
            JOIN permissions p ON rp.permission_id = p.id 
            WHERE ur.user_id = ? AND p.permission_name = ?
        ");
        $stmt->execute([$user_id, $permission_name]);
        return $stmt->fetch() !== false;
    } catch (PDOException $e) {
        $logMessage = date('Y-m-d H:i:s') . ' - ERROR: Permission check failed: ' . $e->getMessage() . PHP_EOL;
        file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/api/logs/api.log', $logMessage, FILE_APPEND);
        return false;
    }
}

$script_name = basename($_SERVER['SCRIPT_NAME']);
$permission_name = str_replace('.php', '', $script_name);

if (!isset($_SESSION['id']) || !hasPermission($pdo, $_SESSION['id'], $permission_name)) {
    $logMessage = date('Y-m-d H:i:s') . ' - ERROR: Unauthorized access attempt to ' . $permission_name . ' by user ID ' . ($_SESSION['id'] ?? 'unknown') . PHP_EOL;
    file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/api/logs/api.log', $logMessage, FILE_APPEND);
    header("Location: ../../login");
    die();
}
?>