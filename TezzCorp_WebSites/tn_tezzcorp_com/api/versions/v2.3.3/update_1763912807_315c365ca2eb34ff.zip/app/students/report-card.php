<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!--Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!--Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">
    <!--Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!--JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Report Card Generation - AI-ERP 2.0</title>
    <style>
        .btn-loading .spinner-border {
            display: inline-block;
        }
        .spinner-border {
            display: none;
            width: 1rem;
            height: 1rem;
        }
        .student-checkbox {
            margin-bottom: 10px;
        }
        .download-section {
            display: none;
            margin-top: 20px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #dee2e6;
        }
        .download-section.show {
            display: block;
        }
        .download-info {
            margin-bottom: 15px;
        }
        .download-info h6 {
            color: #28a745;
            margin-bottom: 10px;
        }
        .student-list {
            max-height: 200px;
            overflow-y: auto;
            background: white;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #e9ecef;
        }
        .signature-upload {
            margin-top: 20px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #dee2e6;
        }
        .file-upload-wrapper {
            position: relative;
            display: inline-block;
            width: 100%;
        }
        .file-upload-input {
            position: absolute;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        .file-upload-label {
            display: block;
            padding: 10px 15px;
            background-color: #fff;
            border: 2px dashed #dee2e6;
            border-radius: 4px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .file-upload-label:hover {
            border-color: #007bff;
            background-color: #f8f9ff;
        }
        .file-upload-label.has-file {
            border-color: #28a745;
            background-color: #f8fff8;
        }
    </style>
</head>
<body>
    <!--Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!--Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--Sidebar End -->
        <div class="page-wrapper">
            <!--Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--Header End -->
            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Generate Report Cards</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Report Cards
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Report Card Generation Form -->
                    <div class="card card-body">
                        <form id="reportCardForm" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="class_id" class="form-label">Select Class</label>
                                    <select id="class_id" name="class_id" class="form-control" required>
                                        <option value="">Select a class</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="session" class="form-label">Select Session</label>
                                    <select id="session" name="session" class="form-control" required>
                                        <option value="">Select a session</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="term" class="form-label">Select Term</label>
                                    <select id="term" name="term" class="form-control" required>
                                        <option value="">Select a Term</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                            </div>

                            <!--Signature Upload Section -->
                            <div class="signature-upload">
                                <h5 class="mb-3">Upload Signatures (Optional)</h5>
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Dept. of Examination</label>
                                        <div class="file-upload-wrapper">
                                            <input type="file" id="dept_examination_signature" name="dept_examination_signature" class="file-upload-input" accept="image/*">
                                            <label for="dept_examination_signature" class="file-upload-label">
                                                <i class="ti ti-upload"></i>
                                                <span class="upload-text">Click to upload dept. of exam. sign.</span>
                                            </label>
                                        </div>
                                        <small class="text-muted">Supported formats: JPG, PNG, GIF (Max: 2MB)</small>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Class Teacher Signature</label>
                                        <div class="file-upload-wrapper">
                                            <input type="file" id="class_teacher_signature" name="class_teacher_signature" class="file-upload-input" accept="image/*">
                                            <label for="class_teacher_signature" class="file-upload-label">
                                                <i class="ti ti-upload"></i>
                                                <span class="upload-text">Click to upload class teacher's sign.</span>
                                            </label>
                                        </div>
                                        <small class="text-muted">Supported formats: JPG, PNG, GIF (Max: 2MB)</small>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Principal Signature</label>
                                        <div class="file-upload-wrapper">
                                            <input type="file" id="principal_signature" name="principal_signature" class="file-upload-input" accept="image/*">
                                            <label for="principal_signature" class="file-upload-label">
                                                <i class="ti ti-upload"></i>
                                                <span class="upload-text">Click to upload principal's sign.</span>
                                            </label>
                                        </div>
                                        <small class="text-muted">Supported formats: JPG, PNG, GIF (Max: 2MB)</small>
                                    </div>
                                </div>
                            </div>

                            <h5 class="mt-4 mb-3">Select Students</h5>
                            <div class="mb-3">
                                <button type="button" id="select-all-students" class="btn btn-primary">Select All</button>
                            </div>
                            <div id="student-checkboxes" class="row">
                                <!--Dynamic student checkboxes -->
                            </div>
                            <div class="text-end mt-4">
                                <button type="submit" class="btn btn-success" id="generate-report-cards">Generate Report Cards
                                    <div class="spinner-border text-light btn-loading" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                </button>
                            </div>
                        </form>
                        
                        <!--Download Section -->
                        <div id="download-section" class="download-section">
                            <div class="download-info">
                                <h6><i class="ti ti-check-circle"></i> Report Cards Generated Successfully!</h6>
                                <p class="mb-2">Report cards have been generated for <span id="student-count">0</span> students.</p>
                                <div class="student-list" id="generated-students">
                                    <!--Student list will be populated here -->
                                </div>
                            </div>
                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-primary" id="download-pdf">
                                    <i class="ti ti-download"></i> Download PDF
                                </button>
                                <button type="button" class="btn btn-secondary" id="generate-new">
                                    <i class="ti ti-plus"></i> Generate New Report Cards
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Core JS -->
    <script src="../assets/js/vendor.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        $(document).ready(function() {
            let downloadUrl = null;
            let generatedData = null;

            // File upload handling
            $('.file-upload-input').on('change', function() {
                const file = this.files[0];
                const label = $(this).siblings('.file-upload-label');
                const uploadText = label.find('.upload-text');
                
                if (file) {
                    uploadText.text(file.name);
                    label.addClass('has-file');
                } else {
                    const inputId = $(this).attr('id');
                    let defaultText = '';
                    switch(inputId) {
                        case 'dept_examination_signature':
                            defaultText = 'Click to upload dept. examination signature';
                            break;
                        case 'class_teacher_signature':
                            defaultText = 'Click to upload class teacher signature';
                            break;
                        case 'principal_signature':
                            defaultText = 'Click to upload principal signature';
                            break;
                    }
                    uploadText.text(defaultText);
                    label.removeClass('has-file');
                }
            });

            // Load classes
            function loadClasses() {
                $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 50, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        const classes = response.data || [];
                        $('#class_id').empty().append('<option value="">Select a class</option>');
                        classes.forEach(cls => {
                            $('#class_id').append(`<option value="${cls.id}">${cls.class_name}</option>`);
                        });
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load classes: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Load sessions from results table
            function loadSessions() {
                $.ajax({
                    url: 'api/get_sessions.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        const sessions = response.data || [];
                        $('#session').empty().append('<option value="">Select a session</option>');
                        sessions.forEach(session => {
                            $('#session').append(`<option value="${session.session}">${session.session}</option>`);
                        });
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load sessions: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Load terms from results table
            function loadTerms() {
                $.ajax({
                    url: 'api/get_terms.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        const terms = response.data || [];
                        $('#term').empty().append('<option value="">Select a Term</option>');
                        terms.forEach(term => {
                            $('#term').append(`<option value="${term.term}">${term.term}</option>`);
                        });
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load terms: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Load students and create checkboxes
            function loadStudents(classId) {
                if (!classId) {
                    $('#student-checkboxes').empty();
                    return;
                }
                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: { perPage: 100, class: classId },
                    dataType: 'json',
                    success: function(response) {
                        const students = response.data || [];
                        $('#student-checkboxes').empty();
                        students.forEach(student => {
                            $('#student-checkboxes').append(`
                                <div class="col-md-4 student-checkbox">
                                    <label class="form-check-label">
                                        <input type="checkbox" name="students[]" value="${student.uid}" class="form-check-input">
                                        ${student.full_name} (Roll: ${student.roll_no})
                                    </label>
                                </div>
                            `);
                        });
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load students: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Handle class selection
            $('#class_id').on('change', function() {
                const classId = $(this).val();
                loadStudents(classId);
                hideDownloadSection();
            });

            // Select All button functionality
            $('#select-all-students').on('click', function() {
                const checkboxes = $('#student-checkboxes input[type="checkbox"]');
                const allChecked = checkboxes.length > 0 && checkboxes.length === checkboxes.filter(':checked').length;
                checkboxes.prop('checked', !allChecked);
                $(this).text(allChecked ? 'Select All' : 'Deselect All');
            });

            // Show download section
            function showDownloadSection(data) {
                generatedData = data;
                downloadUrl = data.download_url;
                
                const reportCards = data.report_cards || [];
                $('#student-count').text(reportCards.length);
                
                const studentList = $('#generated-students');
                studentList.empty();
                
                reportCards.forEach(card => {
                    studentList.append(`
                        <div class="d-flex justify-content-between align-items-center py-1">
                            <span>${card.full_name} (Roll: ${card.roll_no})</span>
                            <small class="text-muted">${card.class_name} - ${card.session} - ${card.term}</small>
                        </div>
                    `);
                });
                
                $('#download-section').addClass('show');
                
                // Scroll to download section
                $('html, body').animate({
                    scrollTop: $('#download-section').offset().top - 100
                }, 500);
            }

            // Hide download section
            function hideDownloadSection() {
                $('#download-section').removeClass('show');
                downloadUrl = null;
                generatedData = null;
            }

            // Handle download button click
            $('#download-pdf').on('click', function() {
                if (!downloadUrl) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'No download URL available. Please generate report cards first.'
                    });
                    return;
                }

                // Show loading state
                const $btn = $(this);
                const originalText = $btn.html();
                $btn.html('<i class="ti ti-loader ti-spin"></i> Downloading...').prop('disabled', true);

                // Create a temporary form to trigger download
                const form = $('<form>', {
                    method: 'POST',
                    action: downloadUrl,
                    target: '_blank'
                });

                // Add form to body and submit
                $('body').append(form);
                form.submit();
                form.remove();

                // Reset button after a short delay
                setTimeout(() => {
                    $btn.html(originalText).prop('disabled', false);
                    
                    Swal.fire({
                        icon: 'success',
                        title: 'Download Started',
                        text: 'Your PDF download should start shortly.',
                        timer: 2000,
                        showConfirmButton: false
                    });
                }, 1000);
            });

            // Handle generate new button click
            $('#generate-new').on('click', function() {
                hideDownloadSection();
                $('#reportCardForm')[0].reset();
                $('#class_id').trigger('change');
                $('#select-all-students').text('Select All');
                
                // Reset file upload labels
                $('.file-upload-label').removeClass('has-file');
                $('.file-upload-label .upload-text').each(function() {
                    const label = $(this).closest('.file-upload-label');
                    const inputId = label.attr('for');
                    let defaultText = '';
                    switch(inputId) {
                        case 'dept_examination_signature':
                            defaultText = 'Click to upload dept. examination signature';
                            break;
                        case 'class_teacher_signature':
                            defaultText = 'Click to upload class teacher signature';
                            break;
                        case 'principal_signature':
                            defaultText = 'Click to upload principal signature';
                            break;
                    }
                    $(this).text(defaultText);
                });
                
                Swal.fire({
                    icon: 'info',
                    title: 'Ready for New Generation',
                    text: 'You can now generate new report cards.',
                    timer: 2000,
                    showConfirmButton: false
                });
            });

            // Handle form submission
            $('#reportCardForm').on('submit', function(e) {
                e.preventDefault();
                
                if (!this.checkValidity()) {
                    this.reportValidity();
                    return;
                }
                
                const formData = new FormData(this);
                const selectedStudents = formData.getAll('students[]');
                
                if (selectedStudents.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Students Selected',
                        text: 'Please select at least one student.'
                    });
                    return;
                }
                
                $('#generate-report-cards').addClass('btn-loading');
                hideDownloadSection();
                
                $.ajax({
                    url: 'api/generate-report-card.php',
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(response) {
                        $('#generate-report-cards').removeClass('btn-loading');
                        
                        if (response.error) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: response.error
                            });
                            return;
                        }
                        
                        if (!response.success || !response.data) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Invalid response from server'
                            });
                            return;
                        }
                        
                        // Show success message and download section
                        Swal.fire({
                            icon: 'success',
                            title: 'Success!',
                            text: response.data.message || 'Report cards generated successfully!',
                            timer: 2000,
                            showConfirmButton: false
                        });
                        
                        // Show download section
                        showDownloadSection(response.data);
                    },
                    error: function(xhr, status, error) {
                        $('#generate-report-cards').removeClass('btn-loading');
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to process request: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            });

            // Initialize
            loadClasses();
            loadSessions();
            loadTerms();
        });
    </script>
</body>
</html>