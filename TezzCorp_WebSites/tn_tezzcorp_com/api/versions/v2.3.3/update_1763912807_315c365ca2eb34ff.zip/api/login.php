<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

class LoginController {
    private $pdo;
    private $logger;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    // Validate input data
    private function validateInput(array $data): array {
        $errors = [];
        $validData = [];

        $fields = [
            'username' => ['type' => 'string', 'max' => 255, 'required' => true],
            'password' => ['type' => 'string', 'max' => 255, 'required' => true],
        ];

        foreach ($fields as $field => $rules) {
            if (isset($data[$field])) {
                $value = $data[$field];

                if ($rules['type'] === 'string' && !is_string($value)) {
                    $errors[] = "$field must be a string";
                } elseif (isset($rules['max']) && strlen($value) > $rules['max']) {
                    $errors[] = "$field exceeds maximum length of {$rules['max']} characters";
                }

                $validData[$field] = $value;
            } elseif ($rules['required']) {
                $errors[] = "$field is required";
            }
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return $validData;
    }

    // Send JSON error response
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['success' => false, 'message' => $message]);
        exit;
    }

    // Send JSON success response
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode(['success' => true, ...$data]);
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Handle POST request for login
    public function post($data) {
        $validData = $this->validateInput($data);
        $username = $validData['username'];
        $password = $validData['password'];

        try {
            // Fetch user
            $stmt = $this->pdo->prepare("SELECT id, uid, email, password, name, photo FROM users WHERE email = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if (!$user) {
                $this->logError("User not found: $username");
                $this->sendError(404, 'User not found');
            }

            // Verify password
            if (!password_verify($password, $user['password'])) {
                $this->logError("Invalid password for user: $username");
                $this->sendError(401, 'Invalid password');
            }

            // Fetch user's roles
            $stmt = $this->pdo->prepare("
                SELECT r.id, r.role_name 
                FROM roles r 
                JOIN user_roles ur ON r.id = ur.role_id 
                WHERE ur.user_id = ? AND r.status = 'active'
            ");
            $stmt->execute([$user['id']]);
            $roles = $stmt->fetchAll();

            if (empty($roles)) {
                $this->logError("No active roles assigned to user: $username");
                $this->sendError(403, 'No active roles assigned to user');
            }

            // Fetch user's permissions
            $stmt = $this->pdo->prepare("
                SELECT DISTINCT p.permission_name 
                FROM permissions p 
                JOIN role_permissions rp ON p.id = rp.permission_id 
                JOIN user_roles ur ON rp.role_id = ur.role_id 
                WHERE ur.user_id = ?
            ");
            $stmt->execute([$user['id']]);
            $permissions = array_column($stmt->fetchAll(), 'permission_name');

            // Start session and store user data
            session_start();
            $_SESSION['id'] = $user['id'];
            $_SESSION['uid'] = $user['uid'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['photo'] = $user['photo'];
            $_SESSION['roles'] = array_column($roles, 'role_name');
            $_SESSION['permissions'] = $permissions;
            
            // Determine redirect based on permissions
            $redirect = '/app/'; // default dashboard
            
            if (!in_array('index', $permissions)) {
                if (in_array('profile', $permissions)) {
                    $redirect = '/app/profile';
                }
            }

            $this->sendSuccess(200, [
                'message' => 'Login successful',
                'email' => $user['email'],
                'name' => $user['name'],
                'photo' => $user['photo'],
                'roles' => $_SESSION['roles'],
                'permissions' => $permissions,
                'redirect' => $redirect
            ]);
        } catch (PDOException $e) {
            $this->logError('Login failed: ' . $e->getMessage());
            $this->sendError(500, 'Login failed due to database error');
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $data = json_decode(file_get_contents('php://input'), true) ?: [];

        if ($method === 'POST') {
            $this->post($data);
        } else {
            $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new LoginController();
$controller->handleRequest();
?>