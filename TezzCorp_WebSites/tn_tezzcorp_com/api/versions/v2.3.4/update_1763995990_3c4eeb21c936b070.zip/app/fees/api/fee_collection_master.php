<?php
header('Content-Type: application/json');
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
$pdo = getDBConnection();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

function getMonthName($m) {
    if ($m == 0) return "Pending Dues (Prior Session)";
    return date("F", mktime(0, 0, 0, $m, 10));
}

// Index 0 = Pending, Index 1 = Apr ... Index 3 = June
$SESSION_MONTH_ORDER = [0, 4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3];

try {
    if ($action == 'get_dues') {
        $student_id = $_GET['student_id'];
        $session = $_GET['session'];

        // 1. Student Info
        $stmt = $pdo->prepare("SELECT id, class, transport_id, uid FROM students WHERE id = ?");
        $stmt->execute([$student_id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        if(!$student) throw new Exception("Student not found");
        $student_uid = $student['uid'];

        // 2. Pending Fees
        $stmt = $pdo->prepare("SELECT id, pending_amount, status, collection_id FROM pending_fees WHERE student_uid = ?");
        $stmt->execute([$student_uid]);
        $pending_rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $total_pending_due = 0;
        $is_pending_cleared = true; 
        $pending_collection_ids = [];

        foreach($pending_rows as $pr) {
            if($pr['status'] === 'pending') {
                $total_pending_due += $pr['pending_amount'];
                $is_pending_cleared = false;
            } else {
                if($pr['collection_id']) {
                    $pending_collection_ids[] = $pr['collection_id'];
                }
            }
        }

        // 3. Calculate Fee Structure
        $class_id = $student['class'];
        $transport_id = $student['transport_id'];

        $stmt = $pdo->prepare("SELECT particular_id, amount, frequency, custom_frequency, applicable_months FROM fee_structure WHERE class_id = ? AND session = ? AND status = 'active'");
        $stmt->execute([$class_id, $session]);
        $fee_structures = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = $pdo->prepare("SELECT particular_id, fee_type, special_amount, discount_percentage FROM special_structure WHERE student_uid = ? AND status = 'active'");
        $stmt->execute([$student_uid]);
        $special_structures = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $special_academic_map = [];
        $special_transport = null;
        foreach ($special_structures as $ss) {
            if ($ss['fee_type'] === 'transport') $special_transport = $ss;
            else $special_academic_map[$ss['particular_id']] = $ss;
        }

        // Transport
        $transport_monthly_rate = 0;
        if ($transport_id) {
            $stmt = $pdo->prepare("SELECT transport_fees FROM transport WHERE id = ? AND session = ?");
            $stmt->execute([$transport_id, $session]);
            $raw_transport = $stmt->fetchColumn() ?: 0;
            
            if ($special_transport) {
                $discount_amt = 0;
                if ($special_transport['discount_percentage'] > 0) {
                    $discount_amt += ($raw_transport * $special_transport['discount_percentage'] / 100);
                }
                if ($special_transport['special_amount'] > 0) {
                    $discount_amt += $special_transport['special_amount'];
                }
                $raw_transport = max(0, $raw_transport - $discount_amt);
            }
            $transport_monthly_rate = $raw_transport;
        }

        $monthly_dues_map = [];
        foreach($SESSION_MONTH_ORDER as $m) {
            if ($m !== 0) $monthly_dues_map[$m] = 0;
        }

        // Distribute Fees
        foreach ($fee_structures as $fee) {
            $pid = $fee['particular_id'];
            $amount = $fee['amount'];

            if (isset($special_academic_map[$pid])) {
                $ss = $special_academic_map[$pid];
                $discount_amt = 0;
                if ($ss['discount_percentage'] > 0) {
                    $discount_amt += ($amount * $ss['discount_percentage'] / 100);
                }
                if ($ss['special_amount'] > 0) {
                    $discount_amt += $ss['special_amount'];
                }
                $amount = max(0, $amount - $discount_amt);
            }

            if ($fee['frequency'] === 'monthly') {
                $months_to_apply = ($fee['applicable_months'] === 'all') 
                    ? [4,5,6,7,8,9,10,11,12,1,2,3] 
                    : explode(',', $fee['applicable_months']);
                
                foreach ($months_to_apply as $m_id) {
                    $m_id = intval($m_id);
                    if (isset($monthly_dues_map[$m_id])) $monthly_dues_map[$m_id] += $amount;
                }
            } elseif ($fee['frequency'] === 'annual') {
                if (isset($monthly_dues_map[4])) $monthly_dues_map[4] += $amount;
            } elseif ($fee['frequency'] === 'other') {
                // --- UPDATED CUSTOM FREQUENCY LOGIC ---
                // custom_frequency = interval
                // Start from June (Index 3 because 0 is pending)
                $interval = intval($fee['custom_frequency']);
                
                if ($interval > 0) {
                     for ($i = 3; $i < count($SESSION_MONTH_ORDER); $i += $interval) {
                         $m_id = $SESSION_MONTH_ORDER[$i];
                         if (isset($monthly_dues_map[$m_id])) {
                             $monthly_dues_map[$m_id] += $amount;
                         }
                     }
                } else {
                    // Fallback
                    if (!empty($fee['applicable_months']) && $fee['applicable_months'] !== 'all') {
                        $months_to_apply = explode(',', $fee['applicable_months']);
                        foreach ($months_to_apply as $m_id) {
                            $m_id = intval($m_id);
                            if (isset($monthly_dues_map[$m_id])) $monthly_dues_map[$m_id] += $amount;
                        }
                    } else {
                        if (isset($monthly_dues_map[4])) $monthly_dues_map[4] += $amount;
                    }
                }
            }
        }

        foreach ($monthly_dues_map as $m_id => $val) {
            $monthly_dues_map[$m_id] += $transport_monthly_rate;
        }

        // 4. Payments
        $stmt = $pdo->prepare("SELECT id, amount_collected, discount, payment_month FROM fee_collections WHERE student_id = ? AND session = ?");
        $stmt->execute([$student_id, $session]);
        $all_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $total_paid_available_for_months = 0;
        $total_paid_for_pending = 0;

        foreach($all_payments as $p) {
            $pay_val = $p['amount_collected'] + $p['discount'];
            if (in_array($p['id'], $pending_collection_ids) || $p['payment_month'] == '0') {
                $total_paid_for_pending += $pay_val;
            } else {
                $total_paid_available_for_months += $pay_val;
            }
        }

        // 5. Waterfall
        $response_data = [];
        $cumulative_monthly_fee = 0;

        if ($total_pending_due > 0 || !$is_pending_cleared) {
            $response_data[] = [
                'month_id' => 0,
                'month_name' => "Pending Dues (Previous Session)",
                'total_fee' => $total_pending_due,
                'paid_amount' => 0,
                'due_amount' => $total_pending_due,
                'status' => 'unpaid'
            ];
        }

        foreach ($SESSION_MONTH_ORDER as $month_id) {
            if ($month_id == 0) continue; 

            $month_fee = $monthly_dues_map[$month_id] ?? 0;
            $cumulative_monthly_fee += $month_fee;

            $previous_months_cost = $cumulative_monthly_fee - $month_fee;
            $paid_for_this_month = max(0, min($month_fee, $total_paid_available_for_months - $previous_months_cost));
            $due = $month_fee - $paid_for_this_month;
            
            $status = 'unpaid';
            if ($due <= 0.01) { $status = 'fully_paid'; $due = 0; }
            elseif ($paid_for_this_month > 0) { $status = 'partial'; }

            $response_data[] = [
                'month_id' => $month_id,
                'month_name' => getMonthName($month_id),
                'total_fee' => $month_fee,
                'paid_amount' => $paid_for_this_month,
                'due_amount' => $due,
                'status' => $status
            ];
        }

        echo json_encode([
            'status' => 'success',
            'data' => $response_data,
            'summary' => [
                'total_fee' => $cumulative_monthly_fee + $total_pending_due,
                'total_paid' => $total_paid_available_for_months + $total_paid_for_pending,
                'total_outstanding' => ($cumulative_monthly_fee - $total_paid_available_for_months) + $total_pending_due
            ]
        ]);
        exit;
    }

    if ($action == 'collect_fee') {
        $pdo->beginTransaction();
        
        $student_id = $_POST['student_id'];
        $session = $_POST['session'];
        $amount = (float)$_POST['amount_collected'];
        $discount = (float)$_POST['discount'];
        $months = $_POST['months']; // Array of month IDs
        $remarks = $_POST['remarks'];
        $date = $_POST['payment_date'];
        $method = $_POST['payment_method'];
        
        $months_csv = implode(',', $months);
        
        // Insert collection
        $stmt = $pdo->prepare("INSERT INTO fee_collections 
            (student_id, amount_collected, discount, payment_month, payment_date, payment_method, session, remarks, fee_type, collected_by) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'monthly', ?)");
        
        $stmt->execute([
            $student_id, $amount, $discount, $months_csv, $date, $method, $session, $remarks, $_SESSION['name'] ?? 'Admin'
        ]);
        
        $payment_id = $pdo->lastInsertId();

        // Update Pending Fees if Month 0 is selected
        if (in_array('0', $months)) {
             $stmt = $pdo->prepare("UPDATE pending_fees SET status = 'paid', collection_id = ?, updated_on = NOW() WHERE student_uid = (SELECT student_uid FROM students WHERE id = ?)");
             $stmt->execute([$payment_id, $student_id]);
        }
        
        $pdo->commit();
        
        echo json_encode(['status' => 'success', 'payment_id' => $payment_id]);
        exit;
    }

    // get_history, delete_payment, print_receipt remain mostly the same.

    if ($action == 'get_history') {
        $stmt = $pdo->prepare("SELECT * FROM fee_collections WHERE student_id = ? AND session = ? ORDER BY id DESC");
        $stmt->execute([$_GET['student_id'], $_GET['session']]);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Format Month Names
        foreach($data as &$row) {
            $m_ids = explode(',', $row['payment_month']);
            $names = array_map('getMonthName', $m_ids);
            // Handle if month 0 is the only one, otherwise list all.
            if (count($m_ids) === 1 && $m_ids[0] == 0) {
                 $row['months_covered'] = getMonthName(0);
            } else {
                 $row['months_covered'] = implode(', ', $names);
            }
            // For remaining_balance, we'll keep it simple and default to 0 for historical payments.
            $row['remaining_balance'] = 0; 
        }
        
        echo json_encode(['data' => $data]);
        exit;
    }

    // delete_payment needs to revert pending_fees if the deleted payment covered month 0
    if ($action == 'delete_payment') {
        $payment_id = $_POST['payment_id'];
        
        // 1. Check if the payment covered month 0
        $stmt = $pdo->prepare("SELECT student_id, payment_month FROM fee_collections WHERE id = ?");
        $stmt->execute([$payment_id]);
        $pay_data = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$pay_data) throw new Exception("Payment not found.");

        $pdo->beginTransaction();

        // 2. Delete the payment
        $pdo->prepare("DELETE FROM fee_collections WHERE id = ?")->execute([$payment_id]);
        
        // 3. Revert pending_fees status if the payment covered month 0
        if (in_array('0', explode(',', $pay_data['payment_month']))) {
            $student_id = $pay_data['student_id'];
            $stmt = $pdo->prepare("UPDATE pending_fees SET status = 'pending', collection_id = NULL, updated_on = NOW() WHERE student_uid = (SELECT student_uid FROM students WHERE id = ?)");
            $stmt->execute([$student_id]);
        }
        
        $pdo->commit();

        echo json_encode(['status' => 'success']);
        exit;
    }

    if ($action == 'print_receipt') {
        header('Content-Type: text/html');
        
        $id = $_GET['payment_id'];
        
        // 1. Fetch Payment Data
        $stmt = $pdo->prepare("SELECT * FROM fee_collections WHERE id = ?");
        $stmt->execute([$id]);
        $pay = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$pay) throw new Exception("Receipt not found.");

        // 2. Fetch Student Data
        $stmt = $pdo->prepare("SELECT full_name, father_name, class, admission_number FROM students WHERE id = ?");
        $stmt->execute([$pay['student_id']]);
        $stu = $stmt->fetch(PDO::FETCH_ASSOC);

        // 3. Fetch Class Data
        $stmt = $pdo->prepare("SELECT class_name FROM class WHERE id = ?");
        $stmt->execute([$stu['class']]);
        $class_info = $stmt->fetch(PDO::FETCH_ASSOC);

        // 4. Fetch School Settings
        $school = $pdo->query("SELECT school_name, logo, address, phone FROM site_settings LIMIT 1")->fetch(PDO::FETCH_ASSOC);
        
        // 5. Logic to Separate "Pending Dues" from "Regular Months"
        $m_ids = explode(',', $pay['payment_month']);
        $regular_months = [];
        $has_pending = false;

        foreach($m_ids as $mid) {
            if($mid == '0') {
                $has_pending = true;
            } else {
                $regular_months[] = getMonthName($mid);
            }
        }

        // Construct the Description String
        $description_html = "";
        
        // Row for Pending Dues
        if ($has_pending) {
            $description_html .= "
            <tr>
                <td><span class='item-title'>Previous Session Dues</span><br><small class='text-muted'>Arrears cleared</small></td>
                <td style='text-align:right'>Included</td>
            </tr>";
        }

        // Row for Regular Months
        if (!empty($regular_months)) {
            $month_str = implode(', ', $regular_months);
            $description_html .= "
            <tr>
                <td><span class='item-title'>Monthly Tuition & Transport</span><br><small class='text-muted'>$month_str</small></td>
                <td style='text-align:right'>Included</td>
            </tr>";
        }

        // 6. HTML Output
        echo "
        <!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <title>Receipt #$id</title>
            <style>
                @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap');
                
                body {
                    font-family: 'Roboto', sans-serif;
                    background: #f5f5f5;
                    margin: 0;
                    padding: 10px;
                    -webkit-print-color-adjust: exact;
                }
        
                .receipt-box {
                    max-width: 210mm; /* A4 Width (Half of A4) */
                    margin: auto;
                    background: #fff;
                    border: 1px solid #e0e0e0;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
                    position: relative;
                    overflow: hidden;
                }
        
                /* Top Color Bar */
                .brand-strip {
                    height: 4px;
                    background: linear-gradient(90deg, #0d6efd 0%, #0a58ca 100%);
                    width: 100%;
                }
        
                .content {
                    padding: 12px 15px;
                }
        
                /* New wrapper for logo, school info, and receipt number in one row */
                .header-row {
                    display: flex;
                    flex-direction: row;
                    gap: 12px;
                    align-items: center;
                    margin-bottom: 10px;
                    padding-bottom: 8px;
                    border-bottom: 1px solid #eee;
                    justify-content: space-between;
                }
        
                /* Logo positioned in row */
                .logo-section {
                    flex: 0 0 auto;
                    text-align: center;
                }
                .logo-section img {
                    width: 60px;
                    height: auto;
                }
        
                /* School details in row */
                .school-info {
                    flex: 1;
                    text-align: center;
                }
                .school-info h2 {
                    margin: 0;
                    font-size: 16px;
                    color: #222;
                    text-transform: uppercase;
                    letter-spacing: 0.3px;
                    font-weight: 700;
                }
                .school-info p {
                    margin: 2px 0;
                    font-size: 12px;
                    color: #666;
                    line-height: 1.2;
                }
        
                /* Receipt number section in row */
                .receipt-meta {
                    flex: 0 0 auto;
                    text-align: center;
                }
                .receipt-badge {
                    background: #eef2ff;
                    color: #0d6efd;
                    padding: 3px 8px;
                    border-radius: 12px;
                    font-weight: bold;
                    font-size: 12px;
                    display: inline-block;
                    border: 1px solid #dce5ff;
                    margin-bottom: 2px;
                }
                .meta-date {
                    font-size: 11px;
                    color: #444;
                }
        
                /* Changed from grid 2 columns to flex row layout */
                .info-grid {
                    display: flex;
                    flex-direction: row;
                    gap: 6px;
                    margin-bottom: 10px;
                    background: #f8f9fa;
                    padding: 8px;
                    border-radius: 4px;
                    border: 1px solid #eee;
                    flex-wrap: wrap;
                }
                .info-item {
                    flex: 1;
                    min-width: 80px;
                }
                .info-item label {
                    display: block;
                    font-size: 12px;
                    text-transform: uppercase;
                    color: #888;
                    margin-bottom: 1px;
                    font-weight: 500;
                }
                .info-item span {
                    font-size: 12px;
                    font-weight: 500;
                    color: #333;
                }
        
        
                /* Table */
                .fee-table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 10px;
                    font-size: 14px;
                }
                .fee-table th {
                    text-align: left;
                    padding: 6px 0;
                    border-bottom: 2px solid #eee;
                    font-size: 12px;
                    text-transform: uppercase;
                    color: #555;
                    font-weight: 600;
                }
                .fee-table td {
                    padding: 6px 0;
                    border-bottom: 1px solid #eee;
                    font-size: 12px;
                    color: #333;
                }
                .item-title {
                    font-weight: 500;
                    display: block;
                }
                .text-muted {
                    color: #777;
                    font-size: 12px;
                }
        
                /* Total Section */
                .total-section {
                    display: flex;
                    justify-content: flex-end;
                    margin-bottom: 10px;
                }
                .total-box {
                    width: 120px;
                }
                .total-row {
                    display: flex;
                    justify-content: space-between;
                    padding: 3px 0;
                    font-size: 12px;
                }
                .grand-total {
                    border-top: 2px solid #333;
                    margin-top: 3px;
                    padding-top: 5px;
                    font-weight: 700;
                    font-size: 14px;
                    color: #0d6efd;
                }
        
                /* Footer */
                .footer {
                    margin-top: 10px;
                    border-top: 1px dashed #ccc;
                    padding-top: 8px;
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-end;
                }
                .footer-left p {
                    margin: 1px 0;
                    font-size: 10px;
                    color: #666;
                    line-height: 1.2;
                }
                .footer-right {
                    text-align: right;
                }
                .status-stamp {
                    border: 1.5px solid #198754;
                    color: #198754;
                    padding: 3px 8px;
                    font-weight: bold;
                    text-transform: uppercase;
                    font-size: 12px;
                    letter-spacing: 0.5px;
                    border-radius: 3px;
                    opacity: 0.8;
                }
        
                @media print {
                    body { background: #fff; padding: 0; margin: 0; }
                    .receipt-box { width: 90%; max-width: 100%; }
                    @page { size: 210mm 297mm; margin: 5mm; }
                }
            </style>
        </head>
        <body onload='window.print()'>
            <div class='receipt-box'>
                <div class='brand-strip'></div>
                <div class='content'>
                    
                    <!-- New wrapper for logo, school info, and receipt number in one row -->
                    <div class='header-row'>
                        <!-- Logo section in row -->
                        <div class='logo-section'>
                            <img src='{$school['logo']}' alt='{$school['school_name']}'>
                        </div>
        
                        <!-- School details in row -->
                        <div class='school-info'>
                            <h2>{$school['school_name']}</h2>
                            <p>{$school['address']}</p>
                            <p>Phone: {$school['phone']}</p>
                        </div>
        
                        <!-- Receipt number section in row -->
                        <div class='receipt-meta'>
                            <div class='receipt-badge'>RECEIPT #$id</div>
                            <div class='meta-date'>".date('d M Y', strtotime($pay['payment_date']))."</div>
                        </div>
                    </div>
        
                    <!-- Student Info -->
                    <div class='info-grid'>
                        <div class='info-item'>
                            <label>Student Name</label>
                            <span>{$stu['full_name']}</span>
                        </div>
                        <div class='info-item'>
                            <label>Admission No.</label>
                            <span>".($stu['admission_number'] ? $stu['admission_number'] : 'N/A')."</span>
                        </div>
                        <div class='info-item'>
                            <label>Father's Name</label>
                            <span>{$stu['father_name']}</span>
                        </div>
                        <div class='info-item'>
                            <label>Class / Section</label>
                            <span>{$class_info['class_name']} " . ($class_info['section'] ? ' - '.$class_info['section'] : '') . "</span>
                        </div>
                    </div>
        
                    <!-- Fee Table -->
                    <table class='fee-table'>
                        <thead>
                            <tr>
                                <th>Fee Description</th>
                                <th style='text-align:right'>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            $description_html
                        </tbody>
                    </table>
        
                    <!-- Totals -->
                    <div class='total-section'>
                        <div class='total-box'>
                            <div class='total-row'>
                                <span>Sub Total:</span>
                                <span>".number_format($pay['amount_collected'] + $pay['discount'], 2)."</span>
                            </div>
                            <div class='total-row text-muted'>
                                <span>Discount:</span>
                                <span>- ".number_format($pay['discount'], 2)."</span>
                            </div>
                            <div class='total-row grand-total'>
                                <span>Total Paid:</span>
                                <span>₹".number_format($pay['amount_collected'], 2)."</span>
                            </div>
                        </div>
                    </div>
        
                    <!-- Footer -->
                    <div class='footer'>
                        <div class='footer-left'>
                            <p><strong>Payment Mode:</strong> ".strtoupper($pay['payment_method'])." " . ($pay['remarks'] ? '('.$pay['remarks'].')' : '') . "</p>
                            <p><strong>Collected By:</strong> " . ($pay['collected_by'] ? $pay['collected_by'] : 'System Admin') . "</p>
                            <p style='margin-top:2px; font-style:italic; font-size:8px;'>* System generated receipt</p>
                        </div>
                        <div class='footer-right'>
                            <div class='status-stamp'>PAID</div>
                        </div>
                    </div>
        
                </div>
            </div>
        </body>
        </html>
        ";
        exit;
    }

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>