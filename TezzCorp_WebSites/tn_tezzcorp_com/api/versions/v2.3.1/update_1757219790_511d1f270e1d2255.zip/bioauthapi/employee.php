<?php
header('Access-Control-Allow-Origin: https://www.bthdevelopers.com');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

require '../conn.php';

date_default_timezone_set("Asia/Kolkata");
$date = date("Y-m-d");
$time = date("h:i:sa");

$query = mysqli_query($conn, "SELECT * FROM staff WHERE role = 'Teacher'");

$response = array();
    
while ($fetch = mysqli_fetch_array($query)) {
    $id = $fetch['id'];
    $name = $fetch['name'];
    $response[] = array(
        "id" => $id,
        "name" => $name
    );
}

header('Content-Type: application/json');
echo json_encode($response);
?>