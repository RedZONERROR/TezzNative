<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Export libraries for PDF and Excel -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.31/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

    <title>Student Admission - AI-ERP 2.0</title>
    <style>
        .staff-photo {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 50%;
        }
        .action-buttons {
            display: none;
        }
        .btn-loading .fa-spinner {
            display: inline-block;
        }
        .btn-loading .btn-text, .btn-loading .ti {
            display: none;
        }
        .fa-spinner {
            display: none;
            font-size: 0.9rem;
        }
        .pagination {
            margin-top: 1rem;
        }
        .export-buttons {
            display: flex;
            gap: 0.5rem;
        }
        .export-btn {
            padding: 0.375rem 0.75rem;
            font-size: 0.875rem;
            border-radius: 0.375rem;
            border: 1px solid transparent;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
        }
        .export-btn-pdf {
            background-color: #dc3545;
            color: white;
            border-color: #dc3545;
        }
        .export-btn-pdf:hover {
            background-color: #c82333;
            border-color: #bd2130;
            color: white;
        }
        .export-btn-excel {
            background-color: #198754;
            color: white;
            border-color: #198754;
        }
        .export-btn-excel:hover {
            background-color: #157347;
            border-color: #146c43;
            color: white;
        }
        #pdf-temp {
            display: none;
        }
        #preview-form .form-container {
            transform: scale(0.8);
            transform-origin: top left;
            width: 125%;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Manage Students</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Students
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Student Management -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-3 col-xl-2">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Students..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-3 col-xl-2">
                                    <select class="form-select" id="class-filter">
                                        <option value="">All Classes</option>
                                        <!-- Classes will be populated dynamically -->
                                    </select>
                                </div>
                                <div class="col-md-6 col-xl-8 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div class="action-buttons me-2">
                                        <button class="delete-multiple btn bg-danger-subtle text-danger me-1">
                                            <i class="fas fa-spinner fa-spin"></i>
                                            <span class="btn-text">Delete</span>
                                        </button>
                                        <button class="approve-multiple btn bg-success-subtle text-success">
                                            <i class="fas fa-spinner fa-spin"></i>
                                            <span class="btn-text">Approve</span>
                                        </button>
                                    </div>
                                    <div class="export-buttons me-2">
                                        <button class="export-btn export-btn-excel">
                                            <i class="fas fa-user"></i>
                                            Total: <span id="totalStudents"></span>
                                        </button>
                                        <button class="export-btn export-btn-pdf" id="export-pdf">
                                            <i class="fas fa-file-pdf"></i>
                                            Export PDF
                                        </button>
                                        <button class="export-btn export-btn-excel" id="export-excel">
                                            <i class="fas fa-file-excel"></i>
                                            Export Excel
                                        </button>
                                    </div>
                                    <a href="admission.php" id="btn-add-student"
                                        class="btn btn-primary d-flex align-items-center">
                                        <i class="ti ti-user-plus text-white me-1 fs-5"></i> Add Student
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="card card-body">
                            <div class="d-flex justify-content-center">
                                <div class="spinner-border text-primary" role="status" id="table-loader">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <th>
                                            <div class="n-chk align-self-center text-center">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input primary" id="student-check-all" />
                                                    <label class="form-check-label" for="student-check-all"></label>
                                                    <span class="new-control-indicator"></span>
                                                </div>
                                            </div>
                                        </th>
                                        <th>Photo</th>
                                        <th>Name</th>
                                        <th>Class</th>
                                        <th>Mobile Number</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody id="student_list_table_body">
                                        <!-- Data will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <nav aria-label="Page navigation" id="pagination-nav">
                                <ul class="pagination justify-content-center">
                                    <!-- Pagination controls -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- View Modal -->
    <div class="modal fade" id="viewStudentModal" tabindex="-1" aria-labelledby="viewStudentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewStudentModalLabel">Student Registration Preview</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="preview-form"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="download-student-pdf">Print/Save PDF</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Temporary container for PDF generation -->
    <div id="pdf-temp"></div>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        hljs.initHighlightingOnLoad();
        document.querySelectorAll("pre.code-view > code").forEach((codeBlock) => {
            codeBlock.textContent = codeBlock.innerHTML;
        });

        $(document).ready(function() {
            // Pagination state
            let currentPage = 1;
            const perPage = 10;
            const pageRange = 10;
            let classOptions = [];
            let isSearching = false;
            let currentStudent = {};
            let siteSettings = {};
            
            // Function to update total students count
            function updateTotalStudents(count) {
                $('#totalStudents').text(count);
            }

            // Fetch site settings
            function fetchSiteSettings() {
                return $.ajax({
                    url: 'api/site_settings.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success' && response.data) {
                            siteSettings = response.data;
                            console.log('Site settings loaded:', siteSettings);
                        } else {
                            siteSettings = {
                                school_name: 'SHREE SARASWATI VIDYA MANDIR',
                                address: 'Village: Rampur, Post: Rampur, District: Patna, State: Bihar - 801503',
                                phone: '+91-9876543210',
                                email: 'info@saraswatividyamandir.edu.in',
                                logo: ''
                            };
                            console.warn('No site settings found, using defaults:', siteSettings);
                        }
                    },
                    error: function(xhr, status, error) {
                        siteSettings = {
                            school_name: 'SHREE SARASWATI VIDYA MANDIR',
                            address: 'Village: Rampur, Post: Rampur, District: Patna, State: Bihar - 801503',
                            phone: '+91-9876543210',
                            email: 'info@saraswatividyamandir.edu.in',
                            logo: ''
                        };
                        console.error('Failed to load site settings:', status, error);
                        Swal.fire({
                            icon: 'warning',
                            title: 'Warning',
                            text: 'Failed to load site settings. Using default values.'
                        });
                    }
                });
            }

            // Student registration form HTML template
            const registrationTemplate = `<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Student Registration Form</title>
                <style>
                    * {
                        margin: 0;
                        padding: 0;
                        box-sizing: border-box;
                    }
            
                    body {
                        font-family: 'Arial', sans-serif;
                        font-size: 12px;
                        line-height: 1.4;
                        color: #000;
                        background: white;
                        padding: 1mm;
                    }
            
                    @media print {
                        body {
                            padding: 3mm;
                        }
                        .no-print {
                            display: none;
                        }
                    }
            
                    @page {
                        size: A4;
                        margin: 3mm;
                    }
            
                    .form-container {
                        max-width: 100%;
                        background: white;
                        border: 2px solid #000;
                        box-shadow: 0 0 10px rgba(0,0,0,0.1);
                        page-break-after: always;
                        position: relative; /* Make form-container the positioning context */
                    }
            
                    .school-header {
                        background: #e9ecf0;
                        padding: 15px;
                        text-align: center;
                        border-bottom: 2px solid #000;
                    }
            
                    .school-logo {
                        height: 50px;
                        margin-bottom: 10px;
                        object-fit: contain;
                    }
            
                    .school-header h1 {
                        font-size: 20px;
                        margin-bottom: 6px;
                        font-weight: bold;
                        color: #000;
                        letter-spacing: 1px;
                    }
            
                    .school-header .school-details {
                        font-size: 12px;
                        font-weight: normal;
                        color: #000;
                        margin-bottom: 3px;
                    }
            
                    .form-header {
                        background: white;
                        padding: 12px;
                        text-align: center;
                        border-bottom: 2px solid #000;
                    }
            
                    .form-header h1 {
                        font-size: 18px;
                        margin-bottom: 5px;
                        font-weight: bold;
                        color: #000;
                        text-transform: uppercase;
                        letter-spacing: 0.5px;
                    }
            
                    .form-header p {
                        font-size: 12px;
                        color: #666;
                    }
            
                    .form-content {
                        display: flex;
                        gap: 15px;
                        padding: 15px;
                        background: white;
                    }
            
                    .form-fields {
                        flex: 2.5;
                    }
            
                    .section {
                        margin-bottom: 15px;
                        border: 1px solid #000;
                        background: white;
                    }
            
                    .section-title {
                        font-size: 13px;
                        font-weight: bold;
                        margin: 0;
                        background: #f8f9fa;
                        padding: 8px 12px;
                        border-bottom: 1px solid #000;
                        color: #000;
                        text-transform: uppercase;
                        letter-spacing: 0.5px;
                    }
            
                    .field-grid {
                        display: grid;
                        grid-template-columns: 1fr 1fr;
                        gap: 15px;
                        padding: 12px;
                    }
            
                    .field-grid-three {
                        display: grid;
                        grid-template-columns: 1fr 1fr 1fr;
                        gap: 15px;
                        padding: 12px;
                    }
            
                    .field-full {
                        display: grid;
                        grid-template-columns: 1fr;
                        gap: 10px;
                        padding: 12px;
                    }
            
                    .field {
                        display: flex;
                        flex-direction: column;
                        gap: 4px;
                    }
            
                    .photo {
                        position: absolute;
                        right: 15px;
                        top: 222px; /* Adjusted to place photo within Personal Information section */
                        gap: 4px;
                    }
            
                    .field label {
                        font-weight: bold;
                        font-size: 10px;
                        color: #000;
                        text-transform: uppercase;
                        letter-spacing: 0.3px;
                    }
            
                    .field-value {
                        border-bottom: 1px solid #000;
                        padding: 4px 2px;
                        min-height: 20px;
                        font-size: 11px;
                        background: white;
                        font-weight: 500;
                    }
            
                    .parent-section {
                        margin-bottom: 15px;
                        border: 1px solid #000;
                        background: white;
                    }
            
                    .parent-section .section-title {
                        background: #f8f9fa;
                        color: #000;
                        border-bottom: 1px solid #000;
                    }
            
                    .parent-columns {
                        display: flex;
                        gap: 20px;
                        padding: 12px;
                    }
            
                    .parent-column {
                        flex: 1;
                        display: flex;
                        flex-direction: column;
                        gap: 12px;
                    }
            
                    .student-photo {
                        width: 140px;
                        height: 160px;
                        border: 2px solid #000;
                        object-fit: cover;
                        margin-bottom: 10px;
                    }
            
                    .signature-section {
                        margin-top: 20px;
                        display: flex;
                        justify-content: space-between;
                        border-top: 2px solid #000;
                        padding: 15px;
                        background: white;
                    }
            
                    .signature-box {
                        text-align: center;
                        width: 140px;
                    }
            
                    .signature-line {
                        border-bottom: 1px solid #000;
                        height: 40px;
                        margin-bottom: 6px;
                    }
            
                    .signature-box div:last-child {
                        font-size: 10px;
                        font-weight: bold;
                        text-transform: uppercase;
                        letter-spacing: 0.3px;
                    }
                </style>
            </head>
            <body>
                <div class="form-container">
                    <div class="school-header">
                        <h1>{{school_name}}</h1>
                        <div class="school-details">{{school_address}}</div>
                        <div class="school-details">Contact: {{school_phone}} | Email: {{school_email}}</div>
                    </div>
            
                    <div class="form-header">
                        <h1>Student Registration Form</h1>
                    </div>
            
                    <div class="form-content">
                        <div class="form-fields">
                            <div class="info-section">
                                <div class="section-title">Personal Information</div>
                                <div class="field-grid">
                                    <div class="field">
                                        <label>Student Name:</label>
                                        <div class="field-value">{{student_name}}</div>
                                    </div>
                                    <div class="field">
                                        <label>Roll Number:</label>
                                        <div class="field-value">{{roll_number}}</div>
                                    </div>
                                    <div class="field">
                                        <label>Date of Birth:</label>
                                        <div class="field-value">{{dob}}</div>
                                    </div>
                                    <div class="field">
                                        <label>Gender:</label>
                                        <div class="field-value">{{gender}}</div>
                                    </div>
                                    <div class="field">
                                        <label>Category:</label>
                                        <div class="field-value">{{category}}</div>
                                    </div>
                                    <div class="field">
                                        <label>Religion:</label>
                                        <div class="field-value">{{religion}}</div>
                                    </div>
                                    <div class="photo">
                                        <img src="{{student_photo}}" alt="Student Photo" class="student-photo">
                                    </div>
                                </div>
            
                                <div class="field-grid-three">
                                    <div class="field">
                                        <label>Mobile Number:</label>
                                        <div class="field-value">{{mobile}}</div>
                                    </div>
                                    <div class="field">
                                        <label>Aadhaar Number:</label>
                                        <div class="field-value">{{aadhaar}}</div>
                                    </div>
                                    <div class="field">
                                        <label>Blood Group:</label>
                                        <div class="field-value">{{blood_group}}</div>
                                    </div>
                                </div>
                            </div>
            
                            <div class="section">
                                <div class="section-title">Academic Information</div>
                                <div class="field-grid">
                                    <div class="field">
                                        <label>Class & Section:</label>
                                        <div class="field-value">{{class_section}}</div>
                                    </div>
                                    <div class="field">
                                        <label>Medium of Instruction:</label>
                                        <div class="field-value">{{medium}}</div>
                                    </div>
                                    <div class="field">
                                        <label>Academic Session:</label>
                                        <div class="field-value">{{session}}</div>
                                    </div>
                                    <div class="field">
                                        <label>Admission Number:</label>
                                        <div class="field-value">{{admission_number}}</div>
                                    </div>
                                    <div class="field">
                                        <label>Admission Date:</label>
                                        <div class="field-value">{{admission_date}}</div>
                                    </div>
                                    <div class="field">
                                        <label>Transport Required:</label>
                                        <div class="field-value">{{transport}}</div>
                                    </div>
                                </div>
                            </div>
            
                            <div class="parent-section">
                                <div class="section-title">Parent / Guardian Information</div>
                                <div class="parent-columns">
                                    <div class="parent-column">
                                        <div class="field">
                                            <label>Father's Name:</label>
                                            <div class="field-value">{{father_name}}</div>
                                        </div>
                                    </div>
                                    <div class="parent-column">
                                        <div class="field">
                                            <label>Mother's Name:</label>
                                            <div class="field-value">{{mother_name}}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
            
                            <div class="section">
                                <div class="section-title">Address Details</div>
                                <div class="field-full">
                                    <div class="field">
                                        <label>Permanent Address:</label>
                                        <div class="field-value" style="min-height: 40px;">{{address}}</div>
                                    </div>
                                </div>
                            </div>
            
                            <div class="signature-section">
                                <div class="signature-box">
                                    <div class="signature-line"></div>
                                    <div>Parent Signature</div>
                                </div>
                                <div class="signature-box">
                                    <div class="signature-line"></div>
                                    <div>Principal Signature</div>
                                </div>
                                <div class="signature-box">
                                    <div class="signature-line"></div>
                                    <div>Office Seal</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </body>
            </html>`;

            // Function to populate the template with student data and site settings
            function populateTemplate(student) {
                let html = registrationTemplate;
                html = html.replace(/{{school_name}}/g, siteSettings.school_name || 'SHREE SARASWATI VIDYA MANDIR');
                html = html.replace(/{{school_address}}/g, siteSettings.address || 'Village: Rampur, Post: Rampur, District: Patna, State: Bihar - 801503');
                html = html.replace(/{{school_phone}}/g, siteSettings.phone || '+91-9876543210');
                html = html.replace(/{{school_email}}/g, siteSettings.email || 'info@saraswatividyamandir.edu.in');
                const logoPath = siteSettings.logo ? window.location.origin + '/' + siteSettings.logo : '';
                html = html.replace(/{{school_logo}}/g, logoPath);
                html = html.replace(/{{student_name}}/g, student.full_name || student.name || student.student_name || 'N/A');
                html = html.replace(/{{roll_number}}/g, student.roll_number || '_________________');
                html = html.replace(/{{dob}}/g, student.date_of_birth ? new Date(student.date_of_birth).toLocaleDateString('en-GB') : '_________________');
                html = html.replace(/{{gender}}/g, student.gender || '_________________');
                html = html.replace(/{{category}}/g, student.category || '_________________');
                html = html.replace(/{{religion}}/g, student.religion || '_________________');
                html = html.replace(/{{mobile}}/g, student.mobile_number || student.mobile || '_________________');
                html = html.replace(/{{aadhaar}}/g, student.aadhaar || '_________________');
                html = html.replace(/{{blood_group}}/g, student.blood_group || '_________________');
                html = html.replace(/{{class_section}}/g, student.class_name || 'N/A');
                html = html.replace(/{{medium}}/g, student.medium || 'Hindi');
                html = html.replace(/{{session}}/g, student.session || '2024-25');
                html = html.replace(/{{admission_number}}/g, student.admission_number || '_________________');
                html = html.replace(/{{admission_date}}/g, student.admission_date ? new Date(student.admission_date).toLocaleDateString('en-GB') : '_________________');
                html = html.replace(/{{transport}}/g, student.transport == 1 ? 'Yes' : 'No');
                html = html.replace(/{{father_name}}/g, student.father_name || 'N/A');
                html = html.replace(/{{mother_name}}/g, student.mother_name || 'N/A');
                html = html.replace(/{{address}}/g, student.residential_address || '_________________________________');
                const photoPath = student.student_photo ? window.location.origin + '/' + student.student_photo + '?t=' + new Date().getTime() : window.location.origin + '/app/students/assets/images/profile/user-1.jpg';
                html = html.replace(/{{student_photo}}/g, photoPath);
                return html;
            }

            // Function to preload images
            function preloadImage(src) {
                return new Promise((resolve, reject) => {
                    const img = new Image();
                    img.crossOrigin = 'Anonymous';
                    img.src = src;
                    img.onload = () => {
                        console.log('Image loaded successfully:', src);
                        resolve(img);
                    };
                    img.onerror = () => {
                        console.warn('Image failed to load, using fallback:', src);
                        const fallback = window.location.origin + '/app/students/assets/images/profile/user-1.jpg';
                        img.src = fallback;
                        img.onload = () => {
                            console.log('Fallback image loaded:', fallback);
                            resolve(img);
                        };
                        img.onerror = () => {
                            console.error('Failed to load fallback image:', fallback);
                            reject(new Error('Failed to load fallback image'));
                        };
                    };
                });
            }

            // Function to extract and preload all unique images
            function waitForImages(studentsData, isSingle = false) {
                return new Promise((resolve, reject) => {
                    const imageUrls = new Set();
                    // Add school logo if available
                    if (siteSettings.logo) {
                        imageUrls.add(window.location.origin + '/' + siteSettings.logo);
                    }
                    // Add student photos
                    if (isSingle) {
                        const student = studentsData;
                        if (student.student_photo) {
                            imageUrls.add(window.location.origin + '/' + student.student_photo + '?t=' + new Date().getTime());
                        }
                    } else {
                        studentsData.forEach(student => {
                            if (student.student_photo) {
                                imageUrls.add(window.location.origin + '/' + student.student_photo + '?t=' + new Date().getTime());
                            }
                        });
                    }
                    // Convert Set to Array and filter out empty or invalid URLs
                    const urls = Array.from(imageUrls).filter(url => url && typeof url === 'string');
                    if (urls.length === 0) {
                        console.log('No images to preload');
                        resolve();
                        return;
                    }
                    let loaded = 0;
                    const total = urls.length;
                    console.log('Preloading images:', urls);
                    const timeout = setTimeout(() => {
                        console.error('Image loading timeout after 10s');
                        reject(new Error('Image loading timeout'));
                    }, 10000);
                    urls.forEach(url => {
                        preloadImage(url).then(() => {
                            loaded++;
                            console.log(`Image ${loaded}/${total} loaded: ${url}`);
                            if (loaded === total) {
                                clearTimeout(timeout);
                                resolve();
                            }
                        }).catch(err => {
                            console.error('Error preloading image:', url, err);
                            loaded++;
                            if (loaded === total) {
                                clearTimeout(timeout);
                                resolve();
                            }
                        });
                    });
                });
            }

            // Function to generate and open print popup for Registration Form
            async function generateFormPrintPopup(studentsData, filename, isSingle = false) {
                console.log('Generating print popup for:', isSingle ? 'single student' : 'multiple students', studentsData);
                let allHtml = '';
                if (isSingle) {
                    allHtml = populateTemplate(studentsData);
                } else {
                    studentsData.forEach(student => {
                        allHtml += populateTemplate(student);
                    });
                }
                try {
                    // Preload all images
                    await waitForImages(studentsData, isSingle);
                    console.log('All images preloaded, opening print popup');
                    const printWindow = window.open('', '_blank', 'width=800,height=600');
                    printWindow.document.write(`
                        <!DOCTYPE html>
                        <html>
                        <head>
                            <title>${filename}</title>
                            <style>
                                @media print {
                                    .form-container { page-break-after: always; }
                                    body { margin: 0; }
                                }
                            </style>
                        </head>
                        <body>
                            ${allHtml}
                        </body>
                        </html>
                    `);
                    printWindow.document.close();
                    printWindow.onload = () => {
                        console.log('Print window loaded, triggering print dialog');
                        printWindow.focus();
                        printWindow.print();
                    };
                } catch (error) {
                    console.error('Print popup generation failed:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to generate print popup: ' + error.message
                    });
                }
            }

            // Function to generate list PDF
            async function generateListPDF(studentsData, title, filename) {
                const { jsPDF } = window.jspdf;
                const doc = new jsPDF('portrait');
                doc.setFontSize(16);
                doc.text(title, 14, 15);
                doc.setFontSize(10);
                doc.text(`Exported on: ${new Date().toLocaleDateString('en-GB')} ${new Date().toLocaleTimeString()}`, 14, 25);
                doc.text(`Total Students: ${studentsData.length}`, 14, 32);
                const tableData = [];
                const headers = ['Sl No.', 'Name', 'Class', 'Mobile', 'Father Name', 'Mother Name', 'D.O.B'];
                studentsData.forEach((student, index) => {
                    tableData.push([
                        index + 1,
                        student.full_name || 'N/A',
                        student.class_name || 'N/A',
                        student.mobile_number || 'N/A',
                        student.father_name || 'N/A',
                        student.mother_name || 'N/A',
                        student.date_of_birth ? new Date(student.date_of_birth).toLocaleDateString('en-GB') : 'N/A'
                    ]);
                });
                doc.autoTable({
                    head: [headers],
                    body: tableData,
                    startY: 40,
                    styles: { fontSize: 8, cellPadding: 2, lineColor: [200, 200, 200], lineWidth: 0.1 },
                    headStyles: { fillColor: [52, 152, 219], textColor: 255, fontStyle: 'bold', fontSize: 9, halign: 'center' },
                    alternateRowStyles: { fillColor: [248, 249, 250] },
                    margin: { top: 30, right: 10, bottom: 20, left: 10 },
                    columnStyles: {
                        0: { cellWidth: 12, halign: 'center' },
                        1: { cellWidth: 35 },
                        2: { cellWidth: 18, halign: 'center' },
                        3: { cellWidth: 22, halign: 'center' },
                        4: { cellWidth: 40 },
                        5: { cellWidth: 40 },
                        6: { cellWidth: 20, halign: 'center' }
                    },
                    didDrawPage: (data) => {
                        const pageCount = doc.internal.getNumberOfPages();
                        const pageHeight = doc.internal.pageSize.getHeight();
                        doc.setFontSize(8);
                        doc.text('Page ' + data.pageNumber + ' of ' + pageCount, data.settings.margin.left, pageHeight - 10);
                    }
                });
                doc.save(`${filename}.pdf`);
            }

            // Export confirmation dialog
            function showExportConfirmation(exportFormat, callback) {
                const currentClass = $('#class-filter').val();
                if (!currentClass) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Warning',
                        text: 'Please select a class first'
                    });
                    return;
                }
                Swal.fire({
                    title: 'Export Options',
                    text: 'Which students would you like to export?',
                    icon: 'question',
                    showCancelButton: true,
                    showDenyButton: true,
                    confirmButtonText: 'All Students',
                    denyButtonText: 'Transport Students',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    let studentType;
                    if (result.isConfirmed) {
                        studentType = 'all';
                    } else if (result.isDenied) {
                        studentType = 'transport';
                    } else {
                        return;
                    }
                    if (exportFormat === 'pdf') {
                        Swal.fire({
                            title: 'PDF Type',
                            text: 'Choose PDF format',
                            icon: 'question',
                            showCancelButton: true,
                            showDenyButton: true,
                            confirmButtonText: 'List PDF',
                            denyButtonText: 'Registration Forms',
                            cancelButtonText: 'Cancel'
                        }).then((pdfResult) => {
                            let pdfType;
                            if (pdfResult.isConfirmed) {
                                pdfType = 'list';
                            } else if (pdfResult.isDenied) {
                                pdfType = 'forms';
                            } else {
                                return;
                            }
                            callback(studentType, pdfType);
                        });
                    } else {
                        callback(studentType);
                    }
                });
            }

            // Export to PDF
            async function exportToPDF(studentType, pdfType) {
                const currentDate = new Date().toLocaleDateString('en-GB').replace(/\//g, '-');
                const currentClass = $('#class-filter').val();
                const searchTerm = $('#input-search').val();
                let exportTitle = studentType === 'all' ? 'All Students List' : 'Transport Students List';
                let filename = studentType === 'all' ? `all-students-${currentDate}` : `transport-students-${currentDate}`;
                if (currentClass) {
                    const selectedClassName = $('#class-filter option:selected').text();
                    exportTitle = `${selectedClassName} - ${studentType === 'all' ? 'All Students' : 'Transport Students'} List`;
                    filename = `${selectedClassName.toLowerCase().replace(/\s+/g, '-')}-${studentType === 'all' ? 'all' : 'transport'}-students-${currentDate}`;
                }
                Swal.fire({
                    title: 'Exporting...',
                    text: `Fetching ${studentType === 'all' ? 'all' : 'transport'} students from selected class`,
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
                try {
                    const response = await $.ajax({
                        url: 'api/student_master.php',
                        type: 'GET',
                        data: { 
                            page: 1, 
                            perPage: 10000,
                            class: currentClass,
                            search: searchTerm
                        },
                        dataType: 'json'
                    });
                    Swal.close();
                    if (response.data && Array.isArray(response.data)) {
                        const filteredData = studentType === 'all' ? response.data : response.data.filter(student => student.transport === 1);
                        if (filteredData.length === 0) {
                            Swal.fire({
                                icon: 'warning',
                                title: 'No Data',
                                text: `No ${studentType === 'all' ? 'students' : 'transport students'} found for the selected class.`
                            });
                            return;
                        }
                        if (pdfType === 'list') {
                            await generateListPDF(filteredData, exportTitle, filename);
                        } else {
                            await generateFormPrintPopup(filteredData, filename);
                        }
                        Swal.fire({
                            icon: 'success',
                            title: pdfType === 'list' ? 'PDF Exported' : 'Print Window Opened',
                            text: pdfType === 'list' ? `${exportTitle} has been exported to PDF successfully!` : 'Print or save as PDF using the browser dialog.',
                            timer: 2000,
                            showConfirmButton: false
                        });
                    } else {
                        Swal.fire({
                            icon: 'warning',
                            title: 'No Data',
                            text: `No ${studentType === 'all' ? 'students' : 'transport students'} found for the selected class.`
                        });
                    }
                } catch (error) {
                    console.error('Export PDF error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to fetch student data for export.'
                    });
                }
            }

            // Export to Excel
            async function exportToExcel(studentType) {
                const currentDate = new Date().toLocaleDateString('en-GB').replace(/\//g, '-');
                const currentClass = $('#class-filter').val();
                const searchTerm = $('#input-search').val();
                let exportTitle = studentType === 'all' ? 'All Students List' : 'Transport Students List';
                let filename = studentType === 'all' ? `all-students-${currentDate}` : `transport-students-${currentDate}`;
                if (currentClass) {
                    const selectedClassName = $('#class-filter option:selected').text();
                    exportTitle = `${selectedClassName} - ${studentType === 'all' ? 'All Students' : 'Transport Students'} List`;
                    filename = `${selectedClassName.toLowerCase().replace(/\s+/g, '-')}-${studentType === 'all' ? 'all' : 'transport'}-students-${currentDate}`;
                }
                Swal.fire({
                    title: 'Exporting...',
                    text: `Fetching ${studentType === 'all' ? 'all' : 'transport'} students from selected class`,
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
                try {
                    const response = await $.ajax({
                        url: 'api/student_master.php',
                        type: 'GET',
                        data: { 
                            page: 1, 
                            perPage: 10000,
                            class: currentClass,
                            search: searchTerm
                        },
                        dataType: 'json'
                    });
                    Swal.close();
                    if (response.data && Array.isArray(response.data)) {
                        const filteredData = studentType === 'all' ? response.data : response.data.filter(student => student.transport === 1);
                        if (filteredData.length === 0) {
                            Swal.fire({
                                icon: 'warning',
                                title: 'No Data',
                                text: `No ${studentType === 'all' ? 'students' : 'transport students'} found for the selected class.`
                            });
                            return;
                        }
                        generateExcelWithData(filteredData, exportTitle, filename);
                        Swal.fire({
                            icon: 'success',
                            title: 'Excel Exported',
                            text: `${exportTitle} has been exported to Excel successfully!`,
                            timer: 2000,
                            showConfirmButton: false
                        });
                    } else {
                        Swal.fire({
                            icon: 'warning',
                            title: 'No Data',
                            text: `No ${studentType === 'all' ? 'students' : 'transport students'} found for the selected class.`
                        });
                    }
                } catch (error) {
                    console.error('Export Excel error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to fetch student data for export.'
                    });
                }
            }

            // Excel generation function
            function generateExcelWithData(studentsData, title, filename) {
                const excelData = [];
                const headers = ['Sl No.', 'Name', 'Class', 'Mobile Number', 'Father Name', 'Mother Name', 'Date of Birth'];
                excelData.push(headers);
                studentsData.forEach((student, index) => {
                    const rowData = [
                        index + 1,
                        student.full_name || student.name || student.student_name || 'N/A',
                        student.class_name || 'N/A',
                        student.mobile_number || student.mobile || 'N/A',
                        student.father_name || 'N/A',
                        student.mother_name || 'N/A',
                        student.date_of_birth ? new Date(student.date_of_birth).toLocaleDateString('en-GB') : 'N/A'
                    ];
                    excelData.push(rowData);
                });
                const wb = XLSX.utils.book_new();
                const ws = XLSX.utils.aoa_to_sheet(excelData);
                ws['!cols'] = [
                    { width: 8 },
                    { width: 25 },
                    { width: 12 },
                    { width: 15 },
                    { width: 25 },
                    { width: 25 },
                    { width: 18 }
                ];
                const headerRange = XLSX.utils.decode_range(ws['!ref']);
                for (let col = headerRange.s.c; col <= headerRange.e.c; col++) {
                    const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
                    if (!ws[cellAddress]) continue;
                    ws[cellAddress].s = {
                        font: { bold: true, color: { rgb: "FFFFFF" } },
                        fill: { fgColor: { rgb: "3498DB" } },
                        alignment: { horizontal: "center", vertical: "center" },
                        border: {
                            top: { style: "thin", color: { rgb: "000000" } },
                            bottom: { style: "thin", color: { rgb: "000000" } },
                            left: { style: "thin", color: { rgb: "000000" } },
                            right: { style: "thin", color: { rgb: "000000" } }
                        }
                    };
                }
                for (let row = 1; row <= studentsData.length; row++) {
                    for (let col = 0; col < headers.length; col++) {
                        const cellAddress = XLSX.utils.encode_cell({ r: row, c: col });
                        if (!ws[cellAddress]) continue;
                        ws[cellAddress].s = {
                            border: {
                                top: { style: "thin", color: { rgb: "CCCCCC" } },
                                bottom: { style: "thin", color: { rgb: "CCCCCC" } },
                                left: { style: "thin", color: { rgb: "CCCCCC" } },
                                right: { style: "thin", color: { rgb: "CCCCCC" } }
                            },
                            alignment: col === 0 || col === 2 || col === 3 || col === 6 ? { horizontal: "center" } : { horizontal: "left" }
                        };
                    }
                }
                XLSX.utils.book_append_sheet(wb, ws, "Students");
                XLSX.writeFile(wb, `${filename}.xlsx`);
            }

            $('#export-pdf').on('click', function() {
                showExportConfirmation('pdf', (studentType, pdfType) => {
                    exportToPDF(studentType, pdfType);
                });
            });

            $('#export-excel').on('click', function() {
                showExportConfirmation('excel', (studentType) => {
                    exportToExcel(studentType);
                });
            });

            // Fetch classes
            function fetchClasses() {
                return $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 100, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        if (response.data && Array.isArray(response.data)) {
                            classOptions = response.data;
                            const classFilter = $('#class-filter');
                            classFilter.empty();
                            classFilter.append('<option value="">All Classes</option>');
                            classOptions.forEach(cls => {
                                classFilter.append(`<option value="${cls.id}">${cls.class_name}</option>`);
                            });
                            console.log('Classes loaded:', classOptions);
                        } else {
                            console.warn('No classes found:', response);
                            Swal.fire({
                                icon: 'warning',
                                title: 'Warning',
                                text: 'No active classes found.'
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Fetch classes error:', status, error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load class options.'
                        });
                    }
                });
            }

            // Fetch students
            function fetchStudents(page = 1, classId = '', search = '') {
                $('#table-loader').show();
                $('#student_list_table_body').empty();
                $('#pagination-nav').toggle(!search);

                const params = { page: page, perPage: perPage };
                if (classId) params.class = classId;
                if (search) params.search = search;

                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: params,
                    dataType: 'json',
                    success: function(response) {
                        const students = response.data || [];
                        const meta = response.meta || { page: page, totalPages: Math.ceil(response.totalItems / perPage), totalItems: response.totalItems };
                        renderStudentTable(students);
                        if (!search) {
                            renderPagination(meta);
                        } else {
                            $('#pagination-nav ul').empty();
                        }
                        // Update total students count
                        updateTotalStudents(meta.totalItems || 0);
                        $('#table-loader').hide();
                    },
                    error: function(xhr, status, error) {
                        $('#table-loader').hide();
                        updateTotalStudents(0); // Set to 0 on error
                        console.error('Fetch students error:', status, error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load student data.'
                        });
                    }
                });
            }

            // Render table
            function renderStudentTable(students) {
                const tbody = $('#student_list_table_body');
                tbody.empty();
                if (students.length === 0) {
                    tbody.append('<tr><td colspan="7" class="text-center">No students found.</td></tr>');
                    return;
                }
                students.forEach((s) => {
                    const photo = s.student_photo ? window.location.origin + '/' + s.student_photo : window.location.origin + '/app/students/assets/images/profile/user-1.jpg';
                    const row = `
                        <tr data-uid="${s.uid}">
                            <td>
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input student-check" value="${s.uid}" />
                                </div>
                            </td>
                            <td><img src="${photo}" class="staff-photo" alt="${s.full_name || 'Photo'}"></td>
                            <td>${s.full_name || '-'}</td>
                            <td>${s.class_name || '-'}</td>
                            <td>${s.mobile_number || '-'}</td>
                            <td>
                                <span class="badge ${s.status === 'active' ? 'bg-success' : s.status === 'inactive' ? 'bg-warning' : s.status === 'deleted' ? 'bg-danger' : 'bg-secondary'}">
                                    ${s.status || '-'}
                                </span>
                            </td>
                            <td>
                                <button class="approve-student btn btn-sm btn-success" data-uid="${s.uid}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-check"></i>
                                </button>
                                <button class="view-student btn btn-sm btn-info" data-uid="${s.uid}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-eye"></i>
                                </button>
                                <a href="edit-student.php?uid=${s.uid}" class="edit-student btn btn-sm btn-primary">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-edit"></i>
                                </a>
                                <button class="delete-student btn btn-sm btn-danger" data-uid="${s.uid}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-trash"></i>
                                </button>
                            </td>
                        </tr>`;
                    tbody.append(row);
                });
            }

            // Render pagination
            function renderPagination(meta) {
                const pagination = $('#pagination-nav ul');
                pagination.empty();
                const current = meta.page || 1;
                const total = meta.totalPages || 1;
                const start = Math.floor((current - 1) / pageRange) * pageRange + 1;
                const end = Math.min(start + pageRange - 1, total);
                pagination.append(`
                    <li class="page-item ${current <= 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${current - 1}">Previous</a>
                    </li>
                `);
                for (let p = start; p <= end; p++) {
                    pagination.append(`
                        <li class="page-item ${p === current ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${p}">${p}</a>
                        </li>
                    `);
                }
                pagination.append(`
                    <li class="page-item ${current >= total ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${current + 1}">Next</a>
                    </li>
                `);
            }

            // Pagination click
            $(document).on('click', '#pagination-nav a', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && page !== currentPage && !isSearching) {
                    currentPage = page;
                    const classId = $('#class-filter').val();
                    fetchStudents(page, classId);
                }
            });

            // Toggle actions
            function toggleActionButtons() {
                const checked = $('.student-check:checked').length;
                $('.action-buttons').toggle(checked > 0);
            }

            $('#student-check-all').on('change', function() {
                $('.student-check').prop('checked', this.checked);
                toggleActionButtons();
            });

            $(document).on('change', '.student-check', toggleActionButtons);

            // Search
            $('#input-search').on('input', function() {
                const search = $(this).val().trim();
                isSearching = search !== '';
                currentPage = 1;
                const classId = $('#class-filter').val();
                fetchStudents(currentPage, classId, search);
            });

            // Class filter
            $('#class-filter').on('change', function() {
                currentPage = 1;
                const classId = $(this).val();
                const search = $('#input-search').val().trim();
                isSearching = search !== '';
                fetchStudents(currentPage, classId, search);
            });

            // Delete multiple
            $('.delete-multiple').on('click', function() {
                const selected = $('.student-check:checked').map(function() {
                    return $(this).val();
                }).get();
                if (selected.length === 0) return Swal.fire({icon: 'warning', title: 'No Selection', text: 'Select at least one student.'});
                Swal.fire({
                    title: 'Are you sure?',
                    text: `Mark ${selected.length} students as deleted?`,
                    icon: 'warning',
                    showCancelButton: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        Promise.all(selected.map(uid => $.ajax({
                            url: 'api/student_master.php',
                            type: 'DELETE',
                            contentType: 'application/json',
                            data: JSON.stringify({ uid: uid })
                        }))).then(() => {
                            Swal.fire({icon: 'success', title: 'Success', text: 'Students marked as deleted.'});
                            selected.forEach(uid => {
                                $(`tr[data-uid="${uid}"] .badge`).removeClass('bg-success bg-warning').addClass('bg-danger').text('deleted');
                            });
                            $('.student-check').prop('checked', false);
                            toggleActionButtons();
                        }).catch(error => {
                            console.error('Delete multiple error:', error);
                            Swal.fire({icon: 'error', title: 'Error', text: 'Failed to mark as deleted.'});
                        }).finally(() => {
                            $(this).removeClass('btn-loading');
                        });
                    }
                });
            });

            // Approve multiple
            $('.approve-multiple').on('click', function() {
                const selected = $('.student-check:checked').map(function() {
                    return $(this).val();
                }).get();
                if (selected.length === 0) return Swal.fire({icon: 'warning', title: 'No Selection', text: 'Select at least one student.'});
                Swal.fire({
                    title: 'Are you sure?',
                    text: `Approve ${selected.length} students?`,
                    icon: 'question',
                    showCancelButton: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/student_master.php',
                            type: 'POST',
                            contentType: 'application/json',
                            data: JSON.stringify({ action: 'approve', uids: selected }),
                            success: function(response) {
                                if (response.status === 'success') {
                                    Swal.fire({icon: 'success', title: 'Success', text: 'Students approved.'});
                                    selected.forEach(uid => {
                                        $(`tr[data-uid="${uid}"] .badge`).removeClass('bg-danger bg-warning').addClass('bg-success').text('active');
                                    });
                                    $('.student-check').prop('checked', false);
                                    toggleActionButtons();
                                } else {
                                    Swal.fire({icon: 'error', title: 'Error', text: 'Failed to approve.'});
                                }
                            },
                            error: function(error) {
                                console.error('Approve multiple error:', error);
                                Swal.fire({icon: 'error', title: 'Error', text: 'Failed to approve.'});
                            },
                            complete: () => {
                                $(this).removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // View student
            $(document).on('click', '.view-student', function() {
                const uid = $(this).data('uid');
                $(this).addClass('btn-loading');
                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: { uid: uid },
                    dataType: 'json',
                    success: async function(response) {
                        if (response.status === 'success' && response.data) {
                            currentStudent = response.data[0] || {};
                            console.log('Student data for view:', currentStudent);
                            const html = populateTemplate(currentStudent);
                            $('#preview-form').html(html);
                            try {
                                await waitForImages(currentStudent, true);
                                console.log('Preview images loaded');
                                $('#viewStudentModal').modal('show');
                            } catch (error) {
                                console.error('Preview image loading error:', error);
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to load preview images.'
                                });
                            }
                        } else {
                            Swal.fire({icon: 'error', title: 'Error', text: 'No student data found.'});
                        }
                    },
                    error: function(error) {
                        console.error('View student error:', error);
                        Swal.fire({icon: 'error', title: 'Error', text: 'Failed to load student details.'});
                    },
                    complete: () => {
                        $(this).removeClass('btn-loading');
                    }
                });
            });

            // Print/Save from view
            $('#download-student-pdf').on('click', async function() {
                if (!currentStudent || !currentStudent.full_name) {
                    Swal.fire({icon: 'warning', title: 'No Data', text: 'No student data.'});
                    return;
                }
                const filename = `${currentStudent.full_name.replace(/\s+/g, '_')}_registration`;
                await generateFormPrintPopup(currentStudent, filename, true);
            });

            // Approve single
            $(document).on('click', '.approve-student', function() {
                const uid = $(this).data('uid');
                Swal.fire({
                    title: 'Approve?',
                    text: 'Approve this student?',
                    icon: 'question',
                    showCancelButton: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/student_master.php',
                            type: 'POST',
                            contentType: 'application/json',
                            data: JSON.stringify({ action: 'approve', uids: [uid] }),
                            success: function(response) {
                                if (response.status === 'success') {
                                    Swal.fire({icon: 'success', title: 'Success', text: 'Student approved.'});
                                    $(`tr[data-uid="${uid}"] .badge`).removeClass('bg-danger bg-warning').addClass('bg-success').text('active');
                                } else {
                                    Swal.fire({icon: 'error', title: 'Error', text: 'Failed to approve.'});
                                }
                            },
                            error: function(error) {
                                console.error('Approve single error:', error);
                                Swal.fire({icon: 'error', title: 'Error', text: 'Failed to approve.'});
                            },
                            complete: () => {
                                $(this).removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // Delete single
            $(document).on('click', '.delete-student', function() {
                const uid = $(this).data('uid');
                Swal.fire({
                    title: 'Delete Student',
                    text: 'Choose deletion type:',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Temporary Delete',
                    showDenyButton: true,
                    denyButtonText: 'Permanent Delete'
                }).then((result) => {
                    let deleteType;
                    if (result.isConfirmed) deleteType = 'temporary';
                    else if (result.isDenied) deleteType = 'permanent';
                    else return;
                    $(this).addClass('btn-loading');
                    $.ajax({
                        url: 'api/student_master.php',
                        type: 'DELETE',
                        contentType: 'application/json',
                        data: JSON.stringify({ uid: uid, delete_type: deleteType }),
                        success: function(response) {
                            if (response.status === 'success') {
                                Swal.fire({icon: 'success', title: deleteType === 'temporary' ? 'Marked Deleted' : 'Deleted', text: 'Success.'});
                                const row = $(`tr[data-uid="${uid}"]`);
                                if (deleteType === 'temporary') {
                                    row.find('.badge').removeClass('bg-success bg-warning').addClass('bg-danger').text('deleted');
                                } else {
                                    row.remove();
                                }
                            } else {
                                Swal.fire({icon: 'error', title: 'Error', text: 'Failed.'});
                            }
                        },
                        error: function(error) {
                            console.error('Delete single error:', error);
                            Swal.fire({icon: 'error', title: 'Error', text: 'Failed.'});
                        },
                        complete: () => {
                            $(this).removeClass('btn-loading');
                        }
                    });
                });
            });

            // Initial load
            fetchSiteSettings().then(() => {
                fetchClasses().then(() => {
                    fetchStudents(currentPage);
                });
            });
        });
    </script>
</body>
</html>