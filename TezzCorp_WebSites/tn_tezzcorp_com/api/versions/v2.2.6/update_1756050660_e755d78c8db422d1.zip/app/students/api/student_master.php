<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class StudentMasterController {
    private $pdo;
    private $logger;

    public function __construct() {
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode([
            'status' => 'error',
            'message' => $message
        ]);
        exit;
    }

    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode(array_merge([
            'status' => 'success'
        ], $data));
        exit;
    }

    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    private function logDebug(string $message): void {
        ($this->logger)('DEBUG: ' . $message);
    }

    private function generateUid(): string {
        $prefix = 'STU';
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomPartLength = 13;
        $maxAttempts = 10;
        $attempt = 0;

        while ($attempt < $maxAttempts) {
            $randomPart = '';
            for ($i = 0; $i < $randomPartLength; $i++) {
                $randomPart .= $characters[rand(0, strlen($characters) - 1)];
            }
            $uid = $prefix . $randomPart;

            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE uid = ?");
            $stmt->execute([$uid]);
            if (!$stmt->fetch()) {
                return $uid;
            }
            $attempt++;
        }

        throw new Exception('Failed to generate a unique UID after ' . $maxAttempts . ' attempts');
    }

    private function validateInput(array $data, bool $isUpdate = false): array {
        $errors = [];
        $studentData = [];
        $documents = [];

        $studentFields = [
            'aadhaar_number' => ['required' => false, 'type' => 'string', 'pattern' => '/^\d{12}$/', 'error' => 'aadhaar_number must be a 12-digit number'],
            'full_name' => ['required' => true, 'type' => 'string'],
            'date_of_birth' => ['required' => true, 'type' => 'date'],
            'gender' => ['required' => true, 'type' => 'enum', 'values' => ['Male', 'Female', 'Other']],
            'mobile_number' => ['required' => true, 'type' => 'string', 'pattern' => '/^\d{10}$/', 'error' => 'mobile_number must be a 10-digit number'],
            'age_year' => ['required' => false, 'type' => 'integer'],
            'age_months' => ['required' => false, 'type' => 'integer'],
            'age_days' => ['required' => false, 'type' => 'integer'],
            'nationality' => ['required' => false, 'type' => 'string'],
            'category' => ['required' => false, 'type' => 'enum', 'values' => ['General', 'OBC', 'EBC', 'SC', 'ST']],
            'languages' => ['required' => false, 'type' => 'string'],
            'id_card' => ['required' => false, 'type' => 'string'],
            'father_name' => ['required' => false, 'type' => 'string'],
            'mother_name' => ['required' => false, 'type' => 'string'],
            'father_dob' => ['required' => false, 'type' => 'date'],
            'father_nationality' => ['required' => false, 'type' => 'string'],
            'father_qualification' => ['required' => false, 'type' => 'string'],
            'father_occupation' => ['required' => false, 'type' => 'string'],
            'father_designation' => ['required' => false, 'type' => 'string'],
            'father_organization' => ['required' => false, 'type' => 'string'],
            'father_office_address' => ['required' => false, 'type' => 'string'],
            'father_mobile' => ['required' => false, 'type' => 'string', 'pattern' => '/^\d{10}$/', 'error' => 'father_mobile must be a 10-digit number'],
            'mother_dob' => ['required' => false, 'type' => 'date'],
            'mother_nationality' => ['required' => false, 'type' => 'string'],
            'mother_qualification' => ['required' => false, 'type' => 'string'],
            'mother_occupation' => ['required' => false, 'type' => 'string'],
            'mother_designation' => ['required' => false, 'type' => 'string'],
            'mother_organization' => ['required' => false, 'type' => 'string'],
            'mother_office_address' => ['required' => false, 'type' => 'string'],
            'mother_mobile' => ['required' => false, 'type' => 'string', 'pattern' => '/^\d{10}$/', 'error' => 'mother_mobile must be a 10-digit number'],
            'last_exam_passed' => ['required' => false, 'type' => 'string'],
            'stream' => ['required' => false, 'type' => 'string'],
            'trade_sector' => ['required' => false, 'type' => 'string'],
            'applying_class' => ['required' => false, 'type' => 'string'],
            'class' => ['required' => false, 'type' => 'integer'],
            'medium' => ['required' => false, 'type' => 'enum', 'values' => ['English', 'Hindi', 'Regional']],
            'contribution' => ['required' => false, 'type' => 'string'],
            'elaborate_choices' => ['required' => false, 'type' => 'string'],
            'rte' => ['required' => false, 'type' => 'string'],
            'email_address' => ['required' => false, 'type' => 'email'],
            'additional_email' => ['required' => false, 'type' => 'email'],
            'residential_address' => ['required' => false, 'type' => 'string'],
            'permanent_address' => ['required' => false, 'type' => 'string'],
            'bank_account_number' => ['required' => false, 'type' => 'string'],
            'ifsc_code' => ['required' => false, 'type' => 'string'],
            'registration_no' => ['required' => false, 'type' => 'string'],
            'session' => ['required' => false, 'type' => 'string'],
            'roll_no' => ['required' => false, 'type' => 'string'],
            'current_school' => ['required' => false, 'type' => 'string'],
            'additional_transport' => ['required' => false, 'type' => 'string'],
            'transport' => ['required' => false, 'type' => 'integer']
        ];

        foreach ($studentFields as $field => $rules) {
            if (isset($data[$field]) && !empty(trim($data[$field]))) {
                $value = trim($data[$field]);
                switch ($rules['type']) {
                    case 'string':
                        $studentData[$field] = $value;
                        break;
                    case 'integer':
                        if (filter_var($value, FILTER_VALIDATE_INT) === false) {
                            $errors[] = "$field must be an integer";
                        } else {
                            $studentData[$field] = (int)$value;
                        }
                        break;
                    case 'date':
                        $date = DateTime::createFromFormat('Y-m-d', $value);
                        if (!$date || $date->format('Y-m-d') !== $value) {
                            $errors[] = "$field must be a valid date (YYYY-MM-DD)";
                        } else {
                            $studentData[$field] = $value;
                        }
                        break;
                    case 'email':
                        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                            $errors[] = "$field must be a valid email address";
                        } else {
                            $studentData[$field] = $value;
                        }
                        break;
                    case 'enum':
                        if (!in_array($value, $rules['values'], true)) {
                            $errors[] = "$field must be one of: " . implode(', ', $rules['values']);
                        } else {
                            $studentData[$field] = $value;
                        }
                        break;
                }
                if (isset($rules['pattern']) && !preg_match($rules['pattern'], $value)) {
                    $errors[] = $rules['error'];
                }
            } elseif ($rules['required'] && !$isUpdate) {
                $errors[] = "$field is required";
            }
        }

        if (isset($studentData['aadhaar_number']) && isset($data['uid'])) {
            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE aadhaar_number = ? AND uid != ?");
            $stmt->execute([$studentData['aadhaar_number'], $data['uid']]);
            if ($stmt->fetch()) {
                $errors[] = "A student with aadhaar_number " . $studentData['aadhaar_number'] . " already exists";
            }
        } elseif (isset($studentData['aadhaar_number'])) {
            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE aadhaar_number = ?");
            $stmt->execute([$studentData['aadhaar_number']]);
            if ($stmt->fetch()) {
                $errors[] = "A student with aadhaar_number " . $studentData['aadhaar_number'] . " already exists";
            }
        }

        $documentFields = [
            'aadhaar_card_upload', 'progress_report', 'birth_certificate', 'slc',
            'residential_proof', 'father_photo', 'student_photo', 'mother_photo'
        ];

        foreach ($documentFields as $field) {
            if (isset($data[$field]) && !empty($data[$field]) && $data[$field] !== '(binary)') {
                $documents[$field] = $data[$field];
            }
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return ['studentData' => $studentData, 'documents' => $documents];
    }

    public function get() {
        $uid = isset($_GET['uid']) ? trim($_GET['uid']) : null;
        $class = isset($_GET['class']) ? filter_var($_GET['class'], FILTER_VALIDATE_INT) : null;
        $search = isset($_GET['search']) ? trim($_GET['search']) : '';
        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $perPage = isset($_GET['perPage']) ? max(1, (int)$_GET['perPage']) : 10;

        try {
            if ($uid) {
                $stmt = $this->pdo->prepare("
                    SELECT s.*, 
                        c.class_name,
                        d.aadhaar_card_upload, 
                        d.progress_report, 
                        d.birth_certificate, 
                        d.slc, 
                        d.residential_proof, 
                        d.father_photo, 
                        d.student_photo, 
                        d.mother_photo
                    FROM students s
                    LEFT JOIN class c ON s.class = c.id
                    LEFT JOIN documents d ON s.uid = d.uid
                    WHERE s.uid = ?
                ");
                $stmt->execute([$uid]);
                $student = $stmt->fetch();

                if (!$student) {
                    $this->sendError(404, 'Student not found');
                }

                $this->sendSuccess(200, ['data' => [$student]]);
            } else {
                $params = [];
                $countParams = [];
                $query = "
                    SELECT s.*, 
                        c.class_name,
                        d.aadhaar_card_upload, 
                        d.progress_report, 
                        d.birth_certificate, 
                        d.slc, 
                        d.residential_proof, 
                        d.father_photo, 
                        d.student_photo, 
                        d.mother_photo
                    FROM students s
                    LEFT JOIN class c ON s.class = c.id
                    LEFT JOIN documents d ON s.uid = d.uid
                ";
                $countQuery = "SELECT COUNT(*) FROM students s";
                $whereClauses = [];

                if ($class !== null) {
                    if ($class === false || $class <= 0) {
                        $this->sendError(400, 'Invalid class');
                    }
                    $whereClauses[] = "s.class = ?";
                    $params[] = $class;
                    $countParams[] = $class;
                }

                if ($search) {
                    $searchTerm = "%$search%";
                    $whereClauses[] = "(s.full_name LIKE ? OR s.mobile_number LIKE ? OR s.father_name LIKE ? OR s.mother_name LIKE ?)";
                    $params[] = $searchTerm;
                    $params[] = $searchTerm;
                    $params[] = $searchTerm;
                    $params[] = $searchTerm;
                    $countParams[] = $searchTerm;
                    $countParams[] = $searchTerm;
                    $countParams[] = $searchTerm;
                    $countParams[] = $searchTerm;
                }

                if (!empty($whereClauses)) {
                    $query .= " WHERE " . implode(' AND ', $whereClauses);
                    $countQuery .= " WHERE " . implode(' AND ', $whereClauses);
                }

                // Apply pagination only if no search term is provided
                if (!$search) {
                    $offset = ($page - 1) * $perPage;
                    $query .= " ORDER BY s.created_at DESC LIMIT ? OFFSET ?";
                    $params[] = $perPage;
                    $params[] = $offset;
                } else {
                    $query .= " ORDER BY s.created_at DESC";
                }

                $countStmt = $this->pdo->prepare($countQuery);
                $countStmt->execute($countParams);
                $totalItems = (int)$countStmt->fetchColumn();
                $totalPages = $search ? 1 : max(1, ceil($totalItems / $perPage));

                $stmt = $this->pdo->prepare($query);
                $stmt->execute($params);
                $students = $stmt->fetchAll();

                $this->sendSuccess(200, [
                    'data' => $students,
                    'meta' => [
                        'page' => $page,
                        'totalPages' => $totalPages,
                        'totalItems' => $totalItems
                    ]
                ]);
            }
        } catch (Exception $e) {
            $this->logError('Failed to fetch students: ' . $e->getMessage());
            $this->sendError(500, 'Failed to fetch students: ' . $e->getMessage());
        }
    }

    public function post($data) {
        if (isset($data['action']) && $data['action'] === 'approve' && isset($data['uids'])) {
            $this->approve($data['uids']);
        }

        $validated = $this->validateInput($data);
        $studentData = $validated['studentData'];
        $documents = $validated['documents'];

        try {
            $this->pdo->beginTransaction();
            $uid = $this->generateUid();
            $this->logDebug('Generated UID: ' . $uid);
            $studentData['status'] = 'inactive';
            $this->logDebug('Inserting into students table with data: ' . json_encode($studentData));
            $studentFields = array_keys($studentData);
            $studentFields[] = 'uid';
            $placeholders = array_fill(0, count($studentFields), '?');
            $sql = "INSERT INTO students (" . implode(',', $studentFields) . ", created_at) VALUES (" . implode(',', $placeholders) . ", NOW())";
            $this->logDebug('Executing SQL: ' . $sql . ' with values: ' . json_encode(array_merge(array_values($studentData), [$uid])));
            $stmt = $this->pdo->prepare($sql);
            $values = array_values($studentData);
            $values[] = $uid;
            $stmt->execute($values);

            if ($stmt->rowCount() === 0) {
                throw new Exception('No rows inserted into students table');
            }

            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE uid = ?");
            $stmt->execute([$uid]);
            $record = $stmt->fetch();
            if (!$record) {
                throw new Exception('Failed to find student record with UID: ' . $uid);
            }
            $this->logDebug('Found student with UID: ' . $uid);

            if (!empty($documents)) {
                $this->logDebug('Inserting into documents table with data: ' . json_encode($documents));
                $documentFields = array_keys($documents);
                $documentFields[] = 'uid';
                $placeholders = array_fill(0, count($documentFields), '?');
                $sql = "INSERT INTO documents (" . implode(',', $documentFields) . ") VALUES (" . implode(',', $placeholders) . ")";
                $this->logDebug('Executing SQL: ' . $sql . ' with values: ' . json_encode(array_merge(array_values($documents), [$uid])));
                $stmt = $this->pdo->prepare($sql);
                $values = array_values($documents);
                $values[] = $uid;
                $stmt->execute($values);
            }

            $this->pdo->commit();
            $this->logDebug('Student and documents inserted successfully for UID: ' . $uid);
            $this->sendSuccess(201, ['message' => 'Student registered successfully', 'uid' => $uid]);
        } catch (Exception $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to register student: ' . $e->getMessage());
            $this->sendError(500, 'Failed to register student: ' . $e->getMessage());
        }
    }

    public function put() {
        $data = json_decode(file_get_contents('php://input'), true);
        $uid = isset($data['uid']) ? trim($data['uid']) : null;

        if (!$uid) {
            $this->sendError(400, 'UID is required');
        }

        $validated = $this->validateInput($data, true);
        $studentData = $validated['studentData'];
        $documents = $validated['documents'];

        try {
            $this->pdo->beginTransaction();
            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE uid = ?");
            $stmt->execute([$uid]);
            if (!$stmt->fetch()) {
                $this->sendError(404, 'Student not found');
            }

            if (!empty($studentData)) {
                $fields = array_keys($studentData);
                $setClause = implode(', ', array_map(fn($field) => "$field = ?", $fields));
                $sql = "UPDATE students SET $setClause WHERE uid = ?";
                $stmt = $this->pdo->prepare($sql);
                $values = array_values($studentData);
                $values[] = $uid;
                $stmt->execute($values);

                if ($stmt->rowCount() === 0 && count($studentData) > 0) {
                    $this->logDebug('No changes made to students table for UID: ' . $uid);
                }
            }

            if (!empty($documents)) {
                $stmt = $this->pdo->prepare("SELECT uid FROM documents WHERE uid = ?");
                $stmt->execute([$uid]);
                if ($stmt->fetch()) {
                    $fields = array_keys($documents);
                    $setClause = implode(', ', array_map(fn($field) => "$field = ?", $fields));
                    $sql = "UPDATE documents SET $setClause WHERE uid = ?";
                    $stmt = $this->pdo->prepare($sql);
                    $values = array_values($documents);
                    $values[] = $uid;
                    $stmt->execute($values);
                } else {
                    $documentFields = array_keys($documents);
                    $documentFields[] = 'uid';
                    $placeholders = array_fill(0, count($documentFields), '?');
                    $sql = "INSERT INTO documents (" . implode(',', $documentFields) . ") VALUES (" . implode(',', $placeholders) . ")";
                    $stmt = $this->pdo->prepare($sql);
                    $values = array_values($documents);
                    $values[] = $uid;
                    $stmt->execute($values);
                }
            }

            $this->pdo->commit();
            $this->logDebug('Student updated successfully for UID: ' . $uid);
            $this->sendSuccess(200, ['message' => 'Student updated successfully']);
        } catch (Exception $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to update student: ' . $e->getMessage());
            $this->sendError(500, 'Failed to update student: ' . $e->getMessage());
        }
    }

    public function delete() {
        $input = json_decode(file_get_contents('php://input'), true);
        $uid = isset($input['uid']) ? trim($input['uid']) : null;
        $deleteType = isset($input['delete_type']) ? trim($input['delete_type']) : 'temporary';

        if (!$uid) {
            $this->sendError(400, 'UID is required');
        }

        if (!in_array($deleteType, ['temporary', 'permanent'])) {
            $this->sendError(400, 'Invalid delete_type. Must be "temporary" or "permanent"');
        }

        try {
            $this->pdo->beginTransaction();
            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE uid = ?");
            $stmt->execute([$uid]);
            if (!$stmt->fetch()) {
                $this->sendError(404, 'Student not found');
            }

            if ($deleteType === 'temporary') {
                $stmt = $this->pdo->prepare("UPDATE students SET status = 'deleted' WHERE uid = ?");
                $stmt->execute([$uid]);
                $message = 'Student marked as deleted successfully';
            } else {
                $stmt = $this->pdo->prepare("DELETE FROM documents WHERE uid = ?");
                $stmt->execute([$uid]);
                $stmt = $this->pdo->prepare("DELETE FROM students WHERE uid = ?");
                $stmt->execute([$uid]);
                $message = 'Student permanently deleted successfully';
            }

            if ($stmt->rowCount() === 0) {
                throw new Exception('Failed to ' . ($deleteType === 'temporary' ? 'mark student as deleted' : 'permanently delete student'));
            }

            $this->pdo->commit();
            $this->logDebug(($deleteType === 'temporary' ? 'Student marked as deleted' : 'Student permanently deleted') . ' successfully for UID: ' . $uid);
            $this->sendSuccess(200, ['message' => $message]);
        } catch (Exception $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to ' . ($deleteType === 'temporary' ? 'mark student as deleted' : 'permanently delete student') . ': ' . $e->getMessage());
            $this->sendError(500, 'Failed to ' . ($deleteType === 'temporary' ? 'mark student as deleted' : 'permanently delete student') . ': ' . $e->getMessage());
        }
    }

    private function approve(array $uids) {
        if (empty($uids)) {
            $this->sendError(400, 'No UIDs provided for approval');
        }

        try {
            $this->pdo->beginTransaction();
            $placeholders = array_fill(0, count($uids), '?');
            $sql = "SELECT uid FROM students WHERE uid IN (" . implode(',', $placeholders) . ")";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($uids);
            $existingUids = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);

            if (count($existingUids) !== count($uids)) {
                $missingUids = array_diff($uids, $existingUids);
                $this->sendError(404, 'Students not found: ' . implode(', ', $missingUids));
            }

            $sql = "UPDATE students SET status = 'active' WHERE uid IN (" . implode(',', $placeholders) . ")";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($uids);

            if ($stmt->rowCount() === 0) {
                throw new Exception('No students were updated during approval');
            }

            $this->pdo->commit();
            $this->logDebug('Students approved successfully: ' . implode(', ', $uids));
            $this->sendSuccess(200, ['message' => 'Students approved successfully']);
        } catch (Exception $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to approve students: ' . $e->getMessage());
            $this->sendError(500, 'Failed to approve students: ' . $e->getMessage());
        }
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];

        switch ($method) {
            case 'GET':
                $this->get();
                break;

            case 'POST':
                $data = $_POST ?: json_decode(file_get_contents('php://input'), true) ?: [];
                $this->post($data);
                break;

            case 'PUT':
                $this->put();
                break;

            case 'DELETE':
                $this->delete();
                break;

            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

$controller = new StudentMasterController();
$controller->handleRequest();
?>