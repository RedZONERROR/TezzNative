<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Added export libraries for PDF and Excel -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.31/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

    <title>Student Admission - AI-ERP 2.0</title>
    <style>
        .staff-photo {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 50%;
        }
        .action-buttons {
            display: none;
        }
        .btn-loading .fa-spinner {
            display: inline-block;
        }
        .btn-loading .btn-text, .btn-loading .ti {
            display: none;
        }
        .fa-spinner {
            display: none;
            font-size: 0.9rem;
        }
        .pagination {
            margin-top: 1rem;
        }
        .export-buttons {
            display: flex;
            gap: 0.5rem;
        }
        .export-btn {
            padding: 0.375rem 0.75rem;
            font-size: 0.875rem;
            border-radius: 0.375rem;
            border: 1px solid transparent;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
        }
        .export-btn-pdf {
            background-color: #dc3545;
            color: white;
            border-color: #dc3545;
        }
        .export-btn-pdf:hover {
            background-color: #c82333;
            border-color: #bd2130;
            color: white;
        }
        .export-btn-excel {
            background-color: #198754;
            color: white;
            border-color: #198754;
        }
        .export-btn-excel:hover {
            background-color: #157347;
            border-color: #146c43;
            color: white;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Manage Students</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Students
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Student Management -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-3 col-xl-2">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Students..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-3 col-xl-2">
                                    <select class="form-select" id="class-filter">
                                        <option value="">All Classes</option>
                                        <!-- Classes will be populated dynamically -->
                                    </select>
                                </div>
                                <div class="col-md-6 col-xl-8 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div class="action-buttons me-2">
                                        <button class="delete-multiple btn bg-danger-subtle text-danger me-1">
                                            <i class="fas fa-spinner fa-spin"></i>
                                            <span class="btn-text">Delete</span>
                                        </button>
                                        <button class="approve-multiple btn bg-success-subtle text-success">
                                            <i class="fas fa-spinner fa-spin"></i>
                                            <span class="btn-text">Approve</span>
                                        </button>
                                    </div>
                                    <div class="export-buttons me-2">
                                        <button class="export-btn export-btn-pdf" id="export-pdf">
                                            <i class="fas fa-file-pdf"></i>
                                            Export PDF
                                        </button>
                                        <button class="export-btn export-btn-excel" id="export-excel">
                                            <i class="fas fa-file-excel"></i>
                                            Export Excel
                                        </button>
                                    </div>
                                    <a href="admission.php" id="btn-add-student"
                                        class="btn btn-primary d-flex align-items-center">
                                        <i class="ti ti-user-plus text-white me-1 fs-5"></i> Add Student
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="card card-body">
                            <div class="d-flex justify-content-center">
                                <div class="spinner-border text-primary" role="status" id="table-loader">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <th>
                                            <div class="n-chk align-self-center text-center">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input primary" id="student-check-all" />
                                                    <label class="form-check-label" for="student-check-all"></label>
                                                    <span class="new-control-indicator"></span>
                                                </div>
                                            </div>
                                        </th>
                                        <th>Photo</th>
                                        <th>Name</th>
                                        <th>Class</th>
                                        <th>Mobile Number</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody id="student_list_table_body">
                                        <!-- Data will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <nav aria-label="Page navigation" id="pagination-nav">
                                <ul class="pagination justify-content-center">
                                    <!-- Pagination controls -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- View Modal -->
    <div class="modal fade" id="viewStudentModal" tabindex="-1" aria-labelledby="viewStudentModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewStudentModalLabel">Student Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Name:</strong> <span id="view-name"></span></p>
                    <p><strong>Class:</strong> <span id="view-class"></span></p>
                    <p><strong>Status:</strong> <span id="view-status"></span></p>
                    <p><strong>Photo:</strong><br><img id="view-photo" class="staff-photo" alt="Student Photo"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        hljs.initHighlightingOnLoad();
        document.querySelectorAll("pre.code-view > code").forEach((codeBlock) => {
            codeBlock.textContent = codeBlock.innerHTML;
        });

        $(document).ready(function() {
            // Pagination state
            let currentPage = 1;
            const perPage = 10;
            const pageRange = 10;
            let classOptions = [];
            let isSearching = false;

            // Export confirmation dialog
            function showExportConfirmation(exportType, callback) {
                const currentClass = $('#class-filter').val();
                if (!currentClass) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Warning',
                        text: 'Please select a class first'
                    });
                    return;
                }
                Swal.fire({
                    title: 'Export Options',
                    text: 'Which students would you like to export?',
                    icon: 'question',
                    showCancelButton: true,
                    showDenyButton: true,
                    confirmButtonText: 'All Students',
                    denyButtonText: 'Transport Students',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        callback('all');
                    } else if (result.isDenied) {
                        callback('transport');
                    }
                });
            }

            // Export to PDF
            function exportToPDF(exportType) {
                const { jsPDF } = window.jspdf;
                const doc = new jsPDF('portrait');
                const currentDate = new Date().toLocaleDateString('en-GB').replace(/\//g, '-');
                const currentClass = $('#class-filter').val();
                const searchTerm = $('#input-search').val();
                let exportTitle = exportType === 'all' ? 'All Students List' : 'Transport Students List';
                let filename = exportType === 'all' ? `all-students-${currentDate}` : `transport-students-${currentDate}`;
                if (currentClass) {
                    const selectedClassName = $('#class-filter option:selected').text();
                    exportTitle = `${selectedClassName} - ${exportType === 'all' ? 'All Students' : 'Transport Students'} List`;
                    filename = `${selectedClassName.toLowerCase().replace(/\s+/g, '-')}-${exportType === 'all' ? 'all' : 'transport'}-students-${currentDate}`;
                }
                Swal.fire({
                    title: 'Exporting...',
                    text: `Fetching ${exportType === 'all' ? 'all' : 'transport'} students from selected class`,
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: { 
                        page: 1, 
                        perPage: 10000,
                        class: currentClass,
                        search: searchTerm
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.data && Array.isArray(response.data)) {
                            const filteredData = exportType === 'all' ? response.data : response.data.filter(student => student.transport === 1);
                            if (filteredData.length === 0) {
                                Swal.fire({
                                    icon: 'warning',
                                    title: 'No Data',
                                    text: `No ${exportType === 'all' ? 'students' : 'transport students'} found for the selected class.`
                                });
                                return;
                            }
                            generatePDFWithData(doc, filteredData, exportTitle, filename);
                        } else {
                            Swal.fire({
                                icon: 'warning',
                                title: 'No Data',
                                text: `No ${exportType === 'all' ? 'students' : 'transport students'} found for the selected class.`
                            });
                        }
                    },
                    error: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to fetch student data for export.'
                        });
                    }
                });
            }

            function generatePDFWithData(doc, studentsData, title, filename) {
                doc.setFontSize(16);
                doc.text(title, 14, 15);
                doc.setFontSize(10);
                doc.text(`Exported on: ${new Date().toLocaleDateString('en-GB')} ${new Date().toLocaleTimeString()}`, 14, 25);
                doc.text(`Total Students: ${studentsData.length}`, 14, 32);
                const tableData = [];
                const headers = ['Sl No.', 'Name', 'Class', 'Mobile', 'Father Name', 'Mother Name', 'D.O.B'];
                studentsData.forEach((student, index) => {
                    const rowData = [
                        (index + 1).toString(),
                        student.full_name || student.name || student.student_name || 'N/A',
                        student.class_name || 'N/A',
                        student.mobile_number || student.mobile || 'N/A',
                        student.father_name || 'N/A',
                        student.mother_name || 'N/A',
                        student.date_of_birth ? new Date(student.date_of_birth).toLocaleDateString('en-GB') : 'N/A'
                    ];
                    tableData.push(rowData);
                });
                doc.autoTable({
                    head: [headers],
                    body: tableData,
                    startY: 40,
                    styles: {
                        fontSize: 8,
                        cellPadding: 2,
                        lineColor: [200, 200, 200],
                        lineWidth: 0.1
                    },
                    headStyles: {
                        fillColor: [52, 152, 219],
                        textColor: 255,
                        fontStyle: 'bold',
                        fontSize: 9,
                        halign: 'center'
                    },
                    alternateRowStyles: {
                        fillColor: [248, 249, 250]
                    },
                    margin: { top: 30, right: 10, bottom: 20, left: 10 },
                    columnStyles: {
                        0: { cellWidth: 12, halign: 'center' },
                        1: { cellWidth: 35 },
                        2: { cellWidth: 18, halign: 'center' },
                        3: { cellWidth: 22, halign: 'center' },
                        4: { cellWidth: 40 },
                        5: { cellWidth: 40 },
                        6: { cellWidth: 20, halign: 'center' }
                    },
                    didDrawPage: function (data) {
                        const pageCount = doc.internal.getNumberOfPages();
                        const pageSize = doc.internal.pageSize;
                        const pageHeight = pageSize.height ? pageSize.height : pageSize.getHeight();
                        doc.setFontSize(8);
                        doc.text('Page ' + data.pageNumber + ' of ' + pageCount, data.settings.margin.left, pageHeight - 10);
                    }
                });
                doc.save(`${filename}.pdf`);
                Swal.fire({
                    icon: 'success',
                    title: 'PDF Exported',
                    text: `${title} has been exported to PDF successfully!`,
                    timer: 2000,
                    showConfirmButton: false
                });
            }

            // Export to Excel
            function exportToExcel(exportType) {
                const currentClass = $('#class-filter').val();
                const searchTerm = $('#input-search').val();
                let exportTitle = exportType === 'all' ? 'All Students List' : 'Transport Students List';
                let filename = exportType === 'all' ? `all-students-${new Date().toLocaleDateString('en-GB').replace(/\//g, '-')}` : `transport-students-${new Date().toLocaleDateString('en-GB').replace(/\//g, '-')}`;
                if (currentClass) {
                    const selectedClassName = $('#class-filter option:selected').text();
                    exportTitle = `${selectedClassName} - ${exportType === 'all' ? 'All Students' : 'Transport Students'} List`;
                    filename = `${selectedClassName.toLowerCase().replace(/\s+/g, '-')}-${exportType === 'all' ? 'all' : 'transport'}-students-${new Date().toLocaleDateString('en-GB').replace(/\//g, '-')}`;
                }
                Swal.fire({
                    title: 'Exporting...',
                    text: `Fetching ${exportType === 'all' ? 'all' : 'transport'} students from selected class`,
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: { 
                        page: 1, 
                        perPage: 10000,
                        class: currentClass,
                        search: searchTerm
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.data && Array.isArray(response.data)) {
                            const filteredData = exportType === 'all' ? response.data : response.data.filter(student => student.transport === 1);
                            if (filteredData.length === 0) {
                                Swal.fire({
                                    icon: 'warning',
                                    title: 'No Data',
                                    text: `No ${exportType === 'all' ? 'students' : 'transport students'} found for the selected class.`
                                });
                                return;
                            }
                            generateExcelWithData(filteredData, exportTitle, filename);
                        } else {
                            Swal.fire({
                                icon: 'warning',
                                title: 'No Data',
                                text: `No ${exportType === 'all' ? 'students' : 'transport students'} found for the selected class.`
                            });
                        }
                    },
                    error: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to fetch student data for export.'
                        });
                    }
                });
            }

            function generateExcelWithData(studentsData, title, filename) {
                const excelData = [];
                const headers = ['Sl No.', 'Name', 'Class', 'Mobile Number', 'Father Name', 'Mother Name', 'Date of Birth'];
                excelData.push(headers);
                studentsData.forEach((student, index) => {
                    const rowData = [
                        index + 1,
                        student.full_name || student.name || student.student_name || 'N/A',
                        student.class_name || 'N/A',
                        student.mobile_number || student.mobile || 'N/A',
                        student.father_name || 'N/A',
                        student.mother_name || 'N/A',
                        student.date_of_birth ? new Date(student.date_of_birth).toLocaleDateString('en-GB') : 'N/A'
                    ];
                    excelData.push(rowData);
                });
                const wb = XLSX.utils.book_new();
                const ws = XLSX.utils.aoa_to_sheet(excelData);
                ws['!cols'] = [
                    { width: 8 },
                    { width: 25 },
                    { width: 12 },
                    { width: 15 },
                    { width: 25 },
                    { width: 25 },
                    { width: 18 }
                ];
                const headerRange = XLSX.utils.decode_range(ws['!ref']);
                for (let col = headerRange.s.c; col <= headerRange.e.c; col++) {
                    const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
                    if (!ws[cellAddress]) continue;
                    ws[cellAddress].s = {
                        font: { bold: true, color: { rgb: "FFFFFF" } },
                        fill: { fgColor: { rgb: "3498DB" } },
                        alignment: { horizontal: "center", vertical: "center" },
                        border: {
                            top: { style: "thin", color: { rgb: "000000" } },
                            bottom: { style: "thin", color: { rgb: "000000" } },
                            left: { style: "thin", color: { rgb: "000000" } },
                            right: { style: "thin", color: { rgb: "000000" } }
                        }
                    };
                }
                for (let row = 1; row <= studentsData.length; row++) {
                    for (let col = 0; col < headers.length; col++) {
                        const cellAddress = XLSX.utils.encode_cell({ r: row, c: col });
                        if (!ws[cellAddress]) continue;
                        ws[cellAddress].s = {
                            border: {
                                top: { style: "thin", color: { rgb: "CCCCCC" } },
                                bottom: { style: "thin", color: { rgb: "CCCCCC" } },
                                left: { style: "thin", color: { rgb: "CCCCCC" } },
                                right: { style: "thin", color: { rgb: "CCCCCC" } }
                            },
                            alignment: col === 0 || col === 2 || col === 3 || col === 6 ? { horizontal: "center" } : { horizontal: "left" }
                        };
                    }
                }
                XLSX.utils.book_append_sheet(wb, ws, "Students");
                XLSX.writeFile(wb, `${filename}.xlsx`);
                Swal.fire({
                    icon: 'success',
                    title: 'Excel Exported',
                    text: `${title} has been exported to Excel successfully!`,
                    timer: 2000,
                    showConfirmButton: false
                });
            }

            $('#export-pdf').on('click', function() {
                showExportConfirmation('pdf', (exportType) => {
                    exportToPDF(exportType);
                });
            });

            $('#export-excel').on('click', function() {
                showExportConfirmation('excel', (exportType) => {
                    exportToExcel(exportType);
                });
            });

            // Fetch classes from class_master.php
            function fetchClasses() {
                return $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 100, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        if (response.data && Array.isArray(response.data)) {
                            classOptions = response.data;
                            const classFilter = $('#class-filter');
                            classFilter.empty();
                            classFilter.append('<option value="">All Classes</option>');
                            classOptions.forEach(cls => {
                                classFilter.append(`<option value="${cls.id}">${cls.class_name}</option>`);
                            });
                        } else {
                            console.warn('No valid classes found in response:', response);
                            classOptions = [];
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Failed to load classes:', {
                            status: status,
                            error: error,
                            response: xhr.responseJSON || xhr.responseText
                        });
                        Swal.fire({
                            icon: 'warning',
                            title: 'Warning',
                            text: 'Failed to load class options. Please try again later.'
                        });
                    }
                });
            }

            // Fetch students data with pagination and class filter
            function fetchStudents(page = 1, classId = '', search = '') {
                $('#table-loader').show();
                $('#student_list_table_body').empty();
                $('#pagination-nav').toggle(!search); // Hide pagination during search

                const params = { page: page, perPage: perPage };
                if (classId) params.class = classId;
                if (search) params.search = search;

                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: params,
                    dataType: 'json',
                    success: function(response) {
                        const students = response.data || [];
                        const meta = response.meta || { page: page, totalPages: Math.ceil(students.length / perPage), totalItems: students.length };
                        renderStudentTable(students);
                        if (!search) {
                            renderPagination(meta);
                        } else {
                            $('#pagination-nav ul').empty(); // Clear pagination for search results
                        }
                        $('#table-loader').hide();
                    },
                    error: function(xhr, status, error) {
                        $('#table-loader').hide();
                        console.error('Student AJAX Error:', xhr.responseJSON, status, error);
                        renderPagination({ page: 1, totalPages: 1, totalItems: 0 });
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load student data: ' + (xhr.responseJSON?.message || error)
                        });
                    }
                });
            }

            // Render student table
            function renderStudentTable(students) {
                const tbody = $('#student_list_table_body');
                tbody.empty();
                if (students.length === 0) {
                    tbody.append('<tr><td colspan="7" class="text-center">No students found.</td></tr>');
                    return;
                }
                students.forEach((s) => {
                    const photo = s.student_photo ? `/${s.student_photo}` : '/app/students/assets/images/profile/user-1.jpg';
                    const row = `
                        <tr data-uid="${s.uid}">
                            <td>
                                <div class="n-chk align-self-center text-center">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input student-check" value="${s.uid}" />
                                        <label class="form-check-label"></label>
                                    </div>
                                </div>
                            </td>
                            <td><img src="${photo}" class="staff-photo" alt="${s.full_name || 'Photo'}"></td>
                            <td>${s.full_name || '-'}</td>
                            <td>${s.class_name || '-'}</td>
                            <td>${s.mobile_number || '-'}</td>
                            <td>
                                <span class="badge ${
                                    s.status === 'active' ? 'bg-success' :
                                    s.status === 'inactive' ? 'bg-warning' :
                                    s.status === 'deleted' ? 'bg-danger' :
                                    'bg-secondary'
                                }">
                                    ${s.status || '-'}
                                </span>
                            </td>
                            <td>
                                <button class="approve-student btn btn-sm btn-success" data-uid="${s.uid}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-check"></i>
                                </button>
                                <button class="view-student btn btn-sm btn-info" data-uid="${s.uid}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-eye"></i>
                                </button>
                                <a href="edit-student.php?uid=${s.uid}" class="edit-student btn btn-sm btn-primary">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-edit"></i>
                                </a>
                                <button class="delete-student btn btn-sm btn-danger" data-uid="${s.uid}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-trash"></i>
                                </button>
                            </td>
                        </tr>`;
                    tbody.append(row);
                });
            }

            // Render pagination with a range of 10 pages
            function renderPagination(meta) {
                const pagination = $('#pagination-nav ul');
                pagination.empty();
                const currentPage = meta.page || 1;
                const totalPages = meta.totalPages || 1;
                const pageRangeStart = Math.floor((currentPage - 1) / pageRange) * pageRange + 1;
                const pageRangeEnd = Math.min(pageRangeStart + pageRange - 1, totalPages);
                pagination.append(`
                    <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
                    </li>
                `);
                for (let p = pageRangeStart; p <= pageRangeEnd; p++) {
                    pagination.append(`
                        <li class="page-item ${p === currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${p}">${p}</a>
                        </li>
                    `);
                }
                pagination.append(`
                    <li class="page-item ${currentPage >= totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
                    </li>
                `);
            }

            // Pagination click
            $(document).on('click', '#pagination-nav a', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && page !== currentPage && !isSearching) {
                    currentPage = page;
                    const classId = $('#class-filter').val();
                    fetchStudents(page, classId);
                }
            });

            // Toggle action buttons
            function toggleActionButtons() {
                const checked = $('.student-check:checked').length;
                $('.action-buttons').toggle(checked > 0);
            }

            // Select all checkboxes
            $('#student-check-all').on('change', function() {
                $('.student-check').prop('checked', this.checked);
                toggleActionButtons();
            });

            // Individual checkbox change
            $(document).on('change', '.student-check', toggleActionButtons);

            // Search functionality
            $('#input-search').on('input', function() {
                const search = $(this).val().trim();
                isSearching = search !== '';
                const classId = $('#class-filter').val();
                currentPage = 1; // Reset to first page
                fetchStudents(currentPage, classId, search);
            });

            // Class filter change
            $('#class-filter').on('change', function() {
                currentPage = 1;
                const classId = $(this).val();
                const search = $('#input-search').val().trim();
                isSearching = search !== '';
                fetchStudents(currentPage, classId, search);
            });

            // Delete multiple
            $('.delete-multiple').on('click', function() {
                const selected = $('.student-check:checked').map(function() {
                    return $(this).val();
                }).get();
                if (selected.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Selection',
                        text: 'Please select at least one student to delete.'
                    });
                    return;
                }
                Swal.fire({
                    title: 'Are you sure?',
                    text: `Mark ${selected.length} students as deleted?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        Promise.all(selected.map(uid =>
                            $.ajax({
                                url: 'api/student_master.php',
                                type: 'DELETE',
                                contentType: 'application/json',
                                data: JSON.stringify({ uid: uid })
                            })
                        )).then(() => {
                            Swal.fire({
                                icon: 'success',
                                title: 'Marked as Deleted',
                                text: 'Students marked as deleted successfully'
                            });
                            selected.forEach(uid => {
                                const row = $(`tr[data-uid="${uid}"]`);
                                row.find('.badge').removeClass('bg-success bg-warning').addClass('bg-danger').text('deleted');
                            });
                            $('.student-check').prop('checked', false);
                            toggleActionButtons();
                        }).catch(xhr => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to mark students as deleted: ' + (xhr.responseJSON?.message || xhr.statusText)
                            });
                        }).finally(() => {
                            $('.delete-multiple').removeClass('btn-loading');
                        });
                    }
                });
            });

            // Approve multiple
            $('.approve-multiple').on('click', function() {
                const selected = $('.student-check:checked').map(function() {
                    return $(this).val();
                }).get();
                if (selected.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Selection',
                        text: 'Please select at least one student to approve.'
                    });
                    return;
                }
                Swal.fire({
                    title: 'Are you sure?',
                    text: `Approve ${selected.length} students?`,
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, approve!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/student_master.php',
                            type: 'POST',
                            contentType: 'application/json',
                            data: JSON.stringify({ action: 'approve', uids: selected }),
                            dataType: 'json',
                            success: function(response) {
                                if (response.status === 'success') {
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Approved',
                                        text: response.message || 'Students approved successfully'
                                    });
                                    selected.forEach(uid => {
                                        const row = $(`tr[data-uid="${uid}"]`);
                                        row.find('.badge').removeClass('bg-danger bg-warning').addClass('bg-success').text('active');
                                    });
                                    $('.student-check').prop('checked', false);
                                    toggleActionButtons();
                                } else {
                                    throw new Error(response.message || 'Failed to approve students');
                                }
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to approve students: ' + (xhr.responseJSON?.message || error)
                                });
                            },
                            complete: function() {
                                $('.approve-multiple').removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // View student
            $(document).on('click', '.view-student', function() {
                const uid = $(this).data('uid');
                $(this).addClass('btn-loading');
                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: { uid: uid },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status !== 'success' || !response.data) {
                            throw new Error(response.message || 'No student data found');
                        }
                        const student = response.data[0] || {};
                        $('#view-name').text(student.full_name || '-');
                        $('#view-class').text(student.class_name || '-');
                        $('#view-status').text(student.status || '-');
                        $('#view-photo').attr('src', student.student_photo ? `/${student.student_photo}` : '/app/students/assets/images/profile/user-1.jpg');
                        $('#viewStudentModal').modal('show');
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load student details: ' + (xhr.responseJSON?.message || error)
                        });
                    },
                    complete: function() {
                        $('.view-student[data-uid="' + uid + '"]').removeClass('btn-loading');
                    }
                });
            });

            // Approve single student
            $(document).on('click', '.approve-student', function() {
                const uid = $(this).data('uid');
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'Approve this student?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, approve!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/student_master.php',
                            type: 'POST',
                            contentType: 'application/json',
                            data: JSON.stringify({ action: 'approve', uids: [uid] }),
                            dataType: 'json',
                            success: function(response) {
                                if (response.status === 'success') {
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Approved',
                                        text: response.message || 'Student approved successfully'
                                    });
                                    const row = $(`tr[data-uid="${uid}"]`);
                                    row.find('.badge').removeClass('bg-danger bg-warning').addClass('bg-success').text('active');
                                } else {
                                    throw new Error(response.message || 'Failed to approve student');
                                }
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to approve student: ' + (xhr.responseJSON?.message || error)
                                });
                            },
                            complete: function() {
                                $('.approve-student[data-uid="' + uid + '"]').removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // Delete single student
            $(document).on('click', '.delete-student', function() {
                const uid = $(this).data('uid');
                Swal.fire({
                    title: 'Delete Student',
                    text: 'Choose deletion type for this student:',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Temporary Delete',
                    cancelButtonText: 'Cancel',
                    showDenyButton: true,
                    denyButtonText: 'Permanent Delete'
                }).then((result) => {
                    if (result.isConfirmed || result.isDenied) {
                        const deleteType = result.isConfirmed ? 'temporary' : 'permanent';
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/student_master.php',
                            type: 'DELETE',
                            contentType: 'application/json',
                            data: JSON.stringify({ uid: uid, delete_type: deleteType }),
                            dataType: 'json',
                            success: function(response) {
                                if (response.status === 'success') {
                                    Swal.fire({
                                        icon: 'success',
                                        title: deleteType === 'temporary' ? 'Marked as Deleted' : 'Permanently Deleted',
                                        text: response.message || `Student ${deleteType === 'temporary' ? 'marked as deleted' : 'permanently deleted'} successfully`
                                    });
                                    const row = $(`tr[data-uid="${uid}"]`);
                                    if (deleteType === 'temporary') {
                                        row.find('.badge').removeClass('bg-success bg-warning').addClass('bg-danger').text('deleted');
                                    } else {
                                        row.remove();
                                    }
                                } else {
                                    throw new Error(response.message || `Failed to ${deleteType === 'temporary' ? 'mark student as deleted' : 'permanently delete student'}`);
                                }
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: `Failed to ${deleteType === 'temporary' ? 'mark student as deleted' : 'permanently delete student'}: ` + (xhr.responseJSON?.message || error)
                                });
                            },
                            complete: function() {
                                $('.delete-student[data-uid="' + uid + '"]').removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // Initial load: Fetch classes and then students
            fetchClasses().then(() => {
                fetchStudents(currentPage);
            });
        });
    </script>
</body>
</html>