let totalAvailableCredits = 0;
let currentFeeData = null;
let appliedCredits = 0;
let selectedStudentId = null;

$(document).ready(function() {
    // Initialize Select2
    $('#student_info').select2({
        theme: 'bootstrap-5',
        placeholder: "Select or search for a student...",
        allowClear: true,
        width: '100%',
        dropdownParent: $('#main-wrapper')
    });
    $('#student_class').select2({
        theme: 'bootstrap-5',
        placeholder: "Select a class...",
        allowClear: true,
        width: '100%',
        dropdownParent: $('#main-wrapper')
    });
    $('#payment_month').select2({
        theme: 'bootstrap-5',
        width: '100%',
        multiple: true,
        placeholder: 'Select payment month(s)...',
        dropdownParent: $('#collectFeeModal')
    });
    $('#collections_count').select2({
        theme: 'bootstrap-5',
        width: '100%',
        dropdownParent: '#collectFeeModal'
    });
    $('#session').select2({
        theme: 'bootstrap-5',
        width: '100%',
        dropdownParent: '#collectFeeModal'
    });

    let studentTransportStatus = 0;
    let currentSession = '';
    let currentMonth = new Date().getMonth() + 1;
    let currentYear = new Date().getFullYear();
    let sessionStartYear = 0;
    let sessionMonths = [];
    const currentDate = new Date();
    
    let studentCredits = [];

    sessionStartYear = currentMonth >= 4 ? currentYear : currentYear - 1;
    currentSession = `${sessionStartYear}-${sessionStartYear + 1}`;

    sessionMonths = [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3];
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    const today = currentDate.toISOString().split('T')[0];
    $('#payment_date').val(today);
    $('#start_date').val(today);
    $('#end_date').val(today);

    $('.table-loader').hide();

    function loadClasses() {
        $('#student_class').parent().addClass('select-loading');
        $.ajax({
            url: 'api/class_master.php',
            method: 'GET',
            data: { perPage: 100, status: 'active' },
            dataType: 'json',
            success: function(response) {
                if (Array.isArray(response.data)) {
                    $('#student_class').empty().append('<option value="">Select Class</option>');
                    response.data.forEach(function(item) {
                        $('#student_class').append(`<option value="${item.id}">${item.class_name}</option>`);
                    });
                } else {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Warning',
                        text: response.message || 'No classes found.'
                    });
                    $('#student_class').empty().append('<option value="">No classes available</option>');
                }
            },
            error: function(xhr) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: xhr.responseJSON?.message || 'Failed to load classes.'
                });
                $('#student_class').empty().append('<option value="">No classes available</option>');
            },
            complete: function() {
                $('#student_class').parent().removeClass('select-loading');
            }
        });
    }

    loadClasses();

    $('#student_class').on('change', function() {
        var selectedClass = $(this).val();
        $('#student_info').prop('disabled', true).val(null).trigger('change');
        $('#student_info').empty().append('<option value="">Select or search for a student...</option>');
        $('#fee_table_body').empty();
        $('#history_table_body').empty();
        initHistoryTableExport([]);
        selectedStudentId = null;
        studentTransportStatus = 0;

        if (selectedClass) {
            loadStudentsByClass(selectedClass);
        }
    });

    function loadStudentsByClass(selectedClass) {
        $('#student_info').parent().addClass('select-loading');
        $.ajax({
            url: `api/fee_collection_master.php?personal_class=${selectedClass}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success' && Array.isArray(response.data)) {
                    var studentData = response.data.map(function(student) {
                        return {
                            id: student.id,
                            text: student.full_name + ' - ' + student.father_name
                        };
                    });
                    $('#student_info').empty().select2({
                        theme: 'bootstrap-5',
                        placeholder: "Select or search for a student...",
                        allowClear: true,
                        data: studentData
                    });
                    $('#student_info').prop('disabled', studentData.length === 0);
                } else {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Students Found',
                        text: response.message || 'No students found for the selected class.'
                    });
                    $('#student_info').empty().select2({
                        theme: 'bootstrap-5',
                        data: [],
                        placeholder: "No students available"
                    });
                    $('#student_info').prop('disabled', true);
                }
            },
            error: function(xhr) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: xhr.responseJSON?.message || 'Failed to load students.'
                });
                $('#student_info').empty().select2({
                    theme: 'bootstrap-5',
                    data: [],
                    placeholder: "No students available"
                });
                $('#student_info').prop('disabled', true);
            },
            complete: function() {
                $('#student_info').parent().removeClass('select-loading');
            }
        });
    }

    $('#student_info').on('change', function() {
        selectedStudentId = $(this).val();
        if (selectedStudentId) {
            loadApplicableFees(selectedStudentId);
            loadPaymentHistory(selectedStudentId);
            loadStudentCredits(selectedStudentId);
        } else {
            $('#fee_table_body').empty();
            $('#history_table_body').empty();
            initHistoryTableExport([]);
            studentTransportStatus = 0;
            $('#credits_application_container').hide();
            totalAvailableCredits = 0;
        }
    });

    function loadApplicableFees(studentId) {
        $('.table-loader').show();
        $.ajax({
            url: `api/fee_collection_master.php?student_id=${studentId}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    studentTransportStatus = response.data.transport_status || 0;
                    renderFeeTable(response.data);
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message || 'Failed to load fees.'
                    });
                    $('#fee_table_body').empty();
                }
            },
            error: function(xhr) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: xhr.responseJSON?.message || 'Failed to load fees.'
                });
                $('#fee_table_body').empty();
            },
            complete: function() {
                $('.table-loader').hide();
            }
        });
    }

    function loadStudentCredits(studentId) {
        $.ajax({
            url: `api/fee_collection_master.php?student_credits=true&student_id=${studentId}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    studentCredits = response.data.credits || [];
                    totalAvailableCredits = response.data.total_available || 0;
                    renderCreditsTable();
                    updateCreditsDisplay();
                } else {
                    studentCredits = [];
                    totalAvailableCredits = 0;
                    $('#credits_section').hide();
                    $('#credits_application_container').hide();
                }
            },
            error: function(xhr) {
                studentCredits = [];
                totalAvailableCredits = 0;
                $('#credits_section').hide();
                $('#credits_application_container').hide();
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: xhr.responseJSON?.message || 'Failed to load student credits.'
                });
            }
        });
    }

    function updateCreditsDisplay() {
        if (totalAvailableCredits > 0) {
            $('#credits_application_container').show();
            $('#available_credits_display').text(`₹${totalAvailableCredits.toFixed(2)}`);
            $('#apply_credits').val('0');
        } else {
            $('#credits_application_container').hide();
            $('#available_credits_display').text('₹0.00');
        }
        updateAmountAfterCredits();
    }

    function renderCreditsTable() {
        const tbody = $('#credits_table_body');
        tbody.empty();
        
        if (studentCredits.length === 0 || totalAvailableCredits <= 0) {
            $('#credits_section').hide();
            return;
        }
        
        $('#credits_section').show();
        $('#total_credits_badge').text(`₹${totalAvailableCredits.toFixed(2)}`);
        
        studentCredits.forEach(credit => {
            const remaining = parseFloat(credit.remaining_amount || 0);
            if (remaining > 0) {
                tbody.append(`
                    <tr>
                        <td>${credit.source === 'excess_payment' ? 'Excess Payment' : credit.source}</td>
                        <td>₹${parseFloat(credit.credit_amount || 0).toFixed(2)}</td>
                        <td>₹${parseFloat(credit.used_amount || 0).toFixed(2)}</td>
                        <td>₹${remaining.toFixed(2)}</td>
                        <td>${new Date(credit.created_on).toLocaleDateString()}</td>
                        <td>${credit.session || 'N/A'}</td>
                    </tr>
                `);
            }
        });
    }

    function loadPaymentHistory(studentId) {
        $('.table-loader').show();
        const startDate = $('#start_date').val();
        const endDate = $('#end_date').val();
        const url = `api/fee_collection_master.php?student_id=${studentId}&history=true${startDate ? `&start_date=${startDate}` : ''}${endDate ? `&end_date=${endDate}` : ''}`;
        $.ajax({
            url: url,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    renderHistoryTable(response.data || []);
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message || 'Failed to load payment history.'
                    });
                    $('#history_table_body').empty();
                    initHistoryTableExport([]);
                }
            },
            error: function(xhr) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: xhr.responseJSON?.message || 'Failed to load payment history.'
                });
                $('#history_table_body').empty();
                initHistoryTableExport([]);
            },
            complete: function() {
                $('.table-loader').hide();
            }
        });
    }

    function initHistoryTableExport(historyData) {
        if ($('#history_table').hasClass('dataTable')) {
            $('#history_table').DataTable().destroy();
            $('#history_export_buttons').empty();
        }
    
        const dataSet = historyData.map(record => [
            `<input type="checkbox" class="history-checkbox" data-id="${record.id}" data-record='${JSON.stringify({
                ...record,
                is_pending_fee: record.is_pending_fee,
                reason: record.reason || null,
                due_session: record.due_session || null
            })}'>`,
            record.particular || 'Pending Fee', // Fallback for null particular
            `₹${parseFloat(record.amount_collected || 0).toFixed(2)}`,
            `₹${parseFloat(record.discount || 0).toFixed(2)}`,
            record.payment_month_name || '-', // Already provided in response
            record.payment_date ? new Date(record.payment_date).toLocaleDateString('en-IN') : '-',
            record.payment_method ? (record.payment_method.charAt(0).toUpperCase() + record.payment_method.slice(1)) : '-',
            record.status === 'completed' ? '<span class="badge bg-success-subtle text-success">Completed</span>' : '<span class="badge bg-danger-subtle text-danger">Failed</span>',
            record.session || 'N/A',
            record.is_pending_fee ? (record.reason || 'Pending Fee') + (record.due_session ? ` (Due: ${record.due_session})` : '') : (record.remarks || '-'),
            `
                <button class="print-receipt btn btn-sm btn-outline-info me-1" data-record='${JSON.stringify({
                    ...record,
                    is_pending_fee: record.is_pending_fee,
                    reason: record.reason || null,
                    due_session: record.due_session || null
                })}'>
                    <i class="fas fa-print"></i> Print
                </button>
                <button class="delete-payment btn btn-sm btn-outline-danger" data-id="${record.id}">
                    <i class="fas fa-trash-alt"></i> Delete
                </button>
            `
        ]);
    
        $('#history_table').DataTable({
            data: dataSet,
            columns: [
                { title: "" },
                { title: "Particular" },
                { title: "Amount Collected" },
                { title: "Discount" },
                { title: "Payment Month" },
                { title: "Payment Date" },
                { title: "Payment Method" },
                { title: "Status" },
                { title: "Session" },
                { title: "Remarks" },
                { title: "Action" }
            ],
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'print',
                    text: '<i class="fas fa-print"></i> Print All',
                    className: 'btn btn-primary btn-sm me-1',
                    exportOptions: { 
                        columns: [1, 2, 3, 4, 5, 6, 7, 8, 9],
                        format: {
                            body: function(data, row, column, node) {
                                if (column === 9) { // Remarks column
                                    const record = JSON.parse(dataSet[row][0].match(/data-record='(.*?)'/)[1]);
                                    return record.is_pending_fee ? (record.reason || 'Pending Fee') + (record.due_session ? ` (Due: ${record.due_session})` : '') : (record.remarks || '-');
                                }
                                return data;
                            }
                        }
                    }
                },
                {
                    extend: 'excelHtml5',
                    text: '<i class="fas fa-file-excel"></i> Excel',
                    className: 'btn btn-success btn-sm me-1',
                    exportOptions: { 
                        columns: [1, 2, 3, 4, 5, 6, 7, 8, 9],
                        format: {
                            body: function(data, row, column, node) {
                                if (column === 9) { // Remarks column
                                    const record = JSON.parse(dataSet[row][0].match(/data-record='(.*?)'/)[1]);
                                    return record.is_pending_fee ? (record.reason || 'Pending Fee') + (record.due_session ? ` (Due: ${record.due_session})` : '') : (record.remarks || '-');
                                }
                                return data;
                            }
                        }
                    }
                },
                {
                    extend: 'pdfHtml5',
                    text: '<i class="fas fa-file-pdf"></i> PDF',
                    className: 'btn btn-danger btn-sm',
                    exportOptions: { 
                        columns: [1, 2, 3, 4, 5, 6, 7, 8, 9],
                        format: {
                            body: function(data, row, column, node) {
                                if (column === 9) { // Remarks column
                                    const record = JSON.parse(dataSet[row][0].match(/data-record='(.*?)'/)[1]);
                                    return record.is_pending_fee ? (record.reason || 'Pending Fee') + (record.due_session ? ` (Due: ${record.due_session})` : '') : (record.remarks || '-');
                                }
                                return data;
                            }
                        }
                    }
                }
            ],
            paging: false,
            searching: false,
            ordering: false,
            info: false,
            autoWidth: false,
            destroy: true,
            initComplete: function() {
                $('#history_export_buttons').empty().append($('.dt-buttons'));
            }
        });
    
        $('.history-checkbox').on('change', function() {
            $('#print_selected').prop('disabled', $('.history-checkbox:checked').length === 0);
        });
    
        $('#select_all_history').on('change', function() {
            $('.history-checkbox').prop('checked', this.checked);
            $('#print_selected').prop('disabled', $('.history-checkbox:checked').length === 0);
        });
    }

    function renderHistoryTable(history) {
        initHistoryTableExport(history);
    }

    function escapeHtml(unsafe) {
        if (unsafe == null) return '';
        return String(unsafe)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    $(document).on('click', '.print-receipt', function() {
        const record = $(this).data('record');
        printReceipts([record]);
    });

    $(document).on('click', '#print_selected', function() {
        const selectedRecords = $('.history-checkbox:checked').map(function() {
            return $(this).data('record');
        }).get();
        if (selectedRecords.length === 0) {
            Swal.fire({
                icon: 'warning',
                title: 'No Selection',
                text: 'Please select at least one payment record to print.'
            });
            return;
        }
        printReceipts(selectedRecords);
    });

    function printReceipts(records) {
        const printWindow = window.open('', '_blank');
        let totalAmount = 0, totalDiscount = 0, totalCollected = 0, totalExtra = 0;

        records.forEach(record => {
            totalAmount += parseFloat(record.amount_collected || 0) + parseFloat(record.discount || 0);
            totalDiscount += parseFloat(record.discount || 0);
            totalCollected += parseFloat(record.amount_collected || 0);
            totalExtra += parseFloat(record.extra_amount || 0);
        });

        let receiptHtml = `
            <html>
            <head>
                <title>Payment Receipt - ${escapeHtml(records[0]?.school_name || "School")}</title>
                <style>
                    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
                    :root {
                        --primary-color: #2563eb;
                        --primary-light: #dbeafe;
                        --secondary-color: #475569;
                        --accent-color: #f59e0b;
                        --light-gray: #f8fafc;
                        --border-color: #e2e8f0;
                        --text-primary: #1e293b;
                        --text-secondary: #64748b;
                    }
                    body { 
                        font-family: 'Poppins', Arial, sans-serif;
                        margin: 0; 
                        padding: 0;
                        background-color: #f1f5f9;
                        color: var(--text-primary);
                        line-height: 1.4;
                    }
                    .receipt-container {
                        max-width: 720px;
                        margin: 20px auto;
                        padding: 25px;
                        border: 1px solid var(--border-color);
                        border-radius: 8px;
                        background-color: #fff;
                        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.05);
                        position: relative;
                    }
                    .receipt-watermark {
                        position: absolute;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%) rotate(-45deg);
                        font-size: 80px;
                        opacity: 0.03;
                        font-weight: 700;
                        white-space: nowrap;
                        pointer-events: none;
                        z-index: 0;
                    }
                    .receipt-header {
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        border-bottom: 2px solid var(--primary-color);
                        padding-bottom: 15px;
                        margin-bottom: 20px;
                        position: relative;
                        z-index: 1;
                    }
                    .school-logo img {
                        max-height: 70px;
                        max-width: 140px;
                        object-fit: contain;
                    }
                    .school-info h2 {
                        margin: 0;
                        font-size: 1.5rem;
                        color: var(--primary-color);
                        font-weight: 600;
                        letter-spacing: -0.5px;
                    }
                    .school-info p {
                        margin: 3px 0;
                        font-size: 0.85rem;
                        color: var(--text-secondary);
                    }
                    .receipt-title h3 {
                        text-align: center;
                        background-color: var(--primary-color);
                        color: white;
                        padding: 6px 25px;
                        border-radius: 25px;
                        font-size: 1.1rem;
                        font-weight: 500;
                        letter-spacing: 0.8px;
                        text-transform: uppercase;
                        box-shadow: 0 3px 5px rgba(37, 99, 235, 0.2);
                        margin: 15px 0;
                    }
                    .receipt-sections {
                        display: grid;
                        grid-template-columns: 1fr 1fr;
                        gap: 20px;
                        margin-bottom: 20px;
                        position: relative;
                        z-index: 1;
                    }
                    .receipt-section h4 {
                        font-size: 0.95rem;
                        color: var(--secondary-color);
                        margin-bottom: 12px;
                        padding-bottom: 6px;
                        border-bottom: 1px dashed var(--border-color);
                    }
                    .info-grid {
                        display: grid;
                        grid-template-columns: 1fr 1fr;
                        gap: 8px;
                    }
                    .info-item {
                        margin-bottom: 6px;
                    }
                    .info-label {
                        font-size: 0.8rem;
                        color: var(--text-secondary);
                    }
                    .info-value {
                        font-size: 0.9rem;
                        font-weight: 500;
                        color: var(--text-primary);
                    }
                    .payment-table {
                        width: 100%;
                        border-collapse: separate;
                        border-spacing: 0;
                        margin-bottom: 20px;
                        border-radius: 8px;
                        overflow: hidden;
                        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
                        font-size: 0.8rem;
                    }
                    .payment-table th, .payment-table td {
                        padding: 8px 6px;
                        text-align: left;
                        font-size: 0.8rem;
                    }
                    .payment-table th {
                        background-color: var(--primary-color);
                        color: white;
                        font-weight: 500;
                        text-transform: uppercase;
                        font-size: 0.75rem;
                        letter-spacing: 0.3px;
                    }
                    .payment-table td {
                        background-color: white;
                        border-bottom: 1px solid var(--border-color);
                        word-break: break-word;
                    }
                    .payment-table tr:last-child td {
                        border-bottom: none;
                    }
                    .amount-row td {
                        font-weight: 600;
                        color: var(--primary-color);
                    }
                    .receipt-footer {
                        margin-top: 25px;
                        padding-top: 15px;
                        border-top: 1px solid var(--border-color);
                        display: flex;
                        justify-content: space-between;
                        position: relative;
                        z-index: 1;
                    }
                    .verification-section {
                        display: flex;
                        flex-direction: column;
                        align-items: flex-start;
                    }
                    .verification-code {
                        font-family: monospace;
                        background-color: var(--light-gray);
                        padding: 4px 8px;
                        border-radius: 3px;
                        font-size: 0.8rem;
                        margin-top: 4px;
                        letter-spacing: 0.8px;
                    }
                    .thank-you h4 {
                        color: var(--primary-color);
                        font-size: 1.1rem;
                        margin-bottom: 4px;
                    }
                    .thank-you p {
                        color: var(--text-secondary);
                        font-size: 0.85rem;
                    }
                    @media print {
                        body {
                            background-color: white;
                        }
                        .receipt-container {
                            margin: 0;
                            padding: 15px;
                            border: none;
                            box-shadow: none;
                            max-width: 100%;
                            width: 95%;
                        }
                        .payment-table {
                            font-size: 0.75rem;
                        }
                        .payment-table th, .payment-table td {
                            padding: 6px 4px;
                        }
                        .payment-table th, .receipt-title h3 {
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                            background-color: var(--primary-color) !important;
                            color: white !important;
                        }
                        @page {
                            size: A4;
                            margin: 0.5in;
                        }
                    }
                    @media (max-width: 768px) {
                        .receipt-container {
                            margin: 10px;
                            padding: 15px;
                        }
                        .receipt-sections {
                            grid-template-columns: 1fr;
                            gap: 15px;
                        }
                        .payment-table {
                            font-size: 0.75rem;
                        }
                        .payment-table th, .payment-table td {
                            padding: 6px 4px;
                        }
                    }
                </style>
            </head>
            <body>
                <div class="receipt-container">
                    <div class="receipt-watermark">${escapeHtml(records[0]?.school_name || "RECEIPT")}</div>
                    <div class="receipt-header">
                        <div class="school-logo">
                            <img src="${escapeHtml(records[0]?.logo || "")}" alt="${escapeHtml(records[0]?.school_name || "School")} Logo">
                        </div>
                        <div class="school-info">
                            <h2>${escapeHtml(records[0]?.school_name || "School Name")}</h2>
                            <p>${escapeHtml(records[0]?.address || "Address not provided")}</p>
                            <p>Phone: ${escapeHtml(records[0]?.phone || "Not provided")}</p>
                        </div>
                    </div>
                    <div class="receipt-title">
                        <h3>Official Payment Receipt</h3>
                    </div>
                    <div class="receipt-sections">
                        <div class="receipt-section">
                            <h4>Student Information</h4>
                            <div class="info-grid">
                                <div class="info-item">
                                    <div class="info-label">Student Name</div>
                                    <div class="info-value">${escapeHtml(records[0]?.student_name || "N/A")}</div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Father's Name</div>
                                    <div class="info-value">${escapeHtml(records[0]?.father_name || "N/A")}</div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Class</div>
                                    <div class="info-value">${escapeHtml(records[0]?.class_name || "N/A")}</div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Session</div>
                                    <div class="info-value">${escapeHtml(records[0]?.session || "N/A")}</div>
                                </div>
                            </div>
                        </div>
                        <div class="receipt-section">
                            <h4>Payment Information</h4>
                            <div class="info-grid">
                                <div class="info-item">
                                    <div class="info-label">Receipt No.</div>
                                    <div class="info-value">${records.map((r) => "#" + escapeHtml(r.id || "N/A")).join(", ")}</div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Generated on</div>
                                    <div class="info-value">${new Date().toLocaleDateString("en-IN", {
                                      day: "numeric",
                                      month: "long",
                                      year: "numeric",
                                      hour: "2-digit",
                                      minute: "2-digit",
                                    })}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="payment-details">
                        <table class="payment-table">
                            <thead>
                                <tr>
                                    <th>Receipt No.</th>
                                    <th>Particular</th>
                                    <th>Payment Date</th>
                                    <th>Payment Month</th>
                                    <th>Amount</th>
                                    <th>Discount</th>
                                    <th>Collected</th>
                                    ${records.some(r => r.is_pending_fee) ? '<th>Reason</th><th>Due Session</th>' : ''}
                                </tr>
                            </thead>
                            <tbody>
                                ${records
                                  .map(
                                    (record) => `
                                    <tr>
                                        <td>#${escapeHtml(record.id || "N/A")}</td>
                                        <td>${escapeHtml(record.particular || "Fees")}</td>
                                        <td>${record.payment_date ? new Date(record.payment_date).toLocaleDateString("en-IN") : "-"}</td>
                                        <td>${escapeHtml(record.payment_month_name || "-")}</td>
                                        <td>₹${(parseFloat(record.amount_collected || 0) + parseFloat(record.discount || 0)).toFixed(2)}</td>
                                        <td>₹${parseFloat(record.discount || 0).toFixed(2)}</td>
                                        <td>₹${parseFloat(record.amount_collected || 0).toFixed(2)}</td>
                                        ${record.is_pending_fee ? `
                                            <td>${escapeHtml(record.reason || "-")}</td>
                                            <td>${escapeHtml(record.due_session || "-")}</td>
                                        ` : record.is_pending_fee ? '<td>-</td><td>-</td>' : ''}
                                    </tr>
                                `,
                                  )
                                  .join("")}
                                <tr class="amount-row">
                                    <td colspan="4"><strong>Total</strong></td>
                                    <td>₹${totalAmount.toFixed(2)}</td>
                                    <td>₹${totalDiscount.toFixed(2)}</td>
                                    <td>₹${totalCollected.toFixed(2)}</td>
                                    ${records.some(r => r.is_pending_fee) ? '<td></td><td></td>' : ''}
                                </tr>
                            </tbody>
                        </table>
                        ${
                          records.some((r) => r.remarks || r.reason)
                            ? `
                        <div class="receipt-section">
                            <h4>Remarks</h4>
                            ${records.map((r) => (r.remarks ? `<div class="info-value">Receipt #${escapeHtml(r.id)}: ${escapeHtml(r.remarks)}</div>` : "")).join("")}
                            ${records.map((r) => (r.reason && r.is_pending_fee ? `<div class="info-value">Receipt #${escapeHtml(r.id)} Reason: ${escapeHtml(r.reason)}</div>` : "")).join("")}
                        </div>
                        `
                            : ""
                        }
                    </div>
                    <div class="receipt-footer">
                        <div class="verification-section">
                            <div class="info-label">Verification Code</div>
                            <div class="verification-code">${records.map((r) => `${escapeHtml(r.id || "000")}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`).join(", ")}</div>
                            <div class="info-label" style="margin-top: 10px;">Generated on</div>
                            <div class="info-value">${new Date().toLocaleDateString("en-IN", {
                              day: "numeric",
                              month: "long",
                              year: "numeric",
                              hour: "2-digit",
                              minute: "2-digit",
                            })}</div>
                        </div>
                        <div class="thank-you">
                            <h4>Thank You!</h4>
                            <p>This is a computer-generated receipt.<br>No signature required.</p>
                        </div>
                    </div>
                </div>
            </body>
            </html>
        `;

        printWindow.document.write(receiptHtml);
        printWindow.document.close();
        
        printWindow.onload = function() {
            setTimeout(function() {
                printWindow.print();
            }, 500);
        };
    }

    $(document).on('click', '.delete-payment', function() {
        const paymentId = $(this).data('id');
        Swal.fire({
            title: 'Are you sure?',
            text: "You are about to delete this payment record. This action cannot be undone.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: `api/fee_collection_master.php?payment_id=${paymentId}`,
                    method: 'DELETE',
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: response.message,
                                timer: 1500,
                                showConfirmButton: false
                            }).then(() => {
                                loadApplicableFees(selectedStudentId);
                                loadPaymentHistory(selectedStudentId);
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: response.message || 'Failed to delete payment record.'
                            });
                        }
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: xhr.responseJSON?.message || 'Failed to delete payment record.'
                        });
                    }
                });
            }
        });
    });

    $('#refresh_history').on('click', function() {
        if (selectedStudentId) {
            $(this).prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Refreshing...');
            loadPaymentHistory(selectedStudentId);
            $(this).prop('disabled', false).html('<i class="fas fa-sync-alt"></i> Refresh');
        } else {
            Swal.fire({
                icon: 'warning',
                title: 'No Student Selected',
                text: 'Please select a student to refresh payment history.'
            });
        }
    });

    $('#start_date, #end_date').on('change', function() {
        if (selectedStudentId) {
            loadPaymentHistory(selectedStudentId);
        }
    });

    // Handle fee collection form submission
    $('#collectFeeForm').on('submit', function(e) {
        e.preventDefault();

        // Validate form
        if (this.checkValidity()) {
            e.stopPropagation();
            $(this).addClass('was-validated');
            Swal.fire({
                icon: 'error',
                title: 'Invalid Form',
                text: 'Please fill out all required fields correctly.'
            });
            return;
        }

        const formData = new FormData(this);
        const submitButton = $('#btn-collect');

        // Ensure critical fields are included
        if (!selectedStudentId) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'No student selected. Please select a student.'
            });
            submitButton.prop('disabled', false).html('<i class="fas fa-money-bill-wave"></i> Collect Fee');
            return;
        }

        // Explicitly append critical fields
        formData.append('student_id', selectedStudentId);
        formData.append('fee_frequency', $('#fee_frequency').val() || '');
        formData.append('apply_credits', $('#apply_credits').val() || '0');
        formData.append('fee_structure_id', $('#fee_structure_id').val() || '');
        formData.append('pending_fee_id', $('#pending_fee_id').val() || '');

        // Convert payment_month array to comma-separated string and ensure only one payment_month is sent
        formData.delete('payment_month[]'); // Remove all payment_month[] entries
        const paymentMonths = $('#payment_month').val() || [];
        if (paymentMonths.length > 0) {
            formData.append('payment_month', paymentMonths.join(',')); // Add as comma-separated string
        }

        // Log form data for debugging
        const formDataEntries = Object.fromEntries(formData);
        console.log('Form Data:', formDataEntries);

        submitButton.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Processing...');

        $.ajax({
            url: 'api/fee_collection_master.php',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                console.log('Success Response:', response);
                if (response.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: response.message || 'Fee collected successfully.',
                        showConfirmButton: false,
                        timer: 2000
                    }).then(() => {
                        // Reset form and close modal
                        $('#collectFeeForm')[0].reset();
                        $('#payment_month').val(null).trigger('change');
                        $('#collections_count').val(null).trigger('change');
                        $('#session').val(null).trigger('change');
                        $('#fee_structure_id').val('');
                        $('#pending_fee_id').val('');
                        $('#collectFeeModal').modal('hide');
                        // Refresh data
                        if (selectedStudentId) {
                            loadApplicableFees(selectedStudentId);
                            loadPaymentHistory(selectedStudentId);
                            loadStudentCredits(selectedStudentId);
                        }
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: response.message || 'Failed to collect fee.'
                    });
                }
            },
            error: function(xhr, status, error) {
                console.error('Error Response:', xhr.responseText);
                let errorMessage = 'Failed to collect fee.';
                try {
                    const response = JSON.parse(xhr.responseText);
                    errorMessage = response.message || errorMessage;
                } catch (e) {
                    errorMessage = xhr.statusText || errorMessage;
                }
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: errorMessage
                });
            },
            complete: function() {
                submitButton.prop('disabled', false).html('<i class="fas fa-money-bill-wave"></i> Collect Fee');
            }
        });
    });

    // Handle Apply Credits button
    $('#apply_credits_btn').on('click', function() {
        const creditsToApply = parseFloat($('#apply_credits').val()) || 0;
        const feeAmount = parseFloat($('#fee_amount').val()) || 0;
        const collectionsCount = parseInt($('#collections_count').val()) || 1;
        const selectedMonths = $('#payment_month').val() || [];
        const monthCount = $('#fee_frequency').val() === 'monthly' ? selectedMonths.length : collectionsCount;
        const totalFeeAmount = feeAmount * monthCount;
        const discount = parseFloat($('#discount').val()) || 0;
        const expectedAmount = totalFeeAmount - discount;

        if (creditsToApply > totalAvailableCredits) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: `Cannot apply ₹${creditsToApply.toFixed(2)}. Available credits: ₹${totalAvailableCredits.toFixed(2)}`
            });
            $('#apply_credits').val(totalAvailableCredits.toFixed(2));
            return;
        }

        if (creditsToApply > expectedAmount) {
            Swal.fire({
                icon: 'warning',
                title: 'Warning',
                text: `Applied credits (₹${creditsToApply.toFixed(2)}) exceed the expected amount (₹${expectedAmount.toFixed(2)}). Adjusting to maximum allowed.`
            });
            $('#apply_credits').val(expectedAmount.toFixed(2));
        }

        updateAmountAfterCredits();
    });

    $('#max_credits_btn').on('click', function() {
        const feeAmount = parseFloat($('#fee_amount').val()) || 0;
        const collectionsCount = parseInt($('#collections_count').val()) || 1;
        const selectedMonths = $('#payment_month').val() || [];
        const monthCount = $('#fee_frequency').val() === 'monthly' ? selectedMonths.length : collectionsCount;
        const totalFeeAmount = feeAmount * monthCount;
        const discount = parseFloat($('#discount').val()) || 0;
        const expectedAmount = totalFeeAmount - discount;
        
        const maxCreditsToUse = Math.min(totalAvailableCredits, expectedAmount);
        $('#apply_credits').val(maxCreditsToUse.toFixed(2));
        updateAmountAfterCredits();
    });

    $('#apply_credits').on('input', function() {
        updateAmountAfterCredits();
    });

    $('#payment_month').on('change', function() {
        updateAmountAfterCredits();
    });

    $('#discount').on('input', function() {
        updateAmountAfterCredits();
    });

    $('#collections_count').on('change', function() {
        updateAmountAfterCredits();
    });

    function updateAmountAfterCredits() {
        const feeAmount = parseFloat($('#fee_amount').val()) || 0;
        const collectionsCount = parseInt($('#collections_count').val()) || 1;
        const selectedMonths = $('#payment_month').val() || [];
        const monthCount = $('#fee_frequency').val() === 'monthly' ? selectedMonths.length : collectionsCount;
        const totalFeeAmount = feeAmount * monthCount;
        const discount = parseFloat($('#discount').val()) || 0;
        const creditsToApply = parseFloat($('#apply_credits').val()) || 0;
        const expectedAmount = totalFeeAmount - discount;

        const maxCreditsAllowed = Math.min(totalAvailableCredits, expectedAmount);
        if (creditsToApply > maxCreditsAllowed) {
            $('#apply_credits').val(maxCreditsAllowed.toFixed(2));
            return;
        }

        const finalAmount = Math.max(0, expectedAmount - creditsToApply);
        
        $('#amount_collected').val(finalAmount.toFixed(2));
        
        $('#amount_breakdown').show();
        $('#base_amount_display').text(`₹${totalFeeAmount.toFixed(2)}`);
        $('#discount_display').text(`-₹${discount.toFixed(2)}`);
        $('#discount_row').toggle(discount > 0);
        $('#credits_applied_display').text(`-₹${creditsToApply.toFixed(2)}`);
        $('#credits_applied_row').toggle(creditsToApply > 0);
        $('#final_amount_display').text(`₹${finalAmount.toFixed(2)}`);

        $('#available_credits_display').text(`₹${totalAvailableCredits.toFixed(2)}`);
    }

    $('#payment_method').on('change', function() {
        const method = $(this).val();
        if (method === 'cheque' || method === 'dd') {
            $('#cheque_dd_container').show();
            $('#cheque_dd_number').prop('required', true);
        } else {
            $('#cheque_dd_container').hide();
            $('#cheque_dd_number').prop('required', false);
        }
    });

    $(document).on('click', '.delete-payment', function() {
        const paymentId = $(this).data('id');
        
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this payment deletion!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                deletePayment(paymentId);
            }
        });
    });

    function deletePayment(paymentId) {
        $.ajax({
            url: `api/fee_collection_master.php?payment_id=${paymentId}`,
            method: 'DELETE',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Deleted!',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 2000
                    });
                    
                    if (selectedStudentId) {
                        loadApplicableFees(selectedStudentId);
                        loadPaymentHistory(selectedStudentId);
                    }
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message || 'Failed to delete payment.'
                    });
                }
            },
            error: function(xhr) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: xhr.responseJSON?.message || 'Failed to delete payment.'
                });
            }
        });
    }

    // collection.js (only showing updated functions for brevity)
    function renderFeeTable(data) {
        let tableBody = $('#fee_table_body');
        tableBody.empty();
        
        console.log('Fee Table Data:', data); // Debug log
        
        const currentFees = data.current_fees || [];
        const pendingFees = data.pending_fees || [];
        
        if (currentFees && currentFees.length > 0) {
            currentFees.forEach(function(fee) {
                let statusBadge = fee.is_fully_paid ? 
                    '<span class="badge bg-success">Paid</span>' : 
                    '<span class="badge bg-warning">Pending</span>';
                
                let collectButton = fee.is_fully_paid ? 
                    '<button class="btn btn-sm btn-secondary" disabled>Paid</button>' :
                    `<button class="btn btn-sm btn-primary collect-fee-btn" 
                             data-fee-id="${fee.id}" 
                             data-particular="${escapeHtml(fee.particular)}" 
                             data-amount="${fee.amount}"
                             data-frequency="${fee.frequency}"
                             data-pending-months='${JSON.stringify(fee.pending_months)}'
                             data-pending-collections="${fee.pending_collections}"
                             data-remaining-balance="${fee.remaining_balance}"
                             data-type="current">
                        <i class="fas fa-money-bill-wave"></i> Collect
                    </button>`;
                
                let row = `
                    <tr>
                        <td>${escapeHtml(fee.particular)}</td>
                        <td>₹${parseFloat(fee.amount).toFixed(2)}</td>
                        <td>${fee.frequency === 'monthly' ? 'Monthly' : 
                             fee.frequency === 'annual' ? 'Annual' : 
                             fee.frequency === 'other' ? `Every ${fee.custom_frequency} months` : fee.frequency}</td>
                        <td>${fee.pending_collections} collections (₹${parseFloat(fee.remaining_balance).toFixed(2)})</td>
                        <td>${statusBadge}</td>
                        <td>${collectButton}</td>
                    </tr>
                `;
                tableBody.append(row);
            });
        }
        
        if (pendingFees && pendingFees.length > 0) {
            pendingFees.forEach(function(fee) {
                let collectButton = `<button class="btn btn-sm btn-danger collect-fee-btn" 
                                     data-pending-id="${fee.id}" 
                                     data-particular="${escapeHtml(fee.particular || 'Pending Fee')}" 
                                     data-amount="${fee.pending_amount}"
                                     data-reason="${escapeHtml(fee.reason)}"
                                     data-due-session="${escapeHtml(fee.due_session)}"
                                     data-type="pending">
                                    <i class="fas fa-exclamation-triangle"></i> Collect
                                </button>`;
                
                let row = `
                    <tr class="pending-fee-row">
                        <td class="pending-fee-tooltip" data-tooltip="Reason: ${escapeHtml(fee.reason)}\nDue Session: ${escapeHtml(fee.due_session)}">
                            ${escapeHtml(fee.particular || 'Pending Fee')}
                        </td>
                        <td>₹${parseFloat(fee.pending_amount).toFixed(2)}</td>
                        <td>-</td>
                        <td>₹${parseFloat(fee.pending_amount).toFixed(2)}</td>
                        <td><span class="badge bg-danger">Pending</span></td>
                        <td>${collectButton}</td>
                    </tr>
                `;
                tableBody.append(row);
            });
        }
        
        if (currentFees.length === 0 && pendingFees.length === 0) {
            tableBody.append(`
                <tr>
                    <td colspan="6" class="text-center text-muted py-4">
                        <i class="fas fa-info-circle me-2"></i>No applicable fees found for this student.
                    </td>
                </tr>
            `);
        }
        
        initializeCollectButtonHandlers();
    }

    function initializeCollectButtonHandlers() {
        $('.collect-fee-btn').off('click.collectFee').on('click.collectFee', function() {
            const button = $(this);
            const feeType = button.data('type');
            
            $('#collectFeeForm')[0].reset();
            $('#payment_month').val(null).trigger('change');
            $('#collections_count').val(null).trigger('change');
            $('#session').val(null).trigger('change');
            $('#fee_structure_id').val('');
            $('#pending_fee_id').val('');
            
            if (feeType === 'pending') {
                setupPendingFeeCollection(button);
            } else {
                setupRegularFeeCollection(button);
            }
            
            $('#collectFeeModal').modal('show');
        });
    }

    function setupRegularFeeCollection(button) {
        const feeId = button.data('fee-id');
        const particular = button.data('particular');
        const amount = button.data('amount');
        const frequency = button.data('frequency');
        const pendingMonths = button.data('pending-months') || [];
        const pendingCollections = button.data('pending-collections');
        const remainingBalance = button.data('remaining-balance');
        
        $('#fee_structure_id').val(feeId);
        $('#pending_fee_id').val('');
        $('#particular').val(particular);
        $('#fee_amount').val(parseFloat(amount).toFixed(2));
        $('#fee_frequency').val(frequency);
        
        if (frequency === 'monthly') {
            $('#payment_month_container').show();
            $('#collections_count_container').hide();
            $('#annual_label').hide();
            
            let monthSelect = $('#payment_month');
            monthSelect.empty();
            
            const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                               'July', 'August', 'September', 'October', 'November', 'December'];
            
            pendingMonths.forEach(function(month) {
                monthSelect.append(`<option value="${month}">${monthNames[month - 1]}</option>`);
            });
            
            monthSelect.select2({
                placeholder: 'Select payment months',
                allowClear: true,
                dropdownParent: $('#collectFeeModal')
            });
            
            // Set default to one month
            if (pendingMonths.length > 0) {
                monthSelect.val([pendingMonths[0]]).trigger('change');
            }
        } else if (frequency === 'annual') {
            $('#payment_month_container').hide();
            $('#collections_count_container').hide();
            $('#annual_label').show();
            $('#amount_collected').val(parseFloat(amount).toFixed(2));
        } else if (frequency === 'other') {
            $('#payment_month_container').hide();
            $('#collections_count_container').show();
            $('#annual_label').hide();
            
            let collectionsSelect = $('#collections_count');
            collectionsSelect.empty();
            
            for (let i = 1; i <= pendingCollections; i++) {
                collectionsSelect.append(`<option value="${i}">${i} collection${i > 1 ? 's' : ''} (₹${(parseFloat(amount) * i).toFixed(2)})</option>`);
            }
            
            collectionsSelect.val('1').trigger('change');
        }
        
        $('#payment_date').val(new Date().toISOString().split('T')[0]);
        
        let currentMonth = new Date().getMonth() + 1;
        let currentYear = new Date().getFullYear();
        let sessionStartYear = currentMonth >= 4 ? currentYear : currentYear - 1;
        let sessionEndYear = sessionStartYear + 1;
        let currentSession = sessionStartYear + '-' + sessionEndYear;
        
        let sessionSelect = $('#session');
        sessionSelect.empty();
        sessionSelect.append(`<option value="${currentSession}" selected>${currentSession}</option>`);
        
        updateCreditsDisplay();
        updateAmountAfterCredits();
    }

    function setupPendingFeeCollection(button) {
        const pendingId = button.data('pending-id');
        const particular = button.data('particular');
        const amount = button.data('amount');
        const reason = button.data('reason');
        const dueSession = button.data('due-session');
        
        $('#fee_structure_id').val('');
        $('#pending_fee_id').val(pendingId);
        $('#particular').val(particular);
        $('#fee_amount').val(parseFloat(amount).toFixed(2));
        $('#fee_frequency').val('');
        $('#amount_collected').val(parseFloat(amount).toFixed(2));
        
        $('#pending_reason').val(reason || 'N/A');
        $('#pending_due_session').val(dueSession || 'N/A');
        $('#pending_fee_info').show();
        $('#pending_session_info').show();
        
        $('#payment_month_container').hide();
        $('#collections_count_container').hide();
        $('#annual_label').hide();
        
        $('#payment_date').val(new Date().toISOString().split('T')[0]);
        
        let currentMonth = new Date().getMonth() + 1;
        let currentYear = new Date().getFullYear();
        let sessionStartYear = currentMonth >= 4 ? currentYear : currentYear - 1;
        let sessionEndYear = sessionStartYear + 1;
        let currentSession = sessionStartYear + '-' + sessionEndYear;
        
        let sessionSelect = $('#session');
        sessionSelect.empty();
        sessionSelect.append(`<option value="${currentSession}" selected>${currentSession}</option>`);
        
        updateCreditsDisplay();
        updateAmountAfterCredits();
    }
});