<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Enable error logging for production debugging
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', $_SERVER['DOCUMENT_ROOT'] . '/logs/error.log');

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class FeeCollectionMaster {
    private $pdo;
    private $months = [
        1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June',
        7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
    ];

    public function __construct() {
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Database connection failed');
            exit();
        }
    }

    private function calculateSession($date) {
        $dateTime = DateTime::createFromFormat('Y-m-d', $date);
        if (!$dateTime) {
            error_log("Invalid date format for session calculation: $date");
            return null;
        }
        $year = (int)$dateTime->format('Y');
        $month = (int)$dateTime->format('m');
        $session = $month >= 4 ? "$year-" . ($year + 1) : ($year - 1) . "-$year";
        error_log("Calculated session for date $date: $session");
        return $session;
    }

    private function getStudentSession($student_id, $payment_date, $override_session = null) {
        if ($override_session !== null) {
            if (!preg_match('/^\d{4}-\d{4}$/', $override_session) || (int)substr($override_session, 5) !== (int)substr($override_session, 0, 4) + 1) {
                error_log("Invalid session format provided: $override_session");
                return null;
            }
            error_log("Using overridden session for student_id $student_id: $override_session");
            return $override_session;
        }

        try {
            $stmt = $this->pdo->prepare("SELECT session FROM students WHERE id = ?");
            $stmt->execute([$student_id]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($student && !empty($student['session'])) {
                error_log("Fetched session from students table for student_id $student_id: {$student['session']}");
                return $student['session'];
            }
            $session = $this->calculateSession($payment_date);
            error_log("Using calculated session for student_id $student_id based on payment_date $payment_date: $session");
            return $session;
        } catch (PDOException $e) {
            error_log("Failed to fetch student session for student_id $student_id: " . $e->getMessage());
            return $this->calculateSession($payment_date);
        }
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        switch ($method) {
            case 'GET':
                $this->handleGet();
                break;
            case 'POST':
                $this->handlePost();
                break;
            case 'DELETE':
                $this->handleDelete();
                break;
            default:
                $this->sendResponse(405, 'error', 'Method not allowed');
        }
    }

    private function handleGet() {
        if (isset($_GET['personal_class'])) {
            $class_id = filter_var($_GET['personal_class'], FILTER_VALIDATE_INT);
            if ($class_id === false || $class_id <= 0) {
                $this->sendResponse(400, 'error', 'Invalid class ID');
                return;
            }
            $this->getStudentsByClass($class_id);
            return;
        }

        if (isset($_GET['student_credits']) && $_GET['student_credits'] === 'true') {
            if (!isset($_GET['student_id'])) {
                $this->sendResponse(400, 'error', 'Student ID is required for credits');
                return;
            }
            $student_id = filter_var($_GET['student_id'], FILTER_VALIDATE_INT);
            if ($student_id === false || $student_id <= 0) {
                $this->sendResponse(400, 'error', 'Invalid student ID');
                return;
            }
            $this->getStudentCredits($student_id);
            return;
        }

        if (!isset($_GET['student_id'])) {
            $this->sendResponse(400, 'error', 'Student ID is required');
            return;
        }

        $student_id = filter_var($_GET['student_id'], FILTER_VALIDATE_INT);
        if ($student_id === false || $student_id <= 0) {
            $this->sendResponse(400, 'error', 'Invalid student ID');
            return;
        }

        $fetch_history = isset($_GET['history']) && $_GET['history'] === 'true';
        if ($fetch_history) {
            $start_date = isset($_GET['start_date']) ? filter_var($_GET['start_date'], FILTER_SANITIZE_STRING) : null;
            $end_date = isset($_GET['end_date']) ? filter_var($_GET['end_date'], FILTER_SANITIZE_STRING) : null;
            $this->getPaymentHistory($student_id, $start_date, $end_date);
        } else {
            $this->getApplicableFees($student_id);
        }
    }

    private function getStudentCredits($student_id) {
        try {
            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE id = ? AND status = 'active'");
            $stmt->execute([$student_id]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$student) {
                $this->sendResponse(404, 'error', 'Student not found or inactive');
                return;
            }
            
            $student_uid = $student['uid'];
            
            $current_session = $this->calculateSession(date('Y-m-d'));
            
            $stmt = $this->pdo->prepare("
                SELECT id, student_uid, credit_amount, source, description, session, 
                       used_amount, remaining_amount, status, created_on, updated_on
                FROM student_credits 
                WHERE student_uid = ? AND status = 'active' AND remaining_amount > 0
                ORDER BY created_on ASC
            ");
            $stmt->execute([$student_uid]);
            $credits = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $total_available = 0;
            foreach ($credits as &$credit) {
                $remaining = (float)($credit['remaining_amount'] ?? $credit['credit_amount']);
                $used = (float)($credit['used_amount'] ?? 0);
                
                if ($credit['remaining_amount'] === null) {
                    $credit['remaining_amount'] = $credit['credit_amount'] - $used;
                }
                
                $total_available += $remaining;
            }
            
            $this->sendResponse(200, 'success', 'Student credits fetched successfully', [
                'credits' => $credits,
                'total_available' => $total_available,
                'student_uid' => $student_uid,
                'current_session' => $current_session
            ]);
            
        } catch (PDOException $e) {
            error_log("Failed to fetch student credits: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch student credits');
        }
    }

    private function getApplicableFees($student_id) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT s.class, s.uid, s.transport, s.transport_id, s.full_name, s.father_name, c.class_name
                FROM students s
                JOIN class c ON s.class = c.id
                WHERE s.id = ? AND s.status = 'active'
            ");
            $stmt->execute([$student_id]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$student) {
                $this->sendResponse(404, 'error', 'Student not found or inactive');
                return;
            }

            $class_id = $student['class'];
            $student_uid = $student['uid'];
            $transport = $student['transport'] ?? 0;
            $transport_id = $student['transport_id'] ?? null;

            $current_date = date('Y-m-d');
            $current_session = $this->calculateSession($current_date);
            if (!$current_session) {
                $this->sendResponse(500, 'error', 'Unable to determine current session');
                return;
            }

            $stmt = $this->pdo->prepare("
                SELECT ss.*, p.particular, fs.frequency, fs.custom_frequency, fs.applicable_months
                FROM special_structure ss
                JOIN particulars p ON ss.particular_id = p.id
                LEFT JOIN fee_structure fs ON fs.particular_id = ss.particular_id AND fs.class_id = ?
                WHERE ss.student_uid = ? AND ss.status = 'active'
            ");
            $stmt->execute([$class_id, $student_uid]);
            $special_discounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $special_discount_map = array_column($special_discounts, null, 'particular_id');

            $stmt = $this->pdo->prepare("
                SELECT fs.id, fs.particular_id, p.particular, fs.amount, fs.applicable_months, fs.frequency, fs.custom_frequency
                FROM fee_structure fs
                JOIN particulars p ON fs.particular_id = p.id
                JOIN (
                    SELECT particular_id, MAX(id) as max_id
                    FROM fee_structure
                    WHERE class_id = ? AND status = 'active'
                    GROUP BY particular_id
                ) latest ON fs.id = latest.max_id
                WHERE fs.class_id = ? AND fs.status = 'active'
            ");
            $stmt->execute([$class_id, $class_id]);
            $fees = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($transport == 1) {
                $transport_fee = null;
                $transport_particular_id = null;
                
                if ($transport_id !== null) {
                    $stmt = $this->pdo->prepare("
                        SELECT transport_fees AS amount
                        FROM transport
                        WHERE id = ? AND status = 'active'
                    ");
                    $stmt->execute([$transport_id]);
                    $transport_fee = $stmt->fetch(PDO::FETCH_ASSOC);
                }
                
                if (!$transport_fee) {
                    $stmt = $this->pdo->prepare("
                        SELECT id AS particular_id, amount
                        FROM particulars
                        WHERE particular = 'Transport Fee' AND status = 'active'
                        LIMIT 1
                    ");
                    $stmt->execute();
                    $transport_fee = $stmt->fetch(PDO::FETCH_ASSOC);
                    $transport_particular_id = $transport_fee['particular_id'] ?? null;
                }
                
                if ($transport_fee) {
                    $fees[] = [
                        'id' => 'transport_' . ($transport_id ?? $transport_particular_id),
                        'particular_id' => $transport_id ?? $transport_particular_id,
                        'particular' => 'Transport Fee',
                        'amount' => (float)$transport_fee['amount'],
                        'applicable_months' => 'all',
                        'frequency' => 'monthly',
                        'custom_frequency' => null
                    ];
                }
            }

            $stmt = $this->pdo->prepare("
                SELECT fee_structure_id, payment_month, amount_collected, discount, remaining_balance, session, status
                FROM fee_collections
                WHERE student_id = ? AND session = ?
            ");
            $stmt->execute([$student_id, $current_session]);
            $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $paid_info_by_fee = [];
            foreach ($payments as $payment) {
                $fee_id = $payment['fee_structure_id'];
                if (!isset($paid_info_by_fee[$fee_id])) {
                    $paid_info_by_fee[$fee_id] = [
                        'collections' => [],
                        'total_amount' => 0,
                        'total_discount' => 0,
                        'remaining_balance' => 0
                    ];
                }
                if ($payment['status'] === 'completed') {
                    $collections = array_map('intval', explode(',', $payment['payment_month']));
                    $paid_info_by_fee[$fee_id]['collections'] = array_unique(array_merge($paid_info_by_fee[$fee_id]['collections'], $collections));
                }
                $paid_info_by_fee[$fee_id]['total_amount'] += (float)$payment['amount_collected'];
                $paid_info_by_fee[$fee_id]['total_discount'] += (float)$payment['discount'];
                $paid_info_by_fee[$fee_id]['remaining_balance'] += (float)$payment['remaining_balance'];
            }

            $stmt = $this->pdo->prepare("
                SELECT pf.id, pf.pending_amount, pf.due_months, pf.due_session, pf.reason, pf.status, p.particular
                FROM pending_fees pf
                LEFT JOIN particulars p ON pf.particular_id = p.id
                WHERE pf.student_uid = ? AND pf.status IN ('pending', 'partially_paid')
            ");
            $stmt->execute([$student_uid]);
            $pending_fees = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $filtered_fees = [];
            $processed_fee_ids = [];
            foreach ($fees as $fee) {
                $fee_id = $fee['id'];
                if (in_array($fee_id, $processed_fee_ids)) continue;
                $processed_fee_ids[] = $fee_id;

                $particular_id = $fee['particular_id'];
                
                if (isset($special_discount_map[$particular_id])) {
                    $special = $special_discount_map[$particular_id];
                    $fee['amount'] = (float)$special['special_amount'];
                    $fee['has_special_discount'] = true;
                    $fee['discount_percentage'] = $special['discount_percentage'];
                } else {
                    $fee['has_special_discount'] = false;
                    $fee['discount_percentage'] = 0;
                }

                $applicable_months = $fee['applicable_months'] === 'all' ? range(1, 12) : array_map('intval', explode(',', $fee['applicable_months']));
                $paid_info = $paid_info_by_fee[$fee_id] ?? ['collections' => [], 'total_amount' => 0, 'total_discount' => 0, 'remaining_balance' => 0];
                $paid_collections = $paid_info['collections'];
                $total_paid = $paid_info['total_amount'];
                $total_discount = $paid_info['total_discount'];

                if ($fee['frequency'] === 'annual') {
                    $expected_amount = $fee['amount'] - $total_discount;
                    $fee['is_fully_paid'] = $total_paid >= $expected_amount - 0.01;
                    $fee['pending_months'] = $fee['is_fully_paid'] ? [] : $applicable_months;
                    $fee['remaining_balance'] = $fee['is_fully_paid'] ? 0 : max(0, $expected_amount - $total_paid);
                } elseif ($fee['frequency'] === 'other') {
                    $custom_frequency = (int)$fee['custom_frequency'] ?: 1;
                    $max_collections = floor(12 / $custom_frequency);
                    $paid_count = count($paid_collections);
                    $pending_count = max(0, $max_collections - $paid_count);
                    $fee['is_fully_paid'] = $pending_count === 0;
                    $fee['pending_months'] = [];
                    $fee['pending_collections'] = $pending_count;
                    $fee['remaining_balance'] = $fee['is_fully_paid'] ? 0 : max(0, ($pending_count * $fee['amount']) - $total_discount);
                } else {
                    $pending_months = array_diff($applicable_months, $paid_collections);
                    $fee['is_fully_paid'] = empty($pending_months);
                    $fee['pending_months'] = array_values($pending_months);
                    $fee['pending_collections'] = count($pending_months);
                    $fee['remaining_balance'] = max(0, (count($pending_months) * $fee['amount']) - $total_discount);
                }

                if (!$fee['is_fully_paid']) {
                    $filtered_fees[] = $fee;
                }
            }

            error_log("Applicable fees for student_id $student_id, session $current_session: " . json_encode([
                'current_fees' => $filtered_fees,
                'pending_fees' => $pending_fees
            ]));

            $this->sendResponse(200, 'success', "Applicable fees fetched for session $current_session", [
                'current_fees' => $filtered_fees,
                'pending_fees' => $pending_fees,
                'transport_status' => $transport,
                'student_name' => $student['full_name'],
                'father_name' => $student['father_name'],
                'class_name' => $student['class_name']
            ]);
        } catch (PDOException $e) {
            error_log("Failed to fetch fees for student_id $student_id: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch fees: ' . $e->getMessage());
        }
    }

    private function getPaymentHistory($student_id, $start_date = null, $end_date = null) {
        try {
            $stmt = $this->pdo->prepare("SELECT id, uid FROM students WHERE id = ? AND status = 'active'");
            $stmt->execute([$student_id]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$student) {
                $this->sendResponse(404, 'error', 'Student not found or inactive');
                return;
            }
    
            $query = "
                SELECT 
                    fc.id, fc.amount_collected, fc.discount, fc.remarks, fc.remaining_balance, 
                    fc.payment_month, fc.payment_date, fc.payment_method, fc.status, fc.created_on, fc.session,
                    fc.fee_structure_id, COALESCE(p.particular, pp.particular, 'Pending Fee') AS particular, 
                    fs.particular_id, fs.amount AS fee_amount, fs.frequency, fs.custom_frequency,
                    s.full_name AS student_name, s.father_name, c.class_name,
                    COALESCE(ss.school_name, 'Default School') AS school_name,
                    COALESCE(ss.logo, '/path/to/default_logo.png') AS logo,
                    COALESCE(ss.address, 'Default Address') AS address,
                    COALESCE(ss.phone, 'N/A') AS phone,
                    (fc.amount_collected - COALESCE(fs.amount - fc.discount, pf.pending_amount - fc.discount, 0)) AS extra_amount,
                    pf.reason, pf.due_session,
                    CASE WHEN fc.fee_structure_id = '0' THEN 1 ELSE 0 END AS is_pending_fee
                FROM fee_collections fc
                LEFT JOIN fee_structure fs ON fc.fee_structure_id = fs.id AND fc.fee_structure_id NOT LIKE 'pending_%'
                LEFT JOIN particulars p ON fs.particular_id = p.id
                LEFT JOIN pending_fees pf ON fc.fee_structure_id = CONCAT('pending_', pf.id)
                LEFT JOIN particulars pp ON pf.particular_id = pp.id
                JOIN students s ON fc.student_id = s.id
                JOIN class c ON s.class = c.id
                LEFT JOIN site_settings ss ON 1=1
                WHERE fc.student_id = ?
            ";
            $params = [$student_id];
            
            if ($start_date && $end_date) {
                $query .= " AND fc.payment_date BETWEEN ? AND ?";
                $params[] = $start_date;
                $params[] = $end_date;
            } elseif ($start_date) {
                $query .= " AND fc.payment_date >= ?";
                $params[] = $start_date;
            } elseif ($end_date) {
                $query .= " AND fc.payment_date <= ?";
                $params[] = $end_date;
            }
            
            $query .= " ORDER BY fc.payment_date DESC";
    
            error_log("Executing payment history query for student_id: $student_id, start_date: " . ($start_date ?? 'N/A') . ", end_date: " . ($end_date ?? 'N/A'));
            error_log("Query: $query");
            error_log("Params: " . json_encode($params));
    
            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
            error_log("Payment history fetched for student_id $student_id: " . json_encode($history));
    
            foreach ($history as &$record) {
                $months_arr = array_map('intval', explode(',', $record['payment_month']));
                $record['payment_month_name'] = implode(', ', array_map(fn($m) => $this->months[$m], $months_arr));
                $record['frequency_display'] = $record['frequency'] === 'other' ? "Every {$record['custom_frequency']} Month" . ($record['custom_frequency'] > 1 ? 's' : '') : ucfirst($record['frequency'] ?? 'N/A');
                $record['extra_amount'] = max(0, (float)$record['extra_amount']);
                $record['is_pending_fee'] = (bool)$record['is_pending_fee'];
            }
    
            $this->sendResponse(200, 'success', 'Payment history fetched successfully', $history);
        } catch (PDOException $e) {
            error_log("Failed to fetch payment history for student_id: $student_id, error: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch payment history: ' . $e->getMessage());
        }
    }

    private function handlePost() {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) {
            $input = $_POST;
        }
    
        if (empty($input)) {
            $this->sendResponse(400, 'error', 'Invalid or missing input data');
            return;
        }
    
        $pending_fee_id = isset($input['pending_fee_id']) ? filter_var($input['pending_fee_id'], FILTER_VALIDATE_INT) : null;
        
        $required_fields = ['student_id', 'amount_collected', 'payment_date', 'payment_method', 'session'];
        if (!$pending_fee_id) {
            $required_fields[] = 'fee_structure_id';
            $required_fields[] = 'fee_frequency';
        }
    
        foreach ($required_fields as $field) {
            if (!isset($input[$field]) || (is_string($input[$field]) && trim($input[$field]) === '')) {
                $this->sendResponse(400, 'error', "Missing or empty required field: $field");
                return;
            }
        }
    
        $student_id = filter_var($input['student_id'], FILTER_VALIDATE_INT);
        $fee_structure_id = isset($input['fee_structure_id']) ? filter_var($input['fee_structure_id'], FILTER_SANITIZE_STRING) : ($pending_fee_id ? 'pending_' . $pending_fee_id : null);
        $amount_collected = filter_var($input['amount_collected'], FILTER_VALIDATE_FLOAT);
        $discount = isset($input['discount']) ? filter_var($input['discount'], FILTER_VALIDATE_FLOAT) : 0;
        $apply_credits = isset($input['apply_credits']) ? filter_var($input['apply_credits'], FILTER_VALIDATE_FLOAT) : 0;
        $remarks = isset($input['remarks']) ? filter_var($input['remarks'], FILTER_SANITIZE_STRING) : null;
        $payment_date = filter_var($input['payment_date'], FILTER_SANITIZE_STRING);
        $payment_method = filter_var($input['payment_method'], FILTER_SANITIZE_STRING);
        $session = filter_var($input['session'], FILTER_SANITIZE_STRING);
        $collections_count = isset($input['collections_count']) ? filter_var($input['collections_count'], FILTER_VALIDATE_INT) : 1;
        $fee_frequency = isset($input['fee_frequency']) ? filter_var($input['fee_frequency'], FILTER_SANITIZE_STRING) : null;
    
        $payment_month = [];
        if (isset($input['payment_month']) && is_string($input['payment_month']) && !empty(trim($input['payment_month']))) {
            $payment_month = array_map('intval', array_filter(explode(',', $input['payment_month'])));
        } elseif (isset($input['payment_month']) && is_array($input['payment_month'])) {
            $payment_month = array_map('intval', array_filter($input['payment_month']));
        }
    
        if ($student_id <= 0 || $amount_collected < 0 || $discount < 0 || $apply_credits < 0 || $collections_count <= 0) {
            $this->sendResponse(400, 'error', 'Invalid input values');
            return;
        }
    
        if (!$pending_fee_id && $fee_frequency !== 'annual' && empty($payment_month) && $fee_frequency !== 'other') {
            $this->sendResponse(400, 'error', 'Payment month is required for non-annual fees');
            return;
        }
    
        if (!in_array($payment_method, ['cash', 'card', 'online', 'cheque'])) {
            $this->sendResponse(400, 'error', 'Invalid payment method');
            return;
        }
    
        if (!DateTime::createFromFormat('Y-m-d', $payment_date)) {
            $this->sendResponse(400, 'error', 'Invalid payment date format');
            return;
        }
    
        $session = $this->getStudentSession($student_id, $payment_date, $session);
        if (!$session) {
            $this->sendResponse(400, 'error', 'Invalid academic session');
            return;
        }
    
        try {
            $stmt = $this->pdo->prepare("SELECT uid, class, transport, transport_id FROM students WHERE id = ? AND status = 'active'");
            $stmt->execute([$student_id]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$student) {
                $this->sendResponse(404, 'error', 'Student not found or inactive');
                return;
            }
            
            $student_uid = $student['uid'];
            $class_id = $student['class'];
            $transport = $student['transport'] ?? 0;
            $transport_id = $student['transport_id'] ?? null;
    
            if ($apply_credits > 0) {
                $stmt = $this->pdo->prepare("
                    SELECT SUM(remaining_amount) as total_available 
                    FROM student_credits 
                    WHERE student_uid = ? AND status = 'active' AND remaining_amount > 0
                ");
                $stmt->execute([$student_uid]);
                $credit_result = $stmt->fetch(PDO::FETCH_ASSOC);
                $available_credits = (float)($credit_result['total_available'] ?? 0);
                
                if ($apply_credits > $available_credits) {
                    $this->sendResponse(400, 'error', "Insufficient credits. Available: ₹{$available_credits}");
                    return;
                }
            }
    
            $this->pdo->beginTransaction();
    
            if ($pending_fee_id) {
                $stmt = $this->pdo->prepare("
                    SELECT pf.*, p.particular
                    FROM pending_fees pf
                    LEFT JOIN particulars p ON pf.particular_id = p.id
                    WHERE pf.id = ? AND pf.student_uid = ?
                ");
                $stmt->execute([$pending_fee_id, $student_uid]);
                $pending_fee = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$pending_fee) {
                    $this->pdo->rollBack();
                    $this->sendResponse(400, 'error', 'Pending fee not found');
                    return;
                }
    
                $total_payment = $amount_collected + $apply_credits;
                $excess_amount = max(0, $total_payment - $pending_fee['pending_amount']);
                
                $stmt = $this->pdo->prepare("
                    INSERT INTO fee_collections (
                        student_id, fee_structure_id, amount_collected, discount, remarks, 
                        remaining_balance, payment_month, payment_date, payment_method, status, 
                        created_on, session
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed', NOW(), ?)
                ");
                $stmt->execute([
                    $student_id, 'pending_' . $pending_fee_id, $total_payment, $discount, $remarks,
                    max(0, $pending_fee['pending_amount'] - $total_payment), 
                    implode(',', $payment_month ?: [date('n')]), $payment_date, $payment_method, $session
                ]);
    
                if ($apply_credits > 0) {
                    $this->applyStudentCredits($student_uid, $apply_credits, "Applied to pending fee collection on {$payment_date}");
                }
    
                $remaining_amount = max(0, $pending_fee['pending_amount'] - $total_payment);
                $new_status = $remaining_amount <= 0 ? 'fully_paid' : 'partially_paid';
                
                $stmt = $this->pdo->prepare("
                    UPDATE pending_fees 
                    SET pending_amount = ?, status = ?, updated_on = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$remaining_amount, $new_status, $pending_fee_id]);
    
                if ($excess_amount > 0) {
                    $stmt = $this->pdo->prepare("
                        INSERT INTO student_credits (
                            student_uid, credit_amount, source, description, session, created_on, status
                        )
                        VALUES (?, ?, 'excess_payment', ?, ?, NOW(), 'active')
                    ");
                    $stmt->execute([
                        $student_uid, 
                        $excess_amount, 
                        "Excess payment of ₹{$excess_amount} from pending fee collection on {$payment_date}",
                        $session
                    ]);
                }
    
                $payment_id = $this->pdo->lastInsertId();
                $receipt_link = "/receipts/fee_receipt_{$payment_id}.pdf";
                $month_names = implode(', ', array_map(fn($m) => $this->months[$m], $payment_month ?: [date('n')]));
                $particular_desc = $pending_fee['particular'] ?? 'Pending Fee';
                $description = "Payment of ₹{$total_payment} for {$particular_desc} (Months: {$month_names}, Session: {$session}) on {$payment_date}.";
                if ($discount > 0) $description .= " Discount: ₹{$discount}.";
                if ($apply_credits > 0) $description .= " Credits applied: ₹{$apply_credits}.";
    
                $stmt = $this->pdo->prepare("
                    INSERT INTO notification_queue (
                        uid, title, description, doc_link, notification_type, is_sticky, created_at, sent_at, status
                    )
                    VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW(), ?)
                ");
                $stmt->execute([$student_uid, 'Fee Payment Receipt', $description, $receipt_link, 'normal', 0, 'pending']);
    
                $this->pdo->commit();
                $message = $excess_amount > 0 
                    ? "Pending fee collected successfully. Excess amount of ₹{$excess_amount} credited for future use."
                    : 'Pending fee collected successfully for session ' . $session;
                if ($apply_credits > 0) {
                    $message .= " Credits applied: ₹{$apply_credits}";
                }
                $this->sendResponse(200, 'success', $message);
                return;
            }
    
            $is_transport_fee = strpos($fee_structure_id, 'transport_') === 0;
            $particular_id = null;
            $fee_amount = null;
            $frequency = $fee_frequency;
            $custom_frequency = 1;
            $applicable_months = 'all';
    
            if ($is_transport_fee) {
                if ($transport != 1) {
                    $this->pdo->rollBack();
                    $this->sendResponse(400, 'error', 'Transport fee not applicable for this student');
                    return;
                }
                
                if ($transport_id !== null) {
                    $stmt = $this->pdo->prepare("SELECT transport_fees AS amount FROM transport WHERE id = ? AND status = 'active'");
                    $stmt->execute([$transport_id]);
                    $transport_fee = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($transport_fee) {
                        $fee_amount = (float)$transport_fee['amount'];
                        $particular_id = $transport_id;
                    }
                }
                
                if (!$fee_amount) {
                    $stmt = $this->pdo->prepare("SELECT id AS particular_id, amount FROM particulars WHERE particular = 'Transport Fee' AND status = 'active' LIMIT 1");
                    $stmt->execute();
                    $particular_fee = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($particular_fee) {
                        $fee_amount = (float)$particular_fee['amount'];
                        $particular_id = $particular_fee['particular_id'];
                    } else {
                        $this->pdo->rollBack();
                        $this->sendResponse(400, 'error', 'Transport fee not found');
                        return;
                    }
                }
            } else {
                $fee_structure_id_int = filter_var($fee_structure_id, FILTER_VALIDATE_INT);
                if ($fee_structure_id_int === false || $fee_structure_id_int <= 0) {
                    $this->pdo->rollBack();
                    $this->sendResponse(400, 'error', 'Invalid fee structure ID');
                    return;
                }
                
                $stmt = $this->pdo->prepare("
                    SELECT fs.id, fs.amount, fs.applicable_months, fs.frequency, fs.custom_frequency, p.particular, p.id AS particular_id
                    FROM fee_structure fs
                    JOIN particulars p ON fs.particular_id = p.id
                    WHERE fs.id = ? AND fs.class_id = ?
                ");
                $stmt->execute([$fee_structure_id_int, $class_id]);
                $fee_structure = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$fee_structure) {
                    $this->pdo->rollBack();
                    $this->sendResponse(400, 'error', 'Fee structure not applicable');
                    return;
                }
                
                $particular_id = $fee_structure['particular_id'];
                $fee_amount = (float)$fee_structure['amount'];
                $frequency = $fee_structure['frequency'];
                $custom_frequency = (int)$fee_structure['custom_frequency'] ?: 1;
                $applicable_months = $fee_structure['applicable_months'];
            }
    
            $stmt = $this->pdo->prepare("
                SELECT special_amount
                FROM special_structure
                WHERE student_uid = ? AND particular_id = ? AND status = 'active'
                LIMIT 1
            ");
            $stmt->execute([$student_uid, $particular_id]);
            $special = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($special) {
                $fee_amount = (float)$special['special_amount'];
            }
    
            $stmt = $this->pdo->prepare("
                SELECT id, payment_month, amount_collected, discount, status, session
                FROM fee_collections
                WHERE student_id = ? AND fee_structure_id = ? AND session = ?
            ");
            $stmt->execute([$student_id, $fee_structure_id, $session]);
            $existing = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
            $already_paid_collections = [];
            $total_paid = 0;
            $total_discount = 0;
            foreach ($existing as $payment) {
                if ($payment['status'] === 'completed') {
                    $collections = array_map('intval', explode(',', $payment['payment_month']));
                    $already_paid_collections = array_unique(array_merge($already_paid_collections, $collections));
                }
                $total_paid += (float)$payment['amount_collected'];
                $total_discount += (float)$payment['discount'];
            }
            $total_discount += $discount;
    
            $applicable_months_array = $applicable_months === 'all' ? range(1, 12) : array_map('intval', explode(',', $applicable_months));
    
            if ($frequency === 'annual') {
                if (!empty($already_paid_collections)) {
                    $this->pdo->rollBack();
                    $this->sendResponse(400, 'error', 'Annual fee already collected in this session');
                    return;
                }
                $total_expected = $fee_amount - $discount - $apply_credits;
                if (abs($amount_collected - $total_expected) > 0.01) {
                    $this->pdo->rollBack();
                    $this->sendResponse(400, 'error', "Amount collected (₹{$amount_collected}) does not match expected amount (₹{$total_expected}) after credits and discount");
                    return;
                }
                $excess_amount = 0;
                $remaining_balance = 0;
            } elseif ($frequency === 'other') {
                $max_collections = floor(12 / $custom_frequency);
                $paid_count = count($already_paid_collections);
                $pending_count = max(0, $max_collections - $paid_count);
                $collections_to_pay = min($collections_count, $pending_count);
                
                if ($collections_to_pay <= 0) {
                    $this->pdo->rollBack();
                    $this->sendResponse(400, 'error', 'No pending collections');
                    return;
                }
                
                $total_expected = ($fee_amount * $collections_to_pay) - $discount - $apply_credits;
                if (abs($amount_collected - $total_expected) > 0.01) {
                    $this->pdo->rollBack();
                    $this->sendResponse(400, 'error', "Amount collected (₹{$amount_collected}) does not match expected amount (₹{$total_expected}) after credits and discount");
                    return;
                }
                $excess_amount = 0;
                $remaining_balance = max(0, ($pending_count - $collections_to_pay) * $fee_amount);
                $payment_month = array_fill(0, $collections_to_pay, $payment_month[0] ?? date('n'));
            } else {
                $pending_months = array_diff($applicable_months_array, $already_paid_collections);
                $to_pay = array_intersect($payment_month, $pending_months);
                
                if (empty($to_pay)) {
                    $this->pdo->rollBack();
                    $this->sendResponse(400, 'error', 'Selected months already paid or not applicable');
                    return;
                }
                
                $total_expected = ($fee_amount * count($to_pay)) - $discount - $apply_credits;
                if (abs($amount_collected - $total_expected) > 0.01) {
                    $this->pdo->rollBack();
                    $this->sendResponse(400, 'error', "Amount collected (₹{$amount_collected}) does not match expected amount (₹{$total_expected}) after credits and discount");
                    return;
                }
                $excess_amount = 0;
                $remaining_balance = max(0, (count($pending_months) - count($to_pay)) * $fee_amount);
                $payment_month = $to_pay;
            }
    
            $total_payment = $amount_collected + $apply_credits;
            
            $stmt = $this->pdo->prepare("
                INSERT INTO fee_collections (
                    student_id, fee_structure_id, amount_collected, discount, remarks, 
                    remaining_balance, payment_month, payment_date, payment_method, status, 
                    created_on, session
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed', NOW(), ?)
            ");
            $stmt->execute([
                $student_id, $fee_structure_id, $total_payment, $discount, $remarks,
                $remaining_balance, implode(',', $payment_month), $payment_date, $payment_method, $session
            ]);
    
            $payment_id = $this->pdo->lastInsertId();
    
            if ($apply_credits > 0) {
                $this->applyStudentCredits($student_uid, $apply_credits, "Applied to fee collection on {$payment_date}");
            }
    
            if ($excess_amount > 0) {
                $stmt = $this->pdo->prepare("
                    INSERT INTO student_credits (
                        student_uid, credit_amount, source, description, session, created_on, status
                    )
                    VALUES (?, ?, 'excess_payment', ?, ?, NOW(), 'active')
                ");
                $stmt->execute([
                    $student_uid, 
                    $excess_amount, 
                    "Excess payment of ₹{$excess_amount} from fee collection on {$payment_date}",
                    $session
                ]);
            }
    
            $receipt_link = "/receipts/fee_receipt_{$payment_id}.pdf";
            $month_names = implode(', ', array_map(fn($m) => $this->months[$m], $payment_month));
            $particular_desc = $is_transport_fee ? 'Transport Fee' : ($fee_structure['particular'] ?? 'Fee');
            $description = "Payment of ₹{$total_payment} for {$particular_desc} (Months: {$month_names}, Session: {$session}) on {$payment_date}.";
            if ($discount > 0) $description .= " Discount: ₹{$discount}.";
            if ($apply_credits > 0) $description .= " Credits applied: ₹{$apply_credits}.";
    
            $stmt = $this->pdo->prepare("
                INSERT INTO notification_queue (
                    uid, title, description, doc_link, notification_type, is_sticky, created_at, sent_at, status
                )
                VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW(), ?)
            ");
            $stmt->execute([$student_uid, 'Fee Payment Receipt', $description, $receipt_link, 'normal', 0, 'pending']);
    
            $this->pdo->commit();
            
            $message = $excess_amount > 0 
                ? "Fee collected successfully. Excess amount of ₹{$excess_amount} credited for future use."
                : 'Fee collected successfully for session ' . $session;
            if ($apply_credits > 0) {
                $message .= " Credits applied: ₹{$apply_credits}";
            }
            $this->sendResponse(200, 'success', $message);
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            error_log("Failed to collect fee for student_id $student_id, pending_fee_id " . ($pending_fee_id ?? 'N/A') . ": " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to collect fee: ' . $e->getMessage());
        }
    }

    private function applyStudentCredits($student_uid, $amount_to_apply, $description) {
        $stmt = $this->pdo->prepare("
            SELECT id, remaining_amount 
            FROM student_credits 
            WHERE student_uid = ? AND status = 'active' AND remaining_amount > 0
            ORDER BY created_on ASC
        ");
        $stmt->execute([$student_uid]);
        $credits = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $remaining_to_apply = $amount_to_apply;
        
        foreach ($credits as $credit) {
            if ($remaining_to_apply <= 0) break;
            
            $available = (float)$credit['remaining_amount'];
            $to_use = min($remaining_to_apply, $available);
            
            $new_used = $to_use;
            $new_remaining = $available - $to_use;
            $new_status = $new_remaining <= 0 ? 'used' : 'active';
            
            $stmt = $this->pdo->prepare("
                UPDATE student_credits 
                SET used_amount = COALESCE(used_amount, 0) + ?, 
                    remaining_amount = ?, 
                    status = ?,
                    updated_on = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$to_use, $new_remaining, $new_status, $credit['id']]);
            
            $remaining_to_apply -= $to_use;
        }
        
        if ($remaining_to_apply > 0) {
            throw new Exception("Insufficient credits available");
        }
    }

    private function handleDelete() {
        $payment_id = filter_var($_GET['payment_id'] ?? 0, FILTER_VALIDATE_INT);
        if ($payment_id <= 0) {
            $this->sendResponse(400, 'error', 'Invalid or missing payment ID');
            return;
        }
    
        try {
            $this->pdo->beginTransaction();
            
            $stmt = $this->pdo->prepare("
                SELECT fee_structure_id, amount_collected, discount, student_id 
                FROM fee_collections 
                WHERE id = ?
            ");
            $stmt->execute([$payment_id]);
            $payment = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$payment) {
                $this->pdo->rollBack();
                $this->sendResponse(404, 'error', 'Payment record not found');
                return;
            }
            
            if (strpos($payment['fee_structure_id'], 'pending_') === 0) {
                $pending_fee_id = (int)str_replace('pending_', '', $payment['fee_structure_id']);
                $stmt = $this->pdo->prepare("
                    SELECT pending_amount, status 
                    FROM pending_fees 
                    WHERE id = ?
                ");
                $stmt->execute([$pending_fee_id]);
                $pending_fee = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($pending_fee) {
                    $new_pending_amount = (float)$pending_fee['pending_amount'] + (float)$payment['amount_collected'] + (float)$payment['discount'];
                    $new_status = $new_pending_amount > 0 ? 'partially_paid' : 'pending';
                    
                    $stmt = $this->pdo->prepare("
                        UPDATE pending_fees 
                        SET pending_amount = ?, status = ?, updated_on = NOW()
                        WHERE id = ?
                    ");
                    $stmt->execute([$new_pending_amount, $new_status, $pending_fee_id]);
                }
            }
            
            $stmt = $this->pdo->prepare("DELETE FROM fee_collections WHERE id = ?");
            $stmt->execute([$payment_id]);
            
            if ($stmt->rowCount() === 0) {
                $this->pdo->rollBack();
                $this->sendResponse(404, 'error', 'Payment record not found');
                return;
            }
            
            $this->pdo->commit();
            $this->sendResponse(200, 'success', 'Payment record deleted successfully');
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            error_log("Failed to delete payment record: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to delete payment record');
        }
    }

    private function getStudentsByClass($class_id) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT id, full_name, father_name
                FROM students
                WHERE class = ? AND status = 'active'
                ORDER BY full_name
            ");
            $stmt->execute([$class_id]);
            $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $this->sendResponse(200, 'success', 'Students fetched successfully', $students);
        } catch (PDOException $e) {
            error_log("Failed to fetch students: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch students');
        }
    }

    private function sendResponse($statusCode, $status, $message, $data = null) {
        http_response_code($statusCode);
        $response = ['status' => $status, 'message' => $message];
        if ($data !== null) {
            $response['data'] = $data;
        }
        echo json_encode($response);
        exit();
    }
}

$feeCollectionMaster = new FeeCollectionMaster();
$feeCollectionMaster->handleRequest();
?>