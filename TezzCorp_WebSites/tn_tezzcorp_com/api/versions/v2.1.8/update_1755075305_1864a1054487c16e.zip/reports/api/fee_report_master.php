<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Enable error logging for production debugging
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', $_SERVER['DOCUMENT_ROOT'] . '/logs/error.log');

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

class FeeReportMaster {
    private $pdo;
    private $months = [
        1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June',
        7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
    ];

    public function __construct() {
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Database connection failed');
            exit();
        }
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        
        if ($method === 'GET') {
            $this->handleGet();
        } elseif ($method === 'POST') {
            $this->handlePost();
        } else {
            $this->sendResponse(405, 'error', 'Method not allowed');
        }
    }

    private function handleGet() {
        $action = $_GET['action'] ?? '';

        switch ($action) {
            case 'get_particulars':
                $this->getParticulars();
                break;
            case 'get_sessions':
                $this->getSessions();
                break;
            case 'get_students_by_class':
                $this->getStudentsByClass();
                break;
            case 'get_report':
                $this->getReport();
                break;
            default:
                $this->sendResponse(400, 'error', 'Invalid action');
                break;
        }
    }

    private function handlePost() {
        $action = $_POST['action'] ?? '';

        if ($action === 'export_report') {
            $this->exportReport();
        } else {
            $this->sendResponse(400, 'error', 'Invalid action');
        }
    }

    private function getParticulars() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT DISTINCT p.id, p.particular 
                FROM particulars p
                JOIN fee_structure fs ON p.id = fs.particular_id
                WHERE fs.status = 'active'
                ORDER BY p.particular
            ");
            $stmt->execute();
            $particulars = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $this->sendResponse(200, 'success', 'Particulars fetched successfully', $particulars);
        } catch (PDOException $e) {
            error_log("Failed to fetch particulars: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch particulars');
        }
    }

    private function getSessions() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT DISTINCT session 
                FROM fee_collections 
                WHERE session IS NOT NULL AND session != ''
                ORDER BY session DESC
            ");
            $stmt->execute();
            $sessions = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $this->sendResponse(200, 'success', 'Sessions fetched successfully', $sessions);
        } catch (PDOException $e) {
            error_log("Failed to fetch sessions: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch sessions');
        }
    }

    private function getStudentsByClass() {
        $class_id = filter_var($_GET['class_id'] ?? '', FILTER_VALIDATE_INT);
        
        if (!$class_id) {
            $this->sendResponse(400, 'error', 'Invalid class ID');
            return;
        }

        try {
            $stmt = $this->pdo->prepare("
                SELECT id, full_name, father_name 
                FROM students 
                WHERE class = ? AND status = 'active'
                ORDER BY full_name
            ");
            $stmt->execute([$class_id]);
            $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $this->sendResponse(200, 'success', 'Students fetched successfully', $students);
        } catch (PDOException $e) {
            error_log("Failed to fetch students: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch students');
        }
    }

    private function getReport() {
        try {
            // Build the query with filters
            $query = "
                SELECT 
                    fc.id,
                    fc.amount_collected,
                    fc.discount,
                    fc.remaining_balance,
                    fc.payment_month,
                    fc.payment_date,
                    fc.payment_method,
                    fc.status,
                    fc.session,
                    fc.remarks,
                    s.full_name AS student_name,
                    s.father_name,
                    c.class_name,
                    p.particular,
                    fs.amount AS fee_amount,
                    fs.frequency
                FROM fee_collections fc
                JOIN fee_structure fs ON fc.fee_structure_id = fs.id
                JOIN particulars p ON fs.particular_id = p.id
                JOIN students s ON fc.student_id = s.id
                JOIN class c ON s.class = c.id
                WHERE 1=1
            ";

            $params = [];
            $conditions = [];

            // Apply filters
            if (!empty($_GET['class_id'])) {
                $conditions[] = "s.class = ?";
                $params[] = $_GET['class_id'];
            }

            if (!empty($_GET['student_id'])) {
                $conditions[] = "fc.student_id = ?";
                $params[] = $_GET['student_id'];
            }

            if (!empty($_GET['particular_id'])) {
                $conditions[] = "fs.particular_id = ?";
                $params[] = $_GET['particular_id'];
            }

            if (!empty($_GET['session'])) {
                $conditions[] = "fc.session = ?";
                $params[] = $_GET['session'];
            }

            if (!empty($_GET['payment_method'])) {
                $conditions[] = "fc.payment_method = ?";
                $params[] = $_GET['payment_method'];
            }

            if (!empty($_GET['status'])) {
                $conditions[] = "fc.status = ?";
                $params[] = $_GET['status'];
            }

            if (!empty($_GET['date_from'])) {
                $conditions[] = "fc.payment_date >= ?";
                $params[] = $_GET['date_from'];
            }

            if (!empty($_GET['date_to'])) {
                $conditions[] = "fc.payment_date <= ?";
                $params[] = $_GET['date_to'];
            }

            if (!empty($conditions)) {
                $query .= " AND " . implode(" AND ", $conditions);
            }

            $query .= " ORDER BY fc.payment_date DESC, fc.id DESC";

            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Process payment months
            foreach ($data as &$record) {
                $months_arr = array_map('intval', explode(',', $record['payment_month']));
                $month_names = array_map(function($m) { return $this->months[$m]; }, $months_arr);
                $record['payment_month_name'] = implode(', ', $month_names);
            }

            // Calculate statistics
            $statistics = $this->calculateStatistics($data);

            $this->sendResponse(200, 'success', 'Report data fetched successfully', $data, $statistics);
        } catch (PDOException $e) {
            error_log("Failed to fetch report data: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch report data');
        }
    }

    private function calculateStatistics($data) {
        $stats = [
            'total_collections' => count($data),
            'total_amount' => 0,
            'total_discount' => 0,
            'pending_amount' => 0
        ];

        foreach ($data as $record) {
            $stats['total_amount'] += (float)$record['amount_collected'];
            $stats['total_discount'] += (float)$record['discount'];
            $stats['pending_amount'] += (float)$record['remaining_balance'];
        }

        return $stats;
    }

    private function exportReport() {
        try {
            // Get the same data as the report
            $_GET = $_POST; // Copy POST data to GET for reuse
            $this->getReport();
        } catch (Exception $e) {
            error_log("Failed to export report: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to export report');
        }
    }

    private function sendResponse($statusCode, $status, $message, $data = null, $statistics = null) {
        http_response_code($statusCode);
        $response = ['status' => $status, 'message' => $message];
        
        if ($data !== null) {
            $response['data'] = $data;
        }
        
        if ($statistics !== null) {
            $response['statistics'] = $statistics;
        }
        
        echo json_encode($response);
        exit();
    }
}

// Instantiate and handle the request
try {
    $feeReportMaster = new FeeReportMaster();
    $feeReportMaster->handleRequest();
} catch (Exception $e) {
    error_log("Failed to handle request: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Internal server error']);
}
?>