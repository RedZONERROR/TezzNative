<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/fpdf/fpdf.php';

// Check if this is a download request
if (isset($_GET['download']) && $_GET['download'] === 'pdf') {
    // Set headers for PDF download
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="report_cards_' . date('Y-m-d_H-i-s') . '.pdf"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    
    // Process the download request
    $controller = new ReportCardController();
    $controller->downloadReportCard();
    exit;
}

// Regular JSON API headers
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

class ReportCardController {
    private $pdo;
    private $logger;

    public function __construct() {
        try {
            $this->pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    private function validateInput(array $data): array {
        $errors = [];
        $validData = [];

        if (!isset($data['class_id']) || !filter_var($data['class_id'], FILTER_VALIDATE_INT) || $data['class_id'] <= 0) {
            $errors[] = 'class_id must be a valid integer';
        } else {
            $validData['class_id'] = (int)$data['class_id'];
        }

        if (!isset($data['session']) || empty(trim($data['session']))) {
            $errors[] = 'session is required';
        } else {
            $validData['session'] = trim($data['session']);
        }

        if (!isset($data['term']) || empty(trim($data['term']))) {
            $errors[] = 'term is required';
        } else {
            $validData['term'] = trim($data['term']);
        }

        if (!isset($data['students']) || !is_array($data['students']) || empty($data['students'])) {
            $errors[] = 'At least one student must be selected';
        } else {
            $validData['students'] = array_map('trim', $data['students']);
            foreach ($validData['students'] as $uid) {
                if (empty($uid)) {
                    $errors[] = 'Invalid student UID';
                    break;
                }
            }
        }

        // Optional signature fields
        $validData['dept_examination_signature'] = $data['dept_examination_signature'] ?? null;
        $validData['class_teacher_signature'] = $data['class_teacher_signature'] ?? null;
        $validData['principal_signature'] = $data['principal_signature'] ?? null;

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return $validData;
    }

    private function handleFileUpload($file, $uploadDir = 'uploads/signatures/') {
        if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
            return null;
        }

        $uploadPath = $_SERVER['DOCUMENT_ROOT'] . '/' . $uploadDir;
        if (!file_exists($uploadPath)) {
            mkdir($uploadPath, 0755, true);
        }

        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($file['type'], $allowedTypes)) {
            throw new Exception('Invalid file type. Only JPEG, PNG, and GIF are allowed.');
        }

        $maxSize = 2 * 1024 * 1024; // 2MB
        if ($file['size'] > $maxSize) {
            throw new Exception('File size too large. Maximum 2MB allowed.');
        }

        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'signature_' . uniqid() . '.' . $extension;
        $fullPath = $uploadPath . $filename;

        if (move_uploaded_file($file['tmp_name'], $fullPath)) {
            return $uploadDir . $filename;
        }

        throw new Exception('Failed to upload file.');
    }

    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    private function logInfo(string $message): void {
        ($this->logger)('INFO: ' . $message);
    }

    private function getTemplateFile() {
        try {
            $stmt = $this->pdo->prepare("SELECT template_file FROM templates WHERE template_type = ? AND status = ?");
            $stmt->execute(['marksheet', 'active']);
            $template = $stmt->fetch();
            return $template ? $template['template_file'] : '1.png';
        } catch (PDOException $e) {
            $this->logError('Template query failed: ' . $e->getMessage());
            return '1.png';
        }
    }

    private function validateAndProcessImage($imagePath) {
        if (!file_exists($imagePath)) {
            $this->logError("Image file does not exist: $imagePath");
            return false;
        }

        if (!is_readable($imagePath)) {
            $this->logError("Image file is not readable: $imagePath");
            return false;
        }

        $fileSize = filesize($imagePath);
        if ($fileSize === false || $fileSize === 0) {
            $this->logError("Image file is empty or unreadable: $imagePath (Size: $fileSize)");
            return false;
        }

        $imageInfo = getimagesize($imagePath);
        if ($imageInfo === false) {
            $this->logError("Invalid image file or corrupted: $imagePath");
            return false;
        }

        $supportedTypes = [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF];
        if (!in_array($imageInfo[2], $supportedTypes)) {
            $this->logError("Unsupported image format: $imagePath (Type: " . $imageInfo[2] . ")");
            return false;
        }

        return true;
    }

    private function calculateRank($class_id, $session, $term, $student_totals) {
        try {
            $sql = "SELECT r.uid, SUM(r.marks_obtained) as total_marks
                    FROM results r
                    WHERE r.class_id = ? AND r.session = ? AND r.term = ?
                    GROUP BY r.uid
                    ORDER BY total_marks DESC";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$class_id, $session, $term]);
            $all_students = $stmt->fetchAll();

            $ranks = [];
            $current_rank = 1;
            $previous_total = null;
            $position = 1;

            foreach ($all_students as $student) {
                $uid = $student['uid'];
                $total = $student['total_marks'];

                if ($total !== $previous_total) {
                    $current_rank = $position;
                }

                if (isset($student_totals[$uid])) {
                    $ranks[$uid] = $current_rank;
                }

                $previous_total = $total;
                $position++;
            }

            return $ranks;
        } catch (PDOException $e) {
            $this->logError('Rank calculation failed: ' . $e->getMessage());
            return [];
        }
    }

    private function generatePDF($validData) {
        $template_file = $this->getTemplateFile();

        $placeholders = implode(',', array_fill(0, count($validData['students']), '?'));
        $sql = "SELECT r.uid, r.subject_id, r.marks_obtained, r.max_marks, s.subject, s.passing_marks,
                       sm.full_name, sm.father_name, sm.mother_name, sm.date_of_birth,
                       sm.roll_no, cm.class_name, d.student_photo
                FROM results r
                JOIN subject s ON r.subject_id = s.id
                JOIN students sm ON r.uid = sm.uid
                JOIN documents d ON sm.uid = d.uid
                JOIN class cm ON r.class_id = cm.id
                WHERE r.class_id = ? AND r.session = ? AND r.term = ? AND r.uid IN ($placeholders)";

        $stmt = $this->pdo->prepare($sql);
        $params = array_merge([$validData['class_id'], $validData['session'], $validData['term']], $validData['students']);
        $stmt->execute($params);

        $report_cards = [];
        $student_totals = [];

        while ($row = $stmt->fetch()) {
            $uid = $row['uid'];
            
            if (!isset($report_cards[$uid])) {
                $report_cards[$uid] = [
                    'full_name' => $row['full_name'],
                    'father_name' => $row['father_name'],
                    'mother_name' => $row['mother_name'],
                    'date_of_birth' => $row['date_of_birth'],
                    'roll_no' => $row['roll_no'],
                    'class_name' => $row['class_name'],
                    'student_photo' => $row['student_photo'],
                    'session' => $validData['session'],
                    'term' => $validData['term'],
                    'subjects' => []
                ];
                $student_totals[$uid] = 0;
            }

            $report_cards[$uid]['subjects'][] = [
                'subject_id' => $row['subject_id'],
                'subject' => $row['subject'],
                'marks_obtained' => $row['marks_obtained'],
                'max_marks' => $row['max_marks'],
                'passing_marks' => $row['passing_marks']
            ];

            $student_totals[$uid] += $row['marks_obtained'];
        }

        if (empty($report_cards)) {
            throw new Exception('No results found for the selected criteria');
        }

        $ranks = $this->calculateRank($validData['class_id'], $validData['session'], $validData['term'], $student_totals);

        $pdf = new FPDF();
        $image_path = $_SERVER['DOCUMENT_ROOT'] . '/app/settings/templates/marksheet/' . $template_file;

        if (!file_exists($image_path)) {
            throw new Exception('Template image not found: ' . $image_path);
        }

        foreach ($report_cards as $uid => &$card) {
            $total_max = array_sum(array_column($card['subjects'], 'max_marks'));
            $total_passing_marks = array_sum(array_column($card['subjects'], 'passing_marks'));
            $total_obt = array_sum(array_column($card['subjects'], 'marks_obtained'));
            $percentage = $total_max > 0 ? ($total_obt / $total_max) * 100 : 0;
            $rank = $ranks[$uid] ?? 'N/A';

            $card['total_marks'] = $total_obt;
            $card['total_max_marks'] = $total_max;
            $card['total_passing_marks'] = $total_passing_marks;
            $card['percentage'] = $percentage;
            $card['rank'] = $rank;

            $pdf->AddPage();
            $pdf->Image($image_path, 0, 0, 210, 297);
            $pdf->SetFont('Arial', 'B', 12);

            // Student photo handling
            $photo_path = $card['student_photo'];
            $photo = $_SERVER['DOCUMENT_ROOT'] . '/' . ltrim($photo_path, '/');
            
            if ($this->validateAndProcessImage($photo)) {
                try {
                    $pdf->Image($photo, 161, 72, 33.5, 37);
                } catch (Exception $e) {
                    $this->logError("FPDF Image error for $photo: " . $e->getMessage());
                    $pdf->SetXY(161, 72);
                    $pdf->SetFont('Arial', '', 8);
                    $pdf->Cell(33.5, 37, 'Photo\nNot Available', 1, 0, 'C');
                }
            } else {
                $pdf->SetXY(161, 72);
                $pdf->SetFont('Arial', '', 8);
                $pdf->Cell(33.5, 37, 'Photo\nNot Available', 1, 0, 'C');
            }
            
            $date = date('d-m-Y');

            // Student information
            $pdf->SetFont('Arial', 'B', 12);
            
            $pdf->SetXY(14.2, 63);
            $pdf->Cell(0, 10, "Date: " . $date, 0, 1);
            
            $pdf->SetXY(154.8, 63);
            $pdf->Cell(0, 10, "Session: " . $card['session'], 0, 1);
            
            $pdf->SetXY(52, 72);
            $pdf->Cell(0, 10, $card['full_name'], 0, 1);
            $pdf->SetXY(52, 81);
            $pdf->Cell(0, 10, $card['father_name'], 0, 1);
            $pdf->SetXY(52, 90.5);
            $pdf->Cell(0, 10, $card['mother_name'], 0, 1);
            $pdf->SetXY(52, 99.8);
            $pdf->Cell(0, 10, $card['class_name'], 0, 1);
            $pdf->SetXY(41, 109.6);
            $pdf->Cell(0, 10, $card['roll_no'], 0, 1);
            $pdf->SetXY(136, 109.6);
            $pdf->Cell(0, 10, $card['date_of_birth'], 0, 1);

            // Subject Table Header (using original widths)
            $pdf->SetXY(15.3, 120);
            $pdf->Cell(89.7, 10, 'Subject', 1, 0, 'C');
            $pdf->Cell(30, 10, 'Max Marks', 1, 0, 'C');
            $pdf->Cell(30, 10, 'Pass Marks', 1, 0, 'C');
            $pdf->Cell(30, 10, 'Obt. Marks', 1, 0, 'C');
            $pdf->Ln();

            // Subject Table Data
            $y_pos = 130;
            foreach ($card['subjects'] as $subject) {
                $pdf->SetXY(15.3, $y_pos);
                $pdf->Cell(89.7, 10, $subject['subject'], 1, 0, 'L');
                $pdf->Cell(30, 10, $subject['max_marks'], 1, 0, 'C');
                $pdf->Cell(30, 10, number_format($subject['passing_marks'], 2), 1, 0, 'C');
                $pdf->Cell(30, 10, $subject['marks_obtained'], 1, 0, 'C');
                $y_pos += 10;
            }

            // Summary Table (using original widths)
            $headers = ['Total Marks', 'Percentage', 'Rank', 'Result', 'Term'];
            
            if ($percentage >= 60) {
                $result = 'First';
            } elseif ($percentage >= 50) {
                $result = 'Second';
            } elseif ($percentage >= 35) {
                $result = 'Third';
            } else {
                $result = 'Fail';
            }

            $data_row = [
                "{$total_obt} / {$total_max}",
                number_format($percentage, 2) . "%",
                $rank,
                $result,
                $card['term']
            ];

            $col_width = 35.945;
            $row_height = 10;
            
            $pdf->SetXY(15.3, $y_pos);
            foreach ($headers as $header) {
                $pdf->Cell($col_width, $row_height, $header, 1, 0, 'C');
            }
            $pdf->Ln();
            
            $y_pos += $row_height;
            $pdf->SetXY(15.3, $y_pos);
            foreach ($data_row as $value) {
                $pdf->Cell($col_width, $row_height, $value, 1, 0, 'C');
            }
            $pdf->Ln();

            // Add signatures as images at the bottom (no table)
            $y_pos = 265; // Add some space
            
            if ($template_file == '1.png') {
                
                // Department of Examination signature
                if ($validData['dept_examination_signature']) {
                    $dept_sig_path = $_SERVER['DOCUMENT_ROOT'] . '/' . $validData['dept_examination_signature'];
                    if ($this->validateAndProcessImage($dept_sig_path)) {
                        try {
                            $pdf->Image($dept_sig_path, 45, $y_pos, 15, 8);
                        } catch (Exception $e) {
                            $this->logError("Department signature error: " . $e->getMessage());
                        }
                    }
                }
    
                // Class Teacher signature
                if ($validData['class_teacher_signature']) {
                    $class_teacher_sig_path = $_SERVER['DOCUMENT_ROOT'] . '/' . $validData['class_teacher_signature'];
                    if ($this->validateAndProcessImage($class_teacher_sig_path)) {
                        try {
                            $pdf->Image($class_teacher_sig_path, 90, $y_pos, 15, 8);
                        } catch (Exception $e) {
                            $this->logError("Class teacher signature error: " . $e->getMessage());
                        }
                    }
                }
    
                // Principal signature
                if ($validData['principal_signature']) {
                    $principal_sig_path = $_SERVER['DOCUMENT_ROOT'] . '/' . $validData['principal_signature'];
                    if ($this->validateAndProcessImage($principal_sig_path)) {
                        try {
                            $pdf->Image($principal_sig_path, 130, $y_pos, 15, 8);
                        } catch (Exception $e) {
                            $this->logError("Principal signature error: " . $e->getMessage());
                        }
                    }
                }
                
            } else {

                // Class Teacher signature
                if ($validData['class_teacher_signature']) {
                    $class_teacher_sig_path = $_SERVER['DOCUMENT_ROOT'] . '/' . $validData['class_teacher_signature'];
                    if ($this->validateAndProcessImage($class_teacher_sig_path)) {
                        try {
                            $pdf->Image($class_teacher_sig_path, 42, $y_pos, 15, 8);
                        } catch (Exception $e) {
                            $this->logError("Class teacher signature error: " . $e->getMessage());
                        }
                    }
                }
    
                // Principal signature
                if ($validData['principal_signature']) {
                    $principal_sig_path = $_SERVER['DOCUMENT_ROOT'] . '/' . $validData['principal_signature'];
                    if ($this->validateAndProcessImage($principal_sig_path)) {
                        try {
                            $pdf->Image($principal_sig_path, 100, $y_pos, 15, 8);
                        } catch (Exception $e) {
                            $this->logError("Principal signature error: " . $e->getMessage());
                        }
                    }
                }
                
            }
            
        }

        return ['pdf' => $pdf, 'report_cards' => $report_cards];
    }

    public function downloadReportCard() {
        if (!isset($_SESSION['uid']) || !in_array($_SESSION['role'], ['Super Admin', 'Admin', 'Accountant'])) {
            http_response_code(403);
            echo 'Unauthorized access';
            exit;
        }

        $data = [
            'class_id' => $_POST['class_id'] ?? $_SESSION['download_class_id'] ?? '',
            'session' => $_POST['session'] ?? $_SESSION['download_session'] ?? '',
            'term' => $_POST['term'] ?? $_SESSION['download_term'] ?? '',
            'students' => $_POST['students'] ?? $_SESSION['download_students'] ?? [],
            'dept_examination_signature' => $_SESSION['download_dept_examination_signature'] ?? null,
            'class_teacher_signature' => $_SESSION['download_class_teacher_signature'] ?? null,
            'principal_signature' => $_SESSION['download_principal_signature'] ?? null
        ];

        try {
            $validData = $this->validateInput($data);
            $result = $this->generatePDF($validData);
            
            $this->logInfo("PDF download initiated for " . count($result['report_cards']) . " students");
            
            // Output PDF directly for download
            echo $result['pdf']->Output('S');
            
        } catch (Exception $e) {
            $this->logError('PDF download failed: ' . $e->getMessage());
            http_response_code(500);
            echo 'Failed to generate PDF: ' . $e->getMessage();
        }
    }

    public function generateReportCard() {
        if (!isset($_SESSION['uid']) || !in_array($_SESSION['role'], ['Super Admin', 'Admin', 'Accountant'])) {
            $this->sendError(403, 'Unauthorized access');
        }

        try {
            // Handle file uploads
            $dept_examination_signature = null;
            $class_teacher_signature = null;
            $principal_signature = null;

            if (isset($_FILES['dept_examination_signature'])) {
                $dept_examination_signature = $this->handleFileUpload($_FILES['dept_examination_signature']);
            }

            if (isset($_FILES['class_teacher_signature'])) {
                $class_teacher_signature = $this->handleFileUpload($_FILES['class_teacher_signature']);
            }

            if (isset($_FILES['principal_signature'])) {
                $principal_signature = $this->handleFileUpload($_FILES['principal_signature']);
            }

            $data = [
                'class_id' => $_POST['class_id'] ?? '',
                'session' => $_POST['session'] ?? '',
                'term' => $_POST['term'] ?? '',
                'students' => $_POST['students'] ?? [],
                'dept_examination_signature' => $dept_examination_signature,
                'class_teacher_signature' => $class_teacher_signature,
                'principal_signature' => $principal_signature
            ];

            $validData = $this->validateInput($data);
            
            // Store data in session for download
            $_SESSION['download_class_id'] = $validData['class_id'];
            $_SESSION['download_session'] = $validData['session'];
            $_SESSION['download_term'] = $validData['term'];
            $_SESSION['download_students'] = $validData['students'];
            $_SESSION['download_dept_examination_signature'] = $validData['dept_examination_signature'];
            $_SESSION['download_class_teacher_signature'] = $validData['class_teacher_signature'];
            $_SESSION['download_principal_signature'] = $validData['principal_signature'];
            
            $result = $this->generatePDF($validData);
            
            $this->logInfo("Report card generation successful for " . count($result['report_cards']) . " students");
            
            // Create download URL
            $downloadUrl = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '?download=pdf';
            
            $this->sendSuccess(200, [
                'success' => true,
                'data' => [
                    'report_cards' => array_values($result['report_cards']),
                    'download_url' => $downloadUrl,
                    'message' => 'Report cards generated successfully. Use the download_url to download the PDF.'
                ]
            ]);

        } catch (PDOException $e) {
            $this->logError('Query failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to generate report cards');
        } catch (Exception $e) {
            $this->logError('PDF generation failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to generate PDF: ' . $e->getMessage());
        }
    }

    public function handleRequest() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->generateReportCard();
        } else {
            $this->sendError(405, 'Method not allowed');
        }
    }
}

// Create logs directory if it doesn't exist
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

$controller = new ReportCardController();
$controller->handleRequest();
?>