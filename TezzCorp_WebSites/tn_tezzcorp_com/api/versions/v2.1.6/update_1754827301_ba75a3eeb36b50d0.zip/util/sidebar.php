<aside class="side-mini-panel with-vertical">
    <!-- ---------------------------------- -->
    <!-- Start Vertical Layout Sidebar -->
    <!-- ---------------------------------- -->
    <div class="iconbar">
        <div>
            <div class="mini-nav">
                <div class="brand-logo d-flex align-items-center justify-content-center">
                    <a class="nav-link sidebartoggler" id="headerCollapse" href="javascript:void(0)">
                        <iconify-icon icon="solar:hamburger-menu-line-duotone" class="fs-7"></iconify-icon>
                    </a>
                </div>
                <ul class="mini-nav-ul" data-simplebar>

                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Dashboards -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <li class="mini-nav-item" id="mini-1">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Dashboards">
                            <iconify-icon icon="solar:layers-line-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>

                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Students -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <li class="mini-nav-item" id="mini-2">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Students">
                            <iconify-icon icon="solar:users-group-two-rounded-outline" class="fs-7"></iconify-icon>
                        </a>
                    </li>
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Staff  -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <li class="mini-nav-item" id="mini-3">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Staff">
                            <iconify-icon icon="solar:users-group-two-rounded-line-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>

                    <li>
                        <span class="sidebar-divider lg"></span>
                    </li>
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Settings -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <li class="mini-nav-item" id="mini-4">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Settings">
                            <iconify-icon icon="solar:tuning-square-2-line-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Fees -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <li class="mini-nav-item" id="mini-5">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Fees">
                            <iconify-icon icon="solar:wallet-money-line-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Messages -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <li class="mini-nav-item" id="mini-6">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Messages">
                            <iconify-icon icon="solar:chat-square-code-line-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Reports -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <li class="mini-nav-item" id="mini-7">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Reports">
                            <iconify-icon icon="solar:cardholder-line-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>

                    <li>
                        <span class="sidebar-divider lg"></span>
                    </li>

                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Support -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <li class="mini-nav-item" id="mini-8">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Support">
                            <iconify-icon icon="solar:plain-bold-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>

                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Updates -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <li class="mini-nav-item" id="mini-9">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Updates">
                            <iconify-icon icon="solar:server-square-update-bold-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>
                </ul>

            </div>
            <div class="sidebarmenu">
                <div class="brand-logo d-flex align-items-center nav-logo">
                    <a href="/app/" class="text-nowrap logo-img">
                        <img src="assets/images/logos/logo.svg" alt="Logo" />
                    </a>

                </div>
                <!-- ---------------------------------- -->
                <!-- Dashboard -->
                <!-- ---------------------------------- -->
                <nav class="sidebar-nav" id="menu-right-mini-1" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <!-- ---------------------------------- -->
                        <!-- Home -->
                        <!-- ---------------------------------- -->
                        <li class="nav-small-cap">
                            <span class="hide-menu">Dashboards</span>
                        </li>
                        <!-- ---------------------------------- -->
                        <!-- Dashboard -->
                        <!-- ---------------------------------- -->
                        <!-- <li class="sidebar-item">
                            <a class="sidebar-link" href="/app/" id="get-url" aria-expanded="false">
                                <iconify-icon icon="solar:atom-line-duotone"></iconify-icon>
                                <span class="hide-menu">Dashboard 1</span>
                            </a>
                        </li>

                        <li class="sidebar-item">
                            <a class="sidebar-link" href="/app/index2" aria-expanded="false">
                                <iconify-icon icon="solar:chart-line-duotone"></iconify-icon>
                                <span class="hide-menu">Dashboard 2</span>
                            </a>
                        </li> -->

                        <li class="sidebar-item">
                            <a class="sidebar-link" href="/app/" id="get-url" aria-expanded="false">
                                <iconify-icon icon="solar:screencast-2-line-duotone"></iconify-icon>
                                <span class="hide-menu">Dashboard</span>
                            </a>
                        </li>

                        <li>
                            <span class="sidebar-divider"></span>
                        </li>

                        <li class="nav-small-cap">
                            <span class="hide-menu">Apps</span>
                        </li>

                        <li class="sidebar-item">
                            <a class="sidebar-link" href="/app/profile" aria-expanded="false">
                                <iconify-icon icon="solar:shield-user-line-duotone"></iconify-icon>
                                Profile
                            </a>
                        </li>
                        <!-- <li class="sidebar-item">
                            <a class="sidebar-link" href="/app/app-email.php"><iconify-icon
                                    icon="solar:letter-line-duotone"></iconify-icon>Email</a>
                        </li> -->
                        <!-- <li class="sidebar-item">
                            <a class="sidebar-link" href="/app/app-calendar.php"><iconify-icon
                                    icon="solar:calendar-mark-line-duotone"></iconify-icon>Calendar</a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="/app/app-chat.php"><iconify-icon
                                    icon="solar:chat-round-line-line-duotone"></iconify-icon>Chat</a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="/app/app-notes.php"><iconify-icon
                                    icon="solar:document-text-line-duotone"></iconify-icon>Notes</a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="/app/app-contact.php"><iconify-icon
                                    icon="solar:iphone-line-duotone"></iconify-icon>Contact Table</a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="/app/app-contact2.php"><iconify-icon
                                    icon="solar:phone-line-duotone"></iconify-icon>Contact List</a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="/app/app-invoice.php"><iconify-icon
                                    icon="solar:bill-list-line-duotone"></iconify-icon>Invoice</a>
                        </li> -->
                    </ul>
                </nav>

                <!-- ---------------------------------- -->
                <!-- Students -->
                <!-- ---------------------------------- -->
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-2" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <!-- ---------------------------------- -->
                        <!-- Home -->
                        <!-- ---------------------------------- -->
                        <li class="nav-small-cap">
                            <span class="hide-menu">Students</span>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/students/admission" class="sidebar-link">
                                <iconify-icon icon="solar:user-plus-rounded-line-duotone"></iconify-icon>
                                <span class="hide-menu">Admission</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/students/students" class="sidebar-link">
                                <iconify-icon icon="solar:users-group-two-rounded-line-duotone"></iconify-icon>
                                <span class="hide-menu">Students</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/students/attendance" class="sidebar-link">
                                <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Attendance</span>
                            </a>
                        </li>
                        <!-- <li class="sidebar-item">
                            <a href="/app/students/homework" class="sidebar-link">
                                <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Homework</span>
                            </a>
                        </li> -->
                        <li class="sidebar-item">
                            <a href="/app/students/set-results" class="sidebar-link">
                                <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Set Results</span>
                            </a>
                        </li>
                        <li class="sidebar-item" style="display: none;">
                            <a href="/app/students/view-student.php" class="sidebar-link">
                                <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                <span class="hide-menu">View Student Details</span>
                            </a>
                        </li>
                        <li class="sidebar-item" style="display: none;">
                            <a href="/app/students/edit-student.php" class="sidebar-link">
                                <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Edit Student Details</span>
                            </a>
                        </li>
                        <li>
                            <span class="sidebar-divider lg"></span>
                        </li>
                        <li class="nav-small-cap">
                            <span class="hide-menu">Generate</span>
                        </li>
                        <!-- <li class="sidebar-item">
                            <a href="/app/students/id-card" class="sidebar-link">
                                <iconify-icon icon="solar:user-id-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Identity Card</span>
                            </a>
                        </li> -->
                        <li class="sidebar-item">
                            <a href="/app/students/admit-card" class="sidebar-link">
                                <iconify-icon icon="solar:user-id-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Admit Card</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/students/report-card" class="sidebar-link">
                                <iconify-icon icon="solar:user-id-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Report Card</span>
                            </a>
                        </li>
                        <li>
                            <span class="sidebar-divider lg"></span>
                        </li>
                        <li class="nav-small-cap">
                            <span class="hide-menu">Reports</span>
                        </li>

                        <!-- ---------------------------------- -->
                        <!-- Widgets -->
                        <!-- ---------------------------------- -->
                        <li class="sidebar-item">
                            <a href="/app/students/attendance-report" class="sidebar-link">
                                <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Attendance</span>
                            </a>
                        </li>
                        <!-- <li class="sidebar-item">
                            <a href="/app/students/homework-report" class="sidebar-link">
                                <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Homework</span>
                            </a>
                        </li> -->
                        <!-- <li class="sidebar-item">
                            <a href="/app/students/results" class="sidebar-link">
                                <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Results</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/students/discipline" class="sidebar-link">
                                <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Discipline</span>
                            </a>
                        </li> -->

                    </ul>
                </nav>

                <!-- ---------------------------------- -->
                <!-- Staff -->
                <!-- ---------------------------------- -->
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-3" data-simplebar>
                    <div>
                        <ul class="sidebar-menu" id="sidebarnav">
                            <!-- ---------------------------------- -->
                            <!-- Home -->
                            <!-- ---------------------------------- -->
                            <li class="nav-small-cap">
                                <span class="hide-menu">Staff</span>
                            </li>
                            <li class="sidebar-item">
                                <a href="/app/staff/registration" class="sidebar-link">
                                    <iconify-icon icon="solar:user-plus-rounded-line-duotone"></iconify-icon>
                                    <span class="hide-menu">Registration</span>
                                </a>
                            </li>
                            <li class="sidebar-item">
                                <a href="/app/staff/staff" class="sidebar-link">
                                    <iconify-icon icon="solar:users-group-two-rounded-line-duotone"></iconify-icon>
                                    <span class="hide-menu">Staff</span>
                                </a>
                            </li>
                            <li class="sidebar-item" style="display: none;">
                                <a href="/app/staff/edit_staff.php" class="sidebar-link">
                                    <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                    <span class="hide-menu">Edit Staff Details</span>
                                </a>
                            </li>
                            <li class="sidebar-item">
                                <a href="/app/staff/attendance" class="sidebar-link">
                                    <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                    <span class="hide-menu">Attendance</span>
                                </a>
                            </li>

                            <!-- <li>
                                <span class="sidebar-divider lg"></span>
                            </li>
                            <li class="nav-small-cap">
                                <span class="hide-menu">Generate</span>
                            </li>
                            <li class="sidebar-item">
                                <a href="/app/staff/id-card" class="sidebar-link">
                                    <iconify-icon icon="solar:mask-happly-line-duotone"></iconify-icon>
                                    <span class="hide-menu">Identity Card</span>
                                </a>
                            </li> -->

                            <!-- <li>
                                <span class="sidebar-divider lg"></span>
                            </li>
                            <li class="nav-small-cap">
                                <span class="hide-menu">Payout</span>
                            </li>
                            <li class="sidebar-item">
                                <a href="/app/staff/salary" class="sidebar-link">
                                    <iconify-icon icon="solar:waterdrop-line-duotone"></iconify-icon>
                                    <span class="hide-menu">Salary</span>
                                </a>
                            </li> -->

                            <li>
                                <span class="sidebar-divider lg"></span>
                            </li>
                            <li class="nav-small-cap">
                                <span class="hide-menu">Reports</span>
                            </li>
                            <li class="sidebar-item">
                                <a href="/app/staff/attendance-report" class="sidebar-link">
                                    <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                    <span class="hide-menu">Attendance</span>
                                </a>
                            </li>
                            <!-- <li class="sidebar-item">
                                <a href="/app/staff/payout" class="sidebar-link">
                                    <iconify-icon icon="solar:shield-warning-line-duotone"></iconify-icon>
                                    <span class="hide-menu">Payout</span>
                                </a>
                            </li> -->

                        </ul>
                    </div>
                </nav>

                <!-- ---------------------------------- -->
                <!-- Settings -->
                <!-- ---------------------------------- -->
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-4" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <!-- ---------------------------------- -->
                        <!-- Home -->
                        <!-- ---------------------------------- -->
                        <li class="nav-small-cap">
                            <span class="hide-menu">School Settings</span>
                        </li>
                        <!-- ---------------------------------- -->
                        <!-- Dashboard -->
                        <!-- ---------------------------------- -->

                        <li class="sidebar-item">
                            <a href="/app/settings/timetable" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Timetable</span>
                            </a>
                        </li>
                        <!-- <li class="sidebar-item">
                            <a href="/app/settings/template" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Templates</span>
                            </a>
                        </li> -->
                        <!-- <li class="sidebar-item">
                            <a href="/app/settings/discipline" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Discipline</span>
                            </a>
                        </li> -->
                        <!-- <li class="sidebar-item">
                            <a href="/app/settings/events" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Events</span>
                            </a>
                        </li> -->
                        <li class="sidebar-item">
                            <a href="/app/settings/class" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Class</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/settings/class-teacher" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Class Teacher</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/settings/subject" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Subject</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/settings/subject-teacher" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Subject Teacher</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/settings/transport" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Transport</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/settings/student-form" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Student Form</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/settings/staff-form" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Staff Form</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/settings/site-settings" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Site Settings</span>
                            </a>
                        </li>
                    </ul>
                </nav>

                <!-- ---------------------------------- -->
                <!-- Fees -->
                <!-- ---------------------------------- -->
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-5" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <!-- ---------------------------------- -->
                        <!-- Home -->
                        <!-- ---------------------------------- -->
                        <li class="nav-small-cap">
                            <span class="hide-menu">Fees</span>
                        </li>
                        <!-- ---------------------------------- -->
                        <!-- Dashboard -->
                        <!-- ---------------------------------- -->

                        <li class="sidebar-item">
                            <a href="/app/fees/particulars" class="sidebar-link">
                                <iconify-icon icon="solar:money-bag-line-duotone"></iconify-icon>
                                <span class="hide-menu">Particulars</span>
                            </a>
                        </li>

                        <li class="sidebar-item">
                            <a href="/app/fees/structure" class="sidebar-link">
                                <iconify-icon icon="solar:money-bag-line-duotone"></iconify-icon>
                                <span class="hide-menu">Structure</span>
                            </a>
                        </li>

                        <li class="sidebar-item">
                            <a href="/app/fees/collection" class="sidebar-link">
                                <iconify-icon icon="solar:money-bag-line-duotone"></iconify-icon>
                                <span class="hide-menu">Collection</span>
                            </a>
                        </li>
                    </ul>
                </nav>

                <!-- ---------------------------------- -->
                <!-- Messages -->
                <!-- ---------------------------------- -->
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-6" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <!-- ---------------------------------- -->
                        <!-- Home -->
                        <!-- ---------------------------------- -->
                        <li class="nav-small-cap">
                            <span class="hide-menu">Messages</span>
                        </li>
                        <!-- ---------------------------------- -->
                        <!-- Dashboard -->
                        <!-- ---------------------------------- -->

                        <li class="sidebar-item">
                            <a href="/app/messages/whatsapp-api" class="sidebar-link">
                                <iconify-icon icon="solar:chat-line-line-duotone"></iconify-icon>
                                <span class="hide-menu">WhatsApp API</span>
                            </a>
                        </li>
                        <!-- <li class="sidebar-item">
                            <a href="/app/messages/message-api" class="sidebar-link">
                                <iconify-icon icon="solar:chat-line-line-duotone"></iconify-icon>
                                <span class="hide-menu">Message API</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/messages/wa-bulk-message" class="sidebar-link">
                                <iconify-icon icon="solar:chat-line-line-duotone"></iconify-icon>
                                <span class="hide-menu">WA Bulk Message</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/messages/bulk-message" class="sidebar-link">
                                <iconify-icon icon="solar:chat-line-line-duotone"></iconify-icon>
                                <span class="hide-menu">Bulk Message</span>
                            </a>
                        </li> -->
                    </ul>
                </nav>

                <!-- ---------------------------------- -->
                <!-- Reports -->
                <!-- ---------------------------------- -->
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-7" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <!-- ---------------------------------- -->
                        <!-- Home -->
                        <!-- ---------------------------------- -->
                        <li class="nav-small-cap">
                            <span class="hide-menu">Reports</span>
                        </li>
                        <!-- ---------------------------------- -->
                        <!-- Dashboard -->
                        <!-- ---------------------------------- -->
                        <li class="sidebar-item">
                            <a href="/app/reports/fee-report" class="sidebar-link">
                                <iconify-icon icon="solar:document-text-line-duotone"></iconify-icon>
                                <span class="hide-menu">Fee Report</span>
                            </a>
                        </li>
                        <!-- <li class="sidebar-item">
                            <a href="/app/reports/master-report" class="sidebar-link">
                                <iconify-icon icon="solar:document-text-line-duotone"></iconify-icon>
                                <span class="hide-menu">Master Report</span>
                            </a>
                        </li> -->
                    </ul>
                </nav>

                <!-- ---------------------------------- -->
                <!-- Support -->
                <!-- ---------------------------------- -->
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-8" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <li class="nav-small-cap">
                            <span class="hide-menu">Support</span>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/support/tickets" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Tickets</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/support/maintenance" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Maintenance</span>
                            </a>
                        </li>
                    </ul>
                </nav>

                <!-- ---------------------------------- -->
                <!-- Updates -->
                <!-- ---------------------------------- -->
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-9" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <li class="nav-small-cap">
                            <span class="hide-menu">Updates</span>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/updates/updater" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Updates</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</aside>