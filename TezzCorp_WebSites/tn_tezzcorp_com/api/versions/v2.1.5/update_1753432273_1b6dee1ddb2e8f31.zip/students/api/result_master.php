<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class ResultController {
    private $pdo;
    private $logger;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    // Send JSON error response with status
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode([
            'status' => 'error',
            'message' => $message
        ]);
        exit;
    }

    // Send JSON success response with status
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode(array_merge([
            'status' => 'success'
        ], $data));
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Log debug message
    private function logDebug(string $message): void {
        ($this->logger)('DEBUG: ' . $message);
    }

    // Validate input data
    private function validateInput(array $data): array {
        $errors = [];
        $validData = [];

        // Required fields
        $fields = [
            'uid' => ['type' => 'string', 'required' => true],
            'class_id' => ['type' => 'integer', 'min' => 1, 'required' => true],
            'session' => ['type' => 'string', 'max' => 20, 'required' => true],
            'term' => ['type' => 'enum', 'values' => ['1st Term', '2nd Term', '3rd Term'], 'required' => true],
            'newMarks' => ['type' => 'array', 'required' => false],
            'updatedMarks' => ['type' => 'array', 'required' => false]
        ];

        // Validate top-level fields
        foreach ($fields as $field => $rules) {
            if (isset($data[$field])) {
                $value = $data[$field];

                switch ($rules['type']) {
                    case 'string':
                        if (!is_string($value)) {
                            $errors[] = "$field must be a string";
                        } elseif (isset($rules['max']) && strlen($value) > $rules['max']) {
                            $errors[] = "$field exceeds maximum length of {$rules['max']} characters";
                        }
                        break;
                    case 'integer':
                        $value = filter_var($value, FILTER_VALIDATE_INT);
                        if ($value === false || $value < $rules['min']) {
                            $errors[] = "$field must be an integer >= {$rules['min']}";
                        }
                        break;
                    case 'enum':
                        if (!in_array($value, $rules['values'], true)) {
                            $errors[] = "$field must be one of: " . implode(', ', $rules['values']);
                        }
                        break;
                    case 'array':
                        if (!is_array($value)) {
                            $errors[] = "$field must be an array";
                        }
                        break;
                }

                $validData[$field] = $value;
            } elseif ($rules['required']) {
                $errors[] = "$field is required";
            }
        }

        // Validate marks arrays
        foreach (['newMarks', 'updatedMarks'] as $markType) {
            if (isset($validData[$markType]) && is_array($validData[$markType])) {
                foreach ($validData[$markType] as $index => $mark) {
                    if (!isset($mark['subject_id']) || !filter_var($mark['subject_id'], FILTER_VALIDATE_INT) || $mark['subject_id'] <= 0) {
                        $errors[] = "$markType[$index].subject_id must be a valid integer";
                    }
                    if (!isset($mark['marks_obtained']) || !filter_var($mark['marks_obtained'], FILTER_VALIDATE_INT) || $mark['marks_obtained'] < 0) {
                        $errors[] = "$markType[$index].marks_obtained must be a non-negative integer";
                    }
                    if (!isset($mark['max_marks']) || !filter_var($mark['max_marks'], FILTER_VALIDATE_INT) || $mark['max_marks'] <= 0) {
                        $errors[] = "$markType[$index].max_marks must be a positive integer";
                    }
                    if (isset($mark['marks_obtained']) && isset($mark['max_marks']) && $mark['marks_obtained'] > $mark['max_marks']) {
                        $errors[] = "$markType[$index].marks_obtained cannot exceed max_marks";
                    }
                }
            }
        }

        // Validate student and class exist
        if (isset($validData['uid'])) {
            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE uid = ?");
            $stmt->execute([$validData['uid']]);
            if (!$stmt->fetch()) {
                $errors[] = "Student with UID {$validData['uid']} does not exist";
            }
        }
        if (isset($validData['class_id'])) {
            $stmt = $this->pdo->prepare("SELECT id FROM class WHERE id = ?");
            $stmt->execute([$validData['class_id']]);
            if (!$stmt->fetch()) {
                $errors[] = "Class with ID {$validData['class_id']} does not exist";
            }
        }
        // Validate subjects exist
        $subjectIds = [];
        foreach (['newMarks', 'updatedMarks'] as $markType) {
            if (isset($validData[$markType])) {
                $subjectIds = array_merge($subjectIds, array_column($validData[$markType], 'subject_id'));
            }
        }
        if (!empty($subjectIds)) {
            $placeholders = array_fill(0, count($subjectIds), '?');
            $stmt = $this->pdo->prepare("SELECT id FROM subject WHERE id IN (" . implode(',', $placeholders) . ")");
            $stmt->execute($subjectIds);
            $existingSubjects = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $invalidSubjects = array_diff($subjectIds, $existingSubjects);
            if (!empty($invalidSubjects)) {
                $errors[] = "Invalid subject IDs: " . implode(', ', $invalidSubjects);
            }
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return $validData;
    }

    // Handle GET request to fetch results
    public function get() {
        $uid = isset($_GET['uid']) ? trim($_GET['uid']) : null;
        $class_id = isset($_GET['class_id']) ? filter_var($_GET['class_id'], FILTER_VALIDATE_INT) : null;
        $session = isset($_GET['session']) ? trim($_GET['session']) : null;
        $term = isset($_GET['term']) ? trim($_GET['term']) : null;
        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $perPage = isset($_GET['perPage']) ? max(1, (int)$_GET['perPage']) : 10;

        try {
            if ($uid) {
                // Fetch results for a single student
                $query = "
                    SELECT r.*, s.subject
                    FROM results r
                    JOIN subject s ON r.subject_id = s.id
                    WHERE r.uid = ?
                ";
                $params = [$uid];

                if ($class_id) {
                    $query .= " AND r.class_id = ?";
                    $params[] = $class_id;
                }
                if ($session) {
                    $query .= " AND r.session = ?";
                    $params[] = $session;
                }
                if ($term) {
                    $query .= " AND r.term = ?";
                    $params[] = $term;
                }

                $stmt = $this->pdo->prepare($query);
                $stmt->execute($params);
                $results = $stmt->fetchAll();

                $this->sendSuccess(200, ['data' => $results]);
            } else {
                // Fetch all results with pagination
                $offset = ($page - 1) * $perPage;
                $query = "
                    SELECT r.*, s.subject, st.full_name
                    FROM results r
                    JOIN subject s ON r.subject_id = s.id
                    JOIN students st ON r.uid = st.uid
                ";
                $countQuery = "SELECT COUNT(*) FROM results";
                $params = [];
                $countParams = [];

                $conditions = [];
                if ($class_id) {
                    $conditions[] = "r.class_id = ?";
                    $params[] = $class_id;
                    $countParams[] = $class_id;
                }
                if ($session) {
                    $conditions[] = "r.session = ?";
                    $params[] = $session;
                    $countParams[] = $session;
                }
                if ($term) {
                    $conditions[] = "r.term = ?";
                    $params[] = $term;
                    $countParams[] = $term;
                }

                if ($conditions) {
                    $query .= " WHERE " . implode(' AND ', $conditions);
                    $countQuery .= " WHERE " . implode(' AND ', $conditions);
                }

                $query .= " ORDER BY r.created_at DESC LIMIT ? OFFSET ?";
                $params[] = $perPage;
                $params[] = $offset;

                $stmt = $this->pdo->prepare($query);
                $stmt->execute($params);
                $results = $stmt->fetchAll();

                $countStmt = $this->pdo->prepare($countQuery);
                $countStmt->execute($countParams);
                $totalItems = (int)$countStmt->fetchColumn();
                $totalPages = max(1, ceil($totalItems / $perPage));

                $this->sendSuccess(200, [
                    'data' => $results,
                    'meta' => [
                        'page' => $page,
                        'totalPages' => $totalPages,
                        'totalItems' => $totalItems
                    ]
                ]);
            }
        } catch (Exception $e) {
            $this->logError('Failed to fetch results: ' . $e->getMessage());
            $this->sendError(500, 'Failed to fetch results: ' . $e->getMessage());
        }
    }

    // Handle POST request to create and update results
    public function post($data) {
        $validData = $this->validateInput($data);

        try {
            $this->pdo->beginTransaction();

            // Insert new marks
            if (!empty($validData['newMarks'])) {
                $sql = "
                    INSERT INTO results (uid, class_id, session, term, subject_id, marks_obtained, max_marks, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                ";
                $stmt = $this->pdo->prepare($sql);
                foreach ($validData['newMarks'] as $mark) {
                    $stmt->execute([
                        $validData['uid'],
                        $validData['class_id'],
                        $validData['session'],
                        $validData['term'],
                        $mark['subject_id'],
                        $mark['marks_obtained'],
                        $mark['max_marks']
                    ]);
                }
            }

            // Update existing marks
            if (!empty($validData['updatedMarks'])) {
                $sql = "
                    UPDATE results
                    SET marks_obtained = ?, max_marks = ?, updated_at = NOW()
                    WHERE uid = ? AND class_id = ? AND session = ? AND term = ? AND subject_id = ?
                ";
                $stmt = $this->pdo->prepare($sql);
                foreach ($validData['updatedMarks'] as $mark) {
                    $stmt->execute([
                        $mark['marks_obtained'],
                        $mark['max_marks'],
                        $validData['uid'],
                        $validData['class_id'],
                        $validData['session'],
                        $validData['term'],
                        $mark['subject_id']
                    ]);
                }
            }

            $this->pdo->commit();
            $this->logDebug('Results processed successfully for UID: ' . $validData['uid']);
            $this->sendSuccess(201, ['message' => 'Marks saved successfully']);
        } catch (Exception $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to save results: ' . $e->getMessage());
            $this->sendError(500, 'Failed to save results: ' . $e->getMessage());
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $data = json_decode(file_get_contents('php://input'), true) ?: [];

        switch ($method) {
            case 'GET':
                $this->get();
                break;
            case 'POST':
                $this->post($data);
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new ResultController();
$controller->handleRequest();
?>