<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// StudentDataManager class to fetch student information
class StudentDataManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function getStudentData($user_id) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT s.id, s.full_name, s.roll_no, c.class_name, d.student_photo
                 FROM students s
                 LEFT JOIN class c ON s.class = c.id
                 LEFT JOIN documents d ON s.uid = d.uid
                 WHERE s.id = :id AND s.status = "active"'
            );
            $stmt->execute([':id' => $user_id]);
            return $stmt->fetch() ?: null;
            print_r($stmt);
        } catch (PDOException $e) {
            error_log('Student data fetch failed: ' . $e->getMessage());
            return null;
        }
    }
}

// StatsManager class to fetch academic stats
class StatsManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function getStats($user_id) {
        try {
            // 1. Get student's class + uid
            $stmt = $this->pdo->prepare('SELECT class, uid FROM students WHERE id = :id');
            $stmt->execute([':id' => $user_id]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$student) {
                return ['attendance' => 0, 'grade' => 0, 'pending_tasks' => 0];
            }

            $class_id = $student['class'];
            $uid      = $student['uid'];

            // 2. Query for stats
            $stmt = $this->pdo->prepare(
                'SELECT 
                    -- Attendance %
                    COALESCE(
                        (SELECT 
                            (SUM(CASE WHEN status = "present" THEN 1 ELSE 0 END) * 100.0) / 
                            NULLIF(COUNT(*), 0) 
                         FROM student_attendance 
                         WHERE student_id = :user_id), 
                    0) AS attendance,

                    -- Grade %
                    COALESCE(
                        (SELECT AVG((marks_obtained * 100.0) / NULLIF(max_marks, 0)) 
                         FROM results 
                         WHERE uid = :uid), 
                    0) AS grade,

                    -- Pending homework count
                    COALESCE(
                        (SELECT COUNT(*) 
                         FROM homework 
                         WHERE class = :class_id AND status = "pending"), 
                    0) AS pending_tasks'
            );

            $stmt->execute([
                ':user_id'  => $user_id,  // for attendance
                ':uid'      => $uid,      // for grades
                ':class_id' => $class_id  // for homework
            ]);

            return $stmt->fetch(PDO::FETCH_ASSOC) ?: ['attendance' => 0, 'grade' => 0, 'pending_tasks' => 0];

        } catch (PDOException $e) {
            error_log('Stats fetch failed: ' . $e->getMessage());
            return ['attendance' => 0, 'grade' => 0, 'pending_tasks' => 0];
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);
$studentDataManager = new StudentDataManager($pdo);
$statsManager = new StatsManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch data
$student = $studentDataManager->getStudentData($_SESSION['user_id']);
$stats = $statsManager->getStats($_SESSION['user_id']);

// Prepare student data
$full_name = $student ? htmlspecialchars($student['full_name'] ?: 'Unknown') : 'Unknown';
$class = $student ? htmlspecialchars($student['class_name'] ?: 'N/A') : 'N/A';
$roll_no = $student ? htmlspecialchars($student['roll_no'] ?: 'N/A') : 'N/A';
$initials = $student && $student['full_name'] ? htmlspecialchars(substr(strtoupper(implode('', array_map(function($n) { return $n[0]; }, explode(' ', $student['full_name'])))), 0, 2)) : 'JS';
$student_photo = ($student['student_photo'] ?: $initials);

// Prepare stats data
$attendance = isset($stats['attendance']) ? round(floatval($stats['attendance']), 1) : 0;
$grade = isset($stats['grade']) ? round(floatval($stats['grade']), 1) : 0;
$pending_tasks = isset($stats['pending_tasks']) ? intval($stats['pending_tasks']) : 0;

// Fetch site settings
try {
    $stmt = $pdo->prepare('SELECT school_name, facebook_url, twitter_url, instagram_url, linkedin_url FROM site_settings WHERE id = 1');
    $stmt->execute();
    $settings = $stmt->fetch();
    
    if (!$settings) {
        $settings = [
            'school_name' => 'EduConnect',
            'facebook_url' => '#',
            'twitter_url' => '#',
            'instagram_url' => '#',
            'linkedin_url' => '#'
        ];
    }
} catch (PDOException $e) {
    error_log('Failed to fetch site settings: ' . $e->getMessage());
    $settings = [
        'school_name' => 'EduConnect',
        'facebook_url' => '#',
        'twitter_url' => '#',
        'instagram_url' => '#',
        'linkedin_url' => '#'
    ];
}

$school_name = htmlspecialchars($settings['school_name']);
$facebook_url = htmlspecialchars($settings['facebook_url']);
$twitter_url = htmlspecialchars($settings['twitter_url']);
$instagram_url = htmlspecialchars($settings['instagram_url']);
$linkedin_url = htmlspecialchars($settings['linkedin_url']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <title><?php echo $school_name; ?> - Dashboard</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header-title {
            font-size: 24px;
        }
        
        .header-actions {
            display: flex;
            gap: 15px;
        }
        
        .header-icon {
            font-size: 20px;
            cursor: pointer;
        }
        
        .user-welcome {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .user-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: 600;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .user-role {
            font-size: 14px;
            color: var(--light-text);
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
        }
        
        .quick-action {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 15px 10px;
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: var(--transition);
            cursor: pointer;
            height: 100%;
        }
        
        .quick-action:hover, .quick-action:active {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }
        
        .quick-action-icon {
            width: 50px;
            height: 50px;
            margin-bottom: 12px;
            color: var(--primary-color);
            font-size: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(0, 85, 164, 0.1);
            border-radius: 50%;
            padding: 12px;
        }
        
        .quick-action-name {
            font-size: 13px;
            font-weight: 500;
            color: var(--text-color);
            line-height: 1.3;
        }
        
        .upcoming-events {
            margin-top: 15px;
        }
        
        .event-item {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .event-item:last-child {
            border-bottom: none;
        }
        
        .event-date {
            width: 50px;
            height: 60px;
            background-color: var(--primary-color);
            color: white;
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
        }
        
        .event-day {
            font-size: 20px;
            font-weight: 600;
        }
        
        .event-month {
            font-size: 12px;
            text-transform: uppercase;
        }
        
        .event-details {
            flex: 1;
        }
        
        .event-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .event-time {
            font-size: 13px;
            color: var(--light-text);
            display: flex;
            align-items: center;
        }
        
        .event-time i {
            margin-right: 5px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        
        .stat-card {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: rgba(0, 85, 164, 0.1);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-right: 15px;
        }
        
        .stat-info {
            flex: 1;
        }
        
        .stat-value {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 14px;
            color: var(--light-text);
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        .ripple {
            position: relative;
            overflow: hidden;
        }
        
        .ripple:after {
            content: "";
            display: block;
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            pointer-events: none;
            background-image: radial-gradient(circle, #fff 10%, transparent 10.01%);
            background-repeat: no-repeat;
            background-position: 50%;
            transform: scale(10, 10);
            opacity: 0;
            transition: transform .5s, opacity 1s;
        }
        
        .ripple:active:after {
            transform: scale(0, 0);
            opacity: .3;
            transition: 0s;
        }
        
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        @media (max-width: 480px) {
            .quick-actions {
                grid-template-columns: repeat(4, 1fr);
                gap: 10px;
            }
            
            .quick-action {
                padding: 10px 5px;
            }
            
            .quick-action-icon {
                width: 40px;
                height: 40px;
                font-size: 20px;
                margin-bottom: 8px;
            }
            
            .quick-action-name {
                font-size: 11px;
            }
            
            .section-title {
                font-size: 20px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 360px) {
            .quick-actions {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <div class="header-title">Dashboard</div>
        <div class="header-actions">
            <i class="fas fa-bell header-icon" id="notification"></i>
        </div>
    </div>
    
    <div class="user-welcome">
        <div class="user-avatar">
            <img style="width: 60px; height: 60px; border-radius: 50%;" src="/<?php echo $student_photo ?>" alt="<?php echo $full_name ?>">
        </div>
        <div class="user-info">
            <div class="user-name"><?php echo $full_name; ?></div>
            <div class="user-role">Class: <?php echo $class; ?> • Roll No: <?php echo $roll_no; ?></div>
        </div>
    </div>
    
    <div class="section">
        <div class="section-title">Quick Actions</div>
        <div class="quick-actions">
            <div class="quick-action ripple" id="homework-action">
                <div class="quick-action-icon">
                    <i class="fas fa-book-open"></i>
                </div>
                <div class="quick-action-name">Homework</div>
            </div>
            <div class="quick-action ripple" id="teachers-action">
                <div class="quick-action-icon">
                    <i class="fas fa-chalkboard-teacher"></i>
                </div>
                <div class="quick-action-name">Teachers</div>
            </div>
            <div class="quick-action ripple" id="timetable-action">
                <div class="quick-action-icon">
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <div class="quick-action-name">Time Table</div>
            </div>
            <div class="quick-action ripple" id="payfee-action">
                <div class="quick-action-icon">
                    <i class="fas fa-credit-card"></i>
                </div>
                <div class="quick-action-name">Pay Fee</div>
            </div>
        </div>
    </div>
    
    <div class="section">
        <div class="section-title">Academic Stats</div>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-value"><?php echo $attendance; ?>%</div>
                    <div class="stat-label">Attendance</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-trophy"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-value"><?php echo $grade; ?>%</div>
                    <div class="stat-label">Overall Grade</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-tasks"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-value"><?php echo $pending_tasks; ?></div>
                    <div class="stat-label">Pending Tasks</div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="footer">
        <a href="index.php" class="footer-item active ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="fee_dues.php" class="footer-item ripple">
            <i class="fas fa-inr footer-icon"></i>
            <span class="footer-text">Fees</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loader = document.getElementById('loader');
            
            // Hide loader after page load
            loader.style.opacity = '0';
            setTimeout(() => {
                loader.style.display = 'none';
                loader.style.opacity = '1';
            }, 300);
            
            // Prevent zooming on double tap
            document.addEventListener('dblclick', function(e) {
                e.preventDefault();
            });
            
            // Add touch feedback and loader for quick actions
            const quickActions = document.querySelectorAll('.quick-action');
            quickActions.forEach(action => {
                action.addEventListener('touchstart', function() {
                    this.style.backgroundColor = 'rgba(0, 85, 164, 0.05)';
                });
                
                action.addEventListener('touchend', function() {
                    this.style.backgroundColor = 'white';
                });
            });
            
            // Show loader on navigation
            document.getElementById('homework-action').addEventListener('click', function() {
                loader.style.display = 'flex';
                window.location.href = 'homework.php';
            });
            
            document.getElementById('notification').addEventListener('click', function() {
                loader.style.display = 'flex';
                window.location.href = 'notifications.php';
            });
            
            document.getElementById('teachers-action').addEventListener('click', function() {
                loader.style.display = 'flex';
                window.location.href = 'teachers.php';
            });
            
            document.getElementById('timetable-action').addEventListener('click', function() {
                loader.style.display = 'flex';
                window.location.href = 'timetable.php';
            });
            
            document.getElementById('payfee-action').addEventListener('click', function() {
                loader.style.display = 'flex';
                window.location.href = 'fee_dues.php';
            });
        });
    </script>
</body>
</html>