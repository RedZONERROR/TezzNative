<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Student class to handle operations
class Student {
    private $pdo;
    private $user_id;

    public function __construct(PDO $pdo, $user_id) {
        $this->pdo = $pdo;
        $this->user_id = $user_id;
    }

    public function getStudentDetails() {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT s.id, s.full_name, s.father_name, s.mother_name, s.mobile_number, s.date_of_birth, s.residential_address, s.roll_no, c.class_name, d.student_photo
                 FROM students s
                 LEFT JOIN class c ON s.class = c.id
                 LEFT JOIN documents d ON s.uid = d.uid
                 WHERE s.id = :id AND s.status = "active"'
            );
            $stmt->execute([':id' => $this->user_id]);
            return $stmt->fetch() ?: [];
        } catch (PDOException $e) {
            error_log('Student details fetch failed: ' . $e->getMessage());
            return [];
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Initialize Student manager
$studentManager = new Student($pdo, $_SESSION['user_id']);

// Fetch student details
$student = $studentManager->getStudentDetails();

// If no student data is found, redirect to login
if (empty($student)) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Prepare student data
$full_name = $student ? htmlspecialchars($student['full_name'] ?: 'Unknown') : 'Unknown';
$father_name = $student ? htmlspecialchars($student['father_name'] ?: 'Unknown') : 'Unknown';
$mother_name = $student ? htmlspecialchars($student['mother_name'] ?: 'Unknown') : 'Unknown';
$mobile_number = $student ? htmlspecialchars($student['mobile_number'] ?: 'Unknown') : 'Unknown';
$residential_address = $student ? htmlspecialchars($student['residential_address'] ?: 'Unknown') : 'Unknown';
$date_of_birth = $student ? htmlspecialchars($student['date_of_birth'] ?: 'Unknown') : 'Unknown';
$class = $student ? htmlspecialchars($student['class_name'] ?: 'N/A') : 'N/A';
$roll_no = $student ? htmlspecialchars($student['roll_no'] ?: 'N/A') : 'N/A';
$initials = $student && $student['full_name'] ? htmlspecialchars(substr(strtoupper(implode('', array_map(function($n) { return $n[0]; }, explode(' ', $student['full_name'])))), 0, 2)) : 'JS';
$student_photo = ($student['student_photo'] ?: $initials);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Educational App - Account</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px; /* Space for fixed footer */
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .profile-section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .profile-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            font-weight: 600;
            margin-bottom: 15px;
        }
        
        .profile-name {
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .profile-role {
            font-size: 16px;
            color: var(--light-text);
            margin-bottom: 15px;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .info-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .info-item:last-child {
            border-bottom: none;
            padding-bottom: 0;
        }
        
        .info-label {
            font-size: 16px;
            color: var(--light-text);
        }
        
        .info-value {
            font-size: 16px;
            font-weight: 500;
            text-align: right;
        }
        
        .action-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .action-item {
            display: flex;
            align-items: center;
            padding: 15px;
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: var(--transition);
            cursor: pointer;
        }
        
        .action-item:hover, .action-item:active {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }
        
        .action-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(0, 85, 164, 0.1);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-right: 15px;
        }
        
        .action-text {
            flex: 1;
            font-size: 16px;
            font-weight: 500;
        }
        
        .action-arrow {
            color: var(--light-text);
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .profile-avatar {
                width: 80px;
                height: 80px;
                font-size: 30px;
            }
            
            .profile-name {
                font-size: 20px;
            }
            
            .profile-role {
                font-size: 14px;
            }
            
            .section-title {
                font-size: 20px;
            }
            
            .info-label, .info-value {
                font-size: 15px;
            }
            
            .action-text {
                font-size: 15px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">Account</div>
    
    <div class="profile-section">
        <div class="profile-avatar">
            <img style="width: 80px; height: 80px; border-radius: 50%;" src="/<?php echo htmlspecialchars($student_photo); ?>" alt="Photo">
        </div>
        <div class="profile-name"><?php echo htmlspecialchars($student['full_name']); ?></div>
        <div class="profile-role">Class: <?php echo $class; ?> • Roll No: <?php echo $roll_no; ?></div>
    </div>
    
    <div class="section">
        <div class="section-title">Personal Information</div>
        <div class="info-list">
            <div class="info-item">
                <div class="info-label">Father's Name:</div>
                <div class="info-value"><?php echo $father_name; ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Mother's Name:</div>
                <div class="info-value"><?php echo $mother_name; ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Mobile:</div>
                <div class="info-value"><?php echo $mobile_number; ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Date of Birth:</div>
                <div class="info-value"><?php echo $date_of_birth; ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Address:</div>
                <div class="info-value"><?php echo $residential_address; ?></div>
            </div>
        </div>
    </div>
    
    <div class="section">
        <div class="section-title">Account Settings</div>
        <div class="action-list">
            <div class="action-item" id="logout">
                <div class="action-icon">
                    <i class="fas fa-sign-out-alt"></i>
                </div>
                <div class="action-text">Logout</div>
                <div class="action-arrow">
                    <i class="fas fa-chevron-right"></i>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="fee_dues.php" class="footer-item ripple">
            <i class="fas fa-inr footer-icon"></i>
            <span class="footer-text">Fees</span>
        </a>
        <a href="account.php" class="footer-item active ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            document.getElementById('logout').addEventListener('click', function() {
                showLoader();
                window.location.href = '../logout.php';
            });

            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }

            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>