<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Homework class to handle operations
class Homework {
    private $pdo;
    private $user_id;

    public function __construct(PDO $pdo, $user_id) {
        $this->pdo = $pdo;
        $this->user_id = $user_id;
    }

    public function getStudentClass() {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT class FROM students 
                WHERE id = :id AND status = "active"'
            );
            $stmt->execute([':id' => $this->user_id]);
            $student = $stmt->fetch();
            return $student ? $student['class'] : null;
        } catch (PDOException $e) {
            error_log('Student class fetch failed: ' . $e->getMessage());
            return null;
        }
    }

    public function getHomework($filter = 'all') {
        try {
            $student_class = $this->getStudentClass();
            if (!$student_class) {
                return [];
            }

            // Base query
            $sql = "
                SELECT 
                    h.*,
                    c.class_name
                FROM homework h
                LEFT JOIN class_master c ON h.class = c.id
                WHERE h.class = :class
            ";

            // Apply filter
            $params = [':class' => $student_class];
            if ($filter === 'pending') {
                $sql .= " AND h.status = 'pending'";
            } elseif ($filter === 'completed') {
                $sql .= " AND h.status = 'completed'";
            } elseif ($filter === 'overdue') {
                $sql .= " AND h.status = 'pending' AND h.date < CURDATE()";
            }

            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll() ?: [];
        } catch (PDOException $e) {
            error_log('Homework fetch failed: ' . $e->getMessage());
            return [];
        }
    }

    public function markComplete($homework_id, $teacher_id) {
        try {
            // Update homework status (we can add teacher_id logging here if the table supports it)
            $stmt = $this->pdo->prepare(
                "UPDATE homework SET status = 'completed' WHERE id = :id"
            );
            $stmt->execute([':id' => $homework_id]);
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log('Homework update failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Initialize Homework manager
$homeworkManager = new Homework($pdo, $_SESSION['user_id']);

// Handle Mark Complete action (only for teachers)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'mark_complete') {
    if ($_SESSION['user_type'] !== 'teacher') {
        echo '<div class="section"><div class="empty-state"><div class="empty-icon"><i class="fas fa-exclamation-circle"></i></div><div class="empty-text">Only teachers can mark homework as complete.</div></div></div>';
        exit;
    }

    $homework_id = isset($_POST['homework_id']) ? intval($_POST['homework_id']) : 0;
    $filter = isset($_POST['filter']) ? htmlspecialchars($_POST['filter']) : 'all';

    if ($homework_id > 0) {
        $success = $homeworkManager->markComplete($homework_id, $_SESSION['user_id']);
        if ($success) {
            header("Location: homework.php?filter=$filter");
            exit;
        } else {
            echo '<div class="section"><div class="empty-state"><div class="empty-icon"><i class="fas fa-exclamation-circle"></i></div><div class="empty-text">Failed to mark homework as complete.</div></div></div>';
        }
    }
}

// Get filter from query parameter
$filter = isset($_GET['filter']) ? htmlspecialchars($_GET['filter']) : 'all';

// Fetch homework data
$homeworkList = $homeworkManager->getHomework($filter);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Educational App - Homework</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px; /* Space for fixed footer */
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header-title {
            font-size: 24px;
        }
        
        .header-actions {
            display: flex;
            gap: 15px;
        }
        
        .header-icon {
            font-size: 20px;
            cursor: pointer;
        }
        
        .back-button {
            margin-right: 10px;
            cursor: pointer;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .homework-filters {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            overflow-x: auto;
            padding-bottom: 10px;
        }
        
        .filter-button {
            background-color: var(--secondary-color);
            border: none;
            border-radius: 20px;
            padding: 8px 15px;
            font-size: 14px;
            font-weight: 500;
            color: var(--text-color);
            cursor: pointer;
            white-space: nowrap;
            transition: var(--transition);
        }
        
        .filter-button.active {
            background-color: var(--primary-color);
            color: white;
        }
        
        .homework-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .homework-item {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            border-left: 4px solid var(--primary-color);
            transition: var(--transition);
        }
        
        .homework-item.completed {
            border-left-color: #28a745;
        }
        
        .homework-item.overdue {
            border-left-color: #dc3545;
        }
        
        .homework-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 10px;
        }
        
        .homework-subject {
            font-size: 18px;
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .homework-status {
            font-size: 12px;
            padding: 4px 8px;
            border-radius: 12px;
            font-weight: 500;
        }
        
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-completed {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-overdue {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .homework-details {
            margin-bottom: 10px;
        }
        
        .homework-description {
            font-size: 14px;
            color: var(--light-text);
            margin-bottom: 10px;
        }
        
        .homework-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 13px;
            color: var(--light-text);
        }
        
        .homework-date {
            display: flex;
            align-items: center;
        }
        
        .homework-date i {
            margin-right: 5px;
        }
        
        .homework-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 10px;
        }
        
        .action-button {
            background-color: var(--secondary-color);
            border: none;
            border-radius: var(--border-radius);
            padding: 8px 15px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .action-button.primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .action-button:hover {
            opacity: 0.9;
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Empty state */
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
            text-align: center;
        }
        
        .empty-icon {
            font-size: 50px;
            color: #ccc;
            margin-bottom: 15px;
        }
        
        .empty-text {
            font-size: 16px;
            color: var(--light-text);
            margin-bottom: 20px;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }
            
            .homework-subject {
                font-size: 16px;
            }
            
            .homework-title {
                font-size: 15px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <div class="header-title">
            <i class="fas fa-arrow-left back-button" id="back-button"></i>
            Homework
        </div>
        <div class="header-actions">
            <i class="fas fa-search header-icon"></i>
            <i class="fas fa-filter header-icon"></i>
        </div>
    </div>

    <div class="section">
        <div class="homework-filters">
            <a href="homework.php?filter=all" class="filter-button <?php echo $filter === 'all' ? 'active' : ''; ?>">All</a>
            <a href="homework.php?filter=pending" class="filter-button <?php echo $filter === 'pending' ? 'active' : ''; ?>">Pending</a>
            <a href="homework.php?filter=completed" class="filter-button <?php echo $filter === 'completed' ? 'active' : ''; ?>">Completed</a>
            <a href="homework.php?filter=overdue" class="filter-button <?php echo $filter === 'overdue' ? 'active' : ''; ?>">Overdue</a>
        </div>
        
        <div class="homework-list" id="homework-list">
            <?php if (empty($homeworkList)): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <div class="empty-text">No homework found for this filter.</div>
                </div>
            <?php else: ?>
                <?php foreach ($homeworkList as $homework): ?>
                    <?php
                    // Determine status
                    $status = $homework['status'];
                    if ($status === 'pending' && strtotime($homework['date']) < strtotime(date('Y-m-d'))) {
                        $status = 'overdue';
                    }

                    // Determine status class and text
                    $statusClass = '';
                    $statusText = '';
                    if ($status === 'completed') {
                        $statusClass = 'status-completed';
                        $statusText = 'Completed';
                    } elseif ($status === 'overdue') {
                        $statusClass = 'status-overdue';
                        $statusText = 'Overdue';
                    } else {
                        $statusClass = 'status-pending';
                        $statusText = 'Pending';
                    }
                    ?>
                    <div class="homework-item <?php echo htmlspecialchars($status); ?>">
                        <div class="homework-header">
                            <div class="homework-subject"><?php echo htmlspecialchars($homework['subject']); ?></div>
                            <div class="homework-status <?php echo htmlspecialchars($statusClass); ?>"><?php echo htmlspecialchars($statusText); ?></div>
                        </div>
                        <div class="homework-details">
                            <div class="homework-description"><?php echo htmlspecialchars($homework['description']); ?></div>
                        </div>
                        <div class="homework-meta">
                            <div class="homework-date">
                                <i class="far fa-calendar-alt"></i> Due: <?php echo htmlspecialchars($homework['date']); ?>
                            </div>
                        </div>
                        <div class="homework-actions">
                            <a style="text-decoration: none;" href="https://www.swamivivekanandnationalschool.in/home-work/<?php echo htmlspecialchars($homework['work']); ?>" class="action-button" download>
                                <i class="far fa-eye"></i> View
                            </a>
                            <?php if ($_SESSION['user_type'] === 'teacher' && $status !== 'completed'): ?>
                                <form method="POST" action="homework.php">
                                    <input type="hidden" name="action" value="mark_complete">
                                    <input type="hidden" name="homework_id" value="<?php echo htmlspecialchars($homework['id']); ?>">
                                    <input type="hidden" name="filter" value="<?php echo htmlspecialchars($filter); ?>">
                                    <button type="submit" class="action-button primary">
                                        <i class="fas fa-check"></i> Mark Complete
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="fee_dues.php" class="footer-item ripple">
            <i class="fas fa-inr footer-icon"></i>
            <span class="footer-text">Fees</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            // Back button functionality
            document.getElementById('back-button').addEventListener('click', function() {
                showLoader();
                window.location.href = 'index.php';
            });
            
            // Filter buttons functionality - already handled via <a> tags, just add loader
            const filterButtons = document.querySelectorAll('.filter-button');
            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    showLoader();
                });
            });

            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }

            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>