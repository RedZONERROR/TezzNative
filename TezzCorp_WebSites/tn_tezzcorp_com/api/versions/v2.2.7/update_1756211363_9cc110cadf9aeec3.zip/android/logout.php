<?php
// Start session
session_start();

// Include database connection
include '../conn.php';

// Get session data from multiple sources
$sessionToken = '';
$userId = '';
$userType = '';

// Check POST parameters first
if (isset($_POST['session_token'])) {
    $sessionToken = $_POST['session_token'];
    $userId = $_POST['user_id'] ?? '';
    $userType = $_POST['user_type'] ?? '';
}

// Check JSON POST data
if (empty($sessionToken)) {
    $postData = json_decode(file_get_contents('php://input'), true);
    if (isset($postData['session_token'])) {
        $sessionToken = $postData['session_token'];
        $userId = $postData['user_id'] ?? '';
        $userType = $postData['user_type'] ?? '';
    }
}

// Check cookies
if (empty($sessionToken) && isset($_COOKIE['session_token'])) {
    $sessionToken = $_COOKIE['session_token'];
    $userId = $_COOKIE['user_id'] ?? '';
    $userType = $_COOKIE['user_type'] ?? '';
}

// Check session
if (empty($sessionToken) && isset($_SESSION['session_token'])) {
    $sessionToken = $_SESSION['session_token'];
    $userId = $_SESSION['user_id'] ?? '';
    $userType = $_SESSION['user_type'] ?? '';
}

try {
    // Delete session from database if we have the necessary data
    if (!empty($sessionToken) && !empty($userId)) {
        if (!empty($userType)) {
            $query = "DELETE FROM user_sessions WHERE user_id = ? AND user_type = ? AND session_token = ?";
            $stmt = $con->prepare($query);
            $stmt->bind_param("iss", $userId, $userType, $sessionToken);
        } else {
            $query = "DELETE FROM user_sessions WHERE user_id = ? AND session_token = ?";
            $stmt = $con->prepare($query);
            $stmt->bind_param("is", $userId, $sessionToken);
        }
        $stmt->execute();
        $stmt->close();
    }

    // Clear all PHP session data
    $_SESSION = [];

    // Destroy the session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // Destroy the session
    session_destroy();

    // Clear all cookies
    $paths = ['/', '/app', ''];
    foreach ($paths as $path) {
        setcookie('session_token', '', time() - 3600, $path);
        setcookie('user_id', '', time() - 3600, $path);
        setcookie('user_type', '', time() - 3600, $path);
        setcookie('user_name', '', time() - 3600, $path);
    }

    // ✅ Return SweetAlert2 + redirect (mobile friendly)
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <style>
            /* SweetAlert mobile overrides */
            .swal2-popup {
                font-size: 1rem !important;
                width: 90% !important;
                max-width: 400px;
            }
            .swal2-title {
                font-size: 1.3rem !important;
            }
            .swal2-confirm {
                font-size: 1rem !important;
                padding: 10px 20px !important;
                border-radius: 8px !important;
            }
        </style>
    </head>
    <body>
        <script>
            // Clear localStorage + sessionStorage
            sessionStorage.clear();
            localStorage.clear();

            Swal.fire({
                title: 'Logged Out',
                text: 'You have been logged out successfully.',
                icon: 'success',
                confirmButtonText: 'OK',
                allowOutsideClick: false
            }).then(() => {
                window.location.href = 'index.php';
            });
        </script>
    </body>
    </html>
    <?php

} catch (Exception $e) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </head>
    <body>
        <script>
            Swal.fire({
                title: 'Error',
                text: <?= json_encode("An error occurred: " . $e->getMessage()); ?>,
                icon: 'error',
                confirmButtonText: 'OK'
            }).then(() => {
                window.location.href = 'index.php';
            });
        </script>
    </body>
    </html>
    <?php
}

// Close connection
$con->close();
?>