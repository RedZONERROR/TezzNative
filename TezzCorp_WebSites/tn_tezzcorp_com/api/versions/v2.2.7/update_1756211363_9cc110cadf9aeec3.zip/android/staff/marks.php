<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM staff WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'staff')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'staff';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            error_log('Session validation failed: Invalid user or cookie data');
            header("Location: /android/");
            exit;
        }
    } else {
        error_log('Session validation failed: Missing session token or user ID');
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    error_log('Session validation failed: Invalid or expired session token');
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch class ID for the teacher
try {
    $stmt = $pdo->prepare(
        'SELECT class 
         FROM class_teacher 
         WHERE tid = :tid AND status = "active"'
    );
    $stmt->execute([':tid' => $_SESSION['user_id']]);
    $class_id = $stmt->fetchColumn();
    
    if ($class_id === false || $class_id <= 0) {
        error_log('No active class found for teacher ID: ' . $_SESSION['user_id']);
        header("Location: index.php");
        exit;
    }
    error_log('Class ID fetched: ' . $class_id);
} catch (PDOException $e) {
    error_log('Failed to fetch class ID: ' . $e->getMessage());
    header("Location: index.php");
    exit;
}

// Fetch class details
$class_name = 'N/A'; // Fallback if class_name is not found
try {
    $stmt = $pdo->prepare(
        'SELECT class_name 
         FROM class 
         WHERE id = :id AND status = "active"'
    );
    $stmt->execute([':id' => $class_id]);
    $class = $stmt->fetch();
    
    if ($class && !empty($class['class_name'])) {
        $class_name = htmlspecialchars($class['class_name']);
        error_log('Class name fetched: ' . $class_name);
    } else {
        error_log('No active class found for class ID: ' . $class_id);
        header("Location: classes.php");
        exit;
    }
} catch (PDOException $e) {
    error_log('Failed to fetch class details: ' . $e->getMessage());
    header("Location: classes.php");
    exit;
}

// Fetch teacher's role for this class
$teacher_role = [];
try {
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) 
         FROM class_teacher 
         WHERE tid = :tid AND class = :class_id AND status = "active"'
    );
    $stmt->execute([':tid' => $_SESSION['user_id'], ':class_id' => $class_id]);
    $class_teacher_count = $stmt->fetchColumn();
    
    if ($class_teacher_count > 0) {
        $teacher_role = ['details' => 'Class Teacher'];
        error_log('Teacher role: Class Teacher for class ID: ' . $class_id);
    } else {
        $stmt = $pdo->prepare(
            'SELECT subject
             FROM subject_teacher 
             WHERE tid = :tid AND class = :class_id'
        );
        $stmt->execute([':tid' => $_SESSION['user_id'], ':class_id' => $class_id]);
        $subject_teacher = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($subject_teacher) {
            $teacher_role = ['details' => $subject_teacher['subject']];
            error_log('Teacher role: Subject Teacher (' . $subject_teacher['subject'] . ') for class ID: ' . $class_id);
        }
    }
    
    if (empty($teacher_role)) {
        error_log('No teacher role found for teacher ID: ' . $_SESSION['user_id'] . ', class ID: ' . $class_id);
        header("Location: classes.php");
        exit;
    }
} catch (PDOException $e) {
    error_log('Failed to fetch teacher role: ' . $e->getMessage());
    header("Location: classes.php");
    exit;
}

// Fetch students in the class with session and marks status
$students = [];
$possible_terms = ['FIRST TERMINAL', 'SECOND TERMINAL', 'ANNUAL'];
try {
    // Fetch students
    $stmt = $pdo->prepare(
        'SELECT s.id, s.uid, s.full_name, s.session, d.student_photo
         FROM students s 
         LEFT JOIN documents d ON d.uid = s.uid
         WHERE s.class = :class_id AND s.status = "active"'
    );
    $stmt->execute([':class_id' => $class_id]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($students)) {
        error_log('No active students found for class ID: ' . $class_id);
    } else {
        error_log('Found ' . count($students) . ' active students for class ID: ' . $class_id);
    }
    
    $stmt = $pdo->prepare(
        'SELECT DISTINCT term 
         FROM results 
         WHERE class_id = :class_id_outer 
         AND session IN (
             SELECT DISTINCT session 
             FROM students 
             WHERE class = :class_id_inner AND status = "active"
         )'
    );
    $stmt->execute([
        ':class_id_outer' => $class_id,
        ':class_id_inner' => $class_id
    ]);
    $existing_terms = array_column($stmt->fetchAll(), 'term');
    
    // Set terms to check based on existing terms
    $terms_to_check = !empty($existing_terms) ? array_intersect($possible_terms, $existing_terms) : ['FIRST TERMINAL'];
    error_log('Terms to check for class ID ' . $class_id . ': ' . implode(', ', $terms_to_check));
    
    // Fetch count of active subjects for the class
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) as subject_count
         FROM subject 
         WHERE class = :class_id AND status = "active"'
    );
    $stmt->execute([':class_id' => $class_id]);
    $total_subjects = $stmt->fetchColumn();
    
    if ($total_subjects == 0) {
        error_log('No active subjects found for class ID: ' . $class_id);
    } else {
        error_log('Found ' . $total_subjects . ' active subjects for class ID: ' . $class_id);
    }
    
    foreach ($students as &$student) {
        $student['full_name'] = htmlspecialchars($student['full_name']);
        $student['class_name'] = $class_name;
        $student['student_photo'] = $student['student_photo'] ?: 'default_photo.png';
        $student['marks_status'] = 'Incomplete'; // Default status
    
        if ($total_subjects > 0 && !empty($student['session'])) {
            try {
                // Fetch marks for this student per term
                $stmt = $pdo->prepare(
                    'SELECT term, COUNT(*) as marks_count
                     FROM results 
                     WHERE uid = :uid AND class_id = :class_id AND session = :session
                     GROUP BY term'
                );
                $stmt->execute([
                    ':uid' => $student['uid'],
                    ':class_id' => $class_id,
                    ':session' => $student['session']
                ]);
                $marks_per_term = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
                // Create term=>count map for this student
                $term_marks_count = [];
                foreach ($marks_per_term as $row) {
                    $term_marks_count[$row['term']] = (int)$row['marks_count'];
                }
    
                // Store per-student debug info
                error_log("Marks count for UID {$student['uid']} (" . $student['full_name'] . "): " . json_encode($term_marks_count));
    
                // Check each term one by one for this student
                $marks_complete = true;
                
                foreach ($terms_to_check as $term) {
                    // If the term doesn't exist for this student, skip instead of forcing 0
                    if (!isset($term_marks_count[$term])) {
                        continue; 
                    }
                
                    $count = (int) $term_marks_count[$term];
                    error_log("Checking UID {$student['uid']} - Term: $term - Found: $count - Expected: $total_subjects");
                
                    if ($count !== (int)$total_subjects) {
                        $marks_complete = false;
                        error_log("Incomplete marks for UID {$student['uid']} in Term $term: Expected $total_subjects, Found $count");
                    }
                }
                
                // ✅ If no terms were found at all, keep status blank or default
                if (!empty($term_marks_count)) {
                    $student['marks_status'] = $marks_complete ? 'Complete' : 'Incomplete';
                } else {
                    $student['marks_status'] = ''; // No marks yet
                }
            } catch (PDOException $e) {
                error_log("Failed to fetch marks for UID {$student['uid']} (" . $student['full_name'] . "): " . $e->getMessage());
                $student['marks_status'] = 'Incomplete';
            }
        } else {
            error_log("No subjects or session for UID {$student['uid']} (" . $student['full_name'] . ")");
            $student['marks_status'] = 'Incomplete';
        }
    }
} catch (PDOException $e) {
    error_log('Failed to fetch students, terms, or subjects: ' . $e->getMessage());
    // Do not clear $students to preserve fetched data
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>EduConnect - Add Marks</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
            --success-color: #28a745;
            --warning-color: #ffc107;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }

        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }

        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }

        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }

        .class-info {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            margin-bottom: 15px;
        }

        .class-name {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .class-meta {
            font-size: 14px;
            color: var(--light-text);
        }

        .student-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .student-item {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            gap: 15px;
            transition: var(--transition);
            cursor: pointer;
        }

        .student-item:hover {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }

        .student-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: rgba(0, 85, 164, 0.1);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            flex-shrink: 0;
        }

        .student-details {
            flex: 1;
        }

        .student-name {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .student-meta {
            font-size: 14px;
            color: var(--light-text);
        }

        .marks-status {
            font-size: 12px;
            font-weight: 500;
            padding: 4px 8px;
            border-radius: 12px;
            display: inline-block;
        }

        .marks-status.complete {
            background-color: var(--success-color);
            color: white;
        }

        .marks-status.incomplete {
            background-color: var(--warning-color);
            color: var(--text-color);
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }

        .footer-item.active {
            color: var(--primary-color);
        }

        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }

        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }

        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }

        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }

        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
            text-align: center;
        }

        .empty-icon {
            font-size: 50px;
            color: #ccc;
            margin-bottom: 15px;
        }

        .empty-text {
            font-size: 16px;
            color: var(--light-text);
            margin-bottom: 20px;
        }

        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }

            .class-name {
                font-size: 18px;
            }

            .student-name {
                font-size: 15px;
            }

            .marks-status {
                font-size: 11px;
                padding: 3px 6px;
            }
        }

        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" onclick="window.location.href='index.php';"></i>
        Add Marks
    </div>

    <div class="section">
        <div class="class-info">
            <div class="class-name"><?php echo htmlspecialchars($class_name); ?></div>
            <div class="class-meta"><?php echo htmlspecialchars($teacher_role['details'] ?? 'N/A'); ?></div>
        </div>

        <div class="section-title">Students</div>
        <div class="student-list">
            <?php if (empty($students)): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="empty-text">No students found in this class.</div>
                </div>
            <?php else: ?>
                <?php foreach ($students as $student): ?>
                    <div class="student-item" data-id="<?php echo htmlspecialchars($student['id'] ?? ''); ?>">
                        <div class="student-icon">
                            <img src="/<?php echo htmlspecialchars($student['student_photo'] ?? 'default_photo.png'); ?>" alt="<?php echo htmlspecialchars($student['full_name'] ?? 'Student'); ?>" style="width: 50px; height: 50px; border-radius: 50%;">
                        </div>
                        <div class="student-details">
                            <div class="student-name">
                                <?php echo htmlspecialchars($student['full_name'] ?? 'Unknown Student'); ?>
                                <span class="marks-status <?php echo strtolower($student['marks_status'] ?? 'incomplete'); ?>">
                                    <?php echo htmlspecialchars($student['marks_status'] ?? 'Incomplete'); ?>
                                </span>
                            </div>
                            <div class="student-meta">
                                <?php echo htmlspecialchars($class_name ?? 'N/A'); ?> | Session: <?php echo htmlspecialchars($student['session'] ?? 'N/A'); ?>
                            </div> 
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="footer">
        <a href="index.php" class="footer-item">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="classes.php" class="footer-item">
            <i class="fas fa-chalkboard footer-icon"></i>
            <span class="footer-text">Classes</span>
        </a>
        <a href="marks.php" class="footer-item active">
            <i class="fa fa-pencil-square footer-icon"></i>
            <span class="footer-text">Marks</span>
        </a>
        <a href="profile.php" class="footer-item">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Profile</span>
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loader = document.getElementById('loader');
            
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }
            
            hideLoader();

            const studentItems = document.querySelectorAll('.student-item');
            studentItems.forEach(item => {
                item.addEventListener('click', function() {
                    const studentId = this.getAttribute('data-id');
                    if (studentId) {
                        window.location.href = `add_marks.php?student_id=${studentId}`;
                    } else {
                        console.error('Student ID is missing for this item');
                    }
                });
            });
        });
    </script>
</body>
</html>