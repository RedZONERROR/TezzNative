<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class PendingFeesController {
    private $pdo;
    private $logger;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    private function validateInput(array $data, bool $isUpdate = false): array {
        $this->logError('Validating input: ' . json_encode($data));
        $errors = [];
        $validData = [];

        // Define validation rules
        $fields = [
            'student_id' => ['type' => 'integer', 'required' => !$isUpdate],
            'particular_id' => ['type' => 'integer', 'required' => !$isUpdate],
            'pending_amount' => ['type' => 'decimal', 'min' => 0, 'required' => true],
            'due_months' => ['type' => 'array', 'required' => false],
            'due_session' => ['type' => 'string', 'max_length' => 20, 'required' => true],
            'reason' => ['type' => 'string', 'max_length' => 255, 'required' => false],
            'status' => ['type' => 'string', 'enum' => ['pending', 'partially_paid', 'fully_paid'], 'required' => $isUpdate],
        ];

        // Validate id for updates
        if ($isUpdate) {
            if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT) || $data['id'] <= 0) {
                $errors[] = "id must be a valid integer";
            } else {
                $validData['id'] = (int)$data['id'];
            }
        }

        // Validate other fields
        foreach ($fields as $field => $rules) {
            if (array_key_exists($field, $data)) {
                $value = $data[$field];

                // Handle NULL or empty strings for optional fields
                if ($value === '' && !$rules['required']) {
                    $value = null;
                }

                // Type checking
                if ($value !== null) {
                    switch ($rules['type']) {
                        case 'string':
                            if (!is_string($value)) {
                                $errors[] = "$field must be a string";
                            } elseif (isset($rules['max_length']) && strlen($value) > $rules['max_length']) {
                                $errors[] = "$field must not exceed {$rules['max_length']} characters";
                            }
                            break;
                        case 'integer':
                            if (!filter_var($value, FILTER_VALIDATE_INT) || $value <= 0) {
                                $errors[] = "$field must be a valid positive integer";
                            } else {
                                $value = (int)$value;
                            }
                            break;
                        case 'decimal':
                            if (!is_numeric($value) || $value < 0) {
                                $errors[] = "$field must be a valid positive number";
                            } else {
                                $value = (float)$value;
                            }
                            if (isset($rules['min']) && $value < $rules['min']) {
                                $errors[] = "$field must be at least {$rules['min']}";
                            }
                            break;
                        case 'array':
                            if (!is_array($value)) {
                                $errors[] = "$field must be an array";
                            } else {
                                foreach ($value as $month) {
                                    if (!filter_var($month, FILTER_VALIDATE_INT) || $month < 1 || $month > 12) {
                                        $errors[] = "due_months must contain valid month numbers (1-12)";
                                        break;
                                    }
                                }
                            }
                            break;
                    }

                    // Enum validation
                    if (isset($rules['enum']) && !in_array($value, $rules['enum'], true)) {
                        $errors[] = "$field must be one of: " . implode(', ', $rules['enum']);
                    }
                }

                $validData[$field] = $value;
            } elseif ($rules['required']) {
                $errors[] = "$field is required";
            }
        }

        // Ensure due_months is properly formatted
        if (isset($validData['due_months']) && is_array($validData['due_months']) && !empty($validData['due_months'])) {
            $validData['due_months'] = implode(',', $validData['due_months']);
        } else {
            $validData['due_months'] = 'all';
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        $this->logError('Validated data: ' . json_encode($validData));
        return $validData;
    }

    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['status' => 'error', 'message' => $message]);
        exit;
    }

    private function sendSuccess(int $code, string $message, array $data = []): void {
        http_response_code($code);
        echo json_encode(['status' => 'success', 'message' => $message, 'data' => $data]);
        exit;
    }

    private function logError(string $message): void {
        ($this->logger)('PendingFeesController: ' . $message);
    }

    public function get($request) {
        // Build WHERE clause based on filters
        $conditions = [];
        $params = [];
        
        if (isset($request['class_id']) && filter_var($request['class_id'], FILTER_VALIDATE_INT)) {
            $conditions[] = 's.class = ?';
            $params[] = $request['class_id'];
        }
        
        if (isset($request['particular_id']) && filter_var($request['particular_id'], FILTER_VALIDATE_INT)) {
            $conditions[] = 'pf.particular_id = ?';
            $params[] = $request['particular_id'];
        }
        
        if (isset($request['status']) && in_array($request['status'], ['pending', 'partially_paid', 'fully_paid'])) {
            $conditions[] = 'pf.status = ?';
            $params[] = $request['status'];
        }

        $whereClause = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

        if (isset($request['id']) && filter_var($request['id'], FILTER_VALIDATE_INT)) {
            $conditions[] = 'pf.id = ?';
            $params[] = $request['id'];
            $whereClause = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

            $stmt = $this->pdo->prepare("
                SELECT pf.*, 
                       s.full_name as student_name, 
                       s.uid as student_uid, 
                       c.class_name, 
                       p.particular,
                       CAST(pf.pending_amount AS DECIMAL(10,2)) as pending_amount
                FROM pending_fees pf
                JOIN students s ON pf.student_uid = s.uid
                JOIN class c ON s.class = c.id
                JOIN particulars p ON pf.particular_id = p.id
                $whereClause
            ");
            $stmt->execute($params);
            $entry = $stmt->fetch();

            if ($entry) {
                $this->sendSuccess(200, 'Pending fee fetched successfully', $entry);
            } else {
                $this->sendSuccess(200, 'No pending fee found', []);
            }
        } else {
            $stmt = $this->pdo->prepare("
                SELECT pf.*, 
                       s.full_name as student_name, 
                       s.uid as student_uid, 
                       c.class_name, 
                       p.particular,
                       CAST(pf.pending_amount AS DECIMAL(10,2)) as pending_amount
                FROM pending_fees pf
                JOIN students s ON pf.student_uid = s.uid
                JOIN class c ON s.class = c.id
                JOIN particulars p ON pf.particular_id = p.id
                $whereClause
                ORDER BY pf.created_on DESC
            ");
            $stmt->execute($params);
            $entries = $stmt->fetchAll();

            $this->sendSuccess(200, 'Pending fees fetched successfully', $entries);
        }
    }

    public function post() {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) {
            $input = $_POST;
        }
        $validData = $this->validateInput($input);

        // Fetch student details to get class_id and student_uid
        $stmt = $this->pdo->prepare("SELECT uid, class FROM students WHERE id = ? AND status = 'active'");
        $stmt->execute([$validData['student_id']]);
        $student = $stmt->fetch();
        if (!$student) {
            $this->sendError(404, 'Student not found or inactive');
        }

        try {
            $this->pdo->beginTransaction();

            $stmt = $this->pdo->prepare("
                INSERT INTO pending_fees (
                    student_uid, particular_id, pending_amount, 
                    due_months, due_session, reason, status, created_on, added_by
                ) VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW(), ?)
            ");
            $stmt->execute([
                $student['uid'],
                $validData['particular_id'],
                $validData['pending_amount'],
                $validData['due_months'],
                $validData['due_session'],
                $validData['reason'],
                $_SESSION['uid'] // Assuming added_by is the current user's UID
            ]);

            $this->pdo->commit();
            $this->sendSuccess(201, 'Pending fee created successfully');
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to create pending fee: ' . $e->getMessage());
            $this->sendError(500, 'Failed to create pending fee');
        }
    }

    public function put() {
        $input = json_decode(file_get_contents('php://input'), true);
        $validData = $this->validateInput($input, true);

        try {
            $this->pdo->beginTransaction();

            $stmt = $this->pdo->prepare("
                UPDATE pending_fees 
                SET pending_amount = ?, due_months = ?, due_session = ?, 
                    status = ?, reason = ?, updated_on = NOW()
                WHERE id = ?
            ");
            $stmt->execute([
                $validData['pending_amount'],
                $validData['due_months'],
                $validData['due_session'],
                $validData['status'],
                $validData['reason'],
                $validData['id']
            ]);

            $this->pdo->commit();
            $this->sendSuccess(200, 'Pending fee updated successfully');
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to update pending fee: ' . $e->getMessage());
            $this->sendError(500, 'Failed to update pending fee');
        }
    }

    public function delete($request) {
        $id = isset($request['id']) ? filter_var($request['id'], FILTER_VALIDATE_INT) : false;
        if (!$id) {
            $this->sendError(400, 'Invalid ID');
        }

        try {
            $stmt = $this->pdo->prepare("DELETE FROM pending_fees WHERE id = ?");
            $stmt->execute([$id]);
            if ($stmt->rowCount() > 0) {
                $this->sendSuccess(200, 'Pending fee deleted successfully');
            } else {
                $this->sendSuccess(200, 'Pending fee not found', []);
            }
        } catch (PDOException $e) {
            $this->logError('Failed to delete pending fee: ' . $e->getMessage());
            $this->sendError(500, 'Failed to delete pending fee');
        }
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];

        switch ($method) {
            case 'GET':
                $this->get($_GET);
                break;
            case 'POST':
                $this->post();
                break;
            case 'PUT':
                $this->put();
                break;
            case 'DELETE':
                $this->delete($_GET);
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists($_SERVER['DOCUMENT_ROOT'] . '/logs')) {
    mkdir($_SERVER['DOCUMENT_ROOT'] . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new PendingFeesController();
$controller->handleRequest();
?>