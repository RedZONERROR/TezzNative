<?php
session_start();
if (!isset($_SESSION['uid'])) {
    header("location: ../../login");
    die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- Select2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" />
    <!-- Select2 Bootstrap 5 Theme -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">

    <title>Fee Collection - AI-ERP 2.0</title>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }

        .card-header {
            background-color: #fff;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            padding: 1rem 1.5rem;
        }

        .table {
            margin-bottom: 0;
        }

        .table thead th {
            background-color: #e9ecef;
            text-transform: uppercase;
            font-size: 0.85rem;
            font-weight: 600;
            color: #495057;
        }

        .table tbody tr:hover {
            background-color: #f1f3f5;
        }

        .table td, .table th {
            vertical-align: middle;
            padding: 0.75rem;
        }

        .badge {
            font-size: 0.75rem;
            padding: 0.35em 0.65em;
        }

        .btn {
            border-radius: 0.375rem;
            transition: all 0.2s ease;
        }

        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }

        .btn i {
            margin-right: 0.25rem;
        }

        .btn-loading .fa-spinner {
            display: inline-block;
        }

        .btn-loading .btn-text, .btn-loading .ti {
            display: none;
        }

        .fa-spinner {
            display: none;
            font-size: 0.9rem;
        }

        .table-loader {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 10;
        }

        .table-container {
            position: relative;
        }

        .form-label {
            font-weight: 500;
            color: #495057;
        }

        .form-select, .form-control {
            border-radius: 0.375rem;
            transition: all 0.2s ease;
        }

        .form-select:focus, .form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }
        
        .pending-fee-row {
            background-color: #fef2f2; /* Light red background for pending fees */
        }
        
        .pending-fee-row .badge {
            font-weight: 600;
        }
        
        .pending-fee-tooltip {
            position: relative;
            cursor: pointer;
        }
        
        .pending-fee-tooltip:hover::after {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            background-color: #333;
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 0.75rem;
            z-index: 1000;
            white-space: nowrap;
        }

        .modal-content {
            border-radius: 0.75rem;
        }

        .modal-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }

        .modal-footer {
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }

        .select2-container {
            width: 100% !important;
            z-index: 1055 !important;
        }

        .select2-container--bootstrap-5 .select2-selection {
            border-radius: 0.375rem;
            border: 1px solid #ced4da;
            min-height: 38px;
            display: flex;
            align-items: center;
        }

        .select2-container--bootstrap-5 .select2-selection--multiple .select2-selection__choice {
            background-color: #0d6efd;
            color: white;
            border-radius: 0.25rem;
        }

        .select2-container--bootstrap-5 .select2-selection--single .select2-selection__rendered {
            line-height: 38px;
        }

        .select2-container--bootstrap-5 .select2-selection--multiple .select2-selection__rendered {
            line-height: normal;
        }

        .select2-container .select2-dropdown {
            z-index: 1056 !important;
        }

        .select-loading::after {
            content: "Loading...";
            color: #6c757d;
            font-size: 0.875rem;
            margin-left: 0.5rem;
            display: inline-block;
        }

        #collections_count_container {
            display: none;
        }

        .receipt-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 40px;
            font-family: 'Poppins', Arial, sans-serif;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            background-color: #fff;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
        }

        .receipt-watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-45deg);
            font-size: 120px;
            opacity: 0.03;
            font-weight: 700;
            white-space: nowrap;
            pointer-events: none;
            z-index: 0;
        }

        .receipt-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #2563eb;
            padding-bottom: 20px;
            margin-bottom: 30px;
            position: relative;
            z-index: 1;
        }

        .school-logo img {
            max-height: 90px;
            max-width: 180px;
            object-fit: contain;
        }

        .school-info h2 {
            margin: 0;
            font-size: 1.8rem;
            color: #2563eb;
            font-weight: 600;
            letter-spacing: -0.5px;
        }

        .school-info p {
            margin: 4px 0;
            font-size: 0.95rem;
            color: #64748b;
        }

        .receipt-title h3 {
            text-align: center;
            background-color: #2563eb;
            color: white;
            padding: 8px 30px;
            border-radius: 30px;
            font-size: 1.2rem;
            font-weight: 500;
            letter-spacing: 1px;
            text-transform: uppercase;
            box-shadow: 0 4px 6px rgba(37, 99, 235, 0.2);
            margin: 20px 0;
        }

        .receipt-sections {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
            position: relative;
            z-index: 1;
        }

        .receipt-section {
            background-color: #f8fafc;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.03);
        }

        .receipt-section h4 {
            font-size: 1rem;
            color: #475569;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 1px dashed #e2e8f0;
        }

        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .info-item {
            margin-bottom: 8px;
        }

        .info-label {
            font-size: 0.85rem;
            color: #64748b;
        }

        .info-value {
            font-size: 0.95rem;
            font-weight: 500;
            color: #1e293b;
        }

        .payment-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-bottom: 30px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .payment-table th, .payment-table td {
            padding: 12px 15px;
            text-align: left;
            font-size: 0.95rem;
        }

        .payment-table th {
            background-color: #2563eb;
            color: white;
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }

        .payment-table td {
            background-color: white;
            border-bottom: 1px solid #e2e8f0;
        }

        .payment-table tr:last-child td {
            border-bottom: none;
        }

        .amount-row td {
            font-weight: 600;
            color: #2563eb;
        }

        .receipt-footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            position: relative;
            z-index: 1;
        }

        .verification-section {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .verification-code {
            font-family: monospace;
            background-color: #f8fafc;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 0.9rem;
            margin-top: 5px;
            letter-spacing: 1px;
        }

        .thank-you h4 {
            color: #2563eb;
            font-size: 1.2rem;
            margin-bottom: 5px;
        }

        .thank-you p {
            color: #64748b;
            font-size: 0.9rem;
        }

        .date-filter-container {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .select-all-checkbox {
            margin-right: 0.5rem;
        }

        @media print {
            body {
                background-color: white;
            }
            .receipt-container {
                margin: 0;
                padding: 20px;
                border: none;
                box-shadow: none;
                max-width: 100%;
            }
            .payment-table th {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                background-color: #2563eb !important;
                color: white !important;
            }
            .receipt-title h3 {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                background-color: #2563eb !important;
                color: white !important;
            }
            .no-print {
                display: none;
            }
        }

        @media (max-width: 576px) {
            .table {
                font-size: 0.875rem;
            }

            .btn-sm {
                padding: 0.2rem 0.4rem;
                font-size: 0.75rem;
            }

            .card-header {
                padding: 0.75rem 1rem;
            }

            .receipt-container {
                padding: 10px;
            }

            .school-logo img {
                max-height: 60px;
            }

            .school-info h2 {
                font-size: 1.2rem;
            }

            .receipt-table th, .receipt-table td {
                font-size: 0.8rem;
                padding: 8px;
            }

            .date-filter-container {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card mb-3">
                        <div class="card-body py-3">
                            <div class="d-flex align-items-center justify-content-between flex-wrap">
                                <h4 class="card-title mb-0">Fee Collection</h4>
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb mb-0">
                                        <li class="breadcrumb-item d-flex align-items-center">
                                            <a class="text-muted text-decoration-none d-flex" href="/app" aria-label="Home">
                                                <iconify-icon icon="solar:home-2-line-duotone" class="fs-5"></iconify-icon>
                                            </a>
                                        </li>
                                        <li class="breadcrumb-item">
                                            <span class="badge bg-primary-subtle text-primary fw-medium">Fee Collection</span>
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>

                    <!-- Fee Collection Section -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title mb-0">Collect Fees</h4>
                                </div>
                                <div class="card-body">
                                    <form class="row g-3 mb-4">
                                        <div class="col-md-6">
                                            <label for="student_class" class="form-label">Class <span class="text-danger">*</span></label>
                                            <div class="position-relative">
                                                <select class="form-select" id="student_class" name="student_class" aria-label="Select class">
                                                    <option value="">Select Class</option>
                                                    <!-- Class will be fetched dynamically -->
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="student_info" class="form-label">Student <span class="text-danger">*</span></label>
                                            <div class="position-relative">
                                                <select class="form-select" id="student_info" name="student_info" aria-label="Select student" disabled>
                                                    <option value="">Select or search for a student...</option>
                                                    <!-- This details will be fetched dynamically -->
                                                </select>
                                            </div>
                                        </div>
                                    </form>

                                    <!-- Applicable Fees Table -->
                                    <div class="table-container mt-4">
                                        <div class="table-loader">
                                            <div class="spinner-border text-primary" role="status">
                                                <span class="visually-hidden">Loading...</span>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Particular</th>
                                                        <th scope="col">Amount</th>
                                                        <th scope="col">Frequency</th>
                                                        <th scope="col">Pending</th>
                                                        <th scope="col">Status</th>
                                                        <th scope="col">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="fee_table_body">
                                                    <!-- Fees will load dynamically -->
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <!-- Added Student Credits Section -->
                                    <div class="table-container mt-4" id="credits_section" style="display: none;">
                                        <div class="card-header d-flex justify-content-between align-items-center">
                                            <h4 class="card-title mb-0">Available Credits</h4>
                                            <div class="badge bg-success fs-6" id="total_credits_badge">₹0.00</div>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-hover table-sm">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Source</th>
                                                        <th scope="col">Amount</th>
                                                        <th scope="col">Used</th>
                                                        <th scope="col">Remaining</th>
                                                        <th scope="col">Date</th>
                                                        <th scope="col">Session</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="credits_table_body">
                                                    <!-- Credits will load dynamically -->
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <!-- Payment History Table -->
                                    <div class="table-container mt-4">
                                        <div class="card-header d-flex justify-content-between align-items-center">
                                            <h4 class="card-title mb-0">Payment History</h4>
                                            <div class="d-flex align-items-center">
                                                <div class="date-filter-container me-2">
                                                    <div>
                                                        <label for="start_date" class="form-label">Start Date</label>
                                                        <input type="date" class="form-control" id="start_date" name="start_date">
                                                    </div>
                                                    <div>
                                                        <label for="end_date" class="form-label">End Date</label>
                                                        <input type="date" class="form-control" id="end_date" name="end_date">
                                                    </div>
                                                </div>
                                                <button id="refresh_history" class="btn btn-sm btn-outline-secondary me-2">
                                                    <i class="fas fa-sync-alt"></i> Refresh
                                                </button>
                                                <button id="print_selected" class="btn btn-sm btn-outline-info me-2" disabled>
                                                    <i class="fas fa-print"></i> Print Selected
                                                </button>
                                                <div id="history_export_buttons" class="btn-group btn-group-sm" role="group">
                                                    <!-- Export buttons will be added dynamically -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="table-loader">
                                            <div class="spinner-border text-primary" role="status">
                                                <span class="visually-hidden">Loading...</span>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-hover" id="history_table">
                                                <thead>
                                                    <tr>
                                                        <th scope="col"><input type="checkbox" id="select_all_history" class="select-all-checkbox"></th>
                                                        <th scope="col">Particular</th>
                                                        <th scope="col">Amount Collected</th>
                                                        <th scope="col">Discount</th>
                                                        <th scope="col">Payment Month</th>
                                                        <th scope="col">Payment Date</th>
                                                        <th scope="col">Payment Method</th>
                                                        <th scope="col">Status</th>
                                                        <th scope="col">Session</th>
                                                        <th scope="col">Remarks</th>
                                                        <th scope="col">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="history_table_body">
                                                    <!-- History will load dynamically -->
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Collect Fee Modal -->
                    <div class="modal fade" id="collectFeeModal" tabindex="-1" aria-labelledby="collectFeeModalTitle" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="collectFeeModalTitle">Collect Fee</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form id="collectFeeForm" class="needs-validation" novalidate>
                                        <input type="hidden" id="fee_structure_id">
                                        <input type="hidden" id="fee_frequency" value="">
                                        <input type="hidden" id="pending_fee_id" value="">
                                        <div class="mb-3">
                                            <label for="particular" class="form-label">Particular</label>
                                            <input type="text" class="form-control" id="particular" readonly>
                                        </div>
                                        <div class="mb-3" id="pending_fee_info" style="display: none;">
                                            <label for="pending_reason" class="form-label">Reason for Pending Fee</label>
                                            <input type="text" class="form-control" id="pending_reason" readonly>
                                        </div>
                                        <div class="mb-3" id="pending_session_info" style="display: none;">
                                            <label for="pending_due_session" class="form-label">Due Session</label>
                                            <input type="text" class="form-control" id="pending_due_session" readonly>
                                        </div>
                                        <div class="mb-3">
                                            <label for="fee_amount" class="form-label">Expected Amount (Per Collection)</label>
                                            <input type="number" class="form-control" id="fee_amount" readonly>
                                        </div>
                                        <div class="mb-3" id="payment_month_container">
                                            <label for="payment_month" class="form-label">Payment Month <span class="text-danger">*</span></label>
                                            <select class="form-control" id="payment_month" name="payment_month[]" multiple required aria-label="Select payment months">
                                                <!-- Populated dynamically -->
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select at least one payment month.
                                            </div>
                                        </div>
                                        <div class="mb-3" id="collections_count_container">
                                            <label for="collections_count" class="form-label">Number of Collections to Pay <span class="text-danger">*</span></label>
                                            <select class="form-control" id="collections_count" name="collections_count" required>
                                                <!-- Populated dynamically -->
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select the number of collections to pay.
                                            </div>
                                        </div>
                                        <div class="mb-3" id="annual_label" style="display: none;">
                                            <label class="form-label">Payment Period</label>
                                            <p class="form-control-plaintext text-info">Annual</p>
                                        </div>
                                        <div class="mb-3">
                                            <label for="discount" class="form-label">Discount</label>
                                            <input type="number" class="form-control" id="discount" name="discount" min="0" step="0.01" value="0">
                                        </div>
                                        
                                        <!-- Enhanced Credits Application Section with Apply Credits Button -->
                                        <div class="mb-3" id="credits_application_container" style="display: none;">
                                            <label class="form-label">Available Credits</label>
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <span class="text-muted">Total Available:</span>
                                                <span class="fw-bold text-success" id="available_credits_display">₹0.00</span>
                                            </div>
                                            <div class="input-group mb-2">
                                                <span class="input-group-text">₹</span>
                                                <input type="number" class="form-control" id="apply_credits" name="apply_credits" min="0" step="0.01" value="0" placeholder="Enter amount to apply">
                                                <button type="button" class="btn btn-outline-secondary" id="max_credits_btn">Max</button>
                                            </div>
                                            <button type="button" class="btn btn-success btn-sm w-100" id="apply_credits_btn">
                                                <i class="fas fa-credit-card me-1"></i>Apply Credits to Amount
                                            </button>
                                            <div class="form-text mt-1">Credits will be deducted from your available balance</div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label for="amount_collected" class="form-label">Amount to Collect <span class="text-danger">*</span></label>
                                            <div class="input-group">
                                                <span class="input-group-text">₹</span>
                                                <input type="number" class="form-control" id="amount_collected" name="amount_collected" min="0" step="0.01" required>
                                            </div>
                                            <div class="invalid-feedback">
                                                Please enter a valid amount.
                                            </div>
                                            <!-- Added amount breakdown display -->
                                            <div class="form-text mt-2" id="amount_breakdown" style="display: none;">
                                                <div class="d-flex justify-content-between">
                                                    <span>Base Amount:</span>
                                                    <span id="base_amount_display">₹0.00</span>
                                                </div>
                                                <div class="d-flex justify-content-between" id="credits_applied_row" style="display: none;">
                                                    <span>Credits Applied:</span>
                                                    <span class="text-success" id="credits_applied_display">-₹0.00</span>
                                                </div>
                                                <div class="d-flex justify-content-between" id="discount_row" style="display: none;">
                                                    <span>Discount:</span>
                                                    <span class="text-info" id="discount_display">-₹0.00</span>
                                                </div>
                                                <hr class="my-1">
                                                <div class="d-flex justify-content-between fw-bold">
                                                    <span>Final Amount:</span>
                                                    <span id="final_amount_display">₹0.00</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="payment_date" class="form-label">Payment Date <span class="text-danger">*</span></label>
                                            <input type="date" class="form-control" id="payment_date" name="payment_date" required>
                                            <div class="invalid-feedback">
                                                Please select a payment date.
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="payment_method" class="form-label">Payment Method <span class="text-danger">*</span></label>
                                            <select class="form-control" id="payment_method" name="payment_method" required aria-label="Select payment method">
                                                <option value="cash">Cash</option>
                                                <option value="card">Card</option>
                                                <option value="online">Online</option>
                                                <option value="cheque">Cheque</option>
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select a payment method.
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="session" class="form-label">Session <span class="text-danger">*</span></label>
                                            <select class="form-control" id="session" name="session" required aria-label="Select session">
                                                <!-- Populated dynamically -->
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select a session.
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="remarks" class="form-label">Remarks</label>
                                            <textarea class="form-control" id="remarks" name="remarks" rows="3"></textarea>
                                        </div>
                                        
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <button id="btn-collect" class="btn btn-primary">
                                                <i class="fas fa-spinner fa-spin btn-loading"></i>
                                                <span class="btn-text">Collect Fee</span>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="dark-transparent sidebartoggler"></div>
    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script src="../assets/js/index.global.min.js"></script>
    <!-- DataTables JS and Dependencies -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
    <script src="collection.js?v=18"></script>
</body>
</html>