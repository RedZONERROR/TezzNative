<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class ClassController {
    private $pdo;
    private $logger;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    // Validate input data
    private function validateInput(array $data, bool $isUpdate = false): array {
        $errors = [];
        $validData = [];

        // Define validation rules
        $fields = [
            'class_name' => ['type' => 'string', 'max' => 50, 'required' => !$isUpdate],
            'status' => ['type' => 'string', 'enum' => ['active', 'inactive'], 'required' => !$isUpdate],
        ];

        // Validate id separately for updates
        if ($isUpdate) {
            if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT) || $data['id'] <= 0) {
                $errors[] = "id must be a valid integer";
            } else {
                $validData['id'] = (int)$data['id'];
            }
        }

        // Validate other fields
        foreach ($fields as $field => $rules) {
            if (isset($data[$field])) {
                $value = $data[$field];

                // Type checking
                switch ($rules['type']) {
                    case 'string':
                        if (!is_string($value)) {
                            $errors[] = "$field must be a string";
                        } elseif (isset($rules['max']) && strlen($value) > $rules['max']) {
                            $errors[] = "$field exceeds maximum length of {$rules['max']} characters";
                        }
                        break;
                }

                // Enum validation
                if (isset($rules['enum']) && !in_array($value, $rules['enum'], true)) {
                    $errors[] = "$field must be one of: " . implode(', ', $rules['enum']);
                }

                $validData[$field] = $value;
            } elseif ($rules['required']) {
                $errors[] = "$field is required";
            }
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return $validData;
    }

    // Send JSON error response
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    // Send JSON success response
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Handle GET requests
    public function get($request) {
        if (isset($request['id'])) {
            $id = filter_var($request['id'], FILTER_VALIDATE_INT);
            if (!$id) {
                $this->sendError(400, 'Invalid ID');
            }

            $stmt = $this->pdo->prepare("SELECT * FROM class WHERE id = ?");
            $stmt->execute([$id]);
            $entry = $stmt->fetch();

            if ($entry) {
                $this->sendSuccess(200, ['data' => [$entry]]);
            } else {
                $this->sendError(404, 'Class not found');
            }
        } else {
            // Pagination
            $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
            $perPage = isset($_GET['perPage']) ? max(1, min(100, (int)$_GET['perPage'])) : 10;
            $offset = ($page - 1) * $perPage;

            $query = "SELECT * FROM class";
            $countQuery = "SELECT COUNT(*) FROM class";
            $params = [];

            // Filtering
            $conditions = [];
            if (isset($_GET['status'])) {
                $conditions[] = "status = ?";
                $params[] = $_GET['status'];
            }

            if ($conditions) {
                $query .= " WHERE " . implode(' AND ', $conditions);
                $countQuery .= " WHERE " . implode(' AND ', $conditions);
            }

            $query .= " ORDER BY id LIMIT ? OFFSET ?";
            $params[] = $perPage;
            $params[] = $offset;

            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            $entries = $stmt->fetchAll();

            $countStmt = $this->pdo->prepare($countQuery);
            $countStmt->execute(array_slice($params, 0, count($params) - 2));
            $total = $countStmt->fetchColumn();

            $this->sendSuccess(200, [
                'data' => $entries,
                'meta' => [
                    'page' => $page,
                    'perPage' => $perPage,
                    'total' => $total,
                    'totalPages' => ceil($total / $perPage)
                ]
            ]);
        }
    }

    // Handle POST requests
    public function post($data) {
        $validData = $this->validateInput($data);

        $fields = ['class_name', 'status'];
        $placeholders = array_fill(0, count($fields), '?');
        $sql = "INSERT INTO class (" . implode(',', $fields) . ", created_at) VALUES (" . implode(',', $placeholders) . ", NOW())";

        try {
            $stmt = $this->pdo->prepare($sql);
            $values = [];
            foreach ($fields as $field) {
                $values[] = $validData[$field] ?? null;
            }
            $stmt->execute($values);
            $this->sendSuccess(201, ['message' => 'Class created', 'id' => $this->pdo->lastInsertId()]);
        } catch (PDOException $e) {
            $this->logError('Create failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to create class');
        }
    }

    // Handle PUT requests
    public function put($data) {
        $validData = $this->validateInput($data, true);

        if (!isset($validData['id'])) {
            $this->sendError(400, 'ID is required');
        }

        // Fetch existing record to preserve unchanged fields
        $stmt = $this->pdo->prepare("SELECT * FROM class WHERE id = ?");
        $stmt->execute([$validData['id']]);
        $existing = $stmt->fetch();

        if (!$existing) {
            $this->sendError(404, 'Class not found');
        }

        $fields = ['class_name', 'status'];
        $updateFields = [];
        $values = [];
        foreach ($fields as $field) {
            if (isset($validData[$field])) {
                $updateFields[] = "$field = ?";
                $values[] = $validData[$field];
            } else {
                $updateFields[] = "$field = ?";
                $values[] = $existing[$field];
            }
        }
        $values[] = $validData['id'];

        $sql = "UPDATE class SET " . implode(', ', $updateFields) . " WHERE id = ?";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($values);
            $this->sendSuccess(200, ['message' => 'Class updated']);
        } catch (PDOException $e) {
            $this->logError('Update failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to update class');
        }
    }

    // Handle DELETE requests
    public function delete($data) {
        if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT)) {
            $this->sendError(400, 'Invalid or missing ID');
        }

        try {
            $stmt = $this->pdo->prepare("DELETE FROM class WHERE id = ?");
            $stmt->execute([$data['id']]);
            if ($stmt->rowCount()) {
                $this->sendSuccess(200, ['message' => 'Class deleted']);
            } else {
                $this->sendError(404, 'Class not found');
            }
        } catch (PDOException $e) {
            $this->logError('Delete failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to delete class');
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $data = json_decode(file_get_contents('php://input'), true) ?: [];

        switch ($method) {
            case 'GET':
                $this->get($_GET);
                break;
            case 'POST':
                $this->post($data);
                break;
            case 'PUT':
                $this->put($data);
                break;
            case 'DELETE':
                $this->delete($data);
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new ClassController();
$controller->handleRequest();
?>