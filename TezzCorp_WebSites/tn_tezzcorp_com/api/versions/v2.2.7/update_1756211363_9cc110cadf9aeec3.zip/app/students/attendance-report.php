<?php
session_start();
if(!isset($_SESSION['uid'])){
    header("location: ../../login");
    die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- jsPDF and AutoTable -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js"></script>
    <!-- SheetJS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <!-- Highlight.js -->
    <script src="https://cdn.jsdelivr.net/npm/highlight.js@11.9.0/lib/highlight.min.js"></script>

    <title>Student Attendance Report - AI-ERP 2.0</title>
    <style>
        #table-loader {
            display: none;
        }
        .pagination {
            margin-top: 1rem;
        }
        .export-btn {
            margin-right: 0.5rem;
        }
        .btn-spinner {
            display: none;
            font-size: 0.8rem;
        }
        .btn-outline-primary .btn-spinner {
            color: #0d6efd;
        }
        .btn-outline-success .btn-spinner {
            color: #198754;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!-- Sidebar End -->
        <div class="page-wrapper">
            <!-- Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!-- Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Student Attendance Report</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Attendance Report
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Attendance Report -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-4 col-xl-3">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Students..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-3 col-xl-2">
                                    <select class="form-select" id="class-filter">
                                        <option value="">All Classes</option>
                                        <!-- Classes will be populated dynamically -->
                                    </select>
                                </div>
                                <div class="col-md-5 col-xl-7 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div class="form-group me-2">
                                        <input type="month" class="form-control" id="monthPicker">
                                    </div>
                                    <button class="btn btn-outline-primary btn-sm export-btn" id="export-pdf">
                                        <span class="btn-content"><i class="fas fa-file-pdf"></i> PDF</span>
                                        <span class="btn-spinner" role="status" aria-hidden="true"><i class="fas fa-spinner fa-spin"></i></span>
                                    </button>
                                    <button class="btn btn-outline-success btn-sm export-btn" id="export-excel">
                                        <span class="btn-content"><i class="fas fa-file-excel"></i> Excel</span>
                                        <span class="btn-spinner" role="status" aria-hidden="true"><i class="fas fa-spinner fa-spin"></i></span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="card card-body" id="attendance-table">
                            <div class="d-flex justify-content-center">
                                <div class="spinner-border text-primary" role="status" id="table-loader">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <tr id="header-row">
                                            <th>SN</th>
                                            <th>Student Name</th>
                                            <!-- Days added dynamically -->
                                        </tr>
                                    </thead>
                                    <tbody id="student_attendance_table_body">
                                        <!-- Data will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <nav aria-label="Page navigation" id="pagination-nav">
                                <ul class="pagination justify-content-center">
                                    <!-- Pagination controls -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="dark-transparent sidebartoggler"></div>
    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        $(document).ready(function() {
            // Set month picker to current month
            const now = new Date();
            const month = String(now.getMonth() + 1).padStart(2, '0');
            const year = now.getFullYear();
            $('#monthPicker').val(`${year}-${month}`);

            // Pagination state
            let currentPage = 1;
            const perPage = 10;
            const pageRange = 10; // Number of pages to show at a time
            let classOptions = [];

            // Fetch classes from class_master.php
            function fetchClasses() {
                return $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 100, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        if (response.data && Array.isArray(response.data)) {
                            classOptions = response.data;
                            const classFilter = $('#class-filter');
                            classFilter.empty();
                            classFilter.append('<option value="">All Classes</option>');
                            classOptions.forEach(cls => {
                                classFilter.append(`<option value="${cls.id}">${cls.class_name}</option>`);
                            });
                        } else {
                            console.warn('No valid classes found in response:', response);
                            classOptions = [];
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Failed to load classes:', {
                            status: status,
                            error: error,
                            response: xhr.responseJSON || xhr.responseText
                        });
                        Swal.fire({
                            icon: 'warning',
                            title: 'Warning',
                            text: 'Failed to load class options. Please try again later.'
                        });
                    }
                });
            }

            // Fetch attendance report
            function fetchAttendanceReport(year, month, page = 1, classId = '') {
                $('#table-loader').show();
                $('#student_attendance_table_body').empty();
                $('#header-row').html('<th>SN</th><th>Student Name</th>');

                // Ensure month is string
                month = String(month).padStart(2, '0');
                const dateLike = `${year}-${month}%`;

                // Get days in month
                const daysInMonth = new Date(year, parseInt(month), 0).getDate();
                const days = [];
                for (let d = 1; d <= daysInMonth; d++) {
                    const date = `${year}-${month}-${String(d).padStart(2, '0')}`;
                    days.push(date);
                }

                // Fetch students with pagination and optional class filter
                const studentParams = { page: page, perPage: perPage };
                if (classId) {
                    studentParams.class = classId;
                }

                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: studentParams,
                    dataType: 'json',
                    success: function(studentResponse) {
                        const students = studentResponse.data || [];
                        const meta = studentResponse.meta || { page: page, totalPages: 1, totalItems: students.length };
                        if (students.length === 0) {
                            $('#student_attendance_table_body').html('<tr><td colspan="2" class="text-center">No students found.</td></tr>');
                            renderPagination(meta);
                            $('#table-loader').hide();
                            return;
                        }

                        // Fetch all attendance for month
                        $.ajax({
                            url: 'api/student_attendance_master.php',
                            type: 'GET',
                            data: { date_like: dateLike },
                            dataType: 'json',
                            success: function(attResponse) {
                                const attendance = attResponse.data || [];
                                // Filter attendance to include only selected class students
                                const classStudents = students.map(s => s.id);
                                const filteredAttendance = classId
                                    ? attendance.filter(a => classStudents.includes(a.student_id))
                                    : attendance;
                                const workingDays = [...new Set(filteredAttendance.map(a => a.date))].length;
                                renderAttendanceTable(students, filteredAttendance, days, workingDays);
                                renderPagination(meta);
                                $('#table-loader').hide();
                                // Reapply search filter if active
                                const search = $('#input-search').val().toLowerCase();
                                if (search) {
                                    $('#student_attendance_table_body tr').each(function() {
                                        const text = $(this).find('td:eq(1)').text().toLowerCase();
                                        $(this).toggle(text.includes(search));
                                    });
                                }
                            },
                            error: function(xhr) {
                                console.error('Attendance Error:', xhr.responseJSON || xhr.statusText);
                                $('#table-loader').hide();
                                renderPagination(meta);
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to load attendance: ' + (xhr.responseJSON?.message || xhr.statusText)
                                });
                            }
                        });
                    },
                    error: function(xhr) {
                        console.error('Student Error:', xhr.responseJSON || xhr.statusText);
                        $('#table-loader').hide();
                        renderPagination({ page: 1, totalPages: 1, totalItems: 0 });
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load students: ' + (xhr.responseJSON?.message || xhr.statusText)
                        });
                    }
                });
            }

            // Render attendance table
            function renderAttendanceTable(students, attendance, days, workingDays) {
                const headerRow = $('#header-row');
                const tbody = $('#student_attendance_table_body');

                // Add day columns
                days.forEach(date => {
                    const d = new Date(date);
                    const day = d.getDate();
                    const th = $('<th>').text(`${day} ${d.toLocaleString('default', { month: 'short' })}`);
                    headerRow.append(th);
                });
                headerRow.append('<th>Present</th><th>Absent</th><th>Working Days</th><th>Average</th>');

                // Build rows
                students.forEach((s, index) => {
                    const tr = $('<tr>');
                    tr.append(`<td>${(currentPage - 1) * perPage + index + 1}</td><td>${s.full_name || '-'}</td>`);
                    let present = 0;

                    days.forEach(date => {
                        const att = attendance.find(a => a.student_id === s.id && a.date === date);
                        const status = att ? att.status : '0';
                        const colorClass = status === '1' ? 'present' : 'absent';
                        const mark = status === '1' ? '✓' : '✗';
                        if (status === '1') present++;
                        tr.append(`<td class="${colorClass}">${mark}</td>`);
                    });

                    const absent = workingDays - present;
                    const average = workingDays > 0 ? ((present / workingDays) * 100).toFixed(1) : '0.0';
                    tr.append(`<td>${present}</td><td>${absent}</td><td>${workingDays}</td><td>${average}%</td>`);
                    tbody.append(tr);
                });
            }

            // Render pagination with a range of 10 pages
            function renderPagination(meta) {
                const pagination = $('#pagination-nav ul');
                pagination.empty();

                // Fallback values
                const currentPage = meta.page || 1;
                const totalPages = meta.totalPages || 1;

                // Calculate the start and end page for the range
                const pageRangeStart = Math.floor((currentPage - 1) / pageRange) * pageRange + 1;
                const pageRangeEnd = Math.min(pageRangeStart + pageRange - 1, totalPages);

                // Add Previous button
                pagination.append(`
                    <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
                    </li>
                `);

                // Add page numbers within the range
                for (let p = pageRangeStart; p <= pageRangeEnd; p++) {
                    pagination.append(`
                        <li class="page-item ${p === currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${p}">${p}</a>
                        </li>
                    `);
                }

                // Add Next button
                pagination.append(`
                    <li class="page-item ${currentPage >= totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
                    </li>
                `);
            }

            // Pagination click
            $(document).on('click', '#pagination-nav a', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && page !== currentPage) {
                    currentPage = page;
                    const [year, month] = $('#monthPicker').val().split('-').map(Number);
                    const classId = $('#class-filter').val();
                    fetchAttendanceReport(year, month, page, classId);
                }
            });

            // Month picker change
            $('#monthPicker').on('change', function() {
                const value = $(this).val();
                const [year, month] = value.split('-').map(Number);
                currentPage = 1;
                const classId = $('#class-filter').val();
                fetchAttendanceReport(year, month, currentPage, classId);
            });

            // Class filter change
            $('#class-filter').on('change', function() {
                currentPage = 1;
                const classId = $(this).val();
                const [year, month] = $('#monthPicker').val().split('-').map(Number);
                fetchAttendanceReport(year, month, currentPage, classId);
            });

            // Search functionality
            $('#input-search').on('keyup', function() {
                const search = $(this).val().toLowerCase();
                $('#student_attendance_table_body tr').each(function() {
                    const text = $(this).find('td:eq(1)').text().toLowerCase();
                    $(this).toggle(text.includes(search));
                });
            });

            // Export PDF
            $('#export-pdf').on('click', function() {
                const $btn = $(this);
                $btn.find('.btn-content').hide();
                $btn.find('.btn-spinner').show();
                const { jsPDF } = window.jspdf;
                const doc = new jsPDF('l', 'mm', 'a3');
                const [year, month] = $('#monthPicker').val().split('-').map(Number);
                const monthStr = String(month).padStart(2, '0');
                const classId = $('#class-filter').val();

                // Fetch all students
                const studentParams = { perPage: 1000 };
                if (classId) {
                    studentParams.class = classId;
                }

                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: studentParams,
                    dataType: 'json',
                    success: function(studentResponse) {
                        const students = studentResponse.data || [];
                        if (students.length === 0) {
                            doc.text('No student data available.', 14, 20);
                            doc.save(`student_attendance_report_${year}_${monthStr}.pdf`);
                            $btn.find('.btn-spinner').hide();
                            $btn.find('.btn-content').show();
                            return;
                        }

                        // Fetch all attendance for month
                        $.ajax({
                            url: 'api/student_attendance_master.php',
                            type: 'GET',
                            data: { date_like: `${year}-${monthStr}%` },
                            dataType: 'json',
                            success: function(attResponse) {
                                const attendance = attResponse.data || [];
                                if (attendance.length === 0) {
                                    doc.text('No attendance data available for this period.', 14, 20);
                                    doc.save(`student_attendance_report_${year}_${monthStr}.pdf`);
                                    $btn.find('.btn-spinner').hide();
                                    $btn.find('.btn-content').show();
                                    return;
                                }

                                const classStudents = students.map(s => s.id);
                                const filteredAttendance = classId
                                    ? attendance.filter(a => classStudents.includes(a.student_id))
                                    : attendance;

                                const daysInMonth = new Date(year, month, 0).getDate();
                                const days = [];
                                for (let d = 1; d <= daysInMonth; d++) {
                                    days.push(`${year}-${monthStr}-${String(d).padStart(2, '0')}`);
                                }
                                const workingDays = [...new Set(filteredAttendance.map(a => a.date))].length;

                                // Prepare table data
                                const headers = ['SN', 'Student Name'];
                                days.forEach(date => {
                                    const d = new Date(date);
                                    headers.push(`${d.getDate()} ${d.toLocaleString('default', { month: 'short' })}`);
                                });
                                headers.push('Present', 'Absent', 'Working Days', 'Average');

                                const rows = students.map((s, index) => {
                                    const row = [(index + 1), s.full_name || '-'];
                                    let present = 0;
                                    days.forEach(date => {
                                        const att = filteredAttendance.find(a => a.student_id === s.id && a.date === date);
                                        const status = att ? att.status : '0';
                                        const mark = status === '1' ? 'P' : 'A';
                                        if (status === '1') present++;
                                        row.push(mark);
                                    });
                                    const absent = workingDays - present;
                                    const average = workingDays > 0 ? ((present / workingDays) * 100).toFixed(1) : '0.0';
                                    row.push(present, absent, workingDays, `${average}%`);
                                    return row;
                                });

                                // Generate PDF
                                doc.text(`Student Attendance Report - ${year}-${monthStr}`, 14, 10);
                                doc.autoTable({
                                    head: [headers],
                                    body: rows,
                                    theme: 'grid',
                                    headStyles: { fillColor: [41, 128, 185], fontSize: 8 },
                                    styles: { fontSize: 8, cellPadding: 2 },
                                    columnStyles: {
                                        0: { cellWidth: 15 },
                                        1: { cellWidth: 40 }
                                    },
                                    margin: { top: 20 },
                                    pageBreak: 'auto',
                                    tableWidth: 'auto',
                                    startY: 20
                                });
                                doc.save(`student_attendance_report_${year}_${monthStr}.pdf`);
                                $btn.find('.btn-spinner').hide();
                                $btn.find('.btn-content').show();
                            },
                            error: function(xhr) {
                                console.error('PDF Attendance Error:', xhr.responseJSON || xhr.statusText);
                                doc.text('Error fetching attendance data.', 14, 20);
                                doc.save(`student_attendance_report_${year}_${monthStr}.pdf`);
                                $btn.find('.btn-spinner').hide();
                                $btn.find('.btn-content').show();
                            }
                        });
                    },
                    error: function(xhr) {
                        console.error('PDF Student Error:', xhr.responseJSON || xhr.statusText);
                        doc.text('Error fetching student data.', 14, 20);
                        doc.save(`student_attendance_report_${year}_${monthStr}.pdf`);
                        $btn.find('.btn-spinner').hide();
                        $btn.find('.btn-content').show();
                    }
                });
            });

            // Export Excel
            $('#export-excel').on('click', function() {
                const $btn = $(this);
                $btn.find('.btn-content').hide();
                $btn.find('.btn-spinner').show();
                const [year, month] = $('#monthPicker').val().split('-').map(Number);
                const monthStr = String(month).padStart(2, '0');
                const classId = $('#class-filter').val();

                // Fetch all students
                const studentParams = { perPage: 1000 };
                if (classId) {
                    studentParams.class = classId;
                }

                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: studentParams,
                    dataType: 'json',
                    success: function(studentResponse) {
                        const students = studentResponse.data || [];
                        $.ajax({
                            url: 'api/student_attendance_master.php',
                            type: 'GET',
                            data: { date_like: `${year}-${monthStr}%` },
                            dataType: 'json',
                            success: function(attResponse) {
                                const attendance = attResponse.data || [];
                                const classStudents = students.map(s => s.id);
                                const filteredAttendance = classId
                                    ? attendance.filter(a => classStudents.includes(a.student_id))
                                    : attendance;

                                const daysInMonth = new Date(year, month, 0).getDate();
                                const days = [];
                                for (let d = 1; d <= daysInMonth; d++) {
                                    days.push(`${year}-${monthStr}-${String(d).padStart(2, '0')}`);
                                }
                                const workingDays = [...new Set(filteredAttendance.map(a => a.date))].length;

                                // Prepare table data
                                const headers = ['SN', 'Student Name'];
                                days.forEach(date => {
                                    const d = new Date(date);
                                    headers.push(`${d.getDate()} ${d.toLocaleString('default', { month: 'short' })}`);
                                });
                                headers.push('Present', 'Absent', 'Working Days', 'Average');

                                const rows = students.map((s, index) => {
                                    const row = [(index + 1), s.full_name || '-'];
                                    let present = 0;
                                    days.forEach(date => {
                                        const att = filteredAttendance.find(a => a.student_id === s.id && a.date === date);
                                        const status = att ? att.status : '0';
                                        row.push(status === '1' ? '✓' : '✗');
                                        if (status === '1') present++;
                                    });
                                    const absent = workingDays - present;
                                    const average = workingDays > 0 ? ((present / workingDays) * 100).toFixed(1) : '0.0';
                                    row.push(present, absent, workingDays, `${average}%`);
                                    return row;
                                });

                                // Generate Excel
                                const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
                                const wb = XLSX.utils.book_new();
                                XLSX.utils.book_append_sheet(wb, ws, 'Attendance');
                                XLSX.writeFile(wb, `student_attendance_report_${year}_${monthStr}.xlsx`);
                                $btn.find('.btn-spinner').hide();
                                $btn.find('.btn-content').show();
                            },
                            error: function(xhr) {
                                console.error('Excel Attendance Error:', xhr.responseJSON || xhr.statusText);
                                $btn.find('.btn-spinner').hide();
                                $btn.find('.btn-content').show();
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to export Excel: ' + (xhr.responseJSON?.message || xhr.statusText)
                                });
                            }
                        });
                    },
                    error: function(xhr) {
                        console.error('Excel Student Error:', xhr.responseJSON || xhr.statusText);
                        $btn.find('.btn-spinner').hide();
                        $btn.find('.btn-content').show();
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to export Excel: ' + (xhr.responseJSON?.message || xhr.statusText)
                        });
                    }
                });
            });

            // Initial load: Fetch classes and then attendance report
            fetchClasses().then(() => {
                fetchAttendanceReport(year, month);
            });
        });
    </script>
</body>
</html>