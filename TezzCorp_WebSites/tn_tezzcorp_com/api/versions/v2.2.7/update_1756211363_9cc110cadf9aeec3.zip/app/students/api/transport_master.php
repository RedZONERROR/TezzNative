<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

class TransportMasterController {
    private $pdo;
    private $logger;

    public function __construct() {
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode([
            'status' => 'error',
            'message' => $message
        ]);
        exit;
    }

    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode(array_merge([
            'status' => 'success'
        ], $data));
        exit;
    }

    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    public function get() {
        try {
            $stmt = $this->pdo->prepare("
                SELECT id, registration_no, driver_name, from_location, transport_fees
                FROM transport
                WHERE status = 'active'
                ORDER BY registration_no ASC
            ");
            $stmt->execute();
            $transports = $stmt->fetchAll();

            $this->sendSuccess(200, [
                'data' => $transports
            ]);
        } catch (Exception $e) {
            $this->logError('Failed to fetch transports: ' . $e->getMessage());
            $this->sendError(500, 'Failed to fetch transports: ' . $e->getMessage());
        }
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];

        if ($method === 'GET') {
            $this->get();
        } else {
            $this->sendError(405, 'Method not allowed');
        }
    }
}

if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

$controller = new TransportMasterController();
$controller->handleRequest();
?>