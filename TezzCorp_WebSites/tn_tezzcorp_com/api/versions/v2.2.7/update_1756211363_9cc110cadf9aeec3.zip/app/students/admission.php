<?php
session_start();
if(!isset($_SESSION['uid'])){
    header("location: ../../login");
    die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">

<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/additional-methods.min.js"></script>
    <script src="../assets/js/jquery.steps.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Student Admission - AI-ERP 2.0</title>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar -->
        <?php include 'util/sidebar.php'; ?>
        <div class="page-wrapper">
            <!-- Header -->
            <?php include 'util/topbar.php'; ?>

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Student Admission Form</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Admission Form
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Admission Form -->
                    <div class="card">
                        <div class="card-body wizard-content">
                            <h4 class="card-title">Step Wizard with Validation</h4>
                            <p class="card-subtitle mb-3">Complete the form step-by-step</p>
                            <div id="error-message" class="alert alert-danger d-none"></div>
                            <form id="admission-form" class="validation-wizard wizard-circle mt-5" enctype="multipart/form-data">
                                <!-- Step 1 -->
                                <h6>Personal Information</h6>
                                <section id="section_1">
                                    <div class="d-flex justify-content-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                    </div>
                                    <div class="row" id="personal_fields"></div>
                                </section>
                                <!-- Step 2 -->
                                <h6>Academic & Identity</h6>
                                <section id="section_2">
                                    <div class="d-flex justify-content-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                    </div>
                                    <div class="row" id="parent_fields"></div>
                                    <div class="row" id="academic_identity_fields"></div>
                                </section>
                                <!-- Step 3 -->
                                <h6>Address & Additional Info</h6>
                                <section id="section_3">
                                    <div class="d-flex justify-content-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                    </div>
                                    <div class="row" id="address_employment_fields"></div>
                                    <div class="row" id="transport_fields"></div>
                                </section>
                                <!-- Step 4 -->
                                <h6>Documents</h6>
                                <section id="section_4">
                                    <div class="d-flex justify-content-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                    </div>
                                    <div class="row" id="document_fields"></div>
                                </section>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Initialize jQuery Steps
            const form = $("#admission-form").show();
            form.steps({
                headerTag: "h6",
                bodyTag: "section",
                transitionEffect: "fade",
                titleTemplate: '<span class="step">#index#</span> #title#',
                labels: {
                    finish: "Submit",
                    next: "Next <span class='spinner-border spinner-border-sm d-none'></span>",
                    previous: "Previous"
                },
                onStepChanging: function(event, currentIndex, newIndex) {
                    if (currentIndex < newIndex) {
                        $('.btn-next .spinner-border').removeClass('d-none');
                        const currentStep = $(form.steps('getCurrentStep'));
                        const inputs = currentStep.find(':input').not(':hidden');
                        let isValid = true;
                        inputs.each(function() {
                            if (!form.validate().element(this)) {
                                isValid = false;
                            }
                        });
                        if (!isValid) {
                            $('.btn-next .spinner-border').addClass('d-none');
                            $('#error-message')
                                .text('Please correct the errors in the current step.')
                                .removeClass('d-none');
                            return false;
                        }
                        $('.btn-next .spinner-border').addClass('d-none');
                        $('#error-message').addClass('d-none');
                        return true;
                    }
                    return true;
                },
                onFinishing: function(event, currentIndex) {
                    return form.valid();
                },
                onFinished: function(event, currentIndex) {
                    submitForm();
                }
            });

            // Add custom validation methods
            $.validator.addMethod("aadhaar", function(value, element) {
                return this.optional(element) || /^\d{12}$/.test(value);
            }, "Please enter a valid 12-digit Aadhaar number");

            $.validator.addMethod("mobile", function(value, element) {
                return this.optional(element) || /^\d{10}$/.test(value);
            }, "Please enter a valid 10-digit mobile number");

            $.validator.addMethod("pastDate", function(value, element) {
                if (!value) return this.optional(element);
                const selectedDate = new Date(value);
                const currentDate = new Date();
                return selectedDate < currentDate;
            }, "Date of birth must be in the past");

            $.validator.addMethod("enumSelect", function(value, element, param) {
                if (!value) return this.optional(element);
                return param.includes(value);
            }, "Please select a valid option");

            $.validator.addMethod("filesize", function(value, element, param) {
                return this.optional(element) || (element.files && element.files[0] && element.files[0].size <= param);
            }, "File size must be less than 5MB");

            // Initialize jQuery Validation
            const validator = form.validate({
                ignore: "input[type=hidden]",
                errorElement: "div",
                errorClass: "invalid-feedback",
                errorPlacement: function(error, element) {
                    error.appendTo(element.closest('.mb-3'));
                },
                highlight: function(element) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element) {
                    $(element).removeClass('is-invalid');
                },
                rules: {
                    aadhaar_number: { aadhaar: true },
                    mobile_number: { mobile: true },
                    father_mobile: { mobile: true },
                    mother_mobile: { mobile: true },
                    date_of_birth: { pastDate: true },
                    father_dob: { pastDate: true },
                    mother_dob: { pastDate: true },
                    gender: { enumSelect: ['Male', 'Female', 'Other'] },
                    social_category: { enumSelect: ['General', 'OBC', 'EBC', 'SC', 'ST'] },
                    religion: { enumSelect: ['Hindu', 'Muslim', 'Christian', 'Sikh', 'Other'] },
                    mother_tongue: { enumSelect: ['Hindi', 'English', 'Bengali', 'Tamil', 'Other'] },
                    category: { enumSelect: ['General', 'OBC', 'EBC', 'SC', 'ST'] },
                    medium: { enumSelect: ['English', 'Hindi', 'Regional'] },
                    class: { required: true, number: true },
                    transport_id: { number: true }
                },
                messages: {
                    class: {
                        required: "Please select a class",
                        number: "Please select a valid class"
                    },
                    transport_id: {
                        number: "Please select a valid transport option"
                    }
                }
            });

            // Show section loaders
            $('.spinner-border').show();

            // Fetch form fields, classes, and transports in parallel
            let transportOptions = [];
            Promise.all([
                $.ajax({
                    url: 'api/form_element_master.php',
                    type: 'GET',
                    data: { perPage: 100 },
                    dataType: 'json'
                }),
                $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 100 },
                    dataType: 'json'
                }),
                $.ajax({
                    url: 'api/transport_master.php',
                    type: 'GET',
                    dataType: 'json'
                })
            ]).then(([formResponse, classResponse, transportResponse]) => {
                const fields = formResponse.data?.elements || [];
                const classes = classResponse.data || [];
                transportOptions = transportResponse.data || [];
                renderFormFields(fields, classes);
                $('.spinner-border').hide();
                validator.resetForm();
                form.validate().form();

                $('#date_of_birth').on('change', function() {
                    calculateAge($(this).val());
                });

                // Toggle transport_id field visibility
                $('#transport').on('change', function() {
                    const isChecked = $(this).is(':checked');
                    $('#transport_id_container').toggle(isChecked);
                    if (!isChecked) {
                        $('#transport_id').val('').trigger('change');
                    }
                });
            }).catch(error => {
                $('.spinner-border').hide();
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Failed to load form fields, classes, or transports: ' + (error.responseJSON?.message || error.message)
                });
            });

            // Function to calculate age based on date of birth
            function calculateAge(dob) {
                if (!dob) return;
                const dobDate = new Date(dob);
                const currentDate = new Date('2025-08-24T15:15:00+05:30'); // Current date: Aug 24, 2025, 03:15 PM IST

                let years = currentDate.getFullYear() - dobDate.getFullYear();
                let months = currentDate.getMonth() - dobDate.getMonth();
                let days = currentDate.getDate() - dobDate.getDate();

                if (days < 0) {
                    months--;
                    days += new Date(currentDate.getFullYear(), currentDate.getMonth(), 0).getDate();
                }
                if (months < 0) {
                    years--;
                    months += 12;
                }

                $('#age_year').val(years);
                $('#age_months').val(months);
                $('#age_days').val(days);
            }

            // Render form fields
            function renderFormFields(fields, classes) {
                const sectionMap = {
                    'Personal Information': '#personal_fields',
                    'Parent Information': '#parent_fields',
                    'Academic Information': '#academic_identity_fields',
                    'Additional Information': '#address_employment_fields',
                    'Contact Information': '#address_employment_fields',
                    'Financial Information': '#address_employment_fields',
                    'Health Information': '#address_employment_fields',
                    'School Information': '#address_employment_fields',
                    'Socio-Economic': '#address_employment_fields',
                    'System Information': '#document_fields',
                    'Documents': '#document_fields'
                };

                // Clear all containers
                Object.values(sectionMap).forEach(sel => $(sel).empty());

                // Check if a "class" field already exists in the fields
                const hasClassField = fields.some(field => field.column_name === 'class');

                // Group fields by section
                const grouped = {};
                fields.sort(function(a, b) {
                    if (a.section === b.section) {
                        return (parseInt(a.display_order) || 0) - (parseInt(b.display_order) || 0);
                    }
                    return a.section.localeCompare(b.section);
                });
                fields.forEach(field => {
                    if (!grouped[field.section]) grouped[field.section] = [];
                    grouped[field.section].push(field);
                });

                // Render each section in rows of two
                Object.keys(grouped).forEach(section => {
                    const container = $(sectionMap[section] || '#personal_fields');
                    const sectionFields = grouped[section];
                    for (let i = 0; i < sectionFields.length; i += 2) {
                        let rowHtml = '<div class="row">';
                        rowHtml += renderFieldHtml(sectionFields[i], section === 'Academic Information' && sectionFields[i].column_name === 'class' ? classes : null);
                        if (i + 1 < sectionFields.length) {
                            rowHtml += renderFieldHtml(sectionFields[i + 1], section === 'Academic Information' && sectionFields[i + 1].column_name === 'class' ? classes : null);
                        }
                        rowHtml += '</div>';
                        container.append(rowHtml);
                    }
                });

                // If no class field was found in the API response, add it manually
                if (!hasClassField) {
                    const classFieldHtml = `
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Class <span class="text-danger">*</span></label>
                            <select class="form-select" name="class" id="class" required>
                                <option value="">Select Class</option>
                                ${classes.map(cls => `<option value="${cls.id}">${cls.class_name}</option>`).join('')}
                            </select>
                            <div class="invalid-feedback"></div>
                        </div>
                    `;
                    $(sectionMap['Academic Information']).append(`<div class="row">${classFieldHtml}</div>`);
                }

                // Add transport_id field in the Additional Information section
                const transportFieldHtml = `
                    <div class="row">
                        <div class="col-md-6 mb-3" id="transport_id_container" style="display: none;">
                            <label class="form-label">Transport Option</label>
                            <select class="form-select" name="transport_id" id="transport_id">
                                <option value="">Select Transport</option>
                                ${transportOptions.map(t => `<option value="${t.id}">${t.registration_no} - ${t.driver_name} - ${t.from_location} - ₹${t.transport_fees}</option>`).join('')}
                            </select>
                            <div class="invalid-feedback"></div>
                        </div>
                    </div>
                `;
                $('#transport_fields').append(transportFieldHtml);
            }

            // Helper to render a single field
            function renderFieldHtml(field, classOptions = null) {
                const fieldName = field.column_name;
                const isRequired = field.is_required ? 'required' : '';
                const label = `<label class="form-label">${field.field_name}${field.is_required ? ' *' : ''}</label>`;
                let inputHtml = '';

                // Special handling for the class field to use classOptions
                if (fieldName === 'class' && classOptions) {
                    inputHtml = `
                        <div class="col-md-6 mb-3">
                            ${label}
                            <select class="form-select" name="${fieldName}" id="${fieldName}" ${isRequired}>
                                <option value="">Select ${field.field_name}</option>
                                ${classOptions.map(cls => `<option value="${cls.id}">${cls.class_name}</option>`).join('')}
                            </select>
                            <div class="invalid-feedback"></div>
                        </div>`;
                } else {
                    switch (field.field_type) {
                        case 'text':
                        case 'email':
                        case 'password':
                        case 'number':
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <input type="${field.field_type}" class="form-control" name="${fieldName}" id="${fieldName}"
                                        placeholder="${field.placeholder || ''}" ${isRequired}>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        case 'date':
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <input type="date" class="form-control" name="${fieldName}" id="${fieldName}" ${isRequired}>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        case 'select':
                            let options = '';
                            if (field.options) {
                                options = field.options.split(',').map(opt => {
                                    const parts = opt.split(':');
                                    if (parts.length === 2) {
                                        return `<option value="${parts[0].trim()}">${parts[1].trim()}</option>`;
                                    } else {
                                        return `<option value="${opt.trim()}">${opt.trim()}</option>`;
                                    }
                                }).join('');
                            }
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <select class="form-select" name="${fieldName}" id="${fieldName}" ${isRequired}>
                                        <option value="">Select ${field.field_name}</option>
                                        ${options}
                                    </select>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        case 'file':
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <input type="file" class="form-control" name="${fieldName}" id="${fieldName}" ${isRequired}>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        case 'textarea':
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <textarea class="form-control" name="${fieldName}" id="${fieldName}" rows="4" ${isRequired}></textarea>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        case 'checkbox':
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    <div class="form-check mt-4">
                                        <input type="checkbox" class="form-check-input" name="${fieldName}" id="${fieldName}" value="1" ${isRequired}>
                                        <label class="form-check-label" for="${fieldName}">${field.field_name}</label>
                                    </div>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        default:
                            return '';
                    }
                }

                // Add validation rules dynamically
                if (!validator.settings.rules[fieldName]) validator.settings.rules[fieldName] = {};
                if (!validator.settings.messages[fieldName]) validator.settings.messages[fieldName] = {};
                if (field.is_required) {
                    if (field.field_type !== 'checkbox') {
                        validator.settings.rules[fieldName].required = true;
                        validator.settings.messages[fieldName].required = `Please enter ${field.field_name}`;
                    }
                }
                if (field.field_type === 'email') {
                    validator.settings.rules[fieldName].email = true;
                    validator.settings.messages[fieldName].email = 'Please enter a valid email address';
                }
                if (field.field_type === 'number') {
                    validator.settings.rules[fieldName].number = true;
                    validator.settings.messages[fieldName].number = 'Please enter a valid number';
                }
                if (field.field_type === 'file') {
                    validator.settings.rules[fieldName].extension = "jpg|jpeg|png|pdf|doc|docx";
                    validator.settings.messages[fieldName].extension = 'Please upload a file with a valid extension (jpg, jpeg, png, pdf, doc, docx)';
                    validator.settings.rules[fieldName].filesize = 5 * 1024 * 1024;
                    validator.settings.messages[fieldName].filesize = 'File size must be less than 5MB';
                }
                return inputHtml;
            }

            // Submit form
            function submitForm() {
                if (!form.valid()) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Validation Error',
                        text: 'Please correct the errors in the form'
                    });
                    return;
                }
                const formData = new FormData(form[0]);
                const fileFields = [
                    'progress_report', 'birth_certificate', 'slc', 'residential_proof',
                    'father_photo', 'student_photo', 'mother_photo', 'aadhaar_card_upload'
                ];

                const filesToUpload = fileFields.filter(field => {
                    const file = formData.get(field);
                    return file && file.size > 0;
                });

                Promise.all(filesToUpload.map(field => {
                    const file = formData.get(field);
                    if (file && file.size > 0) {
                        const uploadData = new FormData();
                        uploadData.append('file', file);
                        uploadData.append('field', field);
                        return $.ajax({
                            url: 'api/upload.php',
                            type: 'POST',
                            data: uploadData,
                            processData: false,
                            contentType: false,
                            dataType: 'json'
                        }).then(response => {
                            if (response.path) {
                                formData.set(field, response.path);
                            } else {
                                throw new Error(`Failed to upload ${field}`);
                            }
                        });
                    }
                    return Promise.resolve();
                })).then(() => {
                    $.ajax({
                        url: 'api/student_master.php',
                        type: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,
                        dataType: 'json',
                        success: function(response) {
                            if (response.status === 201 || response.status === 'success') {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Success',
                                    text: response.message || 'Student registered successfully!'
                                }).then(() => {
                                    window.location.reload();
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: response.message || 'Something went wrong.'
                                });
                            }
                        },
                        error: function(xhr) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: xhr.responseJSON?.error || 'Something went wrong.'
                            });
                        }
                    });
                }).catch(error => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Upload Error',
                        text: error.message
                    });
                });
            }
        });
    </script>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
</body>

</html>