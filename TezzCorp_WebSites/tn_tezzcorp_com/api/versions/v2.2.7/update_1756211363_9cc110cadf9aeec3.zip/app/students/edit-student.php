<?php
session_start();
if(!isset($_SESSION['uid'])){
    header("location: ../../login");
    die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/additional-methods.min.js"></script>
    <script src="../assets/js/jquery.steps.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Edit Student - AI-ERP 2.0</title>
    <style>
        .btn-loading .fa-spinner {
            display: inline-block;
        }
        .btn-loading .btn-text {
            display: none;
        }
        .fa-spinner {
            display: none;
            font-size: 0.9rem;
        }
        .current-file {
            font-size: 0.9rem;
            color: #6c757d;
            margin-top: 5px;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar -->
        <?php include 'util/sidebar.php'; ?>
        <div class="page-wrapper">
            <!-- Header -->
            <?php include 'util/topbar.php'; ?>

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Edit Student</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <a class="text-muted text-decoration-none" href="students">Students</a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Edit Student
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Edit Form -->
                    <div class="card">
                        <div class="card-body wizard-content">
                            <h4 class="card-title">Edit Student Details</h4>
                            <p class="card-subtitle mb-3">Update the student information step-by-step</p>
                            <div id="error-message" class="alert alert-danger d-none"></div>
                            <form id="edit-student-form" class="validation-wizard wizard-circle mt-5" enctype="multipart/form-data">
                                <!-- Step 1 -->
                                <h6>Personal Information</h6>
                                <section id="section_1">
                                    <div class="d-flex justify-content-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                    </div>
                                    <div class="row" id="personal_fields"></div>
                                </section>
                                <!-- Step 2 -->
                                <h6>Academic & Identity</h6>
                                <section id="section_2">
                                    <div class="d-flex justify-content-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                    </div>
                                    <div class="row" id="parent_fields"></div>
                                    <div class="row" id="academic_identity_fields"></div>
                                </section>
                                <!-- Step 3 -->
                                <h6>Address & Additional Info</h6>
                                <section id="section_3">
                                    <div class="d-flex justify-content-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                    </div>
                                    <div class="row" id="address_employment_fields"></div>
                                    <div class="row" id="transport_fields"></div>
                                </section>
                                <!-- Step 4 -->
                                <h6>Documents</h6>
                                <section id="section_4">
                                    <div class="d-flex justify-content-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                    </div>
                                    <div class="row" id="document_fields"></div>
                                </section>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>

    <script>
        $(document).ready(function() {
            // Get student UID from URL
            const urlParams = new URLSearchParams(window.location.search);
            const studentUid = urlParams.get('uid');
            if (!studentUid || !/^STU[A-Z0-9]{13}$/.test(studentUid)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid Student UID',
                    text: 'Please provide a valid student UID in the URL.'
                }).then(() => {
                    window.location.href = 'students';
                });
                return;
            }

            // Initialize jQuery Steps
            const form = $("#edit-student-form").show();
            form.steps({
                headerTag: "h6",
                bodyTag: "section",
                transitionEffect: "fade",
                titleTemplate: '<span class="step">#index#</span> #title#',
                labels: {
                    finish: '<span class="btn-text">Update</span><i class="fas fa-spinner fa-spin"></i>',
                    next: '<span class="btn-text">Next</span><i class="fas fa-spinner fa-spin"></i>',
                    previous: '<span class="btn-text">Previous</span><i class="fas fa-spinner fa-spin"></i>'
                },
                onStepChanging: function(event, currentIndex, newIndex) {
                    if (currentIndex < newIndex) {
                        $('.actions a[href="#next"]').addClass('btn-loading');
                        const currentStep = $(form.steps('getCurrentStep'));
                        const inputs = currentStep.find(':input').not(':hidden');
                        let isValid = true;

                        inputs.each(function() {
                            if (!form.validate().element(this)) {
                                isValid = false;
                            }
                        });

                        if (!isValid) {
                            $('.actions a[href="#next"]').removeClass('btn-loading');
                            $('#error-message')
                                .text('Please correct the errors in the current step.')
                                .removeClass('d-none');
                            return false;
                        }

                        $('.actions a[href="#next"]').removeClass('btn-loading');
                        $('#error-message').addClass('d-none');
                        return true;
                    } else {
                        $('.actions a[href="#previous"]').addClass('btn-loading');
                        setTimeout(() => {
                            $('.actions a[href="#previous"]').removeClass('btn-loading');
                        }, 500);
                        return true;
                    }
                },
                onFinishing: function(event, currentIndex) {
                    $('.actions a[href="#finish"]').addClass('btn-loading');
                    const isValid = form.valid();
                    return isValid;
                },
                onFinished: function(event, currentIndex) {
                    submitForm();
                }
            });

            // Add custom validation methods
            $.validator.addMethod("filesize", function(value, element, param) {
                return this.optional(element) || (element.files && element.files[0] && element.files[0].size <= param);
            }, "File size must be less than 5MB");

            // Store required fields metadata and transport options
            let requiredFields = {};
            let existingFiles = {};
            let transportOptions = [];

            // Initialize jQuery Validation
            const validator = form.validate({
                ignore: "input[type=hidden]",
                errorElement: "div",
                errorClass: "invalid-feedback",
                errorPlacement: function(error, element) {
                    error.appendTo(element.closest('.mb-3'));
                },
                highlight: function(element) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element) {
                    $(element).removeClass('is-invalid');
                },
                rules: {
                    aadhaar_number: { digits: true, minlength: 12, maxlength: 12 },
                    full_name: { required: true, maxlength: 255 },
                    date_of_birth: { required: true, date: true },
                    gender: { required: true },
                    mobile_number: { required: true, digits: true, minlength: 10, maxlength: 10 },
                    age_year: { digits: true },
                    age_months: { digits: true },
                    age_days: { digits: true },
                    nationality: { maxlength: 100 },
                    category: { maxlength: 50 },
                    languages: { maxlength: 255 },
                    id_card: { maxlength: 50 },
                    father_name: { required: true, maxlength: 255 },
                    mother_name: { required: true, maxlength: 255 },
                    father_dob: { date: true },
                    father_nationality: { maxlength: 100 },
                    father_qualification: { maxlength: 255 },
                    father_occupation: { maxlength: 255 },
                    father_designation: { maxlength: 255 },
                    father_organization: { maxlength: 255 },
                    father_office_address: { maxlength: 65535 },
                    father_mobile: { digits: true, minlength: 10, maxlength: 10 },
                    mother_dob: { date: true },
                    mother_nationality: { maxlength: 100 },
                    mother_qualification: { maxlength: 255 },
                    mother_occupation: { maxlength: 255 },
                    mother_designation: { maxlength: 255 },
                    mother_organization: { maxlength: 255 },
                    mother_office_address: { maxlength: 65535 },
                    mother_mobile: { digits: true, minlength: 10, maxlength: 10 },
                    last_exam_passed: { maxlength: 255 },
                    stream: { maxlength: 100 },
                    trade_sector: { maxlength: 100 },
                    applying_class: { maxlength: 50 },
                    class: { maxlength: 50 },
                    medium: { maxlength: 50 },
                    contribution: { maxlength: 255 },
                    elaborate_choices: { maxlength: 65535 },
                    rte: { maxlength: 50 },
                    email_address: { email: true, maxlength: 255 },
                    additional_email: { email: true, maxlength: 255 },
                    residential_address: { maxlength: 65535 },
                    permanent_address: { maxlength: 65535 },
                    bank_account_number: { maxlength: 20 },
                    ifsc_code: { maxlength: 11 },
                    registration_no: { maxlength: 50 },
                    session: { maxlength: 20 },
                    roll_no: { maxlength: 20 },
                    current_school: { maxlength: 255 },
                    additional_transport: { maxlength: 255 },
                    transport_id: { 
                        number: true,
                        required: function() {
                            return $('#transport').is(':checked');
                        }
                    },
                    ex_student: { required: false },
                    iron_folic_acid: { required: false },
                    deworming_tablets: { required: false },
                    vitamin_a_supplement: { required: false },
                    mdm_beneficiary: { required: false },
                    free_hostel: { required: false },
                    is_homeless: { required: false },
                    transport: { required: false },
                    staff_child: { required: false },
                    aadhaar_card_upload: { 
                        required: function(element) { return requiredFields['aadhaar_card_upload'] === 1 && !existingFiles['aadhaar_card_upload']; },
                        extension: "jpg|jpeg|png|pdf",
                        filesize: 5 * 1024 * 1024
                    },
                    progress_report: { 
                        required: function(element) { return requiredFields['progress_report'] === 1 && !existingFiles['progress_report']; },
                        extension: "jpg|jpeg|png|pdf",
                        filesize: 5 * 1024 * 1024
                    },
                    birth_certificate: { 
                        required: function(element) { return requiredFields['birth_certificate'] === 1 && !existingFiles['birth_certificate']; },
                        extension: "jpg|jpeg|png|pdf",
                        filesize: 5 * 1024 * 1024
                    },
                    slc: { 
                        required: function(element) { return requiredFields['slc'] === 1 && !existingFiles['slc']; },
                        extension: "jpg|jpeg|png|pdf",
                        filesize: 5 * 1024 * 1024
                    },
                    residential_proof: { 
                        required: function(element) { return requiredFields['residential_proof'] === 1 && !existingFiles['residential_proof']; },
                        extension: "jpg|jpeg|png|pdf",
                        filesize: 5 * 1024 * 1024
                    },
                    father_photo: { 
                        required: function(element) { return requiredFields['father_photo'] === 1 && !existingFiles['father_photo']; },
                        extension: "jpg|jpeg|png",
                        filesize: 5 * 1024 * 1024
                    },
                    student_photo: { 
                        required: function(element) { return requiredFields['student_photo'] === 1 && !existingFiles['student_photo']; },
                        extension: "jpg|jpeg|png",
                        filesize: 5 * 1024 * 1024
                    },
                    mother_photo: { 
                        required: function(element) { return requiredFields['mother_photo'] === 1 && !existingFiles['mother_photo']; },
                        extension: "jpg|jpeg|png",
                        filesize: 5 * 1024 * 1024
                    }
                },
                messages: {
                    aadhaar_number: { digits: "Aadhaar must be 12 digits", minlength: "Aadhaar must be 12 digits", maxlength: "Aadhaar must be 12 digits" },
                    full_name: { required: "Please enter full name" },
                    date_of_birth: { required: "Please enter date of birth", date: "Please enter a valid date" },
                    gender: { required: "Please select a gender" },
                    mobile_number: { required: "Please enter mobile number", digits: "Please enter a valid number", minlength: "Mobile must be 10 digits", maxlength: "Mobile must be 10 digits" },
                    father_name: { required: "Please enter father's name" },
                    mother_name: { required: "Please enter mother's name" },
                    father_mobile: { digits: "Please enter a valid number", minlength: "Mobile must be 10 digits", maxlength: "Mobile must be 10 digits" },
                    mother_mobile: { digits: "Please enter a valid number", minlength: "Mobile must be 10 digits", maxlength: "Mobile must be 10 digits" },
                    email_address: { email: "Please enter a valid email" },
                    additional_email: { email: "Please enter a valid email" },
                    transport_id: { 
                        number: "Please select a valid transport option",
                        required: "Please select a transport option"
                    },
                    student_photo: { extension: "Please upload a JPG, JPEG, or PNG file" }
                }
            });

            // Show section loaders
            $('.spinner-border').show();

            // Fetch student data, classes, and transports concurrently
            let studentData = {};
            let classOptions = [];
            // let transportOptions = [];

            Promise.all([
                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: { uid: studentUid },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Student Master API Response:', response);
                        if (response.status === 'success' && response.data && response.data.length > 0) {
                            studentData = response.data[0];
                            const fileFields = ['aadhaar_card_upload', 'progress_report', 'birth_certificate', 'slc', 
                                'residential_proof', 'father_photo', 'student_photo', 'mother_photo'];
                            fileFields.forEach(field => {
                                existingFiles[field] = studentData[field] ? studentData[field] : null;
                            });
                        } else {
                            throw new Error('Student not found');
                        }
                    },
                    error: function(xhr, status, error) {
                        throw new Error('Failed to load student data: ' + (xhr.responseJSON?.message || error));
                    }
                }),
                $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 100, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Class Master API Response:', response);
                        if (response.data && Array.isArray(response.data)) {
                            classOptions = response.data;
                        } else {
                            console.warn('No valid classes found in response:', response);
                            classOptions = [];
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Failed to load classes:', {
                            status: status,
                            error: error,
                            response: xhr.responseJSON || xhr.responseText
                        });
                        classOptions = [];
                        Swal.fire({
                            icon: 'warning',
                            title: 'Warning',
                            text: 'Failed to load class options. Please try again later.'
                        });
                    }
                }),
                $.ajax({
                    url: 'api/transport_master.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        console.log('Transport Master API Response:', response);
                        transportOptions = response.data || [];
                    },
                    error: function(xhr, status, error) {
                        console.error('Failed to load transports:', {
                            status: status,
                            error: error,
                            response: xhr.responseJSON || xhr.responseText
                        });
                        transportOptions = [];
                        Swal.fire({
                            icon: 'warning',
                            title: 'Warning',
                            text: 'Failed to load transport options. Please try again later.'
                        });
                    }
                })
            ]).then(() => {
                console.log('Class Options after fetch:', classOptions);
                console.log('Transport Options after fetch:', transportOptions);
                fetchFormFields();
            }).catch(error => {
                $('.spinner-border').hide();
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: error.message || 'Failed to load data'
                }).then(() => {
                    window.location.href = 'students';
                });
            });

            // Fetch form fields from form_element_master.php
            function fetchFormFields() {
                $.ajax({
                    url: 'api/form_element_master.php',
                    type: 'GET',
                    data: { perPage: 100, status: 'active', entity: 'student' },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Form Element API Response:', response);
                        let fields = (response.data && response.data.elements) || response.form_elements || [];
                        if (!Array.isArray(fields)) {
                            console.warn('Fields is not an array, converting to empty array:', fields);
                            fields = [];
                        }
                        console.log('Fields:', fields);
                        if (!fields || fields.length === 0) {
                            Swal.fire({
                                icon: 'error',
                                title: 'No Form Fields',
                                text: 'No form fields found for students.'
                            });
                            $('.spinner-border').hide();
                            return;
                        }
                        renderFormFields(fields);
                        $('.spinner-border').hide();
                        validator.resetForm();
                        form.validate().form();

                        // Toggle transport_id field visibility based on transport checkbox
                        $('#transport').on('change', function() {
                            const isChecked = $(this).is(':checked');
                            console.log('Transport checkbox changed:', isChecked);
                            $('#transport_id_container').toggle(isChecked);
                            if (!isChecked) {
                                $('#transport_id').val('').trigger('change');
                            }
                        });

                        // Trigger initial visibility based on studentData.transport
                        console.log('Initial transport value:', studentData.transport);
                        if (studentData.transport == '1' || studentData.transport === 1) {
                            $('#transport').prop('checked', true);
                            $('#transport_id_container').show();
                        } else {
                            $('#transport').prop('checked', false);
                            $('#transport_id_container').hide();
                        }
                    },
                    error: function(xhr, status, error) {
                        $('.spinner-border').hide();
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load form fields: ' + (xhr.responseJSON?.message || error)
                        });
                    }
                });
            }

            // Render form fields
            function renderFormFields(fields) {
                const sectionMap = {
                    'Personal Information': '#personal_fields',
                    'Parent Information': '#parent_fields',
                    'Academic Information': '#academic_identity_fields',
                    'Additional Information': '#address_employment_fields',
                    'Contact Information': '#address_employment_fields',
                    'Financial Information': '#address_employment_fields',
                    'Health Information': '#address_employment_fields',
                    'School Information': '#address_employment_fields',
                    'Socio-Economic': '#address_employment_fields',
                    'System Information': '#document_fields',
                    'Documents': '#document_fields',
                    'System Information': null // Skip system fields
                };

                // Clear all containers
                Object.values(sectionMap).forEach(sel => {
                    if (sel) $(sel).empty();
                });
                $('#transport_fields').empty();

                // Populate requiredFields
                fields.forEach(field => {
                    requiredFields[field.column_name] = parseInt(field.is_required, 10);
                });

                // Check if a "class" field exists in the fields
                const hasClassField = fields.some(field => field.column_name === 'class');

                // Group fields by section and sort
                const grouped = {};
                fields.sort(function(a, b) {
                    if (a.section === b.section) {
                        return (parseInt(a.display_order) || 0) - (parseInt(b.display_order) || 0);
                    }
                    return a.section.localeCompare(b.section);
                });
                fields.forEach(field => {
                    if (!grouped[field.section]) grouped[field.section] = [];
                    grouped[field.section].push(field);
                });

                // Render each section in rows of two
                Object.keys(grouped).forEach(section => {
                    const container = $(sectionMap[section] || '#personal_fields');
                    if (!container.length) return;
                    const sectionFields = grouped[section];
                    for (let i = 0; i < sectionFields.length; i += 2) {
                        let rowHtml = '<div class="row">';
                        rowHtml += renderFieldHtml(sectionFields[i], section === 'Academic Information' && sectionFields[i].column_name === 'class' ? classOptions : null);
                        if (i + 1 < sectionFields.length) {
                            rowHtml += renderFieldHtml(sectionFields[i + 1], section === 'Academic Information' && sectionFields[i + 1].column_name === 'class' ? classOptions : null);
                        }
                        rowHtml += '</div>';
                        container.append(rowHtml);
                    }
                });

                // If no class field was found, add it manually
                if (!hasClassField) {
                    const classFieldHtml = `
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Class <span class="text-danger">*</span></label>
                            <select class="form-select" name="class" id="class" required>
                                <option value="">Select Class</option>
                                ${classOptions.map(cls => `<option value="${cls.id}" ${cls.id == studentData.class ? 'selected' : ''}>${cls.class_name}</option>`).join('')}
                            </select>
                            <div class="invalid-feedback"></div>
                        </div>
                    `;
                    $(sectionMap['Academic Information']).append(`<div class="row">${classFieldHtml}</div>`);
                }

                // Add transport_id field in the Additional Information section
                const transportFieldHtml = `
                    <div class="row">
                        <div class="col-md-6 mb-3" id="transport_id_container" style="display: ${studentData.transport == '1' || studentData.transport === 1 ? 'block' : 'none'};">
                            <label class="form-label">Transport Option</label>
                            <select class="form-select" name="transport_id" id="transport_id">
                                <option value="">Select Transport</option>
                                ${transportOptions.map(t => `<option value="${t.id}" ${t.id == studentData.transport_id ? 'selected' : ''}>${t.registration_no} - ${t.driver_name} - ${t.from_location} - ₹${t.transport_fees}</option>`).join('')}
                            </select>
                            <div class="invalid-feedback"></div>
                        </div>
                    </div>
                `;
                $('#transport_fields').append(transportFieldHtml);
            }

            // Helper to render a single field
            function renderFieldHtml(field, classOptions = null) {
                if (field.is_system == 1) return ''; // Skip system fields
                const fieldName = field.column_name;
                const isRequired = field.is_required == 1 ? 'required' : '';
                const label = `<label class="form-label">${field.field_name}${field.is_required == 1 ? ' *' : ''}</label>`;
                let inputHtml = '';
                const value = studentData[fieldName] ?? '';

                // Special handling for the class field to use classOptions
                if (fieldName === 'class' && classOptions) {
                    const options = classOptions.length > 0
                        ? classOptions.map(cls => {
                              return `<option value="${cls.id}" ${cls.id == value ? 'selected' : ''}>${cls.class_name}</option>`;
                          }).join('')
                        : '<option value="">No classes available</option>';
                    inputHtml = `
                        <div class="col-md-6 mb-3">
                            ${label}
                            <select class="form-select" name="${fieldName}" id="${fieldName}" ${isRequired}>
                                <option value="">Select ${field.field_name}</option>
                                ${options}
                            </select>
                            <div class="invalid-feedback"></div>
                        </div>`;
                } else {
                    switch (field.field_type) {
                        case 'text':
                        case 'email':
                        case 'number':
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <input type="${field.field_type}" class="form-control" name="${fieldName}" id="${fieldName}"
                                        placeholder="${field.placeholder || ''}" value="${value}" ${isRequired}>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        case 'date':
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <input type="date" class="form-control" name="${fieldName}" id="${fieldName}" value="${value}" ${isRequired}>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        case 'select':
                            const options = field.options ? field.options.split(',').map(opt => {
                                const trimmedOpt = opt.trim();
                                return `<option value="${trimmedOpt}" ${trimmedOpt === value ? 'selected' : ''}>${trimmedOpt}</option>`;
                            }).join('') : '';
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <select class="form-select" name="${fieldName}" id="${fieldName}" ${isRequired}>
                                        <option value="">Select ${field.field_name}</option>
                                        ${options}
                                    </select>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        case 'file':
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <input type="file" class="form-control" name="${fieldName}" id="${fieldName}" ${value ? '' : isRequired}>
                                    ${value ? `<div class="current-file">Current file: <a href="/${value}" target="_blank">${value}</a></div>` : ''}
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        case 'textarea':
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    ${label}
                                    <textarea class="form-control" name="${fieldName}" id="${fieldName}" rows="4" ${isRequired}>${value}</textarea>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        case 'checkbox':
                            const isChecked = fieldName === 'transport' && (value == '1' || value === 1 || value === true) ? 'checked' : '';
                            console.log(`Rendering checkbox for ${fieldName}: value=${value}, isChecked=${isChecked}`);
                            inputHtml = `
                                <div class="col-md-6 mb-3">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" name="${fieldName}" id="${fieldName}" ${isChecked}>
                                        <label class="form-check-label" for="${fieldName}">${field.field_name}${field.is_required == 1 ? ' *' : ''}</label>
                                    </div>
                                    <div class="invalid-feedback"></div>
                                </div>`;
                            break;
                        default:
                            console.warn('Skipped field due to unsupported type:', field);
                            return '';
                    }
                }

                // Add validation rules dynamically
                if (!validator.settings.rules[fieldName]) validator.settings.rules[fieldName] = {};
                if (!validator.settings.messages[fieldName]) validator.settings.messages[fieldName] = {};
                if (field.is_required == 1) {
                    if (field.field_type !== 'checkbox') {
                        validator.settings.rules[fieldName].required = true;
                        validator.settings.messages[fieldName].required = `Please enter ${field.field_name}`;
                    }
                }
                if (field.field_type === 'email') {
                    validator.settings.rules[fieldName].email = true;
                    validator.settings.messages[fieldName].email = 'Please enter a valid email address';
                }
                if (field.field_type === 'number') {
                    validator.settings.rules[fieldName].number = true;
                    validator.settings.messages[fieldName].number = 'Please enter a valid number';
                }
                if (field.field_type === 'file') {
                    validator.settings.rules[fieldName].extension = "jpg|jpeg|png|pdf|doc|docx";
                    validator.settings.messages[fieldName].extension = 'Please upload a file with a valid extension (jpg, jpeg, png, pdf, doc, docx)';
                    validator.settings.rules[fieldName].filesize = 5 * 1024 * 1024;
                    validator.settings.messages[fieldName].filesize = 'File size must be less than 5MB';
                }
                return inputHtml;
            }

            // Submit form
            function submitForm() {
                if (!form.valid()) {
                    $('.actions a[href="#finish"]').removeClass('btn-loading');
                    Swal.fire({
                        icon: 'error',
                        title: 'Validation Error',
                        text: 'Please correct the errors in the form'
                    });
                    return;
                }

                const formData = new FormData(form[0]);
                const fileFields = ['aadhaar_card_upload', 'progress_report', 'birth_certificate', 'slc', 
                    'residential_proof', 'father_photo', 'student_photo', 'mother_photo'];

                Promise.all(fileFields.map(field => {
                    const file = formData.get(field);
                    const isRequired = requiredFields[field] === 1;
                    if (file && file.size > 0) {
                        const uploadData = new FormData();
                        uploadData.append('file', file);
                        uploadData.append('field', field);
                        return $.ajax({
                            url: 'api/upload.php',
                            type: 'POST',
                            data: uploadData,
                            processData: false,
                            contentType: false,
                            dataType: 'json'
                        }).then(response => {
                            if (response.path) {
                                formData.set(field, response.path);
                            } else {
                                throw new Error(`Failed to upload ${field}`);
                            }
                        });
                    } else if (isRequired && !existingFiles[field]) {
                        return Promise.reject(new Error(`${field} is required but no file was uploaded`));
                    } else {
                        formData.set(field, existingFiles[field] || '');
                    }
                    return Promise.resolve();
                })).then(() => {
                    const jsonData = { uid: studentUid };
                    formData.forEach((value, key) => {
                        if (value && key !== 'tsv') {
                            // Convert transport checkbox value to boolean (1 or 0)
                            if (key === 'transport') {
                                jsonData[key] = value === 'on' ? '1' : '0';
                            } else {
                                jsonData[key] = value;
                            }
                        }
                    });

                    // Include transport_id in jsonData if transport is checked
                    if (jsonData.transport === '1') {
                        jsonData.transport_id = formData.get('transport_id') || '';
                    } else {
                        jsonData.transport_id = '';
                    }

                    $.ajax({
                        url: 'api/student_master.php',
                        type: 'PUT',
                        contentType: 'application/json',
                        data: JSON.stringify(jsonData),
                        dataType: 'json',
                        success: function(response) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success',
                                text: response.message || 'Student updated successfully'
                            }).then(() => {
                                window.location.href = 'students';
                            });
                        },
                        error: function(xhr, status, error) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to update student: ' + (xhr.responseJSON?.message || error)
                            });
                        },
                        complete: function() {
                            $('.actions a[href="#finish"]').removeClass('btn-loading');
                        }
                    });
                }).catch(error => {
                    $('.actions a[href="#finish"]').removeClass('btn-loading');
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: error.message || 'Failed to upload files'
                    });
                });
            }
        });
    </script>
</body>
</html>