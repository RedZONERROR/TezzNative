<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=UTF-8');

class AdmitCardController {
    private $pdo;
    private $logger;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    // Validate input data
    private function validateInput(array $post, array $files): array {
        $this->logError('Validating input: POST=' . json_encode($post) . ', FILES=' . json_encode($files));
        $errors = [];
        $validData = [];

        // Validate class_id
        if (!isset($post['class_id']) || !filter_var($post['class_id'], FILTER_VALIDATE_INT)) {
            $errors[] = "class_id must be a valid integer";
        } else {
            $validData['class_id'] = (int)$post['class_id'];
        }

        // Validate exam schedule
        if (!isset($post['exam_schedule']) || empty(trim($post['exam_schedule']))) {
            $errors[] = "exam_schedule is required";
        } else {
            $examSchedule = json_decode($post['exam_schedule'], true);
            if (!is_array($examSchedule)) {
                $errors[] = "exam_schedule must be a valid JSON array";
            } else {
                foreach ($examSchedule as $index => $schedule) {
                    if (!isset($schedule['subject_id']) || !filter_var($schedule['subject_id'], FILTER_VALIDATE_INT)) {
                        $errors[] = "exam_schedule[$index][subject_id] must be a valid integer";
                    }
                    if (!isset($schedule['sitting']) || !in_array($schedule['sitting'], ['First', 'Second'])) {
                        $errors[] = "exam_schedule[$index][sitting] must be 'First' or 'Second'";
                    }
                    if (!isset($schedule['date']) || empty(trim($schedule['date']))) {
                        $errors[] = "exam_schedule[$index][date] is required";
                    }
                    if (!isset($schedule['start_time']) || empty(trim($schedule['start_time']))) {
                        $errors[] = "exam_schedule[$index][start_time] is required";
                    }
                    if (!isset($schedule['end_time']) || empty(trim($schedule['end_time']))) {
                        $errors[] = "exam_schedule[$index][end_time] is required";
                    }
                }
                // Format times to 12-hour for display
                $formattedSchedule = [];
                foreach ($examSchedule as $index => $schedule) {
                    try {
                        $start = DateTime::createFromFormat('H:i', $schedule['start_time']);
                        $end = DateTime::createFromFormat('H:i', $schedule['end_time']);
                        $timeString = sprintf(
                            '%s - %s',
                            $start ? $start->format('h:i A') : $schedule['start_time'],
                            $end ? $end->format('h:i A') : $schedule['end_time']
                        );
                    } catch (Exception $e) {
                        $timeString = $schedule['start_time'] . ' - ' . $schedule['end_time'];
                        $this->logError("Time format conversion failed for schedule[$index]: " . $e->getMessage());
                    }
                    $formattedSchedule[] = [
                        'subject_id' => $schedule['subject_id'],
                        'date' => $schedule['date'],
                        'time' => $timeString,
                        'sitting' => $schedule['sitting']
                    ];
                }
                $validData['exam_schedule'] = $formattedSchedule;
            }
        }

        // Validate exam title
        if (!isset($post['exam_title']) || empty(trim($post['exam_title']))) {
            $errors[] = "exam_title is required";
        } else {
            $validData['exam_title'] = filter_var(trim($post['exam_title']), FILTER_SANITIZE_STRING);
        }

        // Validate signature file
        if (!isset($files['signature']) || $files['signature']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = "Signature file is required";
        } elseif (!in_array($files['signature']['type'], ['image/png', 'image/jpeg', 'image/jpg'])) {
            $errors[] = "Signature file must be a PNG or JPEG image";
        } elseif ($files['signature']['size'] > 2 * 1024 * 1024) {
            $errors[] = "Signature file must not exceed 2MB";
        } else {
            $validData['signature'] = $files['signature']['tmp_name'];
            $validData['signature_type'] = $files['signature']['type'];
        }

        // Validate template_id
        $validData['template_id'] = isset($post['template_id']) && filter_var($post['template_id'], FILTER_VALIDATE_INT) ? (int)$post['template_id'] : 1;

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return $validData;
    }

    // Send JSON error response
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Convert file to base64
    private function fileToBase64(string $filePath): ?string {
        if (!file_exists($filePath)) {
            $this->logError('File not found for base64 conversion: ' . $filePath);
            return null;
        }
        $content = file_get_contents($filePath);
        if ($content === false) {
            $this->logError('Failed to read file for base64 conversion: ' . $filePath);
            return null;
        }
        return 'data:image/' . pathinfo($filePath, PATHINFO_EXTENSION) . ';base64,' . base64_encode($content);
    }

    // Fetch template file path from database
    private function fetchTemplate(int $templateId): array {
        $this->logError('Fetching template with id: ' . $templateId);
        try {
            $stmt = $this->pdo->prepare("SELECT template_file FROM templates WHERE id = ?");
            $stmt->execute([$templateId]);
            $template = $stmt->fetch();
            if (!$template || empty($template['template_file'])) {
                $this->logError('Template not found for id: ' . $templateId);
                $this->sendError(404, 'Template not found');
            }
            $templateFile = $template['template_file'];
            $templatePath = $_SERVER['DOCUMENT_ROOT'] . '/app/settings/templates/admit-card/' . $templateFile;
            $this->logError('Reading template file: ' . $templatePath);
            if (!file_exists($templatePath) || !is_readable($templatePath)) {
                $this->logError('Template file not found or not readable: ' . $templatePath);
                $this->sendError(500, 'Template file not found or not readable');
            }
            $content = file_get_contents($templatePath);
            if ($content === false) {
                $this->logError('Failed to read template file: ' . $templatePath);
                $this->sendError(500, 'Failed to read template file');
            }
            $this->logError('Template fetched successfully, length: ' . strlen($content));
            return ['file' => $templateFile, 'content' => $content];
        } catch (PDOException $e) {
            $this->logError('Failed to fetch template: ' . $e->getMessage());
            $this->sendError(500, 'Failed to fetch template');
        }
    }

    // Handle request
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $post = $_POST;
        $files = $_FILES;

        $this->logError('Received request: Method=' . $method . ', POST=' . json_encode($post) . ', FILES=' . json_encode($files));

        if ($method !== 'POST') {
            $this->sendError(405, 'Method not allowed');
        }

        try {
            $this->logError('Processing request');
            $validData = $this->validateInput($post, $files);

            // Fetch students
            $this->logError('Fetching students for class_id: ' . $validData['class_id']);
            $stmt = $this->pdo->prepare("
                SELECT s.*, c.class_name
                FROM students s
                LEFT JOIN class c ON s.class = c.id
                WHERE s.class = ? AND s.status = 'active'
            ");
            $stmt->execute([$validData['class_id']]);
            $students = $stmt->fetchAll();
            if (empty($students)) {
                $this->logError('No active students found for class_id: ' . $validData['class_id']);
                $this->sendError(404, 'No active students found for the selected class');
            }

            // Fetch subjects
            $this->logError('Fetching subjects for class_id: ' . $validData['class_id']);
            $stmt = $this->pdo->prepare("SELECT id, subject FROM subject WHERE class = ? AND status = 'active'");
            $stmt->execute([$validData['class_id']]);
            $subjects = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
            if (empty($subjects)) {
                $this->logError('No active subjects found for class_id: ' . $validData['class_id']);
                $this->sendError(404, 'No active subjects found for the selected class');
            }

            // Validate subject IDs
            foreach ($validData['exam_schedule'] as $index => $schedule) {
                if (!isset($subjects[$schedule['subject_id']])) {
                    $this->logError("Invalid subject_id: {$schedule['subject_id']} in exam_schedule[$index]");
                    $this->sendError(400, "Invalid subject_id: {$schedule['subject_id']}");
                }
            }

            // Fetch site settings
            $this->logError('Fetching site settings');
            $stmt = $this->pdo->prepare("SELECT * FROM site_settings LIMIT 1");
            $stmt->execute();
            $settings = $stmt->fetch();
            if (!$settings) {
                $this->logError('Site settings not found');
                $this->sendError(404, 'Site settings not found');
            }

            // Fetch template
            $template = $this->fetchTemplate($validData['template_id']);

            // Handle signature file
            $this->logError('Moving signature file');
            $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'admit_cards_' . uniqid();
            if (!mkdir($tempDir, 0755, true) || !is_writable($tempDir)) {
                $this->logError('Failed to create or write to temporary directory: ' . $tempDir);
                $this->sendError(500, 'Failed to create temporary directory');
            }
            $signatureExtension = pathinfo($files['signature']['name'], PATHINFO_EXTENSION);
            $signaturePath = $tempDir . DIRECTORY_SEPARATOR . 'signature.' . $signatureExtension;
            if (!move_uploaded_file($files['signature']['tmp_name'], $signaturePath)) {
                $this->logError('Failed to move signature file to: ' . $signaturePath);
                $this->sendError(500, 'Failed to process signature file');
            }
            $this->logError('Signature file moved to: ' . $signaturePath);
            $signatureBase64 = $this->fileToBase64($signaturePath);

            // Convert logo to base64
            $logoBase64 = null;
            if ($settings['logo']) {
                $logoPath = $_SERVER['DOCUMENT_ROOT'] . '/app' . $settings['logo'];
                $logoBase64 = $this->fileToBase64($logoPath);
            }

            // Clean up
            $this->logError('Cleaning up temporary files');
            array_map('unlink', glob("$tempDir/*"));
            rmdir($tempDir);

            // Prepare response
            $response = [
                'students' => $students,
                'subjects' => $subjects,
                'exam_schedule' => $validData['exam_schedule'],
                'exam_title' => $validData['exam_title'],
                'settings' => [
                    'school_name' => $settings['school_name'] ?? 'School Name',
                    'address' => $settings['address'] ?? 'Address',
                    'phone' => $settings['phone'] ?? 'N/A',
                    'email' => $settings['email'] ?? 'N/A',
                    'logo_base64' => $logoBase64
                ],
                'signature_base64' => $signatureBase64,
                'template' => $template
            ];

            // Send JSON response
            $this->logError('Sending JSON response');
            echo json_encode($response);
            exit;
        } catch (Exception $e) {
            $this->logError('Unexpected error: ' . $e->getMessage());
            $this->sendError(500, 'Unexpected error');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    if (!mkdir(__DIR__ . '/logs', 0755, true)) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to create logs directory']);
        exit;
    }
}

// Instantiate and handle request
$controller = new AdmitCardController();
$controller->handleRequest();
?>