<?php
session_start();

if (!isset($_SESSION['uid'])) {
    header('HTTP/1.1 401 Unauthorized');
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Initialize logger
$logger = function ($message) {
    $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
    file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
};

$logger('Processing submit-admit-card.php');

// Validate input
if (!isset($_POST['class_id']) || !isset($_POST['exam_title']) || !isset($_POST['exam_schedule']) || !isset($_FILES['signature'])) {
    $logger('Validation failed: Missing required fields - POST: ' . json_encode($_POST) . ', FILES: ' . json_encode($_FILES));
    header('HTTP/1.1 400 Bad Request');
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

$class_id = filter_var($_POST['class_id'], FILTER_VALIDATE_INT);
$exam_title = filter_var(trim($_POST['exam_title']), FILTER_SANITIZE_STRING);
$exam_schedule = json_decode($_POST['exam_schedule'], true);
$signature = $_FILES['signature'];

if (!$class_id || empty($exam_title) || !is_array($exam_schedule) || $signature['error'] !== UPLOAD_ERR_OK) {
    $logger('Validation failed: Invalid input data - POST: ' . json_encode($_POST) . ', FILES: ' . json_encode($_FILES));
    header('HTTP/1.1 400 Bad Request');
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Invalid input data']);
    exit;
}

// Validate signature file
$allowed_types = ['image/png', 'image/jpeg', 'image/jpg'];
if (!in_array($signature['type'], $allowed_types) || $signature['size'] > 2 * 1024 * 1024) {
    $logger('Validation failed: Invalid signature file - Type: ' . $signature['type'] . ', Size: ' . $signature['size']);
    header('HTTP/1.1 400 Bad Request');
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Signature must be a PNG/JPEG file under 2MB']);
    exit;
}

// Validate exam_schedule
foreach ($exam_schedule as $index => $schedule) {
    if (!isset($schedule['subject_id'], $schedule['date'], $schedule['start_time'], $schedule['end_time'], $schedule['sitting'])) {
        $logger('Validation failed: Invalid exam schedule at index ' . $index);
        header('HTTP/1.1 400 Bad Request');
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Invalid exam schedule']);
        exit;
    }
}

// Prepare FormData for API request
$post_fields = [
    'class_id' => $class_id,
    'exam_title' => $exam_title,
    'exam_schedule' => json_encode($exam_schedule),
    'template_id' => isset($_POST['template_id']) ? filter_var($_POST['template_id'], FILTER_VALIDATE_INT) : 1,
    'signature' => new CURLFile($signature['tmp_name'], $signature['type'], $signature['name'])
];

// Use cURL to send request to admit_card_master.php
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://' . $_SERVER['HTTP_HOST'] . '/app/students/api/admit_card_master.php');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: multipart/form-data']);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$logger('API response code: ' . $http_code . ', Response: ' . substr($response, 0, 1000));

// Check API response
if ($http_code !== 200) {
    $logger('API error: ' . $response);
    header('HTTP/1.1 500 Internal Server Error');
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Failed to process request: ' . $response]);
    exit;
}

$response_data = json_decode($response, true);
if (isset($response_data['error'])) {
    $logger('API error: ' . $response_data['error']);
    header('HTTP/1.1 400 Bad Request');
    header('Content-Type: application/json');
    echo json_encode(['error' => $response_data['error']]);
    exit;
}

// Return JSON response with API data
header('Content-Type: application/json');
echo json_encode(['success' => true, 'data' => $response_data]);
$logger('Returning JSON response with API data');
exit;
?>