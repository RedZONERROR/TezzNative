<?php
// Load database configuration
require_once '../includes/config.php';

// MySQLi Procedural
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (!$conn) {
    die("MySQLi Procedural Connection failed: " . mysqli_connect_error());
}

// MySQLi Object-Oriented
$conn_obj = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn_obj->connect_error) {
    die("MySQLi OOP Connection failed: " . $conn_obj->connect_error);
}

// PDO Connection
try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $conn_pdo = new PDO($dsn, DB_USER, DB_PASS);
    // Set the PDO error mode to exception
    $conn_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("PDO Connection failed: " . $e->getMessage());
}
?>