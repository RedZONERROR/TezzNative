<?php
require "../conn.php";


// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get parameters from the request
$searchValue = isset($_GET['searchValue']) ? $_GET['searchValue'] : '';
$class = isset($_GET['class']) ? $_GET['class'] : '';
$session = isset($_GET['session']) ? $_GET['session'] : '';

// Base query
$query = "SELECT * FROM students WHERE 1";
$params = [];
$types = "";

// Apply search filter
if (!empty($searchValue)) {
    $query .= " AND (student_name LIKE ? OR registration_no LIKE ?)";
    $params[] = "%$searchValue%";
    $params[] = "%$searchValue%";
    $types .= "ss"; // Two string parameters for search
}

// Apply class filter
if (!empty($class)) {
    $query .= " AND class = ?";
    $params[] = $class;
    $types .= "s"; // Class parameter as string
}

// Apply session filter
if (!empty($session)) {
    $query .= " AND session = ?";
    $params[] = $session;
    $types .= "s"; // Session parameter as string
}

// Prepare the statement
$stmt = $con->prepare($query);
if ($stmt === false) {
    die("Prepare failed: " . htmlspecialchars($con->error));
}

// Bind parameters if any
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

// Execute the query
$stmt->execute();
$result = $stmt->get_result();

// Check for query errors
if ($result === false) {
    die("Query Error: " . $stmt->error);
}

// Generate the table dynamically
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $studentClass = htmlspecialchars($row['class']);
        $id = htmlspecialchars($row['id']);
        
        $secretKey = 987654321;
        $encodedId = base64_encode($id ^ $secretKey);
        
        $name = htmlspecialchars($row['student_name']);
        echo "<tr>
                <td>
                    <div class='employee-image'>
                        <img src='../student-data/" . htmlspecialchars($row['student_photo']) . "' alt='" . htmlspecialchars($row['student_name']) . "' />
                    </div>
                </td>
                <td>
                    <p>" . htmlspecialchars($row['student_name']) . "</p>
                </td>
                <td>
                    <p>" . htmlspecialchars($row['registration_no']) . "</p>
                </td>
                <td>
                    <p>" . htmlspecialchars($row['father_mobile']) . "</p>
                </td>
                <td><span class='status-btn active-btn'>" . htmlspecialchars($row['status']) . "</span></td>
                <td>
                    <div class='dropdown'>
                        <button class='btn btn-secondary dropdown-toggle text-success' type='button' id='actionMenu$id' data-bs-toggle='dropdown' aria-expanded='false'>
                            <i class='fa-solid fa-sliders'></i>
                        </button>
                        <ul class='dropdown-menu' aria-labelledby='actionMenu$id'>
                            <li><a class='dropdown-item' href='view_student.php?id=$encodedId'><i class='fa-solid fa-eye me-2'></i> View</a></li>
                            <li><a class='dropdown-item' href='edit_student.php?id=$encodedId'><i class='fa-solid fa-pen me-2'></i> Edit</a></li>
                            <li><a class='dropdown-item' href='#' onclick='approveStudent(\"$id\", \"$name\")'><i class='fa-solid fa-check me-2'></i> Approve</a></li>
                            <li><a class='dropdown-item text-danger' href='#' onclick='confirmDelete(\"$id\", \"$name\")'><i class='fa-solid fa-trash me-2'></i> Delete</a></li>
                        </ul>
                    </div>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='6'>No students found.</td></tr>";
}

// Close statements
$stmt->close();
$con->close(); // Close the database connection
?>