<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin', '*');
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
$host = DB_HOST;
$db = DB_NAME;
$user = DB_USER;
$pass = DB_PASS;

$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die(json_encode([
        "status" => "error",
        "message" => "Database connection failed: " . $conn->connect_error
    ]));
}

// Query to fetch data
$sql = "SELECT `id`, `field_name`, `field_type`, `section`, `is_required`, `is_system`, `placeholder`, `options`, `display_order`, `status`, `created_at` FROM `form_elements`";

$result = $conn->query($sql);

// Check if records found
if ($result->num_rows > 0) {
    $data = [];

    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode([
        "status" => "success",
        "data" => $data
    ]);
} else {
    echo json_encode([
        "status" => "success",
        "data" => [],
        "message" => "No records found."
    ]);
}

$conn->close();
?>
