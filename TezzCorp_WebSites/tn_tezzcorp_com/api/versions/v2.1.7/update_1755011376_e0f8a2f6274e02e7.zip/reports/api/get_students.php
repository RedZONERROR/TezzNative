<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin', '*');
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
$host = DB_HOST;
$db = DB_NAME;
$user = DB_USER;
$pass = DB_PASS;
$charset = 'utf8mb4'; // ← THIS LINE ADDED

// DSN (Data Source Name)
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

// Error handling
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
];

try {
    // Database connection
    $pdo = new PDO($dsn, $user, $pass, $options);

    // Query
    $stmt = $pdo->query("SELECT * FROM students");

    // Fetch all results
    $students = $stmt->fetchAll();

    // Return JSON response
    echo json_encode([
        'status' => 'success',
        'data' => $students
    ]);
} catch (PDOException $e) {
    // Error response
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>
