<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set the timezone
date_default_timezone_set('Asia/Kolkata');

// Function to log messages
function logMessage($message) {
    $logFile = '../app.log';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message" . PHP_EOL, FILE_APPEND);
}
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
$host = DB_HOST;
$db = DB_NAME;
$user = DB_USER;
$pass = DB_PASS;

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Could not connect to the database: " . $e->getMessage());
}

$date = date("Y-m-d");

// Function to convert uploaded images to PNG and save them
function convertToPng($sourcePath, $destinationPath) {
    $imageInfo = getimagesize($sourcePath);
    $mime = $imageInfo['mime'];

    switch ($mime) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($sourcePath);
            break;
        case 'image/gif':
            $image = imagecreatefromgif($sourcePath);
            break;
        case 'image/webp':
            $image = imagecreatefromwebp($sourcePath);
            break;
        case 'image/png':
            // If it's already a PNG, just move the file and return
            move_uploaded_file($sourcePath, $destinationPath);
            return;
        default:
            logMessage("Unsupported image format: $mime");
            return;
    }

    // Save the image as PNG
    imagepng($image, $destinationPath);
    imagedestroy($image);
}

// Function to handle file uploads and convert to PNG
function handleFileUpload($file, $uploads_dir, $prefix) {
    if ($file['error'] === UPLOAD_ERR_OK) {
        $newFilename = $prefix . '-' . date('Y-m-d-H-i-s') . '.png';
        $destination = $uploads_dir . $newFilename;

        // Convert image to PNG and save it
        convertToPng($file['tmp_name'], $destination);

        return $newFilename;  // Return the new filename
    }
    return null;  // No file uploaded
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = $_POST['student_id']; // Get the student ID to update

    // Collecting form data
    $fields = [
        'student_name', 'dob', 'age_year', 'age_months', 'age_days', 'nationality',
        'gender', 'category', 'current_school', 'studying_class', 'applying_class',
        'medium', 'languages', 'aadhar', 'father_name', 'father_dob', 'father_nationality',
        'father_qualification', 'father_occupation', 'father_designation', 'father_organization',
        'father_office_address', 'father_mobile', 'mother_name', 'mother_dob',
        'mother_nationality', 'mother_qualification', 'mother_occupation', 'mother_designation',
        'mother_organization', 'mother_office_address', 'mother_mobile', 'residential_address',
        'permanent_address', 'email', 'ex_student', 'staff_child', 'contribution',
        'elaborate_choices', 'transport', 'rti', 'date'
    ];

    $updates = [];
    $values = [];

    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            $updates[] = "$field = ?";
            $values[] = $_POST[$field];
        }
    }

    // Handle file uploads
    $uploads_dir = '../../student-data/';
    $fileFields = [
        'father_signature', 'mother_signature', 'parent_signature', 'progress_report',
        'birth_certificate', 'slc', 'residential_proof', 'father_photo', 'student_photo', 'mother_photo'
    ];

    foreach ($fileFields as $fileField) {
        if (isset($_FILES[$fileField]) && $_FILES[$fileField]['error'] === UPLOAD_ERR_OK) {
            $uploadedFile = handleFileUpload($_FILES[$fileField], $uploads_dir, $fileField);
            if ($uploadedFile) {
                $updates[] = "$fileField = ?";
                $values[] = $uploadedFile;
            }
        }
    }

    // Update query
    if (!empty($updates)) {
        $query = "UPDATE students SET " . implode(", ", $updates) . " WHERE id = ?";
        $values[] = $student_id;

        $stmt = $pdo->prepare($query);
        if ($stmt->execute($values)) {
            logMessage("Student details updated successfully for ID: $student_id");
        } else {
            logMessage("Error updating student details for ID: $student_id");
        }
    }

    echo json_encode(['status' => 'success', 'message' => 'Student details updated successfully']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
?>