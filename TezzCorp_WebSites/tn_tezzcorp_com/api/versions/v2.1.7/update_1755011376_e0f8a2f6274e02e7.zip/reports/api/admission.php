<?php
// Enable error reporting
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

// Set the timezone
date_default_timezone_set('Asia/Kolkata');

// Function to log messages
function logMessage($message) {
    $logFile = '../app.log';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message" . PHP_EOL, FILE_APPEND);
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
$host = DB_HOST;
$db = DB_NAME;
$user = DB_USER;
$pass = DB_PASS;

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Could not connect to the database: " . $e->getMessage());
}

// Function to generate registration number
function generateRegistrationNo($pdo) {
    $currentYear = date('Y');
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE YEAR(created_at) = ?");
    $stmt->execute([$currentYear]);
    $count = $stmt->fetchColumn();

    // Start numbering from 1001
    $registrationNo = sprintf("SVNS/%d/%04d", $currentYear, $count + 1001);
    return $registrationNo;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collecting form data
    $student_name = $_POST['student_name'];
    $dob = $_POST['dob'];
    $age_year = $_POST['age_year'];
    $age_months = $_POST['age_months'];
    $age_days = $_POST['age_days'];
    $nationality = $_POST['nationality'];
    $gender = $_POST['gender'];
    $category = $_POST['category'];
    $current_school = $_POST['current_school'];
    $studying_class = $_POST['studying_class'];
    $applying_class = $_POST['applying_class'];
    $medium = $_POST['medium'];
    $languages = $_POST['languages']; // Assuming this is a comma-separated string
    $aadhar = $_POST['aadhar'];
    $father_name = $_POST['father_name'];
    $father_dob = $_POST['father_dob'];
    $father_nationality = $_POST['father_nationality'];
    $father_qualification = $_POST['father_qualification'];
    $father_occupation = $_POST['father_occupation'];
    $father_designation = $_POST['father_designation'];
    $father_organization = $_POST['father_organization'];
    $father_office_address = $_POST['father_office_address'];
    $father_mobile = $_POST['father_mobile'];
    $mother_name = $_POST['mother_name'];
    $mother_dob = $_POST['mother_dob'];
    $mother_nationality = $_POST['mother_nationality'];
    $mother_qualification = $_POST['mother_qualification'];
    $mother_occupation = $_POST['mother_occupation'];
    $mother_designation = $_POST['mother_designation'];
    $mother_organization = $_POST['mother_organization'];
    $mother_office_address = $_POST['mother_office_address'];
    $mother_mobile = $_POST['mother_mobile'];
    $residential_address = $_POST['residential_address'];
    $permanent_address = $_POST['permanent_address'];
    $email = $_POST['email'];
    $ex_student = $_POST['ex_student'];
    $staff_child = $_POST['staff_child'];
    $contribution = $_POST['contribution'];
    $elaborate_choices = $_POST['elaborate_choices'];
    $transport = $_POST['transport'];
    $date = $_POST['date'];
    $status = "Active";
    
    $year = date("Y"); // Get the current year
    $nextYear = $year + 1; // Get the next year
    
    $sessionYear = $year . "-" . $nextYear;
    
    // Fetch all roll numbers in the selected class, ordered numerically
    $stmt = $pdo->prepare("SELECT roll_no FROM students WHERE class = ? ORDER BY roll_no ASC");
    $stmt->execute([$applying_class]);

    // Retrieve the roll numbers as an array of integers
    $roll_numbers = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));  // Convert to integers

    $expected_roll_no = 1;  // Start checking from roll number 1

    // Iterate through the existing roll numbers to find the first missing roll number (gap)
    foreach ($roll_numbers as $roll_no) {
        if ($roll_no == $expected_roll_no) {
            $expected_roll_no++;  // Increment if no gap
        } else {
            break;  // Found the gap, exit the loop
        }
    }

    // Handle file uploads
    $uploads_dir = '../../student-data/';
    // Check if uploads directory is writable
    if (!is_writable($uploads_dir)) {
        logMessage("Error: Upload directory is not writable.");
        echo json_encode(['status' => 'error', 'message' => 'Upload directory is not writable']);
        exit;
    }

    // Function to handle file uploads
    function handleFileUpload($file, $uploads_dir, $prefix) {
        if ($file['error'] === UPLOAD_ERR_OK) {
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $newFilename = $prefix . '-' . date('Y-m-d-H-i-s') . '.' . $extension;
            $destination = $uploads_dir . $newFilename;

            if (move_uploaded_file($file['tmp_name'], $destination)) {
                return $newFilename;
            } else {
                logMessage("Error: Failed to move uploaded file: " . $file['name']);
                return null;
            }
        } else {
            logMessage("Error: File upload error for: " . $file['name'] . " - Error Code: " . $file['error']);
            return null;
        }
    }

    // Process file uploads
    $father_signature = handleFileUpload($_FILES['father_signature'], $uploads_dir, 'father_signature');
    $mother_signature = handleFileUpload($_FILES['mother_signature'], $uploads_dir, 'mother_signature');
    $parent_signature = handleFileUpload($_FILES['parent_signature'], $uploads_dir, 'parent_signature');
    $progress_report = handleFileUpload($_FILES['progress_report'], $uploads_dir, 'progress_report');
    $birth_certificate = handleFileUpload($_FILES['birth_certificate'], $uploads_dir, 'birth_certificate');
    $slc = handleFileUpload($_FILES['slc'], $uploads_dir, 'slc');
    $residential_proof = handleFileUpload($_FILES['residential_proof'], $uploads_dir, 'residential_proof');
    $father_photo = handleFileUpload($_FILES['father_photo'], $uploads_dir, 'father_photo');
    $student_photo = handleFileUpload($_FILES['student_photo'], $uploads_dir, 'student_photo');
    $mother_photo = handleFileUpload($_FILES['mother_photo'], $uploads_dir, 'mother_photo');

    // Generate registration number
    $registration_no = generateRegistrationNo($pdo);

    // Insert data into the database
    $stmt = $pdo->prepare("INSERT INTO students (session, roll_no, student_name, dob, age_year, age_months, age_days, nationality, gender, category, current_school, studying_class, applying_class, medium, languages, aadhar, father_name, father_dob, father_nationality, father_qualification, father_occupation, father_designation, father_organization, father_office_address, father_mobile, mother_name, mother_dob, mother_nationality, mother_qualification, mother_occupation, mother_designation, mother_organization, mother_office_address, mother_mobile, residential_address, permanent_address, email, ex_student, staff_child, contribution, elaborate_choices, transport, date, registration_no, father_signature, mother_signature, parent_signature, progress_report, birth_certificate, slc, residential_proof, father_photo, student_photo, mother_photo, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $stmt->execute([$sessionYear, $expected_roll_no, $student_name, $dob, $age_year, $age_months, $age_days, $nationality, $gender, $category, $current_school, $studying_class, $applying_class, $medium, $languages, $aadhar, $father_name, $father_dob, $father_nationality, $father_qualification, $father_occupation, $father_designation, $father_organization, $father_office_address, $father_mobile, $mother_name, $mother_dob, $mother_nationality, $mother_qualification, $mother_occupation, $mother_designation, $mother_organization, $mother_office_address, $mother_mobile, $residential_address, $permanent_address, $email, $ex_student, $staff_child, $contribution, $elaborate_choices, $transport, $date, $registration_no, $father_signature, $mother_signature, $parent_signature, $progress_report, $birth_certificate, $slc, $residential_proof, $father_photo, $student_photo, $mother_photo, $status]);
    
    // Get the last inserted student ID
    $student_id = $pdo->lastInsertId(); 
    
    // Decode sibling data from JSON
    $siblingNames = json_decode($_POST['sibling_names'], true);
    $siblingBranches = json_decode($_POST['sibling_branches'], true);
    $siblingClasses = json_decode($_POST['sibling_classes'], true);
    
    // Ensure sibling data arrays are valid
    if (count($siblingNames) !== count($siblingBranches) || count($siblingBranches) !== count($siblingClasses)) {
        error_log("Sibling data arrays do not match in length");
        echo json_encode(['status' => 'error', 'message' => 'Sibling data mismatch']);
        exit;
    }
    
    // Check if there is any sibling data to insert
    if (!empty($siblingNames[0])) { // Check if the first sibling name is not empty
        // Loop through sibling data and insert into database
        foreach ($siblingNames as $index => $siblingName) {
            $siblingBranch = $siblingBranches[$index];
            $siblingClass = $siblingClasses[$index];
    
            // Only insert if the sibling name is not empty
            if (!empty($siblingName)) {
                // Insert into the siblings table
                $sibling_stmt = $pdo->prepare("INSERT INTO siblings (student_id, name, branch, class) VALUES (?, ?, ?, ?)");
                if (!$sibling_stmt->execute([$student_id, $siblingName, $siblingBranch, $siblingClass])) {
                    error_log("Error inserting sibling: " . implode(", ", $sibling_stmt->errorInfo()));
                }
            }
        }
    } else {
        // No sibling data to insert
        error_log("No sibling data to insert.");
    }

    // Prepare and send a professional email
    $subject = "Registration Confirmation - Swami Vivekanand National School";
    $message = "
    <html>
    <head>
        <title>Registration Confirmation</title>
    </head>
    <body>
        <p>Dear $student_name,</p>
        <p>We are thrilled to confirm your registration at <strong>Swami Vivekanand National School, Rampurwa</strong>.</p>
        <p><strong>Your Registration Number:</strong> $registration_no</p>
        <p>Please visit the school campus to complete the remaining formalities. Our administrative team will assist you further.</p>
        <p>We are excited to welcome you to our vibrant community!</p>
        <br>
        <p>Best Regards,<br>
        Swami Vivekanand National School<br>
        Rampurwa, Bihar<br>
        Email: <a href='mailto:contact@swamivivekanandnationalschool.in'>contact@swamivivekanandnationalschool.in</a><br>
        Phone: +91-6299910418</p>
    </body>
    </html>
    ";

    // Email headers
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: contact@swamivivekanandnationalschool.in";

    // Send the email
    if (mail($email, $subject, $message, $headers)) {
        logMessage("Registration email sent successfully to $email");
    } else {
        logMessage("Failed to send registration email to $email");
    }

    echo json_encode(['status' => 'success', 'registration_no' => $registration_no]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
?>