<?php
session_start(); // Start the session

// Unset all session variables
$_SESSION = [];

// Destroy the session
session_destroy();

// Optionally redirect to the login page or homepage
header("Location: ../");
exit;
?>