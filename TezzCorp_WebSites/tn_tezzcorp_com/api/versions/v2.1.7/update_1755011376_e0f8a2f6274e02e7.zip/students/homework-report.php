<?php
session_start();
if(!isset($_SESSION['uid'])){
	header("location: ../../login");
	die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Homework Report - AI-ERP 2.0</title>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-space-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Homework Report</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex"
                                                    href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone"
                                                        class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Homework
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- start Basic Example -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-4 col-xl-3">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Students..." />
                                        <i
                                            class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div
                                    class="col-md-8 col-xl-9 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div class="d-flex">
                                        <div class="form-group me-3">
                                            <select class="form-control" id="subject_option">
                                                <option value="">All Subjects</option>
                                                <option value="English">English</option>
                                                <option value="Hindi">Hindi</option>
                                                <option value="Mathematics">Mathematics</option>
                                                <option value="Science">Science</option>
                                                <option value="Social Studies">Social Studies</option>
                                                <option value="Computer">Computer</option>
                                                <option value="Physics">Physics</option>
                                                <option value="Chemistry">Chemistry</option>
                                                <option value="Biology">Biology</option>
                                                <option value="Economics">Economics</option>
                                                <option value="Accountancy">Accountancy</option>
                                                <option value="Business Studies">Business Studies</option>
                                                <option value="Sanskrit">Sanskrit</option>
                                                <option value="Geography">Geography</option>
                                                <option value="History">History</option>
                                                <option value="Art">Art</option>
                                                <option value="Music">Music</option>
                                                <option value="Physical Education">Physical Education</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <input type="month" class="form-control" id="monthPicker">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card card-body" id="homework-table">
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <tr id="header-row">
                                            <th>Sr</th>
                                            <th>Student Name</th>
                                        </tr>
                                    </thead>
                                    <tbody id="student_list_table_body">
                                        <!-- Data will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Set input value to current month in format YYYY-MM
        const now = new Date();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const year = now.getFullYear();
        document.getElementById('monthPicker').value = `${year}-${month}`;

        // Fetch and display homework data
        function fetch_homework_data() {
            const monthPicker = document.getElementById('monthPicker').value;
            const subject = document.getElementById('subject_option').value;
            const [year, month] = monthPicker.split('-');

            const url = `api/h.php?month=${month}&year=${year}${subject ? `&subject=${encodeURIComponent(subject)}` : ''}`;

            fetch(url)
                .then(response => response.json())
                .then(data => {
                    if (data.status !== 'success') {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: data.message || 'Failed to load homework report.'
                        });
                        return;
                    }

                    const students = data.data;
                    const headerRow = document.getElementById('header-row');
                    const tbody = document.getElementById('student_list_table_body');

                    // Clear table
                    headerRow.innerHTML = '<th>Sr</th><th>Student Name</th>';
                    tbody.innerHTML = '';

                    // Get unique dates
                    const dates = [];
                    students.forEach(student => {
                        student.homework.forEach(hw => {
                            if (!dates.includes(hw.date)) {
                                dates.push(hw.date);
                            }
                        });
                    });
                    dates.sort();

                    // Add date columns to header
                    dates.forEach(date => {
                        const d = new Date(date);
                        const day = d.getDate();
                        const th = document.createElement('th');
                        th.textContent = `${day} ${d.toLocaleString('default', { month: 'short' })}`;
                        headerRow.appendChild(th);
                    });

                    // Add summary columns
                    headerRow.innerHTML += '<th>Completed</th><th>Not Completed</th><th>Total Days</th><th>Percentage</th>';

                    // Populate table rows
                    students.forEach((student, index) => {
                        const tr = document.createElement('tr');
                        tr.innerHTML = `<td>${index + 1}</td><td>${student.student_name}</td>`;

                        let completed = 0;
                        let totalHomeworkDays = 0;

                        // Process each date
                        dates.forEach(date => {
                            // Find homework for this date
                            const homeworkForDate = student.homework.filter(hw => hw.date === date);
                            let isCompleted = false;

                            // Check if any homework is completed
                            homeworkForDate.forEach(hw => {
                                if (hw.completion_status === 'completed') {
                                    isCompleted = true;
                                }
                            });

                            // Count days with homework
                            if (homeworkForDate.length > 0 && homeworkForDate.some(hw => hw.subject !== null)) {
                                totalHomeworkDays++;
                                if (isCompleted) {
                                    completed++;
                                }
                            }

                            // Display ✓ or ✗
                            const color = isCompleted ? '#c8e6c9' : '#ffcdd2';
                            const mark = isCompleted ? '✓' : '✗';
                            tr.innerHTML += `<td style="background:${color}">${mark}</td>`;
                        });

                        // Calculate summary
                        const notCompleted = totalHomeworkDays - completed;
                        const percentage = totalHomeworkDays > 0 ? ((completed / totalHomeworkDays) * 100).toFixed(1) : '0.0';

                        tr.innerHTML += `<td>${completed}</td><td>${notCompleted}</td><td>${totalHomeworkDays}</td><td>${percentage}%</td>`;
                        tbody.appendChild(tr);
                    });

                    // Show message if no homework
                    if (data.message && students.every(student => student.homework.length === 0)) {
                        tbody.innerHTML = '<tr><td colspan="' + (dates.length + 6) + '" class="text-center">' + data.message + '</td></tr>';
                    }
                })
                .catch(error => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to fetch homework report: ' + error.message
                    });
                });
        }

        // Initial fetch
        fetch_homework_data();

        // Update on month or subject change
        document.getElementById('monthPicker').addEventListener('change', fetch_homework_data);
        document.getElementById('subject_option').addEventListener('change', fetch_homework_data);
    </script>

    <div class="dark-transparent sidebartoggler"></div>
    <script src="../assets/js/vendor.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@1.0.8/dist/iconify-icon.min.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        hljs.initHighlightingOnLoad();
        document.querySelectorAll("pre.code-view > code").forEach((codeBlock) => {
            codeBlock.textContent = codeBlock.innerHTML;
        });
    </script>
    <script src="../assets/js/index.global.min.js"></script>
</body>

</html>