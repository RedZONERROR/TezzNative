<?php
session_start();
if(!isset($_SESSION['uid'])){
	header("location: ../../login");
	die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Student Admission - AI-ERP 2.0</title>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-space-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Manage Students</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex"
                                                    href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone"
                                                        class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Students
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card card-body py-3">
                    <!-- start Basic Example -->
                  <form id="homeworkForm" enctype="multipart/form-data">
                  <h5 class="mb-3">Homework Form</h5>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="mb-3 form-group">
                        <label for="homework_class" class="form-label">Class: <span class="text-danger">*</span></label>
                        <select class="form-select required" id="homework_class" name="homework_class" required>
                            <option value="">Select Class</option>
                            <option value="1">Nursery</option>
                            <option value="2">LKG</option>
                            <option value="3">UKG</option>
                            <option value="4">Class 1</option>
                            <option value="5">Class 2</option>
                            <option value="6">Class 3</option>
                            <option value="7">Class 4</option>
                            <option value="8">Class 5</option>
                            <option value="9">Class 6</option>
                            <option value="10">Class 7</option>
                            <option value="11">Class 8</option>
                            <option value="12">Class 9</option>
                            <option value="13">Class 10</option>
                            <option value="14">Class 11</option>
                            <option value="15">Class 12</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="mb-3 form-group">
                        <label for="homework_date" class="form-label">Date: <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="homework_date" name="homework_date" required>
                      </div>
                    </div>
                  </div>
                
                  <div class="row">
                    <div class="col-md-6">
                      <div class="mb-3 form-group">
                        <label for="homework_time" class="form-label">Time: <span class="text-danger">*</span></label>
                        <input type="time" class="form-control" id="homework_time" name="homework_time" required>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="mb-3 form-group">
                        <label for="homework_subject" class="form-label">Subject: <span class="text-danger">*</span></label>
                        <select class="form-select" id="homework_subject" name="subject" required>
                            <option value="">Select Subject</option>
                            <option value="English">English</option>
                            <option value="Hindi">Hindi</option>
                            <option value="Mathematics">Mathematics</option>
                            <option value="Science">Science</option>
                            <option value="Social Studies">Social Studies</option>
                            <option value="Computer">Computer</option>
                            <option value="Physics">Physics</option>
                            <option value="Chemistry">Chemistry</option>
                            <option value="Biology">Biology</option>
                            <option value="Economics">Economics</option>
                            <option value="Accountancy">Accountancy</option>
                            <option value="Business Studies">Business Studies</option>
                            <option value="Sanskrit">Sanskrit</option>
                            <option value="Geography">Geography</option>
                            <option value="History">History</option>
                            <option value="Art">Art</option>
                            <option value="Music">Music</option>
                            <option value="Physical Education">Physical Education</option>
                        </select>
                      </div>
                    </div>
                  </div>
                
                  <div class="row">
                    <div class="col-md-12">
                      <div class="mb-3 form-group">
                        <label for="homework_note" class="form-label">Note:</label>
                        <textarea class="form-control" id="homework_note" name="homework_note" rows="4"></textarea>
                      </div>
                    </div>
                  </div>
                
                  <div class="row">
                    <div class="col-md-12">
                      <div class="mb-3 form-group">
                        <label for="homework_file" class="form-label">Upload File (PDF, DOC, Image):</label>
                        <input type="file" class="form-control" id="homework_file" name="homework_file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">
                      </div>
                    </div>
                  </div>
                
                  <div class="row">
                    <div class="col-md-12 text-end">
                      <button type="submit" class="btn btn-primary">Submit Homework</button>
                    </div>
                  </div>
                
                  <div id="formMessage" class="mt-3"></div>
                </form>

                </div>

                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $('#homeworkForm').on('submit', function (e) {
        e.preventDefault();
    
        // Clear message
        $('#formMessage').html('');
    
        // Validate required fields
        const requiredFields = ['#homework_class', '#homework_date', '#homework_time', '#homework_subject'];
        let isValid = true;
    
        requiredFields.forEach(function (field) {
          if (!$(field).val()) {
            isValid = false;
            $(field).addClass('is-invalid');
          } else {
            $(field).removeClass('is-invalid');
          }
        });
    
        if (!isValid) {
          $('#formMessage').html('<div class="alert alert-danger">Please fill all required fields.</div>');
          return;
        }
    
        // Prepare form data
        const formData = new FormData(this);
    
        $.ajax({
          url: 'api/insert-homework-api.php', // path to your API
          type: 'POST',
          data: formData,
          processData: false,
          contentType: false,
          success: function (response) {
            if (response.status === 'success') {
              $('#formMessage').html('<div class="alert alert-success">' + response.message + '</div>');
              $('#homeworkForm')[0].reset(); // reset form
            } else {
              $('#formMessage').html('<div class="alert alert-danger">' + response.message + '</div>');
            }
          },
          error: function () {
            $('#formMessage').html('<div class="alert alert-danger">Something went wrong. Try again later.</div>');
          }
        });
      });
    </script>

    




    <div class="dark-transparent sidebartoggler"></div>
    <script src="../assets/js/vendor.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@1.0.8/dist/iconify-icon.min.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        hljs.initHighlightingOnLoad();
        document.querySelectorAll("pre.code-view > code").forEach((codeBlock) => {
            codeBlock.textContent = codeBlock.innerHTML;
        });
    </script>
    <script src="../assets/js/index.global.min.js"></script>
    <script src="assets/js/attendance.js"></script>
</body>

</html>