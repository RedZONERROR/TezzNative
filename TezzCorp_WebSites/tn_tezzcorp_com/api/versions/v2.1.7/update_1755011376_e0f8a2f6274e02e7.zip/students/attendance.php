<?php
session_start();
if(!isset($_SESSION['uid'])){
	header("location: ../../login");
	die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Student Attendance - AI-ERP 2.0</title>
    <style>
        /* Toggle Button Style */
        .switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
        }
        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 24px;
        }
        .slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        .round {
            width: 50px !important;
            height: auto !important;
        }
        input:checked + .slider {
            background-color: #4CAF50;
        }
        input:checked + .slider:before {
            transform: translateX(26px);
        }
        /* Spinner Styles */
        .btn-loading .fa-spinner {
            display: inline-block;
        }
        .btn-loading .btn-text, .btn-loading .ti {
            display: none;
        }
        .fa-spinner {
            display: none;
            font-size: 0.9rem;
        }
        .action-buttons {
            display: none;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Manage Student Attendance</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Attendance
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- start Basic Example -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-4 col-xl-3">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Students..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-8 col-xl-9 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div class="action-buttons me-2">
                                        <button class="mark-attendance btn bg-success-subtle text-success me-1">
                                            <i class="fas fa-spinner fa-spin"></i>
                                            <span class="btn-text">Mark Attendance</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card card-body">
                            <div class="d-flex justify-content-center">
                                <div class="spinner-border text-primary" role="status" id="table-loader">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <th>
                                            <div class="n-chk align-self-center text-center">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input primary" id="contact-check-all" />
                                                    <label class="form-check-label" for="contact-check-all"></label>
                                                    <span class="new-control-indicator"></span>
                                                </div>
                                            </div>
                                        </th>
                                        <th>Student's Name</th>
                                        <th>Attendance Date</th>
                                        <th>Attendance Time</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody id="student_attendance_table_body">
                                        <!-- Data will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="dark-transparent sidebartoggler"></div>
    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        hljs.initHighlightingOnLoad();
        document.querySelectorAll("pre.code-view > code").forEach((codeBlock) => {
            codeBlock.textContent = codeBlock.innerHTML;
        });

        $(document).ready(function() {
            // Show table loader
            $('#table-loader').show();

            // Get current date and time
            const now = new Date();
            const currentDate = now.toISOString().split('T')[0]; // YYYY-MM-DD
            const currentTime = now.toTimeString().split(' ')[0]; // HH:MM:SS

            // Fetch student data
            $.ajax({
                url: 'api/student_master.php',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    const students = response.data || [];
                    if (students.length === 0) {
                        $('#student_attendance_table_body').html('<tr><td colspan="6" class="text-center">No students found.</td></tr>');
                        $('#table-loader').hide();
                        return;
                    }

                    // Fetch attendance for today
                    const attendancePromises = students.map(s => 
                        $.ajax({
                            url: 'api/student_attendance_master.php',
                            type: 'GET',
                            data: { student_id: s.id, date: currentDate },
                            dataType: 'json'
                        }).then(res => ({ student_id: s.id, attendance: res.data[0] || {} }))
                    );

                    Promise.all(attendancePromises).then(results => {
                        renderAttendanceTable(students, results);
                        $('#table-loader').hide();
                    }).catch(error => {
                        $('#table-loader').hide();
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load attendance data.'
                        });
                        console.error('Attendance Error:', error);
                    });
                },
                error: function(xhr, status, error) {
                    $('#table-loader').hide();
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to load student data: ' + (xhr.responseJSON?.message || error)
                    });
                }
            });

            // Render attendance table
            function renderAttendanceTable(students, attendanceResults) {
                const tbody = $('#student_attendance_table_body');
                tbody.empty();
                students.forEach(s => {
                    const att = attendanceResults.find(r => r.student_id === s.id)?.attendance || {};
                    const attId = att.id || '';
                    const attDate = att.date || '-';
                    const attTime = att.time || '-';
                    const attStatus = att.status || '0';
                    const row = `
                        <tr data-student-id="${s.id}" data-att-id="${attId}">
                            <td>
                                <div class="n-chk align-self-center text-center">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input student-check" value="${s.id}" />
                                        <label class="form-check-label"></label>
                                    </div>
                                </div>
                            </td>
                            <td>${s.full_name || '-'}</td>
                            <td>${attDate}</td>
                            <td>${attTime}</td>
                            <td>
                                <label class="switch">
                                    <input type="checkbox" class="attendance-toggle" ${attStatus === '1' ? 'checked' : ''}>
                                    <span class="slider round"></span>
                                </label>
                            </td>
                            <td>
                                <button class="delete-attendance btn btn-sm btn-danger" data-att-id="${attId}" ${attId ? '' : 'disabled'}>
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-trash"></i>
                                </button>
                            </td>
                        </tr>`;
                    tbody.append(row);
                });
            }

            // Toggle action buttons
            function toggleActionButtons() {
                const checked = $('.student-check:checked').length;
                $('.action-buttons').toggle(checked > 0);
            }

            // Select all checkboxes
            $('#contact-check-all').on('change', function() {
                $('.student-check').prop('checked', this.checked);
                toggleActionButtons();
            });

            // Individual checkbox change
            $(document).on('change', '.student-check', toggleActionButtons);

            // Search functionality
            $('#input-search').on('keyup', function() {
                const search = $(this).val().toLowerCase();
                $('#student_attendance_table_body tr').each(function() {
                    const text = $(this).find('td:eq(1)').text().toLowerCase();
                    $(this).toggle(text.includes(search));
                });
            });

            // Mark attendance
            $('.mark-attendance').on('click', function() {
                const selected = $('.student-check:checked').map(function() {
                    return $(this).val();
                }).get();
                if (selected.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Selection',
                        text: 'Please select at least one student to mark attendance.'
                    });
                    return;
                }

                Swal.fire({
                    title: 'Mark Attendance',
                    text: `Mark ${selected.length} students as Present for today?`,
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, mark!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        const now = new Date();
                        const date = now.toISOString().split('T')[0];
                        const time = now.toTimeString().split(' ')[0];

                        const promises = selected.map(student_id => {
                            // Check if attendance exists
                            return $.ajax({
                                url: 'api/student_attendance_master.php',
                                type: 'GET',
                                data: { student_id: student_id, date: date }
                            }).then(res => {
                                if (res.data && res.data.length > 0) {
                                    return Promise.resolve(); // Skip if exists
                                }
                                return $.ajax({
                                    url: 'api/student_attendance_master.php',
                                    type: 'POST',
                                    contentType: 'application/json',
                                    data: JSON.stringify({
                                        student_id: student_id,
                                        date: date,
                                        time: time,
                                        status: '1'
                                    }),
                                    dataType: 'json'
                                });
                            });
                        });

                        Promise.all(promises).then(() => {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success',
                                text: 'Attendance marked successfully'
                            });
                            // Refresh table
                            $('#contact-check-all').trigger('change');
                            $.ajax({
                                url: 'api/student_master.php',
                                type: 'GET',
                                dataType: 'json',
                                success: function(response) {
                                    const students = response.data || [];
                                    const attendancePromises = students.map(s => 
                                        $.ajax({
                                            url: 'api/student_attendance_master.php',
                                            type: 'GET',
                                            data: { student_id: s.id, date: date },
                                            dataType: 'json'
                                        }).then(res => ({ student_id: s.id, attendance: res.data[0] || {} }))
                                    );
                                    Promise.all(attendancePromises).then(results => {
                                        renderAttendanceTable(students, results);
                                    });
                                }
                            });
                        }).catch(xhr => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to mark attendance: ' + (xhr.responseJSON?.message || xhr.statusText)
                            });
                        }).finally(() => {
                            $('.mark-attendance').removeClass('btn-loading');
                        });
                    }
                });
            });

            // Toggle attendance status
            $(document).on('change', '.attendance-toggle', function() {
                const row = $(this).closest('tr');
                const attId = row.data('att-id');
                const studentId = row.data('student-id');
                const status = $(this).is(':checked') ? '1' : '0';
                const now = new Date();
                const date = now.toISOString().split('T')[0];
                const time = now.toTimeString().split(' ')[0];

                if (!attId) {
                    // Create new record
                    $.ajax({
                        url: 'api/student_attendance_master.php',
                        type: 'POST',
                        contentType: 'application/json',
                        data: JSON.stringify({
                            student_id: studentId,
                            date: date,
                            time: time,
                            status: status
                        }),
                        dataType: 'json',
                        success: function(response) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success',
                                text: 'Attendance updated'
                            });
                            row.data('att-id', response.id);
                            row.find('td:eq(2)').text(date);
                            row.find('td:eq(3)').text(time);
                            row.find('.delete-attendance').removeAttr('disabled').data('att-id', response.id);
                        },
                        error: function(xhr) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to update attendance: ' + (xhr.responseJSON?.message || xhr.statusText)
                            });
                            $(this).prop('checked', !$(this).is(':checked')); // Revert toggle
                        }
                    });
                } else {
                    // Update existing record
                    $.ajax({
                        url: 'api/student_attendance_master.php',
                        type: 'PUT',
                        contentType: 'application/json',
                        data: JSON.stringify({
                            id: attId,
                            student_id: studentId,
                            date: row.find('td:eq(2)').text(),
                            time: row.find('td:eq(3)').text(),
                            status: status
                        }),
                        dataType: 'json',
                        success: function() {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success',
                                text: 'Attendance updated'
                            });
                        },
                        error: function(xhr) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to update attendance: ' + (xhr.responseJSON?.message || xhr.statusText)
                            });
                            $(this).prop('checked', !$(this).is(':checked')); // Revert toggle
                        }
                    });
                }
            });

            // Delete attendance
            $(document).on('click', '.delete-attendance', function() {
                const attId = $(this).data('att-id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'Delete this attendance record?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/student_attendance_master.php',
                            type: 'DELETE',
                            contentType: 'application/json',
                            data: JSON.stringify({ id: attId }),
                            dataType: 'json',
                            success: function() {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted',
                                    text: 'Attendance record deleted'
                                });
                                const row = $(this).closest('tr');
                                row.data('att-id', '');
                                row.find('td:eq(2)').text('-');
                                row.find('td:eq(3)').text('-');
                                row.find('.attendance-toggle').prop('checked', false);
                                $(this).prop('disabled', true);
                            }.bind(this),
                            error: function(xhr) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to delete attendance: ' + (xhr.responseJSON?.message || xhr.statusText)
                                });
                            },
                            complete: function() {
                                $(this).removeClass('btn-loading');
                            }.bind(this)
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>