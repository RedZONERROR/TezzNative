<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

class SessionController {
    private $pdo;
    private $logger;

    public function __construct() {
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    public function getSessions() {
        try {
            $stmt = $this->pdo->prepare("SELECT DISTINCT session FROM results ORDER BY session DESC");
            $stmt->execute();
            $sessions = $stmt->fetchAll();

            $this->sendSuccess(200, ['success' => true, 'data' => array_map(fn($row) => ['session' => $row['session']], $sessions)]);
        } catch (PDOException $e) {
            $this->logError('Query failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to fetch sessions');
        }
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method === 'GET') {
            $this->getSessions();
        } else {
            $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new SessionController();
$controller->handleRequest();
?>