<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class StudentAttendanceController {
    private $pdo;
    private $logger;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/student_attendance.log', $logMessage, FILE_APPEND);
        };
    }

    // Send JSON error response with status
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode([
            'status' => 'error',
            'message' => $message
        ]);
        exit;
    }

    // Send JSON success response with status
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode(array_merge([
            'status' => 'success'
        ], $data));
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Log debug message
    private function logDebug(string $message): void {
        ($this->logger)('DEBUG: ' . $message);
    }

    // Handle GET request to fetch attendance
    public function get() {
        $student_id = isset($_GET['student_id']) ? (int)$_GET['student_id'] : null;
        $date = isset($_GET['date']) ? trim($_GET['date']) : null;
        $date_like = isset($_GET['date_like']) ? trim($_GET['date_like']) : null;

        // If date_like is provided, fetch all records matching the date pattern
        if ($date_like) {
            try {
                $stmt = $this->pdo->prepare("
                    SELECT * FROM student_attendance
                    WHERE date LIKE ?
                ");
                $stmt->execute([$date_like]);
                $attendance = $stmt->fetchAll();

                $this->sendSuccess(200, ['data' => $attendance]);
            } catch (Exception $e) {
                $this->logError('Failed to fetch attendance with date_like: ' . $e->getMessage());
                $this->sendError(500, 'Failed to fetch attendance: ' . $e->getMessage());
            }
        }
        // If student_id and date are provided, fetch specific attendance
        elseif ($student_id && $date) {
            try {
                $stmt = $this->pdo->prepare("
                    SELECT * FROM student_attendance
                    WHERE student_id = ? AND date = ?
                ");
                $stmt->execute([$student_id, $date]);
                $attendance = $stmt->fetchAll();

                $this->sendSuccess(200, ['data' => $attendance]);
            } catch (Exception $e) {
                $this->logError('Failed to fetch attendance: ' . $e->getMessage());
                $this->sendError(500, 'Failed to fetch attendance: ' . $e->getMessage());
            }
        }
        // If neither condition is met, return an error
        else {
            $this->sendError(400, 'Either date_like or both student_id and date are required');
        }
    }

    // Handle POST request to create a new attendance record
    public function post() {
        $data = json_decode(file_get_contents('php://input'), true);
        $student_id = isset($data['student_id']) ? (int)$data['student_id'] : null;
        $date = isset($data['date']) ? trim($data['date']) : null;
        $time = isset($data['time']) ? trim($data['time']) : null;
        $status = isset($data['status']) ? trim($data['status']) : null;

        if (!$student_id || !$date || !$time || !in_array($status, ['0', '1'])) {
            $this->sendError(400, 'student_id, date, time, and status (0 or 1) are required');
        }

        try {
            $this->pdo->beginTransaction();

            // Check if student exists
            $stmt = $this->pdo->prepare("SELECT id FROM students WHERE id = ?");
            $stmt->execute([$student_id]);
            if (!$stmt->fetch()) {
                $this->sendError(404, 'Student not found');
            }

            // Insert attendance record
            $stmt = $this->pdo->prepare("
                INSERT INTO student_attendance (student_id, date, time, status, created_at)
                VALUES (?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$student_id, $date, $time, $status]);
            $id = $this->pdo->lastInsertId();

            $this->pdo->commit();
            $this->logDebug('Attendance created for student_id: ' . $student_id);
            $this->sendSuccess(201, ['message' => 'Attendance created successfully', 'id' => $id]);
        } catch (Exception $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to create attendance: ' . $e->getMessage());
            $this->sendError(500, 'Failed to create attendance: ' . $e->getMessage());
        }
    }

    // Handle PUT request to update an attendance record
    public function put() {
        $data = json_decode(file_get_contents('php://input'), true);
        $id = isset($data['id']) ? (int)$data['id'] : null;
        $student_id = isset($data['student_id']) ? (int)$data['student_id'] : null;
        $date = isset($data['date']) ? trim($data['date']) : null;
        $time = isset($data['time']) ? trim($data['time']) : null;
        $status = isset($data['status']) ? trim($data['status']) : null;

        if (!$id || !$student_id || !$date || !$time || !in_array($status, ['0', '1'])) {
            $this->sendError(400, 'id, student_id, date, time, and status (0 or 1) are required');
        }

        try {
            $this->pdo->beginTransaction();

            // Check if attendance record exists
            $stmt = $this->pdo->prepare("SELECT id FROM student_attendance WHERE id = ?");
            $stmt->execute([$id]);
            if (!$stmt->fetch()) {
                $this->sendError(404, 'Attendance record not found');
            }

            // Update attendance record
            $stmt = $this->pdo->prepare("
                UPDATE student_attendance
                SET student_id = ?, date = ?, time = ?, status = ?, updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$student_id, $date, $time, $status, $id]);

            $this->pdo->commit();
            $this->logDebug('Attendance updated for id: ' . $id);
            $this->sendSuccess(200, ['message' => 'Attendance updated successfully']);
        } catch (Exception $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to update attendance: ' . $e->getMessage());
            $this->sendError(500, 'Failed to update attendance: ' . $e->getMessage());
        }
    }

    // Handle DELETE request to delete an attendance record
    public function delete() {
        $data = json_decode(file_get_contents('php://input'), true);
        $id = isset($data['id']) ? (int)$data['id'] : null;

        if (!$id) {
            $this->sendError(400, 'id is required');
        }

        try {
            $this->pdo->beginTransaction();

            // Check if attendance record exists
            $stmt = $this->pdo->prepare("SELECT id FROM student_attendance WHERE id = ?");
            $stmt->execute([$id]);
            if (!$stmt->fetch()) {
                $this->sendError(404, 'Attendance record not found');
            }

            // Delete attendance record
            $stmt = $this->pdo->prepare("DELETE FROM student_attendance WHERE id = ?");
            $stmt->execute([$id]);

            $this->pdo->commit();
            $this->logDebug('Attendance deleted for id: ' . $id);
            $this->sendSuccess(200, ['message' => 'Attendance deleted successfully']);
        } catch (Exception $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to delete attendance: ' . $e->getMessage());
            $this->sendError(500, 'Failed to delete attendance: ' . $e->getMessage());
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];

        switch ($method) {
            case 'GET':
                $this->get();
                break;

            case 'POST':
                $this->post();
                break;

            case 'PUT':
                $this->put();
                break;

            case 'DELETE':
                $this->delete();
                break;

            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new StudentAttendanceController();
$controller->handleRequest();
?>