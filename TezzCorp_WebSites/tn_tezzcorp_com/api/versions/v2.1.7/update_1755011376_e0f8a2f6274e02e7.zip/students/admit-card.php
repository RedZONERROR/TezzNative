<?php
session_start();
if (!isset($_SESSION['uid'])) {
    header("location: ../../login");
    die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Admit Card Generation - AI-ERP 2.0</title>
    <style>
        .btn-loading .spinner-border {
            display: inline-block;
        }
        .spinner-border {
            display: none;
            width: 1rem;
            height: 1rem;
        }
        .schedule-row {
            margin-bottom: 15px;
        }
        .time-picker {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .time-picker input {
            width: 120px;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!-- Sidebar End -->
        <div class="page-wrapper">
            <!-- Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!-- Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Generate Admit Cards</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Admit Cards
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Admit Card Generation Form -->
                    <div class="card card-body">
                        <form id="admitCardForm" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="class_id" class="form-label">Select Class</label>
                                    <select id="class_id" name="class_id" class="form-control" required>
                                        <option value="">Select a class</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="exam_title" class="form-label">Examination Title</label>
                                    <input type="text" id="exam_title" name="exam_title" class="form-control" placeholder="e.g., First Term Examination 2025" required />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="signature" class="form-label">Controller of Examinations Signature (PNG/JPEG)</label>
                                    <input type="file" id="signature" name="signature" class="form-control" accept="image/png,image/jpeg" required />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <input type="hidden" name="template_id" value="1" />
                            </div>

                            <h5 class="mt-4 mb-3">Examination Schedule</h5>
                            <div id="schedule-container">
                                <!-- Dynamic schedule rows -->
                            </div>
                            <button type="button" id="add-schedule" class="btn btn-primary mb-3">Add Schedule</button>

                            <div class="text-end mt-4">
                                <button type="submit" class="btn btn-success" id="generate-admit-cards">Generate Admit Cards
                                    <div class="spinner-border text-light btn-loading" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- Student List -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-4 col-xl-3">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search" placeholder="Search Students..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="card card-body">
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <th>Student's Name</th>
                                        <th>Father's Name</th>
                                        <th>Roll No</th>
                                        <th>Class</th>
                                    </thead>
                                    <tbody id="student_list_table_body">
                                        <!-- Data will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="../assets/js/vendor.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        $(document).ready(function() {
            // Load classes
            function loadClasses() {
                $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 50, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        const classes = response.data || [];
                        $('#class_id').empty().append('<option value="">Select a class</option>');
                        classes.forEach(cls => {
                            $('#class_id').append(`<option value="${cls.id}">${cls.class_name}</option>`);
                        });
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load classes: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Load subjects based on class selection
            function loadSubjects(classId) {
                if (!classId) {
                    $('#schedule-container').empty();
                    return;
                }
                $.ajax({
                    url: 'api/subject_master.php',
                    type: 'GET',
                    data: { perPage: 20, class: classId, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        const subjects = response.data || [];
                        window.subjects = subjects;
                        addScheduleRow();
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load subjects: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Load students based on class selection
            function loadStudents(classId) {
                if (!classId) {
                    $('#student_list_table_body').empty();
                    return;
                }
                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: { perPage: 100, class: classId },
                    dataType: 'json',
                    success: function(response) {
                        const students = response.data || [];
                        $('#student_list_table_body').empty();
                        students.forEach(student => {
                            $('#student_list_table_body').append(`
                                <tr>
                                    <td>${student.full_name || 'N/A'}</td>
                                    <td>${student.father_name || 'N/A'}</td>
                                    <td>${student.roll_no || 'N/A'}</td>
                                    <td>${student.class_name || 'N/A'}</td>
                                </tr>
                            `);
                        });
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load students: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Add schedule row
            function addScheduleRow() {
                if (!window.subjects || window.subjects.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Subjects',
                        text: 'No active subjects found for the selected class.'
                    });
                    return;
                }
                const rowId = Date.now();
                const subjectOptions = window.subjects.map(subject => 
                    `<option value="${subject.id}">${subject.subject}</option>`
                ).join('');
                $('#schedule-container').append(`
                    <div class="row schedule-row" data-id="${rowId}">
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Subject</label>
                            <select name="schedule[${rowId}][subject_id]" class="form-control" required>
                                <option value="">Select Subject</option>
                                ${subjectOptions}
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Date</label>
                            <input type="date" name="schedule[${rowId}][date]" class="form-control" required />
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Time</label>
                            <div class="time-picker">
                                <input type="time" name="schedule[${rowId}][start_time]" class="form-control" required />
                                <span>-</span>
                                <input type="time" name="schedule[${rowId}][end_time]" class="form-control" required />
                            </div>
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">Sitting</label>
                            <select name="schedule[${rowId}][sitting]" class="form-control" required>
                                <option value="First">First</option>
                                <option value="Second">Second</option>
                            </select>
                        </div>
                        <div class="col-md-1 mb-3">
                            <button type="button" class="btn btn-danger remove-schedule">Remove</button>
                        </div>
                    </div>
                `);
            }

            // Remove schedule row
            $(document).on('click', '.remove-schedule', function() {
                $(this).closest('.schedule-row').remove();
            });

            // Handle class selection
            $('#class_id').on('change', function() {
                const classId = $(this).val();
                $('#schedule-container').empty();
                loadSubjects(classId);
                loadStudents(classId);
            });

            // Add schedule row
            $('#add-schedule').on('click', addScheduleRow);

            // Handle form submission
            $('#admitCardForm').on('submit', function(e) {
                e.preventDefault();

                if (!this.checkValidity()) {
                    this.reportValidity();
                    return;
                }

                const formData = new FormData(this);
                const examSchedule = [];
                $('.schedule-row').each(function() {
                    const row = $(this);
                    const rowId = row.data('id');
                    const startTime = row.find(`input[name="schedule[${rowId}][start_time]"]`).val();
                    const endTime = row.find(`input[name="schedule[${rowId}][end_time]"]`).val();
                    if (startTime && endTime) {
                        examSchedule.push({
                            subject_id: row.find(`select[name="schedule[${rowId}][subject_id]"]`).val(),
                            date: row.find(`input[name="schedule[${rowId}][date]"]`).val(),
                            start_time: startTime,
                            end_time: endTime,
                            sitting: row.find(`select[name="schedule[${rowId}][sitting]"]`).val()
                        });
                    }
                });

                if (examSchedule.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Schedule',
                        text: 'Please add at least one exam schedule with valid times.'
                    });
                    return;
                }

                if (!formData.get('signature')) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Signature',
                        text: 'Please upload a signature file.'
                    });
                    return;
                }

                formData.set('exam_schedule', JSON.stringify(examSchedule));

                $('#generate-admit-cards').addClass('btn-loading');

                $.ajax({
                    url: 'submit-admit-card.php',
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(response) {
                        $('#generate-admit-cards').removeClass('btn-loading');
                        if (response.error) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: response.error
                            });
                            return;
                        }
                        if (!response.success || !response.data) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Invalid response from server'
                            });
                            return;
                        }
                        // Store API response in sessionStorage
                        sessionStorage.setItem('admitCardApiData', JSON.stringify(response.data));
                        // Open popup window with the template file from the response
                        const templateFile = response.data.template.file || '1.html';
                        const popup = window.open(`/app/settings/templates/admit-card/${templateFile}`, 'AdmitCardPDF', 'width=800,height=600');
                        if (!popup) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Popup blocked. Please allow popups and try again.'
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        $('#generate-admit-cards').removeClass('btn-loading');
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to process request: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            });

            // Search functionality
            $('#input-search').on('input', function() {
                const search = $(this).val().toLowerCase();
                $('#student_list_table_body tr').each(function() {
                    const name = $(this).find('td:eq(0)').text().toLowerCase();
                    const fatherName = $(this).find('td:eq(1)').text().toLowerCase();
                    const rollNo = $(this).find('td:eq(2)').text().toLowerCase();
                    $(this).toggle(name.includes(search) || fatherName.includes(search) || rollNo.includes(search));
                });
            });

            // Initialize
            loadClasses();
        });
    </script>
</body>
</html>