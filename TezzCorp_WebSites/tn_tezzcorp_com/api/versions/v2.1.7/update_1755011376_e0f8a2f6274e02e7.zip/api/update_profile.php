<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

class UserController {
    private $pdo;
    private $logger;
    private $uploadDir;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };

        // Set upload directory
        $this->uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/uploads/users/';
        if (!file_exists($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
    }

    // Validate input data
    private function validateInput(array $data): array {
        $this->logError('Validating input: ' . json_encode($data));
        $errors = [];
        $validData = [];

        // Define validation rules
        $fields = [
            'name' => ['type' => 'string', 'max_length' => 100, 'required' => true],
            'email' => ['type' => 'string', 'max_length' => 100, 'required' => true],
            'photo' => ['type' => 'string', 'max_length' => 255, 'required' => false],
        ];

        foreach ($fields as $field => $rules) {
            if (array_key_exists($field, $data)) {
                $value = $data[$field];

                // Handle NULL or empty strings for optional fields
                if ($value === '' && !$rules['required']) {
                    $value = null;
                }

                // Type checking
                if ($value !== null) {
                    switch ($rules['type']) {
                        case 'string':
                            if (!is_string($value)) {
                                $errors[] = "$field must be a string";
                            } elseif (isset($rules['max_length']) && strlen($value) > $rules['max_length']) {
                                $errors[] = "$field must not exceed {$rules['max_length']} characters";
                            }
                            break;
                    }

                    // Additional validations
                    if ($field === 'email' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                        $errors[] = "email must be a valid email address";
                    }
                }

                $validData[$field] = $value;
            } elseif ($rules['required']) {
                $errors[] = "$field is required";
            }
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        $this->logError('Validated data: ' . json_encode($validData));
        return $validData;
    }

    // Handle file upload
    private function handleFileUpload($fileKey, $existingPath = null) {
        if (!isset($_FILES[$fileKey]) || $_FILES[$fileKey]['error'] === UPLOAD_ERR_NO_FILE) {
            return $existingPath; // No new file uploaded, return existing path
        }

        $file = $_FILES[$fileKey];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 2 * 1024 * 1024; // 2MB

        if (!in_array($file['type'], $allowedTypes)) {
            $this->sendError(400, "Invalid file type for $fileKey. Allowed types: JPEG, PNG, GIF");
        }
        if ($file['size'] > $maxSize) {
            $this->sendError(400, "File size for $fileKey exceeds 2MB");
        }

        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $extension;
        $destination = $this->uploadDir . $filename;

        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            $this->logError("Failed to upload file for $fileKey");
            $this->sendError(500, "Failed to upload file for $fileKey");
        }

        // Delete old file if it exists
        if ($existingPath && file_exists($this->uploadDir . basename($existingPath))) {
            unlink($this->uploadDir . basename($existingPath));
        }

        return '/uploads/users/' . $filename;
    }

    // Send JSON error response
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    // Send JSON success response
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Handle POST request for updating user profile
    public function post() {
        // Check for _method=PUT
        $method = isset($_POST['_method']) ? strtoupper($_POST['_method']) : 'POST';
        if ($method !== 'PUT') {
            $this->sendError(405, 'Method not allowed. Use _method=PUT');
        }

        // Check if user is authenticated
        if (!isset($_SESSION['uid'])) {
            $this->sendError(401, 'Unauthorized');
        }

        // Fetch existing user data
        $stmt = $this->pdo->prepare("SELECT name, email, photo FROM users WHERE uid = ?");
        $stmt->execute([$_SESSION['uid']]);
        $existing = $stmt->fetch();

        if (!$existing) {
            $this->sendError(404, 'User not found');
        }

        // Parse FormData
        $data = $_POST;

        // Validate input
        $validData = $this->validateInput($data);

        // Handle file upload
        $validData['photo'] = $this->handleFileUpload('photo', $existing['photo']);

        // Prepare fields for update
        $fields = array_keys($validData);
        $updateFields = [];
        $values = [];
        foreach ($fields as $field) {
            $updateFields[] = "$field = ?";
            $values[] = $validData[$field];
        }
        $values[] = $_SESSION['uid'];

        $sql = "UPDATE users SET " . implode(', ', $updateFields) . " WHERE uid = ?";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($values);

            // Update session variables
            $_SESSION['name'] = $validData['name'];
            $_SESSION['email'] = $validData['email'];
            if (isset($validData['photo'])) {
                $_SESSION['photo'] = $validData['photo'];
            }

            $this->sendSuccess(200, [
                'status' => 'success',
                'message' => 'Profile updated successfully',
                'data' => $validData
            ]);
        } catch (PDOException $e) {
            $this->logError('Update failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to update profile: ' . $e->getMessage());
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];

        switch ($method) {
            case 'POST':
                $this->post();
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new UserController();
$controller->handleRequest();
?>