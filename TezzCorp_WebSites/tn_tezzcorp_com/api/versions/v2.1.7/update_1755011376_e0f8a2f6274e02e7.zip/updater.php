<?php
/**
 * AI-ERP 2.0 Update System
 * 
 * This file handles checking for updates and installing them
 */

// Start session
session_start();

// Define constants
define('SYSTEM_VERSION', '2.0.0');
define('UPDATE_SERVER', 'https://aierp.bthdevelopers.com');
define('UPDATE_CHANNEL', 'stable');
define('TEMP_DIRECTORY', 'temp/');

// Include required files
require_once 'includes/database.php';
require_once 'includes/encryption.php';

// Check if user is logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit;
}

// Connect to database
$db = connectDatabase();

if (!$db) {
    die('Failed to connect to database.');
}

// Create update_history table if it doesn't exist
$db->query("
    CREATE TABLE IF NOT EXISTS `update_history` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `version` varchar(20) NOT NULL,
      `update_date` datetime NOT NULL DEFAULT current_timestamp(),
      `description` text DEFAULT NULL,
      `applied_by` varchar(100) DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
");

// Create system_settings table if it doesn't exist
$db->query("
    CREATE TABLE IF NOT EXISTS `system_settings` (
      `setting_key` varchar(100) NOT NULL,
      `setting_value` text NOT NULL,
      `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
      `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
      PRIMARY KEY (`setting_key`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
");

// Insert default settings if they don't exist
$db->query("
    INSERT IGNORE INTO `system_settings` (`setting_key`, `setting_value`) VALUES
    ('system_version', '2.0.0'),
    ('last_update_check', ''),
    ('update_channel', 'stable'),
    ('license_key', ''),
    ('auto_update', 'false');
");

// Get admin user details
$email = $_SESSION['email'];
$query = "SELECT * FROM users WHERE email = ?";
$stmt = $db->prepare($query);
$stmt->bind_param('s', $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // Invalid admin ID
    session_destroy();
    header('Location: login.php');
    exit;
}

$admin = $result->fetch_assoc();
$stmt->close();

// Handle actions
$message = '';
$error = '';
$update_info = null;
$update_available = false;

/**
 * Get setting value
 * 
 * @param string $key Setting key
 * @param string $default Default value
 * @return string Setting value
 */
function getSetting($key, $default = '') {
    global $db;
    
    $query = "SELECT setting_value FROM system_settings WHERE setting_key = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param('s', $key);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return $default;
    }
    
    return $result->fetch_assoc()['setting_value'];
}

/**
 * Update setting value
 * 
 * @param string $key Setting key
 * @param string $value Setting value
 * @return bool Whether the setting was updated
 */
function updateSetting($key, $value) {
    global $db;
    
    $query = "INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) 
              ON DUPLICATE KEY UPDATE setting_value = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param('sss', $key, $value, $value);
    
    return $stmt->execute();
}

/**
 * Get license information from license.dat
 * 
 * @return array|false License information or false on failure
 */
function getLicenseInfo() {
    $file_path = 'includes/license.dat';
    
    if (!file_exists($file_path)) {
        return false;
    }
    
    $license_json = file_get_contents($file_path);
    $license_data = json_decode($license_json, true);
    
    if (!$license_data) {
        return false;
    }
    
    // Decrypt license key if needed
    if (isset($license_data['key']) && function_exists('decryptData')) {
        $license_data['key'] = decryptData($license_data['key']);
    }
    
    return $license_data;
}

/**
 * Send admin notification
 * 
 * @param string $subject Notification subject
 * @param string $message Notification message
 * @param string $type Notification type
 * @return bool Whether the notification was sent
 */
function sendAdminNotification($subject, $message, $type = 'info') {
    global $db, $admin;
    
    // Insert notification into database
    $query = "INSERT INTO notifications (user_id, subject, message, type) VALUES (?, ?, ?, ?)";
    $stmt = $db->prepare($query);
    $stmt->bind_param('isss', $admin['id'], $subject, $message, $type);
    
    return $stmt->execute();
}

/**
 * Log error message
 * 
 * @param string $message Error message
 * @return void
 */
function logError($message) {
    $log_file = 'logs/update_errors.log';
    
    // Create logs directory if it doesn't exist
    if (!is_dir('logs')) {
        mkdir('logs', 0755, true);
    }
    
    // Append error message to log file
    $timestamp = date('Y-m-d H:i:s');
    $log_message = "[{$timestamp}] {$message}" . PHP_EOL;
    
    file_put_contents($log_file, $log_message, FILE_APPEND);
}

// Check for updates
function checkForUpdates() {
    $current_version = getSetting('system_version', SYSTEM_VERSION);
    $update_channel = getSetting('update_channel', UPDATE_CHANNEL);
    
    // Get license information
    $license_info = getLicenseInfo();
    
    if (!$license_info || !isset($license_info['key'], $license_info['domain'])) {
        return [
            'status' => 'error',
            'message' => 'No valid license found. Please activate your license to check for updates.'
        ];
    }
    
    // Prepare request data
    $data = [
        'action' => 'check_update',
        'version' => $current_version,
        'channel' => $update_channel,
        'license' => $license_info['key'],
        'domain' => $license_info['domain']
    ];
    
    // Send request to update server
    $ch = curl_init(UPDATE_SERVER . '/update_api.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        logError('cURL error when checking for updates: ' . curl_error($ch));
        curl_close($ch);
        return [
            'status' => 'error',
            'message' => 'Failed to connect to update server. Please try again later.'
        ];
    }
    
    curl_close($ch);
    
    // Parse response
    $result = json_decode($response, true);
    
    if (!$result || !isset($result['status'])) {
        logError('Invalid response from update server: ' . $response);
        return [
            'status' => 'error',
            'message' => 'Invalid response from update server. Please try again later.'
        ];
    }
    
    if ($result['status'] !== 'success') {
        logError('Update check failed: ' . ($result['message'] ?? 'Unknown error'));
        return [
            'status' => 'error',
            'message' => $result['message'] ?? 'Unknown error'
        ];
    }
    
    // Update last check time
    updateSetting('last_update_check', date('Y-m-d H:i:s'));
    
    return $result;
}

// Download update package
function downloadUpdate($update_info) {
    // Get license information
    $license_info = getLicenseInfo();
    
    if (!$license_info || !isset($license_info['key'], $license_info['domain'])) {
        return false;
    }
    
    // Prepare request data
    $data = [
        'action' => 'download_update',
        'version' => $update_info['version'],
        'license' => $license_info['key'],
        'domain' => $license_info['domain']
    ];
    
    // Create temp directory if it doesn't exist
    if (!file_exists(TEMP_DIRECTORY)) {
        mkdir(TEMP_DIRECTORY, 0755, true);
    }
    
    // Set update package path
    $update_package = TEMP_DIRECTORY . 'update_' . $update_info['version'] . '.zip';
    
    // Download update package
    $ch = curl_init(UPDATE_SERVER . '/update_api.php');
    $fp = fopen($update_package, 'w+');
    
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3600); // 1 hour timeout for large updates
    
    $success = curl_exec($ch);
    
    if (curl_errno($ch)) {
        logError('cURL error when downloading update: ' . curl_error($ch));
        curl_close($ch);
        fclose($fp);
        return false;
    }
    
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    curl_close($ch);
    fclose($fp);
    
    if ($http_code !== 200) {
        logError('Failed to download update package. HTTP code: ' . $http_code);
        return false;
    }
    
    return $update_package;
}

// Install update package
function installUpdate($update_package, $update_info) {
    global $db, $admin;
    
    // Create backup directory if it doesn't exist
    $backup_dir = TEMP_DIRECTORY . 'backup_' . date('Y-m-d_H-i-s') . '/';
    
    if (!file_exists($backup_dir)) {
        mkdir($backup_dir, 0755, true);
    }
    
    // Create backup of current files
    $root_dir = dirname(__FILE__);
    $backup_files = [
        'includes/config.php',
        'license_manager.php',
        'api.php',
        'updater.php',
        'license_validator.php'
    ];
    
    foreach ($backup_files as $file) {
        if (file_exists($root_dir . '/' . $file)) {
            $backup_path = $backup_dir . $file;
            $backup_file_dir = dirname($backup_path);
            
            if (!file_exists($backup_file_dir)) {
                mkdir($backup_file_dir, 0755, true);
            }
            
            copy($root_dir . '/' . $file, $backup_path);
        }
    }
    
    // Extract update package
    $zip = new ZipArchive;
    
    if ($zip->open($update_package) !== true) {
        logError('Failed to open update package: ' . $update_package);
        return false;
    }
    
    // Extract to temp directory first
    $extract_dir = TEMP_DIRECTORY . 'extract_' . $update_info['version'] . '/';
    
    if (!file_exists($extract_dir)) {
        mkdir($extract_dir, 0755, true);
    }
    
    $zip->extractTo($extract_dir);
    $zip->close();
    
    // Check for update script
    if (file_exists($extract_dir . 'update.php')) {
        include $extract_dir . 'update.php';
        
        if (function_exists('pre_update')) {
            pre_update();
        }
    }
    
    // Copy files to main directory
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($extract_dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    
    foreach ($files as $file) {
        $target_path = $root_dir . '/app' . $files->getSubPathName();
        $target_dir = dirname($target_path);
        
        // Skip update script and special files
        if (basename($file) === 'update.php' || basename($file) === 'config.php') {
            continue;
        }
        
        if ($file->isDir()) {
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0755, true);
            }
        } else {
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0755, true);
            }
            
            copy($file, $target_path);
        }
    }
    
    // Run database migrations if needed
    // if (file_exists($extract_dir . 'update.php')) {
    //     if (function_exists('run_migrations')) {
    //         run_migrations();
    //     }
        
    //     if (function_exists('post_update')) {
    //         post_update();
    //     }
    // }
    
    // // Update version in database
    // updateSetting('system_version', $update_info['version']);
    
    // // Record update in history
    // $query = "INSERT INTO update_history (version, description, applied_by) VALUES (?, ?, ?)";
    // $stmt = $db->prepare($query);
    // $description = isset($update_info['notes']) ? $update_info['notes'] : 'System updated to version ' . $update_info['version'];
    // $stmt->bind_param('sss', $update_info['version'], $description, $admin['name']);
    // $stmt->execute();
    
    // // Clean up
    // unlink($update_package);
    
    // // Send notification
    // sendAdminNotification(
    //     'System Updated to v' . $update_info['version'],
    //     'The system has been successfully updated to version ' . $update_info['version'] . '.<br><br>' .
    //     '<strong>Release Notes:</strong><br>' . ($update_info['notes'] ?? 'No release notes available.'),
    //     'info'
    // );
    
    return true;
}

// Check for updates if requested
if (isset($_GET['check']) || isset($_POST['check_updates'])) {
    $update_result = checkForUpdates();
    
    if ($update_result && $update_result['status'] === 'success') {
        if (isset($update_result['update_available']) && $update_result['update_available']) {
            $update_available = true;
            $update_info = [
                'version' => $update_result['version'],
                'release_date' => $update_result['release_date'],
                'notes' => $update_result['notes'],
                'size' => $update_result['size']
            ];
            
            // Store update info in session
            $_SESSION['update_info'] = $update_info;
            
            $message = 'Update available: v' . $update_info['version'];
        } else {
            $message = 'Your system is up to date.';
            // Clear any stored update info
            unset($_SESSION['update_info']);
        }
    } else {
        $error = $update_result['message'] ?? 'Failed to check for updates. Please try again later.';
    }
} else if (isset($_SESSION['update_info'])) {
    // Restore update info from session if available
    $update_info = $_SESSION['update_info'];
    $update_available = true;
}

// Install update if requested
if (isset($_POST['install_update'])) {
    // Get update info from session if not already set
    if (empty($update_info) && isset($_SESSION['update_info'])) {
        $update_info = $_SESSION['update_info'];
    }
    
    if (!empty($update_info)) {
        // Download update package
        $update_package = downloadUpdate($update_info);
        
        if ($update_package) {
            // Install update
            $installed = installUpdate($update_package, $update_info);
            
            if ($installed) {
                $message = 'Update installed successfully. System version: v' . $update_info['version'];
                $update_available = false;
                $update_info = null;
                // Clear stored update info
                unset($_SESSION['update_info']);
            } else {
                $error = 'Failed to install update. Please try again or contact support.';
            }
        } else {
            $error = 'Failed to download update package. Please try again later.';
        }
    } else {
        $error = 'No update information available. Please check for updates first.';
    }
}

// Get current version
$current_version = getSetting('system_version', SYSTEM_VERSION);

// Get last update check
$last_check = getSetting('last_update_check', 'Never');

// Update last check time
if (isset($_GET['check']) || isset($_POST['check_updates'])) {
    updateSetting('last_update_check', date('Y-m-d H:i:s'));
    $last_check = date('Y-m-d H:i:s');
}

// Get update history
$update_history = [];
$query = "SELECT * FROM update_history ORDER BY update_date DESC LIMIT 10";
$result = $db->query($query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $update_history[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update System - AI-ERP 2.0</title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" href="https://aierp.bthdevelopers.com/v1/assets/logo/favicon.svg" type="image/x-icon">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    
    <style>
        :root {
            --primary-color: #6366f1;
            --primary-dark: #4f46e5;
            --primary-light: #818cf8;
            --secondary-color: #14b8a6;
            --dark-color: #1e293b;
            --light-color: #f8fafc;
            --gray-color: #64748b;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --border-radius: 12px;
            --box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f1f5f9;
            color: var(--dark-color);
            min-height: 100vh;
            display: flex;
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Poppins', sans-serif;
            font-weight: 600;
        }
        
        .sidebar {
            width: 280px;
            background-color: #fff;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
            z-index: 100;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .sidebar-header img {
            max-width: 160px;
            height: auto;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-item {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            color: var(--dark-color);
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        
        .menu-item:hover {
            background-color: #f8fafc;
            color: var(--primary-color);
        }
        
        .menu-item.active {
            background-color: #f1f5f9;
            color: var(--primary-color);
            border-left-color: var(--primary-color);
        }
        
        .menu-item i {
            margin-right: 10px;
            font-size: 18px;
            width: 24px;
            text-align: center;
        }
        
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 20px;
            transition: all 0.3s ease;
        }
        
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background-color: #fff;
            padding: 15px 20px;
            border-radius: var(--border-radius);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .page-title {
            font-size: 24px;
            margin: 0;
        }
        
        .card {
            background-color: #fff;
            border-radius: var(--border-radius);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
            transition: all 0.3s ease;
        }
        
        .card:hover {
            box-shadow: var(--box-shadow);
            transform: translateY(-2px);
        }
        
        .card-header {
            padding: 20px;
            border-bottom: 1px solid #e2e8f0;
            background-color: #fff;
            border-top-left-radius: var(--border-radius);
            border-top-right-radius: var(--border-radius);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-title {
            margin: 0;
            font-size: 18px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .btn {
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 14px;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover, .btn-primary:focus {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }
        
        .btn-success {
            background-color: var(--success-color);
            border-color: var(--success-color);
        }
        
        .btn-success:hover, .btn-success:focus {
            background-color: #0d9488;
            border-color: #0d9488;
            transform: translateY(-2px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }
        
        .btn-warning {
            background-color: var(--warning-color);
            border-color: var(--warning-color);
            color: #fff;
        }
        
        .btn-warning:hover, .btn-warning:focus {
            background-color: #d97706;
            border-color: #d97706;
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }
        
        .alert {
            border-radius: var(--border-radius);
            padding: 16px;
            margin-bottom: 20px;
            border: none;
        }
        
        .alert-success {
            background-color: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
        }
        
        .alert-danger {
            background-color: rgba(239, 68, 68, 0.1);
            color: var(--danger-color);
        }
        
        .version-info {
            background-color: #f8fafc;
            border-radius: var(--border-radius);
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .version-info p {
            margin-bottom: 5px;
        }
        
        .update-notes {
            background-color: #f8fafc;
            border-radius: var(--border-radius);
            padding: 15px;
            margin-top: 20px;
            max-height: 300px;
            overflow-y: auto;
        }
        
        .update-progress {
            margin-top: 20px;
        }
        
        .progress-step {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .progress-step-icon {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 10px;
            color: #fff;
            font-size: 14px;
        }
        
        .progress-step-icon.completed {
            background-color: var(--success-color);
        }
        
        .progress-step-icon.active {
            background-color: var(--primary-color);
        }
        
        .progress-step-icon.error {
            background-color: var(--danger-color);
        }
        
        .progress-step-text {
            flex: 1;
        }
        
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                transform: translateX(0);
            }
            
            .sidebar.expanded {
                width: 280px;
            }
            
            .sidebar-header span, .menu-item span {
                display: none;
            }
            
            .sidebar.expanded .sidebar-header span, .sidebar.expanded .menu-item span {
                display: inline;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .main-content.expanded {
                margin-left: 280px;
            }
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            
            .sidebar.expanded {
                transform: translateX(0);
            }
            
            .sidebar-header span, .menu-item span {
                display: inline;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .main-content.expanded {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <img src="https://aierp.bthdevelopers.com/v1/assets/logo/logo.svg" alt="AI-ERP 2.0">
        </div>
        
        <div class="sidebar-menu">
            <a href="app/" class="menu-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="app/payments.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                <span>Payments</span>
            </a>
            <a href="updater.php" class="menu-item active">
                <i class="fas fa-sync-alt"></i>
                <span>Updates</span>
            </a>
            <a href="app/api/logout.php" class="menu-item">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content" id="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="toggle-sidebar">
                <button class="btn btn-sm btn-outline-secondary" id="toggle-sidebar-btn">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            
            <h1 class="page-title">Update System</h1>
            
            <div class="user-info">
                <span><?php echo $admin['name']; ?></span>
            </div>
        </div>
        
        <?php if (!empty($message)): ?>
        <div class="alert alert-success" id="success-alert">
            <i class="fas fa-check-circle me-2"></i> <?php echo $message; ?>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($error)): ?>
        <div class="alert alert-danger" id="error-alert">
            <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
        </div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">System Information</h5>
            </div>
            <div class="card-body">
                <div class="version-info">
                    <p><strong>Current Version:</strong> v<?php echo $current_version; ?></p>
                    <p><strong>Last Update Check:</strong> <?php echo $last_check; ?></p>
                    <p><strong>Update Channel:</strong> <?php echo ucfirst(UPDATE_CHANNEL); ?></p>
                    <p><strong>License Status:</strong> 
                        <?php 
                        $license_info = getLicenseInfo();
                        if ($license_info && isset($license_info['key'], $license_info['domain'])) {
                            echo '<span class="badge bg-success">Active</span>';
                        } else {
                            echo '<span class="badge bg-danger">Invalid</span>';
                        }
                        ?>
                    </p>
                </div>
                
                <form method="post" action="">
                    <button type="submit" name="check_updates" class="btn btn-primary">
                        <i class="fas fa-sync-alt me-2"></i> Check for Updates
                    </button>
                </form>
            </div>
        </div>
        
        <?php if ($update_available && $update_info): ?>
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Update Available</h5>
            </div>
            <div class="card-body">
                <div class="version-info">
                    <p><strong>New Version:</strong> v<?php echo $update_info['version']; ?></p>
                    <p><strong>Release Date:</strong> <?php echo $update_info['release_date']; ?></p>
                    <p><strong>Package Size:</strong> <?php echo $update_info['size']; ?></p>
                </div>
                
                <div class="update-notes">
                    <h6>Release Notes:</h6>
                    <?php echo $update_info['notes']; ?>
                </div>
                
                <div class="mt-4">
                    <form method="post" action="">
                        <button type="submit" name="install_update" class="btn btn-success">
                            <i class="fas fa-download me-2"></i> Install Update
                        </button>
                    </form>
                </div>
                
                <div class="alert alert-warning mt-4">
                    <i class="fas fa-exclamation-triangle me-2"></i> 
                    <strong>Important:</strong> Before updating, please make sure to backup your database and files.
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Update History</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Version</th>
                                <th>Date</th>
                                <th>Description</th>
                                <th>Applied By</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($update_history)): ?>
                                <tr>
                                    <td colspan="4" class="text-center">No update history available.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($update_history as $history): ?>
                                    <tr>
                                        <td>v<?php echo $history['version']; ?></td>
                                        <td><?php echo date('M d, Y', strtotime($history['update_date'])); ?></td>
                                        <td><?php echo $history['description']; ?></td>
                                        <td><?php echo $history['applied_by']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    
    <script>
        $(document).ready(function() {
            // Toggle sidebar
            $('#toggle-sidebar-btn').click(function() {
                $('#sidebar').toggleClass('expanded');
                $('#main-content').toggleClass('expanded');
            });
            
            // Auto-hide alerts after 5 seconds
            setTimeout(function() {
                $('.alert').fadeOut('slow');
            }, 5000);
        });
    </script>
</body>
</html>