<?php
session_start();
if(!isset($_SESSION['uid'])){
	header("location: ../../login");
	die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Class Teacher - AI-ERP 2.0</title>
    <style>
        .action-btn {
            display: none;
        }
        .btn-loading .ti {
            display: none;
        }
        .btn-loading .spinner-border {
            display: inline-block;
        }
        .spinner-border {
            display: none;
            width: 1rem;
            height: 1rem;
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Class Teacher</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Class Teacher
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Class Teacher Management -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-4 col-xl-3">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Class Teachers..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-8 col-xl-9 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div class="action-btn me-2">
                                        <button class="delete-multiple btn bg-danger-subtle text-danger d-flex align-items-center">
                                            <div class="spinner-border text-danger me-1" role="status">
                                                <span class="visually-hidden">Loading...</span>
                                            </div>
                                            <i class="ti ti-trash me-1 fs-5"></i> Delete Selected
                                        </button>
                                    </div>
                                    <button id="btn-add-contact" class="btn btn-primary d-flex align-items-center">
                                        <i class="ti ti-plus text-white me-1 fs-5"></i> Add Class Teacher
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Add/Edit Modal -->
                        <div class="modal fade" id="addContactModal" tabindex="-1" aria-labelledby="addContactModalTitle" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header d-flex align-items-center">
                                        <h5 class="modal-title" id="modal-title">Add Class Teacher</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="add-contact-box">
                                            <div class="add-contact-content">
                                                <form id="addClassTeacherForm">
                                                    <input type="hidden" id="class_teacher_id">
                                                    <div class="mb-3">
                                                        <label for="class_id" class="form-label">Class</label>
                                                        <select class="form-control" id="class_id" required>
                                                            <option value="">Select Class</option>
                                                            <!-- Populated dynamically -->
                                                        </select>
                                                        <span class="validation-text text-danger"></span>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="teacher_id" class="form-label">Teacher</label>
                                                        <select class="form-control" id="teacher_id" required>
                                                            <option value="">Select Teacher</option>
                                                            <!-- Populated dynamically -->
                                                        </select>
                                                        <span class="validation-text text-danger"></span>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="status" class="form-label">Status</label>
                                                        <select class="form-control" id="status" required>
                                                            <option value="">Select Status</option>
                                                            <option value="active">Active</option>
                                                            <option value="inactive">Inactive</option>
                                                        </select>
                                                        <span class="validation-text text-danger"></span>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button id="btn-add" class="btn btn-success"> Add
                                            <div class="spinner-border text-light btn-loading" role="status">
                                                <span class="visually-hidden">Loading...</span>
                                            </div>
                                        </button>
                                        <button id="btn-edit" class="btn btn-success" style="display:none;"> Save
                                            <div class="spinner-border text-light btn-loading" role="status">
                                                <span class="visually-hidden">Loading...</span>
                                            </div>
                                        </button>
                                        <button class="btn bg-danger-subtle text-danger" data-bs-dismiss="modal">
                                            Discard
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Table -->
                        <div class="card card-body">
                            <div class="d-flex justify-content-center">
                                <div class="spinner-border text-primary" role="status" id="table-loader">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <tr>
                                            <th>
                                                <div class="n-chk align-self-center text-center">
                                                    <div class="form-check">
                                                        <input type="checkbox" class="form-check-input primary" id="contact-check-all" />
                                                        <label class="form-check-label" for="contact-check-all"></label>
                                                        <span class="new-control-indicator"></span>
                                                    </div>
                                                </div>
                                            </th>
                                            <th>Class</th>
                                            <th>Teacher</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="class_teacher_list_table_body">
                                        <!-- Table will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <nav aria-label="Page navigation" id="pagination-nav">
                                <ul class="pagination justify-content-center">
                                    <!-- Pagination controls -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        hljs.initHighlightingOnLoad();
        document.querySelectorAll("pre.code-view > code").forEach((codeBlock) => {
            codeBlock.textContent = codeBlock.innerHTML;
        });

        $(document).ready(function() {
            // Pagination state
            let currentPage = 1;
            const perPage = 10;
            let teachersMap = {};
            let classesMap = {};

            // Fetch teachers for mapping tid to teacher_name
            function fetchTeachersForMapping(callback) {
                $.ajax({
                    url: 'api/staff_master.php',
                    type: 'GET',
                    data: { perPage: 100 },
                    dataType: 'json',
                    success: function(response) {
                        const teachers = response.data || [];
                        teachersMap = {};
                        teachers.forEach(t => {
                            teachersMap[t.id] = t.name || t.first_name || '-';
                        });
                        if (callback) callback();
                    },
                    error: function(xhr, status, error) {
                        console.error('Fetch Teachers Error:', xhr.responseJSON, status, error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load teachers: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Fetch classes for mapping class_id to class_name
            function fetchClassesForMapping(callback) {
                $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 100 },
                    dataType: 'json',
                    success: function(response) {
                        const classes = response.data || [];
                        classesMap = {};
                        classes.forEach(c => {
                            classesMap[c.id] = c.class_name;
                        });
                        if (callback) callback();
                    },
                    error: function(xhr, status, error) {
                        console.error('Fetch Classes Error:', xhr.responseJSON, status, error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load classes: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Fetch classes for dropdown
            function fetchClassesForDropdown(callback) {
                $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 100 },
                    dataType: 'json',
                    success: function(response) {
                        const classes = response.data || [];
                        const dropdown = $('#class_id');
                        dropdown.empty();
                        dropdown.append('<option value="">Select Class</option>');
                        classes.forEach(c => {
                            dropdown.append(`<option value="${c.id}">${c.class_name}</option>`);
                        });
                        if (callback) callback();
                    },
                    error: function(xhr, status, error) {
                        console.error('Fetch Classes Error:', xhr.responseJSON, status, error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load classes: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Fetch teachers for dropdown
            function fetchTeachersForDropdown(callback) {
                $.ajax({
                    url: 'api/staff_master.php',
                    type: 'GET',
                    data: { perPage: 100 },
                    dataType: 'json',
                    success: function(response) {
                        const teachers = response.data || [];
                        const dropdown = $('#teacher_id');
                        dropdown.empty();
                        dropdown.append('<option value="">Select Teacher</option>');
                        teachers.forEach(t => {
                            const teacherName = t.name || t.first_name || '-';
                            dropdown.append(`<option value="${t.id}">${teacherName}</option>`);
                        });
                        if (callback) callback();
                    },
                    error: function(xhr, status, error) {
                        console.error('Fetch Teachers Error:', xhr.responseJSON, status, error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load teachers: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Fetch class teacher data with pagination
            function fetchClassTeachers(page = 1) {
                $('#table-loader').show();
                $('#class_teacher_list_table_body').empty();

                $.ajax({
                    url: 'api/class_teacher_master.php',
                    type: 'GET',
                    data: { page: page, perPage: perPage },
                    dataType: 'json',
                    success: function(response) {
                        const classTeachers = response.data || [];
                        const meta = response.meta || { page: 1, totalPages: 1, totalItems: classTeachers.length };
                        renderClassTeacherTable(classTeachers, page);
                        renderPagination(meta);
                        $('#table-loader').hide();
                    },
                    error: function(xhr, status, error) {
                        $('#table-loader').hide();
                        renderPagination({ page: 1, totalPages: 1, totalItems: 0 });
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load class teacher data: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Render class teacher table
            function renderClassTeacherTable(classTeachers, page) {
                const tbody = $('#class_teacher_list_table_body');
                tbody.empty();
                if (classTeachers.length === 0) {
                    tbody.append('<tr><td colspan="5" class="text-center">No class teacher entries found.</td></tr>');
                    return;
                }
                classTeachers.forEach((ct, index) => {
                    const serialNumber = (page - 1) * perPage + index + 1;
                    const teacherName = teachersMap[ct.tid] || ct.tid || '-';
                    const className = classesMap[ct.class] || ct.class || '-';
                    const row = `
                        <tr data-id="${ct.id}">
                            <td>
                                <div class="n-chk align-self-center text-center">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input contact-check" value="${ct.id}" />
                                        <label class="form-check-label"></label>
                                    </div>
                                </div>
                            </td>
                            <td>${className}</td>
                            <td>${teacherName}</td>
                            <td>${ct.status || '-'}</td>
                            <td>
                                <button class="edit-class-teacher btn btn-sm btn-primary" data-id="${ct.id}">
                                    <div class="spinner-border text-light" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                    <i class="ti ti-edit"></i>
                                </button>
                                <button class="delete-class-teacher btn btn-sm btn-danger" data-id="${ct.id}">
                                    <div class="spinner-border text-light" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                    <i class="ti ti-trash"></i>
                                </button>
                            </td>
                        </tr>`;
                    tbody.append(row);
                });
            }

            // Render pagination
            function renderPagination(meta) {
                const pagination = $('#pagination-nav ul');
                pagination.empty();

                const currentPage = meta.page || 1;
                const totalPages = meta.totalPages || 1;

                pagination.append(`
                    <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
                    </li>
                `);

                for (let p = 1; p <= totalPages; p++) {
                    pagination.append(`
                        <li class="page-item ${p === currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${p}">${p}</a>
                        </li>
                    `);
                }

                pagination.append(`
                    <li class="page-item ${currentPage >= totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
                    </li>
                `);
            }

            // Pagination click
            $(document).on('click', '#pagination-nav a', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && page !== currentPage) {
                    currentPage = page;
                    fetchClassTeachers(page);
                }
            });

            // Toggle action buttons
            function toggleActionButtons() {
                const checked = $('.contact-check:checked').length;
                $('.action-btn').toggle(checked > 0);
            }

            // Select all checkboxes
            $('#contact-check-all').on('change', function() {
                $('.contact-check').prop('checked', this.checked);
                toggleActionButtons();
            });

            // Individual checkbox change
            $(document).on('change', '.contact-check', toggleActionButtons);

            // Search functionality
            $('#input-search').on('keyup', function() {
                const search = $(this).val().toLowerCase();
                $('#class_teacher_list_table_body tr').each(function() {
                    const text = $(this).text().toLowerCase();
                    $(this).toggle(text.includes(search));
                });
            });

            // Delete multiple
            $('.delete-multiple').on('click', function() {
                const selected = $('.contact-check:checked').map(function() {
                    return $(this).val();
                }).get();
                if (selected.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Selection',
                        text: 'Please select at least one class teacher entry to delete.'
                    });
                    return;
                }
                Swal.fire({
                    title: 'Are you sure?',
                    text: `Delete ${selected.length} class teacher entries?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        Promise.all(selected.map(id =>
                            $.ajax({
                                url: 'api/class_teacher_master.php',
                                type: 'DELETE',
                                contentType: 'application/json',
                                data: JSON.stringify({ id: id })
                            })
                        )).then(() => {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted',
                                text: 'Class teacher entries deleted successfully'
                            });
                            fetchClassTeachers(currentPage);
                            $('.contact-check').prop('checked', false);
                            toggleActionButtons();
                        }).catch(xhr => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to delete class teacher entries: ' + (xhr.responseJSON?.error || xhr.statusText)
                            });
                        }).finally(() => {
                            $('.delete-multiple').removeClass('btn-loading');
                        });
                    }
                });
            });

            // Open add modal and populate dropdowns
            $('#btn-add-contact').on('click', function() {
                $('#modal-title').text('Add Class Teacher');
                $('#addClassTeacherForm')[0].reset();
                $('#class_teacher_id').val('');
                $('#btn-add').show();
                $('#btn-edit').hide();

                fetchClassesForDropdown(() => {
                    fetchTeachersForDropdown(() => {
                        $('#addContactModal').modal('show');
                    });
                });
            });

            // Add class teacher entry
            $('#btn-add').on('click', function() {
                if (!$('#addClassTeacherForm')[0].checkValidity()) {
                    $('#addClassTeacherForm')[0].reportValidity();
                    return;
                }

                const data = {
                    tid: parseInt($('#teacher_id').val()),
                    class: parseInt($('#class_id').val()),
                    status: $('#status').val()
                };

                $(this).addClass('btn-loading');

                $.ajax({
                    url: 'api/class_teacher_master.php',
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(data),
                    dataType: 'json',
                    success: function(response) {
                        $('#addContactModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Class teacher entry added successfully'
                        });
                        fetchClassTeachers(currentPage);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to add class teacher entry: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('#btn-add').removeClass('btn-loading');
                    }
                });
            });

            // Edit class teacher entry
            $(document).on('click', '.edit-class-teacher', function() {
                const id = $(this).data('id');
                $(this).addClass('btn-loading');
                $.ajax({
                    url: 'api/class_teacher_master.php',
                    type: 'GET',
                    data: { id: id },
                    dataType: 'json',
                    success: function(response) {
                        const classTeacher = response.data && response.data[0] || {};
                        fetchClassesForDropdown(() => {
                            fetchTeachersForDropdown(() => {
                                $('#modal-title').text('Edit Class Teacher');
                                $('#class_teacher_id').val(classTeacher.id || '');
                                $('#class_id').val(classTeacher.class || '');
                                $('#teacher_id').val(classTeacher.tid || '');
                                $('#status').val(classTeacher.status || 'active');
                                $('#btn-add').hide();
                                $('#btn-edit').show();
                                $('#addContactModal').modal('show');
                            });
                        });
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load class teacher details: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('.edit-class-teacher[data-id="' + id + '"]').removeClass('btn-loading');
                    }
                });
            });

            // Save edited class teacher entry
            $('#btn-edit').on('click', function() {
                if (!$('#addClassTeacherForm')[0].checkValidity()) {
                    $('#addClassTeacherForm')[0].reportValidity();
                    return;
                }

                const data = {
                    id: $('#class_teacher_id').val(),
                    tid: parseInt($('#teacher_id').val()),
                    class: parseInt($('#class_id').val()),
                    status: $('#status').val()
                };

                $(this).addClass('btn-loading');

                $.ajax({
                    url: 'api/class_teacher_master.php',
                    type: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify(data),
                    dataType: 'json',
                    success: function(response) {
                        $('#addContactModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Class teacher entry updated successfully'
                        });
                        fetchClassTeachers(currentPage);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to update class teacher entry: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('#btn-edit').removeClass('btn-loading');
                    }
                });
            });

            // Delete single class teacher entry
            $(document).on('click', '.delete-class-teacher', function() {
                const id = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'Delete this class teacher entry?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/class_teacher_master.php',
                            type: 'DELETE',
                            contentType: 'application/json',
                            data: JSON.stringify({ id: id }),
                            dataType: 'json',
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted',
                                    text: response.message || 'Class teacher entry deleted successfully'
                                });
                                fetchClassTeachers(currentPage);
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to delete class teacher entry: ' + (xhr.responseJSON?.error || error)
                                });
                            },
                            complete: function() {
                                $('.delete-class-teacher[data-id="' + id + '"]').removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // Initial load: Fetch teachers and classes for mapping, then class teachers
            fetchTeachersForMapping(() => {
                fetchClassesForMapping(() => {
                    fetchClassTeachers(currentPage);
                });
            });
        });
    </script>
</body>
</html>