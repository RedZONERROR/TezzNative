<?php
session_start();
if(!isset($_SESSION['uid'])){
	header("location: ../../login");
	die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Transport Management - AI-ERP 2.0</title>
    <style>
        .action-btn {
            display: none;
        }
        .btn-loading .ti {
            display: none;
        }
        .btn-loading .spinner-border {
            display: inline-block;
        }
        .spinner-border {
            display: none;
            width: 1rem;
            height: 1rem;
        }
        .table-responsive {
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Transport Management</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Transport Management
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Transport Management -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-4 col-xl-3">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Transport Entries..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-8 col-xl-9 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div class="action-btn me-2">
                                        <button class="delete-multiple btn bg-danger-subtle text-danger d-flex align-items-center">
                                            <div class="spinner-border text-danger me-1" role="status">
                                                <span class="visually-hidden">Loading...</span>
                                            </div>
                                            <i class="ti ti-trash me-1 fs-5"></i> Delete Selected
                                        </button>
                                    </div>
                                    <button id="btn-add-contact" class="btn btn-primary d-flex align-items-center">
                                        <i class="ti ti-plus text-white me-1 fs-5"></i> Add Transport Entry
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Add/Edit Modal -->
                        <div class="modal fade" id="addContactModal" tabindex="-1" aria-labelledby="addContactModalTitle" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header d-flex align-items-center">
                                        <h5 class="modal-title" id="modal-title">Add Transport Entry</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="add-contact-box">
                                            <div class="add-contact-content">
                                                <form id="addTransportForm">
                                                    <input type="hidden" id="transport_id">
                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <label for="registration_no" class="form-label">Registration Number</label>
                                                            <input type="text" class="form-control" id="registration_no" placeholder="e.g., MH12AB1234" required pattern="[A-Z0-9\- ]+">
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="driver_name" class="form-label">Driver Name</label>
                                                            <input type="text" class="form-control" id="driver_name" placeholder="e.g., John Doe" required>
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <label for="driver_mobile" class="form-label">Driver Mobile</label>
                                                            <input type="tel" class="form-control" id="driver_mobile" placeholder="e.g., +919876543210" required pattern="\+?\d{10,15}">
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="from_location" class="form-label">From Location</label>
                                                            <input type="text" class="form-control" id="from_location" placeholder="e.g., Mumbai" required>
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <label for="to_location" class="form-label">To Location</label>
                                                            <input type="text" class="form-control" id="to_location" placeholder="e.g., Pune" required>
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="transport_fees" class="form-label">Transport Fees</label>
                                                            <input type="number" step="0.01" min="0" class="form-control" id="transport_fees" placeholder="e.g., 1500.50" required>
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <label for="date" class="form-label">Date</label>
                                                            <input type="date" class="form-control" id="date" required>
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="status" class="form-label">Status</label>
                                                            <select class="form-control" id="status" required>
                                                                <option value="">Select Status</option>
                                                                <option value="active">Active</option>
                                                                <option value="inactive">Inactive</option>
                                                            </select>
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button id="btn-add" class="btn btn-success"> Add
                                            <div class="spinner-border text-light btn-loading" role="status">
                                                <span class="visually-hidden">Loading...</span>
                                            </div>
                                        </button>
                                        <button id="btn-edit" class="btn btn-success" style="display:none;"> Save
                                            <div class="spinner-border text-light btn-loading" role="status">
                                                <span class="visually-hidden">Loading...</span>
                                            </div>
                                        </button>
                                        <button class="btn bg-danger-subtle text-danger" data-bs-dismiss="modal">
                                            Discard
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Table -->
                        <div class="card card-body">
                            <div class="d-flex justify-content-center">
                                <div class="spinner-border text-primary" role="status" id="table-loader">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <tr>
                                            <th>
                                                <div class="n-chk align-self-center text-center">
                                                    <div class="form-check">
                                                        <input type="checkbox" class="form-check-input primary" id="contact-check-all" />
                                                        <label class="form-check-label" for="contact-check-all"></label>
                                                        <span class="new-control-indicator"></span>
                                                    </div>
                                                </div>
                                            </th>
                                            <th>Registration No</th>
                                            <th>Driver Name</th>
                                            <th>Driver Mobile</th>
                                            <th>From Location</th>
                                            <th>To Location</th>
                                            <th>Transport Fees</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th>Updated On</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="transport_list_table_body">
                                        <!-- Table will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <nav aria-label="Page navigation" id="pagination-nav">
                                <ul class="pagination justify-content-center">
                                    <!-- Pagination controls -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        hljs.initHighlightingOnLoad();
        document.querySelectorAll("pre.code-view > code").forEach((codeBlock) => {
            codeBlock.textContent = codeBlock.innerHTML;
        });

        $(document).ready(function() {
            // Pagination state
            let currentPage = 1;
            const perPage = 10;

            // Fetch transport data with pagination
            function fetchTransportEntries(page = 1) {
                $('#table-loader').show();
                $('#transport_list_table_body').empty();

                $.ajax({
                    url: 'api/transport_master.php',
                    type: 'GET',
                    data: { page: page, perPage: perPage },
                    dataType: 'json',
                    success: function(response) {
                        const transportEntries = response.data || [];
                        const meta = response.meta || { page: 1, totalPages: 1, totalItems: transportEntries.length };
                        renderTransportTable(transportEntries, page);
                        renderPagination(meta);
                        $('#table-loader').hide();
                    },
                    error: function(xhr, status, error) {
                        $('#table-loader').hide();
                        renderPagination({ page: 1, totalPages: 1, totalItems: 0 });
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load transport data: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Render transport table
            function renderTransportTable(transportEntries, page) {
                const tbody = $('#transport_list_table_body');
                tbody.empty();
                if (transportEntries.length === 0) {
                    tbody.append('<tr><td colspan="11" class="text-center">No transport entries found.</td></tr>');
                    return;
                }
                transportEntries.forEach((entry, index) => {
                    const serialNumber = (page - 1) * perPage + index + 1;
                    const updatedOn = entry.updated_on ? new Date(entry.updated_on).toLocaleString() : '-';
                    const row = `
                        <tr data-id="${entry.id}">
                            <td>
                                <div class="n-chk align-self-center text-center">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input contact-check" value="${entry.id}" />
                                        <label class="form-check-label"></label>
                                    </div>
                                </div>
                            </td>
                            <td>${entry.registration_no || '-'}</td>
                            <td>${entry.driver_name || '-'}</td>
                            <td>${entry.driver_mobile || '-'}</td>
                            <td>${entry.from_location || '-'}</td>
                            <td>${entry.to_location || '-'}</td>
                            <td>${entry.transport_fees || '0.00'}</td>
                            <td>${entry.date || '-'}</td>
                            <td>${entry.status || '-'}</td>
                            <td>${updatedOn}</td>
                            <td>
                                <button class="edit-transport btn btn-sm btn-primary" data-id="${entry.id}">
                                    <div class="spinner-border text-light" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                    <i class="ti ti-edit"></i>
                                </button>
                                <button class="delete-transport btn btn-sm btn-danger" data-id="${entry.id}">
                                    <div class="spinner-border text-light" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                    <i class="ti ti-trash"></i>
                                </button>
                            </td>
                        </tr>`;
                    tbody.append(row);
                });
            }

            // Render pagination
            function renderPagination(meta) {
                const pagination = $('#pagination-nav ul');
                pagination.empty();

                const currentPage = meta.page || 1;
                const totalPages = meta.totalPages || 1;

                pagination.append(`
                    <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
                    </li>
                `);

                for (let p = 1; p <= totalPages; p++) {
                    pagination.append(`
                        <li class="page-item ${p === currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${p}">${p}</a>
                        </li>
                    `);
                }

                pagination.append(`
                    <li class="page-item ${currentPage >= totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
                    </li>
                `);
            }

            // Pagination click
            $(document).on('click', '#pagination-nav a', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && page !== currentPage) {
                    currentPage = page;
                    fetchTransportEntries(page);
                }
            });

            // Toggle action buttons
            function toggleActionButtons() {
                const checked = $('.contact-check:checked').length;
                $('.action-btn').toggle(checked > 0);
            }

            // Select all checkboxes
            $('#contact-check-all').on('change', function() {
                $('.contact-check').prop('checked', this.checked);
                toggleActionButtons();
            });

            // Individual checkbox change
            $(document).on('change', '.contact-check', toggleActionButtons);

            // Search functionality
            $('#input-search').on('keyup', function() {
                const search = $(this).val().toLowerCase();
                $('#transport_list_table_body tr').each(function() {
                    const text = $(this).text().toLowerCase();
                    $(this).toggle(text.includes(search));
                });
            });

            // Delete multiple
            $('.delete-multiple').on('click', function() {
                const selected = $('.contact-check:checked').map(function() {
                    return $(this).val();
                }).get();
                if (selected.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Selection',
                        text: 'Please select at least one transport entry to delete.'
                    });
                    return;
                }
                Swal.fire({
                    title: 'Are you sure?',
                    text: `Delete ${selected.length} transport entries?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        Promise.all(selected.map(id =>
                            $.ajax({
                                url: 'api/transport_master.php',
                                type: 'DELETE',
                                contentType: 'application/json',
                                data: JSON.stringify({ id: id })
                            })
                        )).then(() => {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted',
                                text: 'Transport entries deleted successfully'
                            });
                            fetchTransportEntries(currentPage);
                            $('.contact-check').prop('checked', false);
                            toggleActionButtons();
                        }).catch(xhr => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to delete transport entries: ' + (xhr.responseJSON?.error || xhr.statusText)
                            });
                        }).finally(() => {
                            $('.delete-multiple').removeClass('btn-loading');
                        });
                    }
                });
            });

            // Open add modal
            $('#btn-add-contact').on('click', function() {
                $('#modal-title').text('Add Transport Entry');
                $('#addTransportForm')[0].reset();
                $('#transport_id').val('');
                $('#btn-add').show();
                $('#btn-edit').hide();
                $('#addContactModal').modal('show');
            });

            // Add transport entry
            $('#btn-add').on('click', function() {
                if (!$('#addTransportForm')[0].checkValidity()) {
                    $('#addTransportForm')[0].reportValidity();
                    return;
                }

                const data = {
                    registration_no: $('#registration_no').val().trim(),
                    driver_name: $('#driver_name').val().trim(),
                    driver_mobile: $('#driver_mobile').val().trim(),
                    from_location: $('#from_location').val().trim(),
                    to_location: $('#to_location').val().trim(),
                    transport_fees: parseFloat($('#transport_fees').val()),
                    date: $('#date').val(),
                    status: $('#status').val()
                };

                $(this).addClass('btn-loading');

                $.ajax({
                    url: 'api/transport_master.php',
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(data),
                    dataType: 'json',
                    success: function(response) {
                        $('#addContactModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Transport entry added successfully'
                        });
                        fetchTransportEntries(currentPage);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to add transport entry: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('#btn-add').removeClass('btn-loading');
                    }
                });
            });

            // Edit transport entry
            $(document).on('click', '.edit-transport', function() {
                const id = $(this).data('id');
                $(this).addClass('btn-loading');
                $.ajax({
                    url: 'api/transport_master.php',
                    type: 'GET',
                    data: { id: id },
                    dataType: 'json',
                    success: function(response) {
                        const transportEntry = response.data && response.data[0] || {};
                        $('#modal-title').text('Edit Transport Entry');
                        $('#transport_id').val(transportEntry.id || '');
                        $('#registration_no').val(transportEntry.registration_no || '');
                        $('#driver_name').val(transportEntry.driver_name || '');
                        $('#driver_mobile').val(transportEntry.driver_mobile || '');
                        $('#from_location').val(transportEntry.from_location || '');
                        $('#to_location').val(transportEntry.to_location || '');
                        $('#transport_fees').val(transportEntry.transport_fees || '0.00');
                        $('#date').val(transportEntry.date || '');
                        $('#status').val(transportEntry.status || 'active');
                        $('#btn-add').hide();
                        $('#btn-edit').show();
                        $('#addContactModal').modal('show');
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load transport details: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('.edit-transport[data-id="' + id + '"]').removeClass('btn-loading');
                    }
                });
            });

            // Save edited transport entry
            $('#btn-edit').on('click', function() {
                if (!$('#addTransportForm')[0].checkValidity()) {
                    $('#addTransportForm')[0].reportValidity();
                    return;
                }

                const data = {
                    id: $('#transport_id').val(),
                    registration_no: $('#registration_no').val().trim(),
                    driver_name: $('#driver_name').val().trim(),
                    driver_mobile: $('#driver_mobile').val().trim(),
                    from_location: $('#from_location').val().trim(),
                    to_location: $('#to_location').val().trim(),
                    transport_fees: parseFloat($('#transport_fees').val()),
                    date: $('#date').val(),
                    status: $('#status').val()
                };

                $(this).addClass('btn-loading');

                $.ajax({
                    url: 'api/transport_master.php',
                    type: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify(data),
                    dataType: 'json',
                    success: function(response) {
                        $('#addContactModal').modal('hide');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Transport entry updated successfully'
                        });
                        fetchTransportEntries(currentPage);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to update transport entry: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('#btn-edit').removeClass('btn-loading');
                    }
                });
            });

            // Delete single transport entry
            $(document).on('click', '.delete-transport', function() {
                const id = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'Delete this transport entry?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/transport_master.php',
                            type: 'DELETE',
                            contentType: 'application/json',
                            data: JSON.stringify({ id: id }),
                            dataType: 'json',
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted',
                                    text: response.message || 'Transport entry deleted successfully'
                                });
                                fetchTransportEntries(currentPage);
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to delete transport entry: ' + (xhr.responseJSON?.error || error)
                                });
                            },
                            complete: function() {
                                $('.delete-transport[data-id="' + id + '"]').removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // Initial load
            fetchTransportEntries(currentPage);
        });
    </script>
</body>
</html>