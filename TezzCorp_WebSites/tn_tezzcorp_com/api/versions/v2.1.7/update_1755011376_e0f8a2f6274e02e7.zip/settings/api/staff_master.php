<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

date_default_timezone_set('Asia/Kolkata');

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class StaffController {
    private $pdo;
    private $logger;
    private $requiredFields = [];

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };

        // Load required fields
        $this->loadRequiredFields();
    }

    // Load required fields from staff_form_elements
    private function loadRequiredFields() {
        try {
            $stmt = $this->pdo->prepare("SELECT column_name, is_required FROM staff_form_elements WHERE status = 'active'");
            $stmt->execute();
            $fields = $stmt->fetchAll();
            foreach ($fields as $field) {
                $this->requiredFields[$field['column_name']] = (bool)$field['is_required'];
            }
        } catch (PDOException $e) {
            $this->logError('Failed to load required fields: ' . $e->getMessage());
            $this->sendError(500, 'Failed to load required fields');
        }
    }

    // Validate input data
    private function validateInput(array $data, bool $isUpdate = false): array {
        $errors = [];
        $validData = [];

        $fields = [
            'name' => ['type' => 'string', 'max' => 255, 'required' => $isUpdate ? false : ($this->requiredFields['name'] ?? true)],
            'mobile' => ['type' => 'string', 'pattern' => '/^[0-9]{10,15}$/', 'required' => $isUpdate ? false : ($this->requiredFields['mobile'] ?? true)],
            'email' => ['type' => 'string', 'max' => 255, 'pattern' => '/^[^\s@]+@[^\s@]+\.[^\s@]+$/', 'required' => $isUpdate ? false : ($this->requiredFields['email'] ?? true)],
            'password' => ['type' => 'string', 'max' => 255, 'required' => $isUpdate ? false : ($this->requiredFields['password'] ?? true)],
            'dob' => ['type' => 'date', 'required' => $this->requiredFields['dob'] ?? false],
            'nationality' => ['type' => 'string', 'enum' => ['Indian', 'Other'], 'required' => $this->requiredFields['nationality'] ?? false],
            'gender' => ['type' => 'string', 'enum' => ['Male', 'Female', 'Other'], 'required' => $this->requiredFields['gender'] ?? false],
            'qualification' => ['type' => 'string', 'enum' => ['High School', 'Diploma', 'Bachelor', 'Master', 'PhD'], 'required' => $this->requiredFields['qualification'] ?? false],
            'aadhaar' => ['type' => 'string', 'pattern' => '/^[0-9]{12}$/', 'required' => $this->requiredFields['aadhaar'] ?? false],
            'pan' => ['type' => 'string', 'pattern' => '/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', 'required' => $this->requiredFields['pan'] ?? false],
            'account_no' => ['type' => 'string', 'max' => 20, 'required' => $this->requiredFields['account_no'] ?? false],
            'ifsc' => ['type' => 'string', 'max' => 11, 'required' => $this->requiredFields['ifsc'] ?? false],
            'bank_name' => ['type' => 'string', 'max' => 100, 'required' => $this->requiredFields['bank_name'] ?? false],
            'residential_address' => ['type' => 'string', 'max' => 65535, 'required' => $this->requiredFields['residential_address'] ?? false],
            'permanent_address' => ['type' => 'string', 'max' => 65535, 'required' => $this->requiredFields['permanent_address'] ?? false],
            'role' => ['type' => 'string', 'enum' => ['Teacher', 'Principal', 'Support Staff'], 'required' => $isUpdate ? false : ($this->requiredFields['role'] ?? true)],
            'status' => ['type' => 'string', 'enum' => ['active', 'inactive', 'deleted'], 'required' => $isUpdate ? false : ($this->requiredFields['status'] ?? false)],
            'doj' => ['type' => 'date', 'required' => $this->requiredFields['doj'] ?? false],
            'doe' => ['type' => 'date', 'required' => $this->requiredFields['doe'] ?? false],
            'photo' => ['type' => 'string', 'max' => 255, 'required' => $this->requiredFields['photo'] ?? false],
            'tenth_marksheet' => ['type' => 'string', 'max' => 255, 'required' => $this->requiredFields['tenth_marksheet'] ?? false],
            'twelfth_marksheet' => ['type' => 'string', 'max' => 255, 'required' => $this->requiredFields['twelfth_marksheet'] ?? false],
            'graduation' => ['type' => 'string', 'max' => 255, 'required' => $this->requiredFields['graduation'] ?? false],
            'b_ed' => ['type' => 'string', 'max' => 255, 'required' => $this->requiredFields['b_ed'] ?? false],
            'd_el_ed' => ['type' => 'string', 'max' => 255, 'required' => $this->requiredFields['d_el_ed'] ?? false],
            'ntt' => ['type' => 'string', 'max' => 255, 'required' => $this->requiredFields['ntt'] ?? false],
            'exp_certificate' => ['type' => 'string', 'max' => 255, 'required' => $this->requiredFields['exp_certificate'] ?? false],
            'signature' => ['type' => 'string', 'max' => 255, 'required' => $this->requiredFields['signature'] ?? false],
            'aadhaar_image' => ['type' => 'string', 'max' => 255, 'required' => $this->requiredFields['aadhaar_image'] ?? false],
            'pan_image' => ['type' => 'string', 'max' => 255, 'required' => $this->requiredFields['pan_image'] ?? false],
            'bank_document' => ['type' => 'string', 'max' => 255, 'required' => $this->requiredFields['bank_document'] ?? false],
            'resume' => ['type' => 'string', 'max' => 255, 'required' => $this->requiredFields['resume'] ?? false],
            'tsv' => ['type' => 'boolean', 'required' => $this->requiredFields['tsv'] ?? false],
            'otp' => ['type' => 'string', 'max' => 10, 'required' => $this->requiredFields['otp'] ?? false],
        ];

        // Validate id for updates
        if ($isUpdate) {
            if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT) || $data['id'] <= 0) {
                $errors[] = "id must be a valid integer";
            } else {
                $validData['id'] = (int)$data['id'];
            }
        }

        foreach ($fields as $field => $rules) {
            $value = isset($data[$field]) ? $data[$field] : null;

            // Handle empty objects
            if (is_array($value) && empty($value)) {
                $value = null;
            }

            // Skip validation if field is not required and value is null/empty
            if (!$rules['required'] && (is_null($value) || $value === '')) {
                $validData[$field] = $value;
                continue;
            }

            // Required field validation
            if ($rules['required'] && (is_null($value) || $value === '')) {
                $errors[] = "$field is required";
                continue;
            }

            // Skip further validation if value is null/empty and not required
            if (is_null($value) || $value === '') {
                $validData[$field] = $value;
                continue;
            }

            switch ($rules['type']) {
                case 'string':
                    if (!is_string($value)) {
                        $errors[] = "$field must be a string";
                    } elseif (isset($rules['max']) && strlen($value) > $rules['max']) {
                        $errors[] = "$field exceeds maximum length of {$rules['max']} characters";
                    } elseif (isset($rules['pattern']) && !preg_match($rules['pattern'], $value)) {
                        $errors[] = "$field format is invalid";
                    }
                    break;
                case 'boolean':
                    $value = filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                    if ($value === null) {
                        $errors[] = "$field must be a boolean (0, 1, true, false)";
                    }
                    break;
                case 'date':
                    if ($value && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) || !strtotime($value)) {
                        $errors[] = "$field must be a valid date (YYYY-MM-DD)";
                    }
                    break;
            }

            if (isset($rules['enum']) && !in_array($value, $rules['enum'], true)) {
                $errors[] = "$field must be one of: " . implode(', ', $rules['enum']);
            }

            $validData[$field] = $value;
        }

        // Check uniqueness for email, aadhaar, pan
        if (isset($validData['email'])) {
            $query = $isUpdate ? "SELECT id FROM staff WHERE email = ? AND id != ?" : "SELECT id FROM staff WHERE email = ?";
            $stmt = $this->pdo->prepare($query);
            $params = $isUpdate ? [$validData['email'], $validData['id']] : [$validData['email']];
            $stmt->execute($params);
            if ($stmt->fetch()) {
                $errors[] = "Email already exists";
            }
        }
        if (isset($validData['aadhaar']) && $validData['aadhaar']) {
            $query = $isUpdate ? "SELECT id FROM staff WHERE aadhaar = ? AND id != ?" : "SELECT id FROM staff WHERE aadhaar = ?";
            $stmt = $this->pdo->prepare($query);
            $params = $isUpdate ? [$validData['aadhaar'], $validData['id']] : [$validData['aadhaar']];
            $stmt->execute($params);
            if ($stmt->fetch()) {
                $errors[] = "Aadhaar already exists";
            }
        }
        if (isset($validData['pan']) && $validData['pan']) {
            $query = $isUpdate ? "SELECT id FROM staff WHERE pan = ? AND id != ?" : "SELECT id FROM staff WHERE pan = ?";
            $stmt = $this->pdo->prepare($query);
            $params = $isUpdate ? [$validData['pan'], $validData['id']] : [$validData['pan']];
            $stmt->execute($params);
            if ($stmt->fetch()) {
                $errors[] = "PAN already exists";
            }
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return $validData;
    }

    // Send JSON error response
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    // Send JSON success response
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Handle GET requests
    public function get($request) {
        if (isset($request['id'])) {
            $id = filter_var($request['id'], FILTER_VALIDATE_INT);
            if (!$id) {
                $this->sendError(400, 'Invalid ID');
            }

            $stmt = $this->pdo->prepare("SELECT * FROM staff WHERE id = ?");
            $stmt->execute([$id]);
            $staff = $stmt->fetch();

            if ($staff) {
                $this->sendSuccess(200, ['data' => [$staff]]);
            } else {
                $this->sendError(404, 'Staff not found');
            }
        } else {
            // Pagination
            $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
            $perPage = isset($_GET['perPage']) ? max(1, min(100, (int)$_GET['perPage'])) : 10;
            $offset = ($page - 1) * $perPage;

            $query = "SELECT * FROM staff";
            $countQuery = "SELECT COUNT(*) FROM staff";
            $params = [];

            // Filtering
            $conditions = [];
            if (isset($_GET['status']) && in_array($_GET['status'], ['active', 'inactive', 'deleted'])) {
                $conditions[] = "status = ?";
                $params[] = $_GET['status'];
            }
            if (isset($_GET['role']) && in_array($_GET['role'], ['Teacher', 'Principal', 'Support Staff'])) {
                $conditions[] = "role = ?";
                $params[] = $_GET['role'];
            }

            if ($conditions) {
                $query .= " WHERE " . implode(' AND ', $conditions);
                $countQuery .= " WHERE " . implode(' AND ', $conditions);
            }

            $query .= " ORDER BY id LIMIT ? OFFSET ?";
            $params[] = $perPage;
            $params[] = $offset;

            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            $staff = $stmt->fetchAll();

            $countStmt = $this->pdo->prepare($countQuery);
            $countStmt->execute(array_slice($params, 0, count($params) - 2));
            $total = $countStmt->fetchColumn();

            $this->sendSuccess(200, [
                'data' => $staff,
                'meta' => [
                    'page' => $page,
                    'perPage' => $perPage,
                    'totalItems' => $total,
                    'totalPages' => ceil($total / $perPage)
                ]
            ]);
        }
    }

    // Handle POST requests
    public function post($data) {
        if (isset($data['action']) && $data['action'] === 'approve') {
            // Approve action: Update status to active
            if (!isset($data['ids']) || !is_array($data['ids']) || empty($data['ids'])) {
                $this->sendError(400, 'No IDs provided');
            }

            $ids = array_filter($data['ids'], function($id) {
                return filter_var($id, FILTER_VALIDATE_INT) && $id > 0;
            });

            if (empty($ids)) {
                $this->sendError(400, 'Invalid IDs');
            }

            try {
                $placeholders = implode(',', array_fill(0, count($ids), '?'));
                $stmt = $this->pdo->prepare("UPDATE staff SET status = 'active' WHERE id IN ($placeholders)");
                $stmt->execute($ids);
                $this->sendSuccess(200, ['message' => 'Staff approved successfully']);
            } catch (PDOException $e) {
                $this->logError('Approve failed: ' . $e->getMessage());
                $this->sendError(500, 'Failed to approve staff');
            }
            return;
        }

        $validData = $this->validateInput($data);

        // Hash password
        if (isset($validData['password'])) {
            $validData['password'] = password_hash($validData['password'], PASSWORD_BCRYPT);
        }

        // Add created_at timestamp
        $validData['created_at'] = date('Y-m-d H:i:s');

        $fields = array_keys($validData);
        $placeholders = array_fill(0, count($fields), '?');
        $sql = "INSERT INTO staff (" . implode(',', $fields) . ") VALUES (" . implode(',', $placeholders) . ")";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute(array_values($validData));
            $this->sendSuccess(201, ['message' => 'Staff created', 'id' => $this->pdo->lastInsertId()]);
        } catch (PDOException $e) {
            $this->logError('Create failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to create staff');
        }
    }

    // Handle PUT requests
    public function put($data) {
        $validData = $this->validateInput($data, true);

        if (!isset($validData['id'])) {
            $this->sendError(400, 'ID is required');
        }

        // Fetch existing record
        $stmt = $this->pdo->prepare("SELECT * FROM staff WHERE id = ?");
        $stmt->execute([$validData['id']]);
        $existing = $stmt->fetch();

        if (!$existing) {
            $this->sendError(404, 'Staff not found');
        }

        // Hash password if provided
        if (isset($validData['password'])) {
            $validData['password'] = password_hash($validData['password'], PASSWORD_BCRYPT);
        }

        // Merge existing data with provided data
        $fields = ['name', 'mobile', 'email', 'password', 'dob', 'nationality', 'gender', 'qualification', 'aadhaar', 'pan', 'account_no', 'ifsc', 'bank_name', 'residential_address', 'permanent_address', 'role', 'status', 'doj', 'doe', 'photo', 'tenth_marksheet', 'twelfth_marksheet', 'graduation', 'b_ed', 'd_el_ed', 'ntt', 'exp_certificate', 'signature', 'aadhaar_image', 'pan_image', 'bank_document', 'resume', 'tsv', 'otp'];
        $updateFields = [];
        $values = [];
        foreach ($fields as $field) {
            if (isset($validData[$field])) {
                $updateFields[] = "$field = ?";
                $values[] = $validData[$field];
            } else {
                $updateFields[] = "$field = ?";
                $values[] = $existing[$field];
            }
        }
        $values[] = $validData['id'];

        $sql = "UPDATE staff SET " . implode(', ', $updateFields) . " WHERE id = ?";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($values);
            $this->sendSuccess(200, ['message' => 'Staff updated']);
        } catch (PDOException $e) {
            $this->logError('Update failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to update staff');
        }
    }

    // Handle DELETE requests
    public function delete($data) {
        if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT)) {
            $this->sendError(400, 'Invalid or missing ID');
        }

        try {
            // Instead of deleting, update status to 'deleted'
            $stmt = $this->pdo->prepare("UPDATE staff SET status = 'deleted' WHERE id = ?");
            $stmt->execute([$data['id']]);
            if ($stmt->rowCount()) {
                $this->sendSuccess(200, ['message' => 'Staff marked as deleted']);
            } else {
                $this->sendError(404, 'Staff not found');
            }
        } catch (PDOException $e) {
            $this->logError('Mark as deleted failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to mark staff as deleted');
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $data = json_decode(file_get_contents('php://input'), true) ?: [];

        switch ($method) {
            case 'GET':
                $this->get($_GET);
                break;
            case 'POST':
                $this->post($data);
                break;
            case 'PUT':
                $this->put($data);
                break;
            case 'DELETE':
                $this->delete($data);
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new StaffController();
$controller->handleRequest();
?>