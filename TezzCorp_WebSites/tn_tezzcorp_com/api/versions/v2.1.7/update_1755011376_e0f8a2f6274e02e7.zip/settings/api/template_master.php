<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

class TemplateController {
    private $pdo;
    private $logger;
    private $templateDir;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };

        // Set template directory
        $this->templateDir = __DIR__ . '/../../settings/templates/';
    }

    // Validate input data
    private function validateInput(array $data, bool $isUpdate = false): array {
        $this->logError('Validating input: ' . json_encode($data));
        $errors = [];
        $validData = [];

        // Define validation rules
        $fields = [
            'template_type' => ['type' => 'string', 'enum' => ['admit-card', 'marksheet', 'id-card'], 'required' => true],
            'template_file' => ['type' => 'string', 'max_length' => 255, 'required' => true],
            'status' => ['type' => 'string', 'enum' => ['active', 'inactive'], 'required' => true],
        ];

        // Validate id for updates
        if ($isUpdate) {
            if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT) || $data['id'] <= 0) {
                $errors[] = "id must be a valid integer";
            } else {
                $validData['id'] = (int)$data['id'];
            }
        }

        // Validate other fields
        foreach ($fields as $field => $rules) {
            if (array_key_exists($field, $data)) {
                $value = $data[$field];

                // Handle NULL or empty strings for optional fields
                if ($value === '' && !$rules['required']) {
                    $value = null;
                }

                // Type checking
                if ($value !== null) {
                    switch ($rules['type']) {
                        case 'string':
                            if (!is_string($value)) {
                                $errors[] = "$field must be a string";
                            } elseif (isset($rules['max_length']) && strlen($value) > $rules['max_length']) {
                                $errors[] = "$field must not exceed {$rules['max_length']} characters";
                            }
                            break;
                    }

                    // Enum validation
                    if (isset($rules['enum']) && !in_array($value, $rules['enum'], true)) {
                        $errors[] = "$field must be one of: " . implode(', ', $rules['enum']);
                    }

                    // Validate template_file exists
                    if ($field === 'template_file') {
                        $filePath = $this->templateDir . $data['template_type'] . '/' . $value;
                        if (!file_exists($filePath)) {
                            $errors[] = "Template file does not exist: $filePath";
                        }
                    }

                    $validData[$field] = $value;
                } elseif ($rules['required']) {
                    $errors[] = "$field is required";
                }
            } elseif ($rules['required']) {
                $errors[] = "$field is required";
            }
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        $this->logError('Validated data: ' . json_encode($validData));
        return $validData;
    }

    // Send JSON error response
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    // Send JSON success response
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Scan templates directory
    private function getAvailableTemplates() {
        $templateTypes = ['admit-card', 'marksheet', 'id-card'];
        $templates = [];

        foreach ($templateTypes as $type) {
            $dir = $this->templateDir . $type;
            $templates[$type] = [];
            if (is_dir($dir)) {
                $files = scandir($dir);
                foreach ($files as $file) {
                    if (pathinfo($file, PATHINFO_EXTENSION) === 'html') {
                        $templates[$type][] = $file;
                    }
                }
            }
        }

        return $templates;
    }

    // Handle GET request
    public function get($request) {
        if (isset($request['id'])) {
            $id = filter_var($request['id'], FILTER_VALIDATE_INT);
            if (!$id) {
                $this->sendError(400, 'Invalid ID');
            }

            $stmt = $this->pdo->prepare("SELECT * FROM templates WHERE id = ?");
            $stmt->execute([$id]);
            $entry = $stmt->fetch();

            if ($entry) {
                $this->sendSuccess(200, ['data' => [$entry]]);
            } else {
                $this->sendError(404, 'Template not found');
            }
        } else {
            $stmt = $this->pdo->prepare("SELECT * FROM templates");
            $stmt->execute();
            $entries = $stmt->fetchAll();

            $availableTemplates = $this->getAvailableTemplates();
            $this->sendSuccess(200, ['data' => $entries, 'available_templates' => $availableTemplates]);
        }
    }

    // Handle POST request (create or update)
    public function post() {
        $data = $_POST;
        $method = isset($data['_method']) ? strtoupper($data['_method']) : 'POST';

        if ($method === 'PUT' && isset($data['id'])) {
            // Update existing template
            $stmt = $this->pdo->prepare("SELECT * FROM templates WHERE id = ?");
            $stmt->execute([$data['id']]);
            $existing = $stmt->fetch();

            if (!$existing) {
                $this->sendError(404, 'Template not found');
            }

            $validData = $this->validateInput($data, true);

            $sql = "UPDATE templates SET template_type = ?, template_file = ?, status = ?, updated_on = NOW() WHERE id = ?";
            $values = [
                $validData['template_type'],
                $validData['template_file'],
                $validData['status'],
                $validData['id']
            ];

            try {
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute($values);
                $this->sendSuccess(200, ['message' => 'Template updated']);
            } catch (PDOException $e) {
                $this->logError('Update failed: ' . $e->getMessage());
                $this->sendError(500, 'Failed to update template: ' . $e->getMessage());
            }
        } else {
            // Create new template
            $validData = $this->validateInput($data);

            // Check if template_type already exists
            $stmt = $this->pdo->prepare("SELECT * FROM templates WHERE template_type = ?");
            $stmt->execute([$validData['template_type']]);
            if ($stmt->fetch()) {
                $this->sendError(400, 'Template type already exists');
            }

            $sql = "INSERT INTO templates (template_type, template_file, status) VALUES (?, ?, ?)";
            $values = [
                $validData['template_type'],
                $validData['template_file'],
                $validData['status']
            ];

            try {
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute($values);
                $this->sendSuccess(201, ['message' => 'Template created', 'id' => $this->pdo->lastInsertId()]);
            } catch (PDOException $e) {
                $this->logError('Create failed: ' . $e->getMessage());
                $this->sendError(500, 'Failed to create template: ' . $e->getMessage());
            }
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];

        switch ($method) {
            case 'GET':
                $this->get($_GET);
                break;
            case 'POST':
                $this->post();
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new TemplateController();
$controller->handleRequest();
?>