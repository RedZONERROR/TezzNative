<?php
header('Content-Type: application/json; charset=UTF-8');

$uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/uploads/staff/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

if (!isset($_FILES['file']) || !isset($_POST['field'])) {
    echo json_encode(['error' => 'Missing file or field']);
    exit;
}

$file = $_FILES['file'];
$field = $_POST['field'];
$allowedExtensions = [
    'photo' => ['jpg', 'jpeg', 'png'],
    'tenth_marksheet' => ['jpg', 'jpeg', 'png', 'pdf'],
    'twelfth_marksheet' => ['jpg', 'jpeg', 'png', 'pdf'],
    'graduation' => ['jpg', 'jpeg', 'png', 'pdf'],
    'b_ed' => ['jpg', 'jpeg', 'png', 'pdf'],
    'd_el_ed' => ['jpg', 'jpeg', 'png', 'pdf'],
    'ntt' => ['jpg', 'jpeg', 'png', 'pdf'],
    'exp_certificate' => ['jpg', 'jpeg', 'png', 'pdf'],
    'signature' => ['jpg', 'jpeg', 'png'],
    'aadhaar_image' => ['jpg', 'jpeg', 'png', 'pdf'],
    'pan_image' => ['jpg', 'jpeg', 'png', 'pdf'],
    'bank_document' => ['jpg', 'jpeg', 'png', 'pdf'],
    'resume' => ['pdf', 'doc', 'docx']
];

$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if (!in_array($ext, $allowedExtensions[$field] ?? [])) {
    echo json_encode(['error' => 'Invalid file type for ' . $field]);
    exit;
}

$filename = uniqid() . '.' . $ext;
$destination = $uploadDir . $filename;

if (move_uploaded_file($file['tmp_name'], $destination)) {
    echo json_encode(['path' => 'uploads/staff/' . $filename]);
} else {
    echo json_encode(['error' => 'Failed to upload file']);
}
?>