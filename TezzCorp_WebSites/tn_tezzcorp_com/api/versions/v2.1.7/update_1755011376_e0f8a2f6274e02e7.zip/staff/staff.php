<?php
session_start();
if(!isset($_SESSION['uid'])){
	header("location: ../../login");
	die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Staff Management - AI-ERP 2.0</title>
    <style>
        .staff-photo {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 50%;
        }
        .action-buttons {
            display: none;
        }
        .btn-loading .fa-spinner {
            display: inline-block;
        }
        .btn-loading .btn-text, .btn-loading .ti {
            display: none;
        }
        .fa-spinner {
            display: none;
            font-size: 0.9rem;
        }
        .pagination {
            margin-top: 1rem;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar -->
        <?php include 'util/sidebar.php'; ?>
        <div class="page-wrapper">
            <!-- Header -->
            <?php include 'util/topbar.php'; ?>

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Manage Staff</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Staff
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Staff Management -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-4 col-xl-3">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Staff..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-8 col-xl-9 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div class="action-buttons me-2">
                                        <button class="delete-multiple btn bg-danger-subtle text-danger me-1">
                                            <i class="fas fa-spinner fa-spin"></i>
                                            <span class="btn-text">Delete</span>
                                        </button>
                                        <button class="approve-multiple btn bg-success-subtle text-success">
                                            <i class="fas fa-spinner fa-spin"></i>
                                            <span class="btn-text">Approve</span>
                                        </button>
                                    </div>
                                    <a href="registration" id="btn-add-staff"
                                        class="btn btn-primary d-flex align-items-center">
                                        <i class="ti ti-user-plus text-white me-1 fs-5"></i> Add Staff
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="card card-body">
                            <div class="d-flex justify-content-center">
                                <div class="spinner-border text-primary" role="status" id="table-loader">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <th>
                                            <div class="n-chk align-self-center text-center">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input primary" id="staff-check-all" />
                                                    <label class="form-check-label" for="staff-check-all"></label>
                                                    <span class="new-control-indicator"></span>
                                                </div>
                                            </div>
                                        </th>
                                        <th>Photo</th>
                                        <th>Name</th>
                                        <th>Mobile</th>
                                        <th>Role</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody id="staff_list_table_body">
                                        <!-- Data will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <nav aria-label="Page navigation" id="pagination-nav">
                                <ul class="pagination justify-content-center">
                                    <!-- Pagination controls -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- View Modal -->
    <div class="modal fade" id="viewStaffModal" tabindex="-1" aria-labelledby="viewStaffModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewStaffModalLabel">Staff Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Name:</strong> <span id="view-name"></span></p>
                    <p><strong>Mobile:</strong> <span id="view-mobile"></span></p>
                    <p><strong>Email:</strong> <span id="view-email"></span></p>
                    <p><strong>Role:</strong> <span id="view-role"></span></p>
                    <p><strong>Status:</strong> <span id="view-status"></span></p>
                    <p><strong>Photo:</strong><br><img id="view-photo" class="staff-photo" alt="Staff Photo"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        hljs.initHighlightingOnLoad();
        document.querySelectorAll("pre.code-view > code").forEach((codeBlock) => {
            codeBlock.textContent = codeBlock.innerHTML;
        });

        $(document).ready(function() {
            // Pagination state
            let currentPage = 1;
            const perPage = 10;

            // Fetch staff data with pagination
            function fetchStaff(page = 1) {
                $('#table-loader').show();
                $('#staff_list_table_body').empty();

                $.ajax({
                    url: 'api/staff_master.php',
                    type: 'GET',
                    data: { page: page, perPage: perPage },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Staff API Response:', response);
                        const staff = response.data || [];
                        const meta = response.meta || { page: 1, totalPages: 1, totalItems: staff.length };
                        console.log('Meta:', meta);
                        renderStaffTable(staff, page);
                        renderPagination(meta);
                        $('#table-loader').hide();
                    },
                    error: function(xhr, status, error) {
                        $('#table-loader').hide();
                        console.error('Staff AJAX Error:', xhr.responseJSON, status, error);
                        renderPagination({ page: 1, totalPages: 1, totalItems: 0 });
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load staff data: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Render staff table
            function renderStaffTable(staff, page) {
                const tbody = $('#staff_list_table_body');
                tbody.empty();
                if (staff.length === 0) {
                    tbody.append('<tr><td colspan="7" class="text-center">No staff found.</td></tr>');
                    return;
                }
                staff.forEach((s, index) => {
                    const photo = s.photo ? `/${s.photo}` : '/app/staff/assets/images/profile/user-1.jpg';
                    const row = `
                        <tr data-id="${s.id}">
                            <td>
                                <div class="n-chk align-self-center text-center">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input staff-check" value="${s.id}" />
                                        <label class="form-check-label"></label>
                                    </div>
                                </div>
                            </td>
                            <td><img src="${photo}" class="staff-photo" alt="${s.name || 'Photo'}"></td>
                            <td>${s.name || '-'}</td>
                            <td>${s.mobile || '-'}</td>
                            <td>${s.role || '-'}</td>
                            <td>
                                <span class="badge ${
                                    s.status === 'active' ? 'bg-success' :
                                    s.status === 'inactive' ? 'bg-warning' :
                                    s.status === 'deleted' ? 'bg-danger' :
                                    'bg-secondary'
                                }">
                                    ${s.status || '-'}
                                </span>
                            </td>
                            <td>
                                <button class="approve-staff btn btn-sm btn-success" data-id="${s.id}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-check"></i>
                                </button>
                                <button class="view-staff btn btn-sm btn-info" data-id="${s.id}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-eye"></i>
                                </button>
                                <a href="edit_staff.php?id=${s.id}" class="edit-staff btn btn-sm btn-primary">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-edit"></i>
                                </a>
                                <button class="delete-staff btn btn-sm btn-danger" data-id="${s.id}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-trash"></i>
                                </button>
                            </td>
                        </tr>`;
                    tbody.append(row);
                });
            }

            // Render pagination
            function renderPagination(meta) {
                const pagination = $('#pagination-nav ul');
                pagination.empty();

                // Fallback values
                const currentPage = meta.page || 1;
                const totalPages = meta.totalPages || 1;

                // Always render pagination
                pagination.append(`
                    <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
                    </li>
                `);

                for (let p = 1; p <= totalPages; p++) {
                    pagination.append(`
                        <li class="page-item ${p === currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${p}">${p}</a>
                        </li>
                    `);
                }

                pagination.append(`
                    <li class="page-item ${currentPage >= totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
                    </li>
                `);
            }

            // Pagination click
            $(document).on('click', '#pagination-nav a', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && page !== currentPage) {
                    currentPage = page;
                    fetchStaff(page);
                }
            });

            // Toggle action buttons
            function toggleActionButtons() {
                const checked = $('.staff-check:checked').length;
                $('.action-buttons').toggle(checked > 0);
            }

            // Select all checkboxes
            $('#staff-check-all').on('change', function() {
                $('.staff-check').prop('checked', this.checked);
                toggleActionButtons();
            });

            // Individual checkbox change
            $(document).on('change', '.staff-check', toggleActionButtons);

            // Search functionality
            $('#input-search').on('keyup', function() {
                const search = $(this).val().toLowerCase();
                $('#staff_list_table_body tr').each(function() {
                    const text = $(this).text().toLowerCase();
                    $(this).toggle(text.includes(search));
                });
            });

            // Delete multiple
            $('.delete-multiple').on('click', function() {
                const selected = $('.staff-check:checked').map(function() {
                    return $(this).val();
                }).get();
                if (selected.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Selection',
                        text: 'Please select at least one staff to delete.'
                    });
                    return;
                }
                Swal.fire({
                    title: 'Are you sure?',
                    text: `Mark ${selected.length} staff as deleted?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        Promise.all(selected.map(id =>
                            $.ajax({
                                url: 'api/staff_master.php',
                                type: 'DELETE',
                                contentType: 'application/json',
                                data: JSON.stringify({ id: id })
                            })
                        )).then(() => {
                            Swal.fire({
                                icon: 'success',
                                title: 'Marked as Deleted',
                                text: 'Staff marked as deleted successfully'
                            });
                            selected.forEach(id => {
                                const row = $(`tr[data-id="${id}"]`);
                                row.find('.badge').removeClass('bg-success bg-warning').addClass('bg-danger').text('deleted');
                            });
                            $('.staff-check').prop('checked', false);
                            toggleActionButtons();
                        }).catch(xhr => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to mark staff as deleted: ' + (xhr.responseJSON?.error || xhr.statusText)
                            });
                        }).finally(() => {
                            $('.delete-multiple').removeClass('btn-loading');
                        });
                    }
                });
            });

            // Approve multiple
            $('.approve-multiple').on('click', function() {
                const selected = $('.staff-check:checked').map(function() {
                    return $(this).val();
                }).get();
                if (selected.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Selection',
                        text: 'Please select at least one staff to approve.'
                    });
                    return;
                }
                Swal.fire({
                    title: 'Are you sure?',
                    text: `Approve ${selected.length} staff?`,
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, approve!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/staff_master.php',
                            type: 'POST',
                            contentType: 'application/json',
                            data: JSON.stringify({ action: 'approve', ids: selected }),
                            dataType: 'json',
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Approved',
                                    text: response.message || 'Staff approved successfully'
                                });
                                selected.forEach(id => {
                                    const row = $(`tr[data-id="${id}"]`);
                                    row.find('.badge').removeClass('bg-danger bg-warning').addClass('bg-success').text('active');
                                });
                                $('.staff-check').prop('checked', false);
                                toggleActionButtons();
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to approve staff: ' + (xhr.responseJSON?.error || error)
                                });
                            },
                            complete: function() {
                                $('.approve-multiple').removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // View staff
            $(document).on('click', '.view-staff', function() {
                const id = $(this).data('id');
                $(this).addClass('btn-loading');
                $.ajax({
                    url: 'api/staff_master.php',
                    type: 'GET',
                    data: { id: id },
                    dataType: 'json',
                    success: function(response) {
                        const staff = response.data && response.data[0] || {};
                        $('#view-name').text(staff.name || '-');
                        $('#view-mobile').text(staff.mobile || '-');
                        $('#view-email').text(staff.email || '-');
                        $('#view-role').text(staff.role || '-');
                        $('#view-status').text(staff.status || '-');
                        $('#view-photo').attr('src', staff.photo ? `/${staff.photo}` : '/app/staff/assets/images/profile/user-1.jpg');
                        $('#viewStaffModal').modal('show');
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load staff details: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('.view-staff[data-id="' + id + '"]').removeClass('btn-loading');
                    }
                });
            });

            // Approve single staff
            $(document).on('click', '.approve-staff', function() {
                const id = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'Approve this staff?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, approve!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/staff_master.php',
                            type: 'POST',
                            contentType: 'application/json',
                            data: JSON.stringify({ action: 'approve', ids: [id] }),
                            dataType: 'json',
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Approved',
                                    text: response.message || 'Staff approved successfully'
                                });
                                const row = $(`tr[data-id="${id}"]`);
                                row.find('.badge').removeClass('bg-danger bg-warning').addClass('bg-success').text('active');
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to approve staff: ' + (xhr.responseJSON?.error || error)
                                });
                            },
                            complete: function() {
                                $('.approve-staff[data-id="' + id + '"]').removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // Delete single staff
            $(document).on('click', '.delete-staff', function() {
                const id = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'Mark this staff as deleted?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/staff_master.php',
                            type: 'DELETE',
                            contentType: 'application/json',
                            data: JSON.stringify({ id: id }),
                            dataType: 'json',
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Marked as Deleted',
                                    text: response.message || 'Staff marked as deleted successfully'
                                });
                                const row = $(`tr[data-id="${id}"]`);
                                row.find('.badge').removeClass('bg-success bg-warning').addClass('bg-danger').text('deleted');
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to mark staff as deleted: ' + (xhr.responseJSON?.error || error)
                                });
                            },
                            complete: function() {
                                $('.delete-staff[data-id="' + id + '"]').removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // Initial load
            fetchStaff(currentPage);
        });
    </script>
</body>
</html>