<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class FeeStructureController {
    private $pdo;
    private $logger;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );

            // Check and update schema for frequency and custom_frequency columns
            $this->ensureFrequencyColumn();
            $this->ensureCustomFrequencyColumn();
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    // Ensure the frequency column exists and includes 'other'
    private function ensureFrequencyColumn() {
        try {
            $stmt = $this->pdo->query("SHOW COLUMNS FROM fee_structure LIKE 'frequency'");
            if ($stmt->rowCount() === 0) {
                // Column doesn't exist, add it
                $this->pdo->exec("
                    ALTER TABLE fee_structure
                    ADD COLUMN frequency ENUM('monthly', 'annual', 'other') NOT NULL DEFAULT 'monthly'
                    AFTER applicable_months
                ");
                $this->logError('Added missing frequency column to fee_structure table');
            } else {
                // Check if 'other' is in the ENUM values
                $stmt = $this->pdo->query("SHOW COLUMNS FROM fee_structure LIKE 'frequency'");
                $column = $stmt->fetch();
                if (strpos($column['Type'], "'other'") === false) {
                    $this->pdo->exec("
                        ALTER TABLE fee_structure
                        MODIFY COLUMN frequency ENUM('monthly', 'annual', 'other') NOT NULL DEFAULT 'monthly'
                    ");
                    $this->logError('Updated frequency column to include "other" option');
                }
            }
        } catch (PDOException $e) {
            $this->logError('Failed to check or add frequency column: ' . $e->getMessage());
            $this->sendError(500, 'Failed to initialize database schema');
        }
    }

    // Ensure the custom_frequency column exists
    private function ensureCustomFrequencyColumn() {
        try {
            $stmt = $this->pdo->query("SHOW COLUMNS FROM fee_structure LIKE 'custom_frequency'");
            if ($stmt->rowCount() === 0) {
                // Column doesn't exist, add it
                $this->pdo->exec("
                    ALTER TABLE fee_structure
                    ADD COLUMN custom_frequency INT DEFAULT NULL
                    AFTER frequency
                ");
                $this->logError('Added missing custom_frequency column to fee_structure table');
            }
        } catch (PDOException $e) {
            $this->logError('Failed to check or add custom_frequency column: ' . $e->getMessage());
            $this->sendError(500, 'Failed to initialize database schema');
        }
    }

    // Validate input data
    private function validateInput(array $data, bool $isUpdate = false): array {
        $this->logError('Validating input: ' . json_encode($data));
        $errors = [];
        $validData = [];

        // Define validation rules
        $fields = [
            'particular_id' => ['type' => 'int', 'required' => true],
            'class_id' => ['type' => 'int', 'required' => true],
            'amount' => ['type' => 'float', 'required' => true, 'min' => 0],
            'applicable_months' => ['type' => 'string', 'required' => true],
            'frequency' => ['type' => 'string', 'enum' => ['monthly', 'annual', 'other'], 'required' => true],
            'custom_frequency' => ['type' => 'int', 'required' => false, 'min' => 1],
            'status' => ['type' => 'string', 'enum' => ['active', 'inactive'], 'required' => true],
        ];

        // Validate id for updates
        if ($isUpdate) {
            if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT) || $data['id'] <= 0) {
                $errors[] = "id must be a valid integer";
            } else {
                $validData['id'] = (int)$data['id'];
            }
        }

        // Validate other fields
        foreach ($fields as $field => $rules) {
            if (array_key_exists($field, $data)) {
                $value = $data[$field];

                // Handle NULL or empty strings for optional fields
                if ($value === '' && !$rules['required']) {
                    $value = null;
                }

                // Type checking
                if ($value !== null) {
                    switch ($rules['type']) {
                        case 'int':
                            if (!filter_var($value, FILTER_VALIDATE_INT) || $value < ($rules['min'] ?? 0)) {
                                $errors[] = "$field must be a positive integer" . (isset($rules['min']) ? " greater than or equal to {$rules['min']}" : "");
                            } else {
                                $value = (int)$value;
                            }
                            break;
                        case 'float':
                            if (!is_numeric($value) || $value < $rules['min']) {
                                $errors[] = "$field must be a number greater than or equal to {$rules['min']}";
                            } else {
                                $value = (float)$value;
                            }
                            break;
                        case 'string':
                            if (!is_string($value)) {
                                $errors[] = "$field must be a string";
                            }
                            break;
                    }

                    // Enum validation
                    if (isset($rules['enum']) && !in_array($value, $rules['enum'], true)) {
                        $errors[] = "$field must be one of: " . implode(', ', $rules['enum']);
                    }

                    // Validate applicable_months
                    if ($field === 'applicable_months') {
                        if ($value !== 'all') {
                            $months = explode(',', $value);
                            foreach ($months as $month) {
                                if (!filter_var($month, FILTER_VALIDATE_INT) || $month < 1 || $month > 12) {
                                    $errors[] = "applicable_months must contain valid month numbers (1-12) or 'all'";
                                    break;
                                }
                            }
                        }
                        // If frequency is annual, applicable_months should be 'all'
                        if (isset($data['frequency']) && $data['frequency'] === 'annual' && $value !== 'all') {
                            $errors[] = "applicable_months must be 'all' for annual fees";
                        }
                        // For 'other', applicable_months can be anything (no restriction)
                    }

                    // Validate custom_frequency
                    if ($field === 'custom_frequency' && isset($data['frequency']) && $data['frequency'] === 'other') {
                        if ($value === null || $value < 1) {
                            $errors[] = "custom_frequency must be a positive integer when frequency is 'other'";
                        }
                    }

                    $validData[$field] = $value;
                } elseif ($rules['required']) {
                    $errors[] = "$field is required";
                }
            } elseif ($rules['required']) {
                $errors[] = "$field is required";
            }
        }

        // Ensure custom_frequency is null if frequency is not 'other'
        if (isset($validData['frequency']) && $validData['frequency'] !== 'other') {
            $validData['custom_frequency'] = null;
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        $this->logError('Validated data: ' . json_encode($validData));
        return $validData;
    }

    // Send JSON error response
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    // Send JSON success response
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Handle GET request
    public function get($request) {
        if (isset($request['id'])) {
            $id = filter_var($request['id'], FILTER_VALIDATE_INT);
            if (!$id) {
                $this->sendError(400, 'Invalid ID');
            }

            $stmt = $this->pdo->prepare("
                SELECT fs.id, fs.particular_id, fs.class_id, fs.amount, fs.applicable_months, fs.frequency, fs.custom_frequency, fs.status, fs.updated_on,
                       p.particular AS particular_name, c.class_name
                FROM fee_structure fs
                LEFT JOIN particulars p ON fs.particular_id = p.id
                LEFT JOIN class c ON fs.class_id = c.id
                WHERE fs.id = ?
            ");
            $stmt->execute([$id]);
            $entry = $stmt->fetch();

            if ($entry) {
                $this->sendSuccess(200, ['data' => [$entry]]);
            } else {
                $this->sendError(404, 'Fee structure not found');
            }
        } else {
            // Pagination parameters
            $page = isset($request['page']) ? max(1, filter_var($request['page'], FILTER_VALIDATE_INT)) : 1;
            $perPage = isset($request['perPage']) ? max(1, filter_var($request['perPage'], FILTER_VALIDATE_INT)) : 10;
            $offset = ($page - 1) * $perPage;

            // Get total count for pagination
            $stmt = $this->pdo->query("SELECT COUNT(*) FROM fee_structure");
            $totalItems = $stmt->fetchColumn();
            $totalPages = max(1, ceil($totalItems / $perPage));

            // Fetch paginated data with joins
            $stmt = $this->pdo->prepare("
                SELECT fs.id, fs.particular_id, fs.class_id, fs.amount, fs.applicable_months, fs.frequency, fs.custom_frequency, fs.status, fs.updated_on,
                       p.particular AS particular_name, c.class_name
                FROM fee_structure fs
                LEFT JOIN particulars p ON fs.particular_id = p.id
                LEFT JOIN class c ON fs.class_id = c.id
                ORDER BY fs.updated_on DESC
                LIMIT ? OFFSET ?
            ");
            $stmt->execute([$perPage, $offset]);
            $entries = $stmt->fetchAll();

            $this->sendSuccess(200, [
                'data' => $entries,
                'meta' => [
                    'page' => $page,
                    'perPage' => $perPage,
                    'totalPages' => $totalPages,
                    'totalItems' => $totalItems
                ]
            ]);
        }
    }

    // Handle POST request (for adding and updating with _method=PUT)
    public function post() {
        // Check for _method field to determine if this is an update
        $method = isset($_POST['_method']) ? strtoupper($_POST['_method']) : 'POST';
        $data = $_POST;

        if ($method === 'PUT') {
            // Update operation
            $data['id'] = isset($data['id']) ? $data['id'] : null;
            $validData = $this->validateInput($data, true);

            $fields = array_keys($validData);
            $updateFields = [];
            $values = [];
            foreach ($fields as $field) {
                if ($field !== 'id') {
                    $updateFields[] = "$field = ?";
                    $values[] = $validData[$field];
                }
            }
            $values[] = $validData['id'];

            $sql = "UPDATE fee_structure SET " . implode(', ', $updateFields) . ", updated_on = NOW() WHERE id = ?";
            $this->logError('SQL Query: ' . $sql);
            $this->logError('SQL Values: ' . json_encode($values));

            try {
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute($values);
                if ($stmt->rowCount() === 0) {
                    $this->logError('No rows updated. Data may be unchanged or ID not found.');
                }
                $this->sendSuccess(200, ['message' => 'Fee structure updated']);
            } catch (PDOException $e) {
                $this->logError('Update failed: ' . $e->getMessage());
                $this->sendError(500, 'Failed to update fee structure: ' . $e->getMessage());
            }
        } else {
            // Add operation
            $validData = $this->validateInput($data);

            $fields = array_keys($validData);
            $placeholders = array_fill(0, count($fields), '?');
            $sql = "INSERT INTO fee_structure (" . implode(', ', $fields) . ", updated_on) VALUES (" . implode(', ', $placeholders) . ", NOW())";
            $this->logError('SQL Query: ' . $sql);
            $this->logError('SQL Values: ' . json_encode(array_values($validData)));

            try {
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute(array_values($validData));
                $this->sendSuccess(201, ['message' => 'Fee structure added']);
            } catch (PDOException $e) {
                $this->logError('Insert failed: ' . $e->getMessage());
                $this->sendError(500, 'Failed to add fee structure: ' . $e->getMessage());
            }
        }
    }

    // Handle DELETE request
    public function delete() {
        $input = json_decode(file_get_contents('php://input'), true);
        $this->logError('DELETE input: ' . json_encode($input));

        if (!isset($input['ids']) || !is_array($input['ids']) || empty($input['ids'])) {
            $this->sendError(400, 'Invalid or missing IDs');
        }

        $ids = array_map('intval', $input['ids']);
        $placeholders = array_fill(0, count($ids), '?');
        $sql = "DELETE FROM fee_structure WHERE id IN (" . implode(',', $placeholders) . ")";
        $this->logError('SQL Query: ' . $sql);
        $this->logError('SQL Values: ' . json_encode($ids));

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($ids);
            $this->sendSuccess(200, ['message' => 'Fee structure(s) deleted']);
        } catch (PDOException $e) {
            $this->logError('Delete failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to delete fee structure(s): ' . $e->getMessage());
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];

        switch ($method) {
            case 'GET':
                $this->get($_GET);
                break;
            case 'POST':
                $this->post();
                break;
            case 'DELETE':
                $this->delete();
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new FeeStructureController();
$controller->handleRequest();
?>