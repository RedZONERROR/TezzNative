<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Enable error logging for production debugging
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', $_SERVER['DOCUMENT_ROOT'] . '/logs/error.log');

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class TransportMaster {
    private $pdo;
    private $months = [
        1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June',
        7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
    ];

    public function __construct() {
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Database connection failed');
            exit();
        }
    }

    /**
     * Calculate the academic session based on the date.
     * Session starts in April and ends in March next year.
     * @param string $date Date in YYYY-MM-DD format
     * @return string Session in YYYY-YYYY format (e.g., "2025-2026")
     */
    private function calculateSession($date) {
        $dateTime = DateTime::createFromFormat('Y-m-d', $date);
        if (!$dateTime) {
            error_log("Invalid date format for session calculation: $date");
            return null;
        }
        $year = (int)$dateTime->format('Y');
        $month = (int)$dateTime->format('m');
        // If month is April or later, session is current year to next year
        if ($month >= 4) {
            $session = "$year-" . ($year + 1);
        } else {
            // Otherwise, session is previous year to current year
            $session = ($year - 1) . "-$year";
        }
        error_log("Calculated session for date $date: $session");
        return $session;
    }

    /**
     * Get the academic session for a student.
     * @param int $student_id
     * @param string $payment_date
     * @param string|null $override_session Optional session override
     * @return string|null Session in YYYY-YYYY format
     */
    private function getStudentSession($student_id, $payment_date, $override_session = null) {
        // If session is provided in the request, validate and use it
        if ($override_session !== null) {
            if (!preg_match('/^\d{4}-\d{4}$/', $override_session)) {
                error_log("Invalid session format provided: $override_session");
                return null; // Invalid session format
            }
            $years = explode('-', $override_session);
            if ((int)$years[1] !== (int)$years[0] + 1) {
                error_log("Invalid session range provided: $override_session");
                return null; // Invalid session (e.g., "2025-2027" is invalid)
            }
            error_log("Using overridden session for student_id $student_id: $override_session");
            return $override_session;
        }

        try {
            // Check if students table has a session column
            $stmt = $this->pdo->prepare("SHOW COLUMNS FROM students LIKE 'session'");
            $stmt->execute();
            $hasSessionColumn = $stmt->rowCount() > 0;

            if ($hasSessionColumn) {
                // Fetch session from students table
                $stmt = $this->pdo->prepare("SELECT session FROM students WHERE id = ?");
                $stmt->execute([$student_id]);
                $student = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($student && !empty($student['session'])) {
                    error_log("Fetched session from students table for student_id $student_id: {$student['session']}");
                    return $student['session'];
                }
            }

            // Fallback to calculating session based on payment date
            $calculated_session = $this->calculateSession($payment_date);
            error_log("Using calculated session for student_id $student_id based on payment_date $payment_date: $calculated_session");
            return $calculated_session;
        } catch (PDOException $e) {
            error_log("Failed to fetch student session for student_id $student_id: " . $e->getMessage());
            return $this->calculateSession($payment_date);
        }
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];

        switch ($method) {
            case 'GET':
                $this->handleGet();
                break;
            case 'POST':
                $this->handlePost();
                break;
            case 'DELETE':
                $this->handleDelete();
                break;
            default:
                $this->sendResponse(405, 'error', 'Method not allowed');
                break;
        }
    }

    private function handleGet() {
        if (isset($_GET['personal_class'])) {
            $class_id = filter_var($_GET['personal_class'], FILTER_VALIDATE_INT);
            if ($class_id === false || $class_id <= 0) {
                $this->sendResponse(400, 'error', 'Invalid class ID');
                return;
            }
            $this->getStudentsByClass($class_id);
            return;
        }
        
        if (!isset($_GET['student_id'])) {
            $this->sendResponse(400, 'error', 'Student ID is required');
            return;
        }

        $student_id = filter_var($_GET['student_id'], FILTER_VALIDATE_INT);
        if ($student_id === false || $student_id <= 0) {
            $this->sendResponse(400, 'error', 'Invalid student ID');
            return;
        }

        $fetch_history = isset($_GET['history']) && $_GET['history'] === 'true';

        if ($fetch_history) {
            $this->getPaymentHistory($student_id);
        } else {
            $this->getApplicableFees($student_id);
        }
    }

    private function getApplicableFees($student_id) {
        try {
            // Get student's class
            $stmt = $this->pdo->prepare("SELECT class FROM students WHERE id = ? AND status = 'active' AND transport = 1");
            $stmt->execute([$student_id]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$student) {
                $this->sendResponse(404, 'error', 'Student not found, inactive, or not opted for transport');
                return;
            }

            $class_id = $student['class'];

            // Determine current session (as of today: 2025-06-04)
            $current_date = date('Y-m-d'); // Hardcoded for consistency with the given date
            $current_session = $this->calculateSession($current_date);
            if (!$current_session) {
                $this->sendResponse(500, 'error', 'Unable to determine current session');
                return;
            }

            // Fetch applicable fee structures for transport, ensuring one record per particular
            $stmt = $this->pdo->prepare("
                SELECT fs.id, fs.particular_id, p.particular, fs.amount, fs.applicable_months, fs.frequency, fs.custom_frequency
                FROM fee_structure fs
                JOIN particulars p ON fs.particular_id = p.id
                JOIN (
                    SELECT particular_id, MAX(id) as max_id
                    FROM fee_structure
                    WHERE class_id = ? AND status = 'active'
                    GROUP BY particular_id
                ) latest ON fs.id = latest.max_id
                WHERE fs.class_id = ? AND fs.status = 'active' AND p.particular = 'Transport Fee'
            ");
            $stmt->execute([$class_id, $class_id]);
            $fees = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (empty($fees)) {
                $this->sendResponse(200, 'success', 'No applicable transport fees found', []);
                return;
            }

            // Log the fetched fees for debugging
            error_log("Fetched transport fees for student_id $student_id: " . json_encode(array_map(function($fee) {
                return ['id' => $fee['id'], 'particular' => $fee['particular']];
            }, $fees)));

            // Fetch all payments for the student
            $stmt = $this->pdo->prepare("
                SELECT fee_structure_id, payment_month, amount_collected, discount, remaining_balance, session
                FROM fee_collections
                WHERE student_id = ? AND status = 'completed'
            ");
            $stmt->execute([$student_id]);
            $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Group payments by fee_structure_id and session
            $paid_info_by_fee_and_session = [];
            foreach ($payments as $payment) {
                $fee_id = $payment['fee_structure_id'];
                $session = $payment['session'];
                if (!isset($paid_info_by_fee_and_session[$fee_id])) {
                    $paid_info_by_fee_and_session[$fee_id] = [];
                }
                if (!isset($paid_info_by_fee_and_session[$fee_id][$session])) {
                    $paid_info_by_fee_and_session[$fee_id][$session] = [
                        'collections' => [],
                        'total_amount' => 0,
                        'total_discount' => 0,
                        'remaining_balance' => 0,
                        'payment_months' => []
                    ];
                }
                $collections = array_map('intval', explode(',', $payment['payment_month']));
                $paid_info_by_fee_and_session[$fee_id][$session]['collections'] = array_unique(array_merge(
                    $paid_info_by_fee_and_session[$fee_id][$session]['collections'],
                    $collections
                ));
                $paid_info_by_fee_and_session[$fee_id][$session]['payment_months'][] = $payment['payment_month'];
                $paid_info_by_fee_and_session[$fee_id][$session]['total_amount'] += (float)$payment['amount_collected'];
                $paid_info_by_fee_and_session[$fee_id][$session]['total_discount'] += (float)$payment['discount'];
                $paid_info_by_fee_and_session[$fee_id][$session]['remaining_balance'] += (float)$payment['remaining_balance'];
            }

            // Log the grouped payments for debugging
            error_log("Grouped payments for student_id $student_id: " . json_encode($paid_info_by_fee_and_session));

            // Calculate pending collections/months and fully paid status for each fee
            $filtered_fees = [];
            $processed_fee_ids = []; // Track processed fee IDs to prevent duplicates
            foreach ($fees as $fee) {
                $fee_id = $fee['id'];

                // Skip if this fee ID has already been processed
                if (in_array($fee_id, $processed_fee_ids)) {
                    error_log("Skipping duplicate fee_structure_id $fee_id for student_id $student_id");
                    continue;
                }
                $processed_fee_ids[] = $fee_id;

                $applicable_months = $fee['applicable_months'] === 'all' 
                    ? range(1, 12) 
                    : array_map('intval', explode(',', $fee['applicable_months']));
                $paid_info = isset($paid_info_by_fee_and_session[$fee_id][$current_session]) 
                    ? $paid_info_by_fee_and_session[$fee_id][$current_session] 
                    : [
                        'collections' => [],
                        'total_amount' => 0,
                        'total_discount' => 0,
                        'remaining_balance' => 0,
                        'payment_months' => []
                    ];
                $paid_collections = $paid_info['collections'];
                $total_paid_amount = $paid_info['total_amount'];
                $total_discount = $paid_info['total_discount'];
                $remaining_balance = $paid_info['remaining_balance'];
                $fee_amount = (float)$fee['amount'];

                if ($fee['frequency'] === 'annual') {
                    // For annual fees, calculate expected amount after discount
                    $expected_amount = $fee_amount - $total_discount;
                    $is_fully_paid = $total_paid_amount >= $expected_amount - 0.01;
                    $fee['is_fully_paid'] = $is_fully_paid;
                    $fee['pending_months'] = $is_fully_paid ? [] : $applicable_months;
                    $fee['remaining_balance'] = $is_fully_paid ? 0 : max(0, $expected_amount - $total_paid_amount);

                    // Skip if fully paid for the current session
                    if ($is_fully_paid) {
                        error_log("Fee $fee_id (annual) is fully paid for session $current_session, skipping");
                        continue;
                    }
                } elseif ($fee['frequency'] === 'other') {
                    // For 'other' frequency, calculate maximum collections per year
                    $custom_frequency = (int)$fee['custom_frequency'];
                    if ($custom_frequency <= 0) $custom_frequency = 1; // Fallback to prevent division by zero
                    $max_collections_per_year = floor(12 / $custom_frequency); // e.g., every 3 months = 4 collections
                    $total_expected = $fee_amount * $max_collections_per_year;
                    $adjusted_expected = $total_expected - $total_discount;
                    $per_collection_expected = $fee_amount;

                    // Calculate how many collections have been paid
                    $paid_collection_count = count($paid_collections);
                    $pending_collection_count = max(0, $max_collections_per_year - $paid_collection_count);
                    $is_fully_paid = $pending_collection_count === 0;

                    $fee['pending_months'] = []; // For 'other', we don't track specific months
                    $fee['pending_collections'] = $pending_collection_count;
                    $fee['is_fully_paid'] = $is_fully_paid;
                    $fee['remaining_balance'] = $is_fully_paid ? 0 : max(0, ($pending_collection_count * $per_collection_expected) - $remaining_balance);

                    // Skip if fully paid for the current session
                    if ($is_fully_paid) {
                        error_log("Fee $fee_id (other) is fully paid for session $current_session, skipping");
                        continue;
                    }
                } else { // monthly
                    // For monthly fees, calculate per-month amount after discount
                    $total_months = count($applicable_months);
                    $total_expected = $fee_amount * $total_months;
                    $adjusted_expected = $total_expected - $total_discount;
                    $per_month_expected = $total_expected / $total_months; // Original per-month amount
                    $pending_months = array_diff($applicable_months, $paid_collections);
                    $is_fully_paid = empty($pending_months);

                    $fee['pending_months'] = array_values($pending_months);
                    $fee['pending_collections'] = count($pending_months);
                    $fee['is_fully_paid'] = $is_fully_paid;
                    $fee['remaining_balance'] = $remaining_balance; // Sum of remaining balances for unpaid months

                    // Skip if fully paid for the current session
                    if ($is_fully_paid) {
                        error_log("Fee $fee_id (monthly) is fully paid for session $current_session, skipping");
                        continue;
                    }
                }

                // Add to filtered fees if not fully paid for the current session
                $filtered_fees[] = $fee;
            }

            // Log the final filtered fees for debugging
            error_log("Filtered fees for student_id $student_id: " . json_encode(array_map(function($fee) {
                return ['id' => $fee['id'], 'particular' => $fee['particular'], 'is_fully_paid' => $fee['is_fully_paid']];
            }, $filtered_fees)));

            if (empty($filtered_fees)) {
                $this->sendResponse(200, 'success', "No pending fees found for the current session ($current_session)", []);
                return;
            }

            $this->sendResponse(200, 'success', "Applicable fees fetched successfully for session $current_session", $filtered_fees);
        } catch (PDOException $e) {
            error_log("Failed to fetch fees: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch fees');
        }
    }

    private function getPaymentHistory($student_id) {
        try {
            // Validate site_settings table has exactly one row
            $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM site_settings");
            $stmt->execute();
            $settingsCount = $stmt->fetchColumn();

            if ($settingsCount === 0) {
                error_log("site_settings table is empty");
                $this->sendResponse(500, 'error', 'School settings not configured');
                return;
            } elseif ($settingsCount > 1) {
                error_log("site_settings table has multiple rows: $settingsCount");
                $this->sendResponse(500, 'error', 'Multiple school settings found; expected exactly one');
                return;
            }

            // Fetch payment history along with school details and session, filtered for transport fee
            $stmt = $this->pdo->prepare("
                SELECT fc.id, fc.amount_collected, fc.discount, fc.remarks, fc.remaining_balance, 
                       fc.payment_month, fc.payment_date, fc.payment_method, fc.status, fc.created_on, 
                       fc.session,
                       fs.particular_id, p.particular, fs.amount AS fee_amount, fs.frequency, fs.custom_frequency,
                       s.full_name AS student_name, s.father_name, c.class_name,
                       ss.school_name, ss.logo, ss.address, ss.phone
                FROM fee_collections fc
                JOIN fee_structure fs ON fc.fee_structure_id = fs.id
                JOIN particulars p ON fs.particular_id = p.id
                JOIN students s ON fc.student_id = s.id
                JOIN class c ON s.class = c.id
                CROSS JOIN site_settings ss
                WHERE fc.student_id = ? AND fc.status = 'completed' AND p.particular = 'Transport Fee'
                ORDER BY fc.payment_date DESC
            ");
            $stmt->execute([$student_id]);
            $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (empty($history)) {
                $this->sendResponse(200, 'success', 'No payment history found', []);
                return;
            }

            // For each record, show all paid months as names (comma-separated)
            foreach ($history as &$record) {
                $months_arr = array_map('intval', explode(',', $record['payment_month']));
                $month_names = array_map(function($m) { return $this->months[$m]; }, $months_arr);
                $record['payment_month_name'] = implode(', ', $month_names);
                $record['frequency_display'] = $record['frequency'] === 'other' 
                    ? "Every {$record['custom_frequency']} Month" . ($record['custom_frequency'] > 1 ? 's' : '')
                    : ucfirst($record['frequency']);
            }

            $this->sendResponse(200, 'success', 'Payment history fetched successfully', $history);
        } catch (PDOException $e) {
            error_log("Failed to fetch payment history for student_id $student_id: " . $e->getMessage());
            $this->sendResponse(500, 'error', "Failed to fetch payment history: " . $e->getMessage());
        }
    }

    private function handlePost() {
        $input = json_decode(file_get_contents('php://input'), true);

        if (!$input) {
            $input = $_POST;
        }

        $required_fields = ['student_id', 'fee_structure_id', 'amount_collected', 'payment_month', 'payment_date', 'payment_method'];
        foreach ($required_fields as $field) {
            if (!isset($input[$field]) || (is_string($input[$field]) && trim($input[$field]) === '')) {
                $this->sendResponse(400, 'error', "Missing or empty required field: $field");
                return;
            }
        }

        $student_id = filter_var($input['student_id'], FILTER_VALIDATE_INT);
        $fee_structure_id = filter_var($input['fee_structure_id'], FILTER_VALIDATE_INT);
        $amount_collected = filter_var($input['amount_collected'], FILTER_VALIDATE_FLOAT);
        $discount = isset($input['discount']) ? filter_var($input['discount'], FILTER_VALIDATE_FLOAT) : 0.00;
        $remarks = isset($input['remarks']) ? trim($input['remarks']) : null;
        $payment_month = $input['payment_month'];
        $payment_date = $input['payment_date'];
        $payment_method = $input['payment_method'];
        $override_session = isset($input['session']) ? trim($input['session']) : null;
        $collections_count = isset($input['collections_count']) ? filter_var($input['collections_count'], FILTER_VALIDATE_INT) : 1;

        // Validate inputs
        if ($student_id === false || $student_id <= 0) {
            $this->sendResponse(400, 'error', 'Invalid student ID');
            return;
        }
        if ($fee_structure_id === false || $fee_structure_id <= 0) {
            $this->sendResponse(400, 'error', 'Invalid fee structure ID');
            return;
        }
        if ($amount_collected === false || $amount_collected < 0) {
            $this->sendResponse(400, 'error', 'Invalid amount collected');
            return;
        }
        if ($discount === false || $discount < 0) {
            $this->sendResponse(400, 'error', 'Invalid discount amount');
            return;
        }
        if ($collections_count === false || $collections_count <= 0) {
            $this->sendResponse(400, 'error', 'Invalid collections count');
            return;
        }

        // Handle payment_month as array or single value and validate
        if (empty($payment_month)) {
            $this->sendResponse(400, 'error', 'Please select at least one payment month');
            return;
        }
        if (!is_array($payment_month)) {
            $payment_month = [strval($payment_month)]; // Convert single value to array for consistency
        }
        $payment_month = array_map('intval', $payment_month);
        $payment_month = array_filter($payment_month); // Remove empty or zero values
        if (empty($payment_month)) {
            $this->sendResponse(400, 'error', 'Please select at least one valid payment month');
            return;
        }
        foreach ($payment_month as $month) {
            if ($month < 1 || $month > 12) {
                $this->sendResponse(400, 'error', "Invalid payment month: $month");
                return;
            }
        }
        // Update payment method validation to match frontend options
        if (!in_array($payment_method, ['cash', 'online', 'cheque', 'card'])) {
            $this->sendResponse(400, 'error', 'Invalid payment method');
            return;
        }
        if (!DateTime::createFromFormat('Y-m-d', $payment_date)) {
            $this->sendResponse(400, 'error', 'Invalid payment date format (use YYYY-MM-DD)');
            return;
        }

        // Get the academic session
        $session = $this->getStudentSession($student_id, $payment_date, $override_session);
        if (!$session) {
            $this->sendResponse(400, 'error', 'Unable to determine or invalid academic session');
            return;
        }

        try {
            // Fetch student's UID
            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE id = ?");
            $stmt->execute([$student_id]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$student || empty($student['uid'])) {
                $this->sendResponse(404, 'error', 'Student UID not found');
                return;
            }
            $student_uid = $student['uid'];

            // Check if the fee structure applies to the student's class and is for transport
            $stmt = $this->pdo->prepare("
                SELECT fs.id, fs.amount, fs.applicable_months, fs.frequency, fs.custom_frequency, p.particular
                FROM fee_structure fs
                JOIN students s ON s.class = fs.class_id
                JOIN particulars p ON fs.particular_id = p.id
                WHERE s.id = ? AND fs.id = ? AND p.particular = 'Transport Fee'
            ");
            $stmt->execute([$student_id, $fee_structure_id]);
            $fee_structure = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$fee_structure) {
                $this->sendResponse(400, 'error', 'Fee structure does not apply to this student or is not a transport fee');
                return;
            }

            // Fetch existing payments to calculate remaining balance and check for duplicates
            $stmt = $this->pdo->prepare("
                SELECT id, payment_month, amount_collected, discount, session
                FROM fee_collections
                WHERE student_id = ? AND fee_structure_id = ? AND status = 'completed'
            ");
            $stmt->execute([$student_id, $fee_structure_id]);
            $existing = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $already_paid_collections_by_session = [];
            $total_paid_by_session = [];
            $total_discount_by_session = [];
            foreach ($existing as $payment) {
                $existing_session = $payment['session'];
                if (!isset($already_paid_collections_by_session[$existing_session])) {
                    $already_paid_collections_by_session[$existing_session] = [];
                    $total_paid_by_session[$existing_session] = 0;
                    $total_discount_by_session[$existing_session] = 0;
                }
                $collections = array_map('intval', explode(',', $payment['payment_month']));
                $already_paid_collections_by_session[$existing_session] = array_merge(
                    $already_paid_collections_by_session[$existing_session],
                    $collections
                );
                $total_paid_by_session[$existing_session] += (float)$payment['amount_collected'];
                $total_discount_by_session[$existing_session] += (float)$payment['discount'];
            }

            // Get collections and totals for the current session
            $already_paid_collections = isset($already_paid_collections_by_session[$session])
                ? array_unique($already_paid_collections_by_session[$session])
                : [];
            $total_paid_amount = isset($total_paid_by_session[$session])
                ? $total_paid_by_session[$session]
                : 0;
            $total_discount = isset($total_discount_by_session[$session])
                ? $total_discount_by_session[$session]
                : 0;
            $total_discount += $discount; // Include current discount

            $applicable_months = $fee_structure['applicable_months'] === 'all' 
                ? range(1, 12) 
                : array_map('intval', explode(',', $fee_structure['applicable_months']));
            $fee_amount = (float)$fee_structure['amount'];

            $remaining_balance = 0;

            if ($fee_structure['frequency'] === 'annual') {
                // Check for duplicate payment for annual fees in the same session
                if (!empty($already_paid_collections)) {
                    $this->sendResponse(400, 'error', "A payment for this annual fee structure in session $session has already been collected");
                    return;
                }

                // For annual fees, calculate total expected amount after discount
                $expected_amount = $fee_amount - $total_discount;
                if ($total_paid_amount >= $expected_amount - 0.01) {
                    $this->sendResponse(400, 'error', 'This annual fee is already fully paid for this session');
                    return;
                }
                if (count($payment_month) > 1) {
                    $this->sendResponse(400, 'error', 'Annual fees can only be paid for one month marker');
                    return;
                }
                if (in_array($payment_month[0], $already_paid_collections)) {
                    $this->sendResponse(400, 'error', 'A payment for this annual fee has already been recorded with the selected month marker in this session');
                    return;
                }
                // Calculate remaining balance for annual fee
                $current_expected = $fee_amount - $discount;
                $remaining_balance = max(0, $current_expected - $amount_collected);
            } elseif ($fee_structure['frequency'] === 'other') {
                // For 'other' frequency, calculate maximum collections per year
                $custom_frequency = (int)$fee_structure['custom_frequency'];
                if ($custom_frequency <= 0) $custom_frequency = 1; // Fallback
                $max_collections_per_year = floor(12 / $custom_frequency); // e.g., every 3 months = 4 collections
                $total_expected = $fee_amount * $max_collections_per_year;
                $adjusted_expected = $total_expected - $total_discount;
                $per_collection_amount = $fee_amount;

                // Calculate pending collections
                $paid_collection_count = count($already_paid_collections);
                $pending_collection_count = max(0, $max_collections_per_year - $paid_collection_count);
                $collections_to_pay = min($collections_count, $pending_collection_count);

                if ($collections_to_pay <= 0) {
                    $this->sendResponse(400, 'error', 'No pending collections available for this fee in this session');
                    return;
                }

                // For 'other' frequency, restrict to one collection per month marker
                if (count($payment_month) > 1) {
                    $this->sendResponse(400, 'error', 'Only one month marker is allowed for "other" frequency');
                    return;
                }

                // Check if the selected month has already been used for a collection
                if (in_array($payment_month[0], $already_paid_collections)) {
                    $this->sendResponse(400, 'error', 'A collection for this month marker has already been recorded in this session');
                    return;
                }

                $total_expected_for_payment = $per_collection_amount * $collections_to_pay - $discount;
                if ($amount_collected > $total_expected_for_payment + 0.01) {
                    $this->sendResponse(400, 'error', "Amount collected (₹$amount_collected) exceeds expected expected amount (₹$total_expected_for_payment) for $collections_to_pay collection(s)");
                    return;
                }

                $remaining_balance = max(0, $total_expected_for_payment - $amount_collected);
                // Since 'other' frequency doesn't tie to specific months, we'll use the provided month as a marker
                $payment_month = array_fill(0, $collections_to_pay, $payment_month[0]);
            } else { // monthly
                // For monthly fees, allow payment for any unpaid months in the session
                $pending_months = array_diff($applicable_months, $already_paid_collections);
                $to_pay = array_intersect($payment_month, $pending_months);
                if (empty($to_pay)) {
                    $unavailable_months = array_diff($payment_month, $pending_months);
                    $month_names = implode(', ', array_map(function($m) { return $this->months[$m]; }, $unavailable_months));
                    $error_msg = "No pending months available to pay. The following months are already paid or not applicable: $month_names.";
                    $this->sendResponse(400, 'error', $error_msg);
                    return;
                }
                $payment_month = $to_pay;
                $months_count = count($to_pay);
                $per_month_amount = $fee_amount;
                $total_expected = $per_month_amount * $months_count - $discount;
                if ($amount_collected > $total_expected + 0.01) {
                    $this->sendResponse(400, 'error', "Amount collected (₹$amount_collected) exceeds expected amount (₹$total_expected) for $months_count month(s)");
                    return;
                }
                $remaining_balance = max(0, $total_expected - $amount_collected); // Fixed syntax error
            }

            // Start a transaction to ensure data consistency
            $this->pdo->beginTransaction();

            try {
                // Insert the payment record with session
                $months_str = implode(',', $payment_month);
                $stmt = $this->pdo->prepare("
                    INSERT INTO fee_collections (
                        student_id, fee_structure_id, amount_collected, discount, remarks, 
                        remaining_balance, payment_month, payment_date, payment_method, status, 
                        created_on, session
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed', NOW(), ?)
                ");
                $stmt->execute([
                    $student_id, $fee_structure_id, $amount_collected, $discount, $remarks,
                    $remaining_balance, $months_str, $payment_date, $payment_method, $session
                ]);

                // Get the inserted payment ID
                $payment_id = $this->pdo->lastInsertId();

                // Insert into notification_queue using student's UID
                $receipt_link = "/receipts/fee_receipt_{$payment_id}.pdf";
                $month_names = implode(', ', array_map(function($m) { return $this->months[$m]; }, $payment_month));
                $description = "Payment of ₹{$amount_collected} for {$fee_structure['particular']} (Months: {$month_names}, Session: {$session}) on {$payment_date}.";
                if ($discount > 0) {
                    $description .= " Discount applied: ₹{$discount}.";
                }
                if ($remaining_balance > 0) {
                    $description .= " Remaining balance: ₹{$remaining_balance}.";
                }

                $stmt = $this->pdo->prepare("
                    INSERT INTO notification_queue (
                        uid, title, description, doc_link, notification_type, is_sticky, created_at, sent_at, status
                    )
                    VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW(), ?)
                ");
                $stmt->execute([
                    $student_uid,
                    'Transport Fee Payment Receipt',
                    $description,
                    $receipt_link,
                    'normal',
                    0,
                    'pending'
                ]);

                // Commit the transaction
                $this->pdo->commit();

                // Prepare success message
                $msg = 'Transport fee collected successfully';
                if ($fee_structure['frequency'] === 'annual') {
                    $msg .= ' for annual fee';
                    if ($remaining_balance > 0) {
                        $msg .= ". Remaining balance: ₹" . number_format($remaining_balance, 2);
                    }
                } elseif ($fee_structure['frequency'] === 'other') {
                    $collections_count = count($payment_month);
                    $msg .= " for $collections_count collection(s)";
                    if ($remaining_balance > 0) {
                        $msg .= ". Remaining balance: ₹" . number_format($remaining_balance, 2);
                    }
                } else {
                    $months_count = count($payment_month);
                    $msg .= " for $months_count month(s)";
                    if ($remaining_balance > 0) {
                        $msg .= ". Remaining balance: ₹" . number_format($remaining_balance, 2);
                    }
                    if (count($to_pay) < count($input['payment_month'])) {
                        $msg .= '. Some months were already paid.';
                    }
                }
                if ($discount > 0) {
                    $msg .= " (Discount applied: ₹" . number_format($discount, 2) . ")";
                }
                $msg .= " for session $session";
                $this->sendResponse(200, 'success', $msg);
            } catch (PDOException $e) {
                // Rollback the transaction on error
                $this->pdo->rollBack();
                error_log("Failed to collect fee or insert notification: " . $e->getMessage());
                $this->sendResponse(500, 'error', 'Failed to collect fee or send notification');
            }
        } catch (PDOException $e) {
            error_log("Failed to collect fee: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to collect fee');
        }
    }

    private function handleDelete() {
        if (!isset($_GET['payment_id']) || !is_numeric($_GET['payment_id'])) {
            $this->sendResponse(400, 'error', 'Invalid or missing payment ID');
            return;
        }
    
        $id = filter_var($_GET['payment_id'], FILTER_VALIDATE_INT);
        if ($id === false || $id <= 0) {
            $this->sendResponse(400, 'error', 'Invalid payment ID');
            return;
        }
    
        try {
            $stmt = $this->pdo->prepare("DELETE FROM fee_collections WHERE id = ?");
            $stmt->execute([$id]);
    
            if ($stmt->rowCount() > 0) {
                $this->sendResponse(200, 'success', 'Payment record deleted successfully');
            } else {
                $this->sendResponse(404, 'error', 'Payment record not found');
            }
        } catch (PDOException $e) {
            error_log("Failed to delete payment record: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to delete payment record');
        }
    }

    private function getStudentsByClass($class_id) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT DISTINCT id, full_name, father_name
                FROM students
                WHERE class = ? AND status = 'active' AND transport = 1
                ORDER BY full_name ASC
            ");
            $stmt->execute([$class_id]);
            $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (empty($students)) {
                $this->sendResponse(404, 'error', 'No students opted for transport in this class');
                return;
            }

            $this->sendResponse(200, 'success', 'Students fetched successfully', $students);
        } catch (PDOException $e) {
            error_log("Failed to fetch students: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch students');
        }
    }

    private function sendResponse($statusCode, $status, $message, $data = null) {
        http_response_code($statusCode);
        $response = ['status' => $status, 'message' => $message];
        if ($data !== null) {
            $response['data'] = $data;
        }
        echo json_encode($response);
        exit();
    }
}

// Instantiate and handle the request
try {
    $transportMaster = new TransportMaster();
    $transportMaster->handleRequest();
} catch (Exception $e) {
    error_log("Failed to handle request: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Internal server error']);
}
?>