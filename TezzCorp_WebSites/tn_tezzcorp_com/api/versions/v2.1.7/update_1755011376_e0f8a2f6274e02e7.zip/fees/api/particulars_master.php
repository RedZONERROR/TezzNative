<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class ParticularsController {
    private $pdo;
    private $logger;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    // Validate input data
    private function validateInput(array $data, bool $isUpdate = false): array {
        $this->logError('Validating input: ' . json_encode($data));
        $errors = [];
        $validData = [];

        // Define validation rules
        $fields = [
            'particular' => ['type' => 'string', 'max_length' => 100, 'required' => true],
            'status' => ['type' => 'string', 'enum' => ['active', 'inactive'], 'required' => true],
        ];

        // Validate id for updates
        if ($isUpdate) {
            if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT) || $data['id'] <= 0) {
                $errors[] = "id must be a valid integer";
            } else {
                $validData['id'] = (int)$data['id'];
            }
        }

        // Validate other fields
        foreach ($fields as $field => $rules) {
            if (array_key_exists($field, $data)) {
                $value = $data[$field];

                // Handle NULL or empty strings for optional fields
                if ($value === '' && !$rules['required']) {
                    $value = null;
                }

                // Type checking
                if ($value !== null) {
                    switch ($rules['type']) {
                        case 'string':
                            if (!is_string($value)) {
                                $errors[] = "$field must be a string";
                            } elseif (isset($rules['max_length']) && strlen($value) > $rules['max_length']) {
                                $errors[] = "$field must not exceed {$rules['max_length']} characters";
                            }
                            break;
                    }

                    // Enum validation
                    if (isset($rules['enum']) && !in_array($value, $rules['enum'], true)) {
                        $errors[] = "$field must be one of: " . implode(', ', $rules['enum']);
                    }
                }

                $validData[$field] = $value;
            } elseif ($rules['required']) {
                $errors[] = "$field is required";
            }
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        $this->logError('Validated data: ' . json_encode($validData));
        return $validData;
    }

    // Send JSON error response
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    // Send JSON success response
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Handle GET request
    public function get($request) {
        if (isset($request['id'])) {
            $id = filter_var($request['id'], FILTER_VALIDATE_INT);
            if (!$id) {
                $this->sendError(400, 'Invalid ID');
            }

            $stmt = $this->pdo->prepare("SELECT * FROM particulars WHERE id = ?");
            $stmt->execute([$id]);
            $entry = $stmt->fetch();

            if ($entry) {
                $this->sendSuccess(200, ['data' => [$entry]]);
            } else {
                $this->sendError(404, 'Particular not found');
            }
        } else {
            // Pagination parameters
            $page = isset($request['page']) ? max(1, filter_var($request['page'], FILTER_VALIDATE_INT)) : 1;
            $perPage = isset($request['perPage']) ? max(1, filter_var($request['perPage'], FILTER_VALIDATE_INT)) : 10;
            $offset = ($page - 1) * $perPage;

            // Get total count for pagination
            $stmt = $this->pdo->query("SELECT COUNT(*) FROM particulars");
            $totalItems = $stmt->fetchColumn();
            $totalPages = max(1, ceil($totalItems / $perPage));

            // Fetch paginated data
            $stmt = $this->pdo->prepare("SELECT * FROM particulars ORDER BY updated_on DESC LIMIT ? OFFSET ?");
            $stmt->execute([$perPage, $offset]);
            $entries = $stmt->fetchAll();

            $this->sendSuccess(200, [
                'data' => $entries,
                'meta' => [
                    'page' => $page,
                    'perPage' => $perPage,
                    'totalPages' => $totalPages,
                    'totalItems' => $totalItems
                ]
            ]);
        }
    }

    // Handle POST request (for adding and updating with _method=PUT)
    public function post() {
        // Check for _method field to determine if this is an update
        $method = isset($_POST['_method']) ? strtoupper($_POST['_method']) : 'POST';
        $data = $_POST;

        if ($method === 'PUT') {
            // Update operation
            $data['id'] = isset($data['id']) ? $data['id'] : null;
            $validData = $this->validateInput($data, true);

            $fields = array_keys($validData);
            $updateFields = [];
            $values = [];
            foreach ($fields as $field) {
                if ($field !== 'id') {
                    $updateFields[] = "$field = ?";
                    $values[] = $validData[$field];
                }
            }
            $values[] = $validData['id'];

            $sql = "UPDATE particulars SET " . implode(', ', $updateFields) . ", updated_on = NOW() WHERE id = ?";
            $this->logError('SQL Query: ' . $sql);
            $this->logError('SQL Values: ' . json_encode($values));

            try {
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute($values);
                if ($stmt->rowCount() === 0) {
                    $this->logError('No rows updated. Data may be unchanged or ID not found.');
                }
                $this->sendSuccess(200, ['message' => 'Particular updated']);
            } catch (PDOException $e) {
                $this->logError('Update failed: ' . $e->getMessage());
                $this->sendError(500, 'Failed to update particular: ' . $e->getMessage());
            }
        } else {
            // Add operation
            $validData = $this->validateInput($data);

            $fields = array_keys($validData);
            $placeholders = array_fill(0, count($fields), '?');
            $sql = "INSERT INTO particulars (" . implode(', ', $fields) . ", updated_on) VALUES (" . implode(', ', $placeholders) . ", NOW())";
            $this->logError('SQL Query: ' . $sql);
            $this->logError('SQL Values: ' . json_encode(array_values($validData)));

            try {
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute(array_values($validData));
                $this->sendSuccess(201, ['message' => 'Particular added']);
            } catch (PDOException $e) {
                $this->logError('Insert failed: ' . $e->getMessage());
                $this->sendError(500, 'Failed to add particular: ' . $e->getMessage());
            }
        }
    }

    // Handle DELETE request
    public function delete() {
        $input = json_decode(file_get_contents('php://input'), true);
        $this->logError('DELETE input: ' . json_encode($input));

        if (!isset($input['ids']) || !is_array($input['ids']) || empty($input['ids'])) {
            $this->sendError(400, 'Invalid or missing IDs');
        }

        $ids = array_map('intval', $input['ids']);
        $placeholders = array_fill(0, count($ids), '?');
        $sql = "DELETE FROM particulars WHERE id IN (" . implode(',', $placeholders) . ")";
        $this->logError('SQL Query: ' . $sql);
        $this->logError('SQL Values: ' . json_encode($ids));

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($ids);
            $this->sendSuccess(200, ['message' => 'Particular(s) deleted']);
        } catch (PDOException $e) {
            $this->logError('Delete failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to delete particular(s): ' . $e->getMessage());
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];

        switch ($method) {
            case 'GET':
                $this->get($_GET);
                break;
            case 'POST':
                $this->post();
                break;
            case 'DELETE':
                $this->delete();
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new ParticularsController();
$controller->handleRequest();
?>