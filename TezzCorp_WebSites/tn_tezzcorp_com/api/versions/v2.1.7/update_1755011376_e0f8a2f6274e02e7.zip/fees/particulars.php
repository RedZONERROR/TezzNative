<?php
session_start();
if(!isset($_SESSION['uid'])){
	header("location: ../../login");
	die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Particulars Master - AI-ERP 2.0</title>
    <style>
        /* Improved UI/UX Styling */
        .card {
            border-radius: 0.75rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        .table th, .table td {
            vertical-align: middle;
            padding: 0.75rem;
        }
        .table th {
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.85rem;
            color: #6c757d;
        }
        .table tbody tr:hover {
            background-color: #f8f9fa;
        }
        .badge {
            font-size: 0.8rem;
            padding: 0.4em 0.8em;
            border-radius: 0.5rem;
        }
        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.85rem;
        }
        .btn i {
            font-size: 1rem;
        }
        .btn:hover i {
            transform: scale(1.1);
            transition: transform 0.2s ease;
        }
        .action-buttons {
            display: none;
        }
        .btn-loading .fa-spinner {
            display: inline-block;
        }
        .btn-loading .btn-text, .btn-loading .ti {
            display: none;
        }
        .fa-spinner {
            display: none;
            font-size: 0.9rem;
        }
        .table-loader {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        .table-container {
            position: relative;
        }
        .pagination {
            margin-top: 1rem;
        }
        .form-control:focus {
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.1);
            border-color: #007bff;
        }
        .modal-content {
            border-radius: 0.75rem;
        }
        .modal-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        @media (max-width: 576px) {
            .table-responsive {
                font-size: 0.9rem;
            }
            .btn-sm {
                padding: 0.2rem 0.4rem;
            }
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Particulars Master</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Particulars Master
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Particulars Table -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-4 col-xl-3">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Particulars..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-8 col-xl-9 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <div class="action-buttons me-2">
                                        <button class="delete-multiple btn bg-danger-subtle text-danger">
                                            <i class="fas fa-spinner fa-spin"></i>
                                            <span class="btn-text">Delete Selected</span>
                                        </button>
                                    </div>
                                    <button id="btn-add-contact" class="btn btn-primary d-flex align-items-center">
                                        <i class="ti ti-plus text-white me-1 fs-5"></i> Add Particular
                                    </button>
                                </div>
                            </div>
                        </div>
                        <!-- Modal -->
                        <div class="modal fade" id="addContactModal" tabindex="-1" role="dialog"
                            aria-labelledby="addContactModalTitle" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="modal-title">Add Particular</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="add-contact-box">
                                            <div class="add-contact-content">
                                                <form id="addParticularForm">
                                                    <input type="hidden" id="particular_id">
                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <label for="particular" class="form-label">Particular Name *</label>
                                                            <input type="text" id="particular" name="particular" class="form-control" placeholder="Enter particular name" required />
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="status" class="form-label">Status *</label>
                                                            <select class="form-control" id="status" name="status" required>
                                                                <option value="">Select Status</option>
                                                                <option value="active">Active</option>
                                                                <option value="inactive">Inactive</option>
                                                            </select>
                                                            <span class="validation-text text-danger"></span>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button id="btn-add" class="btn btn-success">
                                            <i class="fas fa-spinner fa-spin btn-loading"></i>
                                            <span class="btn-text">Add</span>
                                        </button>
                                        <button id="btn-edit" class="btn btn-success" style="display:none;">
                                            <i class="fas fa-spinner fa-spin btn-loading"></i>
                                            <span class="btn-text">Save</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Table -->
                        <div class="card card-body table-container">
                            <div class="table-loader">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <tr>
                                            <th>
                                                <div class="n-chk align-self-center text-center">
                                                    <div class="form-check">
                                                        <input type="checkbox" class="form-check-input primary"
                                                            id="contact-check-all" />
                                                        <label class="form-check-label" for="contact-check-all"></label>
                                                        <span class="new-control-indicator"></span>
                                                    </div>
                                                </div>
                                            </th>
                                            <th>S.N.</th>
                                            <th>Particular</th>
                                            <th>Status</th>
                                            <th>Updated On</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="particulars_list_table_body">
                                        <!-- Table will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <nav aria-label="Page navigation" id="pagination-nav">
                                <ul class="pagination justify-content-center">
                                    <!-- Pagination controls -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="dark-transparent sidebartoggler"></div>
    <!-- Core JS -->
    <script src="../assets/js/vendor.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script src="../assets/js/index.global.min.js"></script>
    <script>
        $(document).ready(function() {
            // Pagination state
            let currentPage = 1;
            const perPage = 10;

            // Hide table loader initially
            $('.table-loader').hide();

            // Load particulars with pagination
            function loadParticulars(page = 1) {
                $('.table-loader').show();
                $.ajax({
                    url: 'api/particulars_master.php',
                    type: 'GET',
                    data: { page: page, perPage: perPage },
                    dataType: 'json',
                    success: function(response) {
                        const particulars = response.data || [];
                        const meta = response.meta || { page: 1, totalPages: 1, totalItems: particulars.length };
                        renderParticularsTable(particulars, page);
                        renderPagination(meta);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load particulars: ' + (xhr.responseJSON?.error || error)
                        });
                        renderPagination({ page: 1, totalPages: 1, totalItems: 0 });
                    },
                    complete: function() {
                        $('.table-loader').hide();
                    }
                });
            }

            // Render particulars table
            function renderParticularsTable(particulars, page) {
                const tbody = $('#particulars_list_table_body');
                tbody.empty();
                if (particulars.length === 0) {
                    tbody.append('<tr><td colspan="6" class="text-center">No particulars found.</td></tr>');
                    return;
                }
                particulars.forEach((particular, index) => {
                    const serialNumber = (page - 1) * perPage + index + 1;
                    const statusBadge = particular.status === 'active'
                        ? '<span class="badge bg-success-subtle text-success">Active</span>'
                        : '<span class="badge bg-danger-subtle text-danger">Inactive</span>';
                    const updatedOn = particular.updated_on
                        ? new Date(particular.updated_on).toLocaleString()
                        : 'N/A';
                    tbody.append(`
                        <tr data-id="${particular.id}">
                            <td>
                                <div class="n-chk align-self-center text-center">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input primary contact-check"
                                            data-id="${particular.id}" />
                                        <label class="form-check-label"></label>
                                        <span class="new-control-indicator"></span>
                                    </div>
                                </div>
                            </td>
                            <td>${serialNumber}</td>
                            <td>${particular.particular}</td>
                            <td>${statusBadge}</td>
                            <td>${updatedOn}</td>
                            <td>
                                <button class="edit-particular btn btn-sm btn-primary me-1" data-id="${particular.id}">
                                    <i class="fas fa-spinner fa-spin btn-loading"></i>
                                    <i class="ti ti-edit"></i>
                                </button>
                                <button class="delete-particular btn btn-sm btn-danger" data-id="${particular.id}">
                                    <i class="fas fa-spinner fa-spin btn-loading"></i>
                                    <i class="ti ti-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `);
                });
            }

            // Render pagination
            function renderPagination(meta) {
                const pagination = $('#pagination-nav ul');
                pagination.empty();

                const currentPage = meta.page || 1;
                const totalPages = meta.totalPages || 1;

                pagination.append(`
                    <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
                    </li>
                `);

                for (let p = 1; p <= totalPages; p++) {
                    pagination.append(`
                        <li class="page-item ${p === currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${p}">${p}</a>
                        </li>
                    `);
                }

                pagination.append(`
                    <li class="page-item ${currentPage >= totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
                    </li>
                `);
            }

            // Pagination click
            $(document).on('click', '#pagination-nav a', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && page !== currentPage) {
                    currentPage = page;
                    loadParticulars(page);
                }
            });

            // Show add modal
            $('#btn-add-contact').on('click', function() {
                $('#modal-title').text('Add Particular');
                $('#addParticularForm')[0].reset();
                $('#particular_id').val('');
                $('#btn-add').show();
                $('#btn-edit').hide();
                $('#addContactModal').modal('show');
            });

            // Add particular
            $('#btn-add').on('click', function() {
                const form = $('#addParticularForm')[0];
                if (!form.checkValidity()) {
                    form.reportValidity();
                    return;
                }

                const formData = new FormData(form);
                $(this).addClass('btn-loading');

                $.ajax({
                    url: 'api/particulars_master.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Particular added successfully'
                        });
                        $('#addContactModal').modal('hide');
                        loadParticulars(currentPage);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to add particular: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('#btn-add').removeClass('btn-loading');
                    }
                });
            });

            // Show edit modal
            $(document).on('click', '.edit-particular', function() {
                const id = $(this).data('id');
                $(this).addClass('btn-loading');
                $.ajax({
                    url: 'api/particulars_master.php',
                    type: 'GET',
                    data: { id: id },
                    dataType: 'json',
                    success: function(response) {
                        const particular = response.data && response.data.length > 0 ? response.data[0] : null;
                        if (particular) {
                            $('#modal-title').text('Edit Particular');
                            $('#particular_id').val(particular.id);
                            $('#particular').val(particular.particular);
                            $('#status').val(particular.status);
                            $('#btn-add').hide();
                            $('#btn-edit').show();
                            $('#addContactModal').modal('show');
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Particular not found'
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to fetch particular: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('.edit-particular[data-id="' + id + '"]').removeClass('btn-loading');
                    }
                });
            });

            // Update particular
            $('#btn-edit').on('click', function() {
                const form = $('#addParticularForm')[0];
                if (!form.checkValidity()) {
                    form.reportValidity();
                    return;
                }

                const formData = new FormData(form);
                formData.append('id', $('#particular_id').val());
                formData.append('_method', 'PUT');

                $(this).addClass('btn-loading');

                $.ajax({
                    url: 'api/particulars_master.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Particular updated successfully'
                        });
                        $('#addContactModal').modal('hide');
                        loadParticulars(currentPage);
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to update particular: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('#btn-edit').removeClass('btn-loading');
                    }
                });
            });

            // Delete particular
            $(document).on('click', '.delete-particular', function() {
                const id = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/particulars_master.php',
                            type: 'DELETE',
                            data: JSON.stringify({ ids: [id] }),
                            contentType: 'application/json',
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted',
                                    text: response.message || 'Particular deleted successfully'
                                });
                                loadParticulars(currentPage);
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to delete particular: ' + (xhr.responseJSON?.error || error)
                                });
                            },
                            complete: function() {
                                $('.delete-particular[data-id="' + id + '"]').removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // Handle select all checkbox
            $('#contact-check-all').on('change', function() {
                $('.contact-check').prop('checked', this.checked);
                $('.action-buttons').toggle($('.contact-check:checked').length > 0);
            });

            // Handle individual checkboxes
            $(document).on('change', '.contact-check', function() {
                const anyChecked = $('.contact-check:checked').length > 0;
                $('#contact-check-all').prop('checked', $('.contact-check').length === $('.contact-check:checked').length);
                $('.action-buttons').toggle(anyChecked);
            });

            // Bulk delete
            $('.delete-multiple').on('click', function() {
                const selectedIds = $('.contact-check:checked').map(function() {
                    return $(this).data('id');
                }).get();

                if (selectedIds.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Selection',
                        text: 'Please select at least one particular to delete.'
                    });
                    return;
                }

                Swal.fire({
                    title: 'Are you sure?',
                    text: `Delete ${selectedIds.length} particulars?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete them!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).addClass('btn-loading');
                        $.ajax({
                            url: 'api/particulars_master.php',
                            type: 'DELETE',
                            data: JSON.stringify({ ids: selectedIds }),
                            contentType: 'application/json',
                            success: function(response) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Deleted',
                                    text: response.message || 'Selected particulars deleted successfully'
                                });
                                loadParticulars(currentPage);
                                $('.action-buttons').hide();
                            },
                            error: function(xhr, status, error) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Failed to delete particulars: ' + (xhr.responseJSON?.error || error)
                                });
                            },
                            complete: function() {
                                $('.delete-multiple').removeClass('btn-loading');
                            }
                        });
                    }
                });
            });

            // Search functionality
            $('#input-search').on('keyup', function() {
                const searchText = $(this).val().toLowerCase();
                $('#particulars_list_table_body tr').filter(function() {
                    $(this).toggle($(this).find('td:eq(2)').text().toLowerCase().indexOf(searchText) > -1);
                });
            });

            // Initial load
            loadParticulars(currentPage);
        });
    </script>
</body>
</html>