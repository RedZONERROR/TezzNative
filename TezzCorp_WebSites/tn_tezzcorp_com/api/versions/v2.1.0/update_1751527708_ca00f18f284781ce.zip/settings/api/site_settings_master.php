<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

class SiteSettingsController {
    private $pdo;
    private $logger;
    private $uploadDir;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };

        // Set upload directory
        $this->uploadDir = __DIR__ . '/../../uploads/';
        if (!file_exists($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
    }

    // Validate input data
    private function validateInput(array $data, bool $isUpdate = false): array {
        $this->logError('Validating input: ' . json_encode($data)); // Debug: Log incoming data
        $errors = [];
        $validData = [];

        // Define validation rules
        $fields = [
            'school_name' => ['type' => 'string', 'max_length' => 100, 'required' => !$isUpdate],
            'logo' => ['type' => 'string', 'max_length' => 255, 'required' => false],
            'favicon' => ['type' => 'string', 'max_length' => 255, 'required' => false],
            'email' => ['type' => 'string', 'max_length' => 100, 'required' => !$isUpdate],
            'address' => ['type' => 'string', 'max_length' => 255, 'required' => !$isUpdate],
            'phone' => ['type' => 'string', 'max_length' => 15, 'required' => !$isUpdate],
            'phpmailer_host' => ['type' => 'string', 'max_length' => 100, 'required' => false],
            'phpmailer_username' => ['type' => 'string', 'max_length' => 100, 'required' => false],
            'phpmailer_password' => ['type' => 'string', 'max_length' => 100, 'required' => false],
            'phpmailer_port' => ['type' => 'integer', 'min' => 1, 'max' => 65535, 'required' => false],
            'status' => ['type' => 'string', 'max_length' => 8, 'enum' => ['active', 'inactive'], 'required' => !$isUpdate],
            'primary_color' => ['type' => 'string', 'max_length' => 7, 'required' => false],
            'secondary_color' => ['type' => 'string', 'max_length' => 7, 'required' => false],
            'background_color' => ['type' => 'string', 'max_length' => 7, 'required' => false],
            'tagline' => ['type' => 'string', 'max_length' => 255, 'required' => false],
            'footer_text' => ['type' => 'string', 'max_length' => 255, 'required' => false],
            'transport_head_mobile' => ['type' => 'string', 'max_length' => 15, 'required' => false],
            'fees_collection_mobile' => ['type' => 'string', 'max_length' => 15, 'required' => false],
            'whatsapp_number' => ['type' => 'string', 'max_length' => 15, 'required' => false],
            'calling_number' => ['type' => 'string', 'max_length' => 15, 'required' => false],
            'facebook_url' => ['type' => 'string', 'max_length' => 255, 'required' => false],
            'twitter_url' => ['type' => 'string', 'max_length' => 255, 'required' => false],
            'instagram_url' => ['type' => 'string', 'max_length' => 255, 'required' => false],
            'linkedin_url' => ['type' => 'string', 'max_length' => 255, 'required' => false],
            'google_analytics_id' => ['type' => 'string', 'max_length' => 20, 'required' => false],
            'maintenance_mode' => ['type' => 'string', 'max_length' => 8, 'enum' => ['enabled', 'disabled'], 'required' => false],
        ];

        // Validate id separately for updates
        if ($isUpdate) {
            if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT) || $data['id'] <= 0) {
                $errors[] = "id must be a valid integer";
            } else {
                $validData['id'] = (int)$data['id'];
            }
        }

        // Validate other fields
        foreach ($fields as $field => $rules) {
            if (array_key_exists($field, $data)) {
                $value = $data[$field];

                // Handle NULL or empty strings for optional fields
                if ($value === '' && !$rules['required']) {
                    $value = null;
                }

                // Type checking
                if ($value !== null) {
                    switch ($rules['type']) {
                        case 'string':
                            if (!is_string($value)) {
                                $errors[] = "$field must be a string";
                            } elseif (isset($rules['max_length']) && strlen($value) > $rules['max_length']) {
                                $errors[] = "$field must not exceed {$rules['max_length']} characters";
                            }
                            break;
                        case 'integer':
                            $value = filter_var($value, FILTER_VALIDATE_INT);
                            if ($value === false || (isset($rules['min']) && $value < $rules['min']) || (isset($rules['max']) && $value > $rules['max'])) {
                                $errors[] = "$field must be an integer between {$rules['min']} and {$rules['max']}";
                            }
                            break;
                    }

                    // Enum validation
                    if (isset($rules['enum']) && !in_array($value, $rules['enum'], true)) {
                        $errors[] = "$field must be one of: " . implode(', ', $rules['enum']);
                    }

                    // Additional validations
                    if ($field === 'email' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                        $errors[] = "email must be a valid email address";
                    }
                    if (in_array($field, ['phone', 'transport_head_mobile', 'fees_collection_mobile', 'whatsapp_number', 'calling_number']) && !empty($value) && !preg_match("/^\+?\d{10,15}$/", $value)) {
                        $errors[] = "$field must be a valid phone number (10-15 digits, optional + prefix)";
                    }
                    if (in_array($field, ['primary_color', 'secondary_color', 'background_color']) && !empty($value) && !preg_match("/^#[0-9A-Fa-f]{6}$/", $value)) {
                        $errors[] = "$field must be a valid hex color code (e.g., #007bff)";
                    }
                    if (in_array($field, ['facebook_url', 'twitter_url', 'instagram_url', 'linkedin_url']) && !empty($value) && !filter_var($value, FILTER_VALIDATE_URL)) {
                        $errors[] = "$field must be a valid URL";
                    }
                    if ($field === 'google_analytics_id' && !empty($value) && !preg_match("/^UA-[0-9]+-[0-9]+$/", $value)) {
                        $errors[] = "google_analytics_id must be in the format UA-XXXXX-Y";
                    }
                }

                $validData[$field] = $value;
            } elseif ($rules['required']) {
                $errors[] = "$field is required";
            }
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        $this->logError('Validated data: ' . json_encode($validData)); // Debug: Log validated data
        return $validData;
    }

    // Handle file upload
    private function handleFileUpload($fileKey, $existingPath = null) {
        if (!isset($_FILES[$fileKey]) || $_FILES[$fileKey]['error'] === UPLOAD_ERR_NO_FILE) {
            return $existingPath; // No new file uploaded, return existing path
        }

        $file = $_FILES[$fileKey];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/svg+xml'];
        $maxSize = 2 * 1024 * 1024; // 2MB

        if (!in_array($file['type'], $allowedTypes)) {
            $this->sendError(400, "Invalid file type for $fileKey. Allowed types: JPEG, PNG, GIF, SVG");
        }
        if ($file['size'] > $maxSize) {
            $this->sendError(400, "File size for $fileKey exceeds 2MB");
        }

        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $extension;
        $destination = $this->uploadDir . $filename;

        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            $this->logError("Failed to upload file for $fileKey");
            $this->sendError(500, "Failed to upload file for $fileKey");
        }

        // Delete old file if it exists
        if ($existingPath && file_exists($this->uploadDir . basename($existingPath))) {
            unlink($this->uploadDir . basename($existingPath));
        }

        return '/uploads/' . $filename;
    }

    // Send JSON error response
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    // Send JSON success response
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Handle GET request
    public function get($request) {
        if (isset($request['id'])) {
            $id = filter_var($request['id'], FILTER_VALIDATE_INT);
            if (!$id) {
                $this->sendError(400, 'Invalid ID');
            }

            $stmt = $this->pdo->prepare("SELECT * FROM site_settings WHERE id = ?");
            $stmt->execute([$id]);
            $entry = $stmt->fetch();

            if ($entry) {
                $this->sendSuccess(200, ['data' => [$entry]]);
            } else {
                $this->sendError(404, 'Site settings not found');
            }
        } else {
            $stmt = $this->pdo->prepare("SELECT * FROM site_settings LIMIT 1");
            $stmt->execute();
            $entry = $stmt->fetch();

            if ($entry) {
                $this->sendSuccess(200, ['data' => [$entry]]);
            } else {
                $this->sendError(404, 'No site settings found');
            }
        }
    }

    // Handle POST request (used for updates with _method=PUT)
    public function post() {
        // Check for _method field to determine if this is an update
        $method = isset($_POST['_method']) ? strtoupper($_POST['_method']) : 'POST';
        
        if ($method === 'PUT') {
            // Since site_settings typically has one record, fetch the existing record
            $stmt = $this->pdo->prepare("SELECT * FROM site_settings LIMIT 1");
            $stmt->execute();
            $existing = $stmt->fetch();

            if (!$existing) {
                $this->sendError(404, 'Site settings not found');
            }

            // Parse FormData
            $data = $_POST; // FormData fields are available in $_POST

            // Add the existing ID to the data
            $data['id'] = $existing['id'];

            // Validate input
            $validData = $this->validateInput($data, true);

            // Handle file uploads
            $validData['logo'] = $this->handleFileUpload('logo', $existing['logo']);
            $validData['favicon'] = $this->handleFileUpload('favicon', $existing['favicon']);

            // Prepare fields for update
            $fields = array_keys($validData);
            $updateFields = [];
            $values = [];
            foreach ($fields as $field) {
                if ($field !== 'id') {
                    $updateFields[] = "$field = ?";
                    $values[] = $validData[$field];
                }
            }
            $values[] = $validData['id'];

            $sql = "UPDATE site_settings SET " . implode(', ', $updateFields) . ", updated_on = NOW() WHERE id = ?";

            try {
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute($values);
                // if ($stmt->rowCount() === 0) {
                //     $this->logError('No rows updated. Data may be unchanged.');
                // }
                $this->sendSuccess(200, ['message' => 'Site settings updated']);
            } catch (PDOException $e) {
                $this->logError('Update failed: ' . $e->getMessage());
                $this->sendError(500, 'Failed to update site settings: ' . $e->getMessage());
            }
        } else {
            $this->sendError(405, 'Method not allowed for POST without _method=PUT');
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];

        switch ($method) {
            case 'GET':
                $this->get($_GET);
                break;
            case 'POST':
                $this->post();
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new SiteSettingsController();
$controller->handleRequest();
?>