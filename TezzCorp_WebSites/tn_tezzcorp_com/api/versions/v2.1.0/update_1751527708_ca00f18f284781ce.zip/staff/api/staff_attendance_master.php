<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

date_default_timezone_set('Asia/Kolkata');

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class StaffAttendanceController {
    private $pdo;
    private $logger;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/attendance.log', $logMessage, FILE_APPEND);
        };
    }

    // Validate input data
    private function validateInput(array $data, bool $isUpdate = false): array {
        $errors = [];
        $validData = [];

        $fields = [
            'staff_id' => ['type' => 'int', 'required' => true],
            'date' => ['type' => 'date', 'required' => true],
            'time' => ['type' => 'time', 'required' => true],
            'status' => ['type' => 'enum', 'enum' => ['0', '1'], 'required' => true],
            'attendance' => ['type' => 'string', 'enum' => ['In', 'Out'], 'required' => true],
        ];

        // Validate id for updates
        if ($isUpdate) {
            if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT) || $data['id'] <= 0) {
                $errors[] = "id must be a valid integer";
            } else {
                $validData['id'] = (int)$data['id'];
            }
        }

        foreach ($fields as $field => $rules) {
            if (isset($data[$field])) {
                $value = $data[$field];

                switch ($rules['type']) {
                    case 'int':
                        if (!filter_var($value, FILTER_VALIDATE_INT) || $value <= 0) {
                            $errors[] = "$field must be a positive integer";
                        }
                        break;
                    case 'date':
                        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) || !strtotime($value)) {
                            $errors[] = "$field must be a valid date (YYYY-MM-DD)";
                        }
                        break;
                    case 'time':
                        if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d:[0-5]\d$/', $value)) {
                            $errors[] = "$field must be a valid time (HH:MM:SS)";
                        }
                        break;
                    case 'enum':
                        if (!in_array($value, $rules['enum'], true)) {
                            $errors[] = "$field must be one of: " . implode(', ', $rules['enum']);
                        }
                        break;
                    case 'string':
                        if (!is_string($value) || !in_array($value, $rules['enum'], true)) {
                            $errors[] = "$field must be one of: " . implode(', ', $rules['enum']);
                        }
                        break;
                }

                $validData[$field] = $value;
            } elseif ($rules['required']) {
                $errors[] = "$field is required";
            }
        }

        // Validate staff_id exists
        if (isset($validData['staff_id'])) {
            $stmt = $this->pdo->prepare("SELECT id FROM staff WHERE id = ?");
            $stmt->execute([$validData['staff_id']]);
            if (!$stmt->fetch()) {
                $errors[] = "staff_id does not exist";
            }
        }

        // Check for duplicate attendance (same staff_id, date, and attendance type)
        if (isset($validData['staff_id'], $validData['date'], $validData['attendance'])) {
            $query = $isUpdate ? 
                "SELECT id FROM staff_attendance WHERE staff_id = ? AND date = ? AND attendance = ? AND id != ?" :
                "SELECT id FROM staff_attendance WHERE staff_id = ? AND date = ? AND attendance = ?";
            $stmt = $this->pdo->prepare($query);
            $params = $isUpdate ? 
                [$validData['staff_id'], $validData['date'], $validData['attendance'], $validData['id']] : 
                [$validData['staff_id'], $validData['date'], $validData['attendance']];
            $stmt->execute($params);
            if ($stmt->fetch()) {
                $errors[] = "Attendance record already exists for this staff on this date for " . $validData['attendance'];
            }
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return $validData;
    }

    // Send JSON error response
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    // Send JSON success response
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Handle GET requests
    public function get($request) {
        if (isset($request['id'])) {
            $id = filter_var($request['id'], FILTER_VALIDATE_INT);
            if (!$id) {
                $this->sendError(400, 'Invalid ID');
            }

            $stmt = $this->pdo->prepare("SELECT id, staff_id, date, time, status, attendance FROM staff_attendance WHERE id = ?");
            $stmt->execute([$id]);
            $attendance = $stmt->fetch();

            if ($attendance) {
                $this->sendSuccess(200, ['data' => [$attendance]]);
            } else {
                $this->sendError(404, 'Attendance record not found');
            }
        } elseif (isset($request['staff_id'])) {
            $staff_id = filter_var($request['staff_id'], FILTER_VALIDATE_INT);
            if (!$staff_id) {
                $this->sendError(400, 'Invalid staff_id');
            }

            // Pagination
            $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
            $perPage = isset($_GET['perPage']) ? max(1, min(100, (int)$_GET['perPage'])) : 10;
            $offset = ($page - 1) * $perPage;

            $query = "SELECT id, staff_id, date, time, status, attendance FROM staff_attendance WHERE staff_id = ?";
            $countQuery = "SELECT COUNT(*) FROM staff_attendance WHERE staff_id = ?";
            $params = [$staff_id];

            if (isset($request['date'])) {
                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $request['date'])) {
                    $this->sendError(400, 'Invalid date format (use YYYY-MM-DD)');
                }
                $query .= " AND date = ?";
                $countQuery .= " AND date = ?";
                $params[] = $request['date'];
            }

            $query .= " ORDER BY date DESC, time DESC LIMIT ? OFFSET ?";
            $params[] = $perPage;
            $params[] = $offset;

            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            $attendance = $stmt->fetchAll();

            $countStmt = $this->pdo->prepare($countQuery);
            $countStmt->execute(array_slice($params, 0, count($params) - 2));
            $total = $countStmt->fetchColumn();

            $this->sendSuccess(200, [
                'data' => $attendance,
                'meta' => [
                    'page' => $page,
                    'perPage' => $perPage,
                    'total' => $total,
                    'totalPages' => ceil($total / $perPage)
                ]
            ]);
        } else {
            // Pagination
            $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
            $perPage = isset($_GET['perPage']) ? max(1, min(100, (int)$_GET['perPage'])) : 10;
            $offset = ($page - 1) * $perPage;

            $query = "SELECT sa.id, sa.staff_id, sa.date, sa.time, sa.status, sa.attendance, s.name FROM staff_attendance sa JOIN staff s ON sa.staff_id = s.id";
            $countQuery = "SELECT COUNT(*) FROM staff_attendance sa JOIN staff s ON sa.staff_id = s.id";
            $params = [];

            // Filtering
            $conditions = [];
            if (isset($_GET['status']) && in_array($_GET['status'], ['0', '1'])) {
                $conditions[] = "sa.status = ?";
                $params[] = $_GET['status'];
            }
            if (isset($_GET['date'])) {
                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['date'])) {
                    $this->sendError(400, 'Invalid date format (use YYYY-MM-DD)');
                }
                $conditions[] = "sa.date = ?";
                $params[] = $_GET['date'];
            }
            if (isset($_GET['date_like'])) {
                if (!preg_match('/^\d{4}-\d{2}%$/', $_GET['date_like'])) {
                    $this->sendError(400, 'Invalid date_like format (use YYYY-MM%)');
                }
                $conditions[] = "sa.date LIKE ?";
                $params[] = $_GET['date_like'];
            }

            if ($conditions) {
                $query .= " WHERE " . implode(' AND ', $conditions);
                $countQuery .= " WHERE " . implode(' AND ', $conditions);
            }

            $query .= " ORDER BY sa.date DESC, sa.time DESC LIMIT ? OFFSET ?";
            $params[] = $perPage;
            $params[] = $offset;

            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            $attendance = $stmt->fetchAll();

            $countStmt = $this->pdo->prepare($countQuery);
            $countStmt->execute(array_slice($params, 0, count($params) - 2));
            $total = $countStmt->fetchColumn();

            $this->sendSuccess(200, [
                'data' => $attendance,
                'meta' => [
                    'page' => $page,
                    'perPage' => $perPage,
                    'total' => $total,
                    'totalPages' => ceil($total / $perPage)
                ]
            ]);
        }
    }

    // Handle POST requests
    public function post($data) {
        $validData = $this->validateInput($data);

        $fields = array_keys($validData);
        $placeholders = array_fill(0, count($fields), '?');
        $sql = "INSERT INTO staff_attendance (" . implode(',', $fields) . ") VALUES (" . implode(',', $placeholders) . ")";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute(array_values($validData));
            $this->sendSuccess(201, ['message' => 'Attendance record created', 'id' => $this->pdo->lastInsertId()]);
        } catch (PDOException $e) {
            $this->logError('Create failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to create attendance record');
        }
    }

    // Handle PUT requests
    public function put($data) {
        $validData = $this->validateInput($data, true);

        if (!isset($validData['id'])) {
            $this->sendError(400, 'ID is required');
        }

        // Fetch existing record
        $stmt = $this->pdo->prepare("SELECT id, staff_id, date, time, status, attendance FROM staff_attendance WHERE id = ?");
        $stmt->execute([$validData['id']]);
        $existing = $stmt->fetch();

        if (!$existing) {
            $this->sendError(404, 'Attendance record not found');
        }

        // Merge existing data with provided data
        $fields = ['staff_id', 'date', 'time', 'status', 'attendance'];
        $updateFields = [];
        $values = [];
        foreach ($fields as $field) {
            if (isset($validData[$field])) {
                $updateFields[] = "$field = ?";
                $values[] = $validData[$field];
            } else {
                $updateFields[] = "$field = ?";
                $values[] = $existing[$field];
            }
        }
        $values[] = $validData['id'];

        $sql = "UPDATE staff_attendance SET " . implode(', ', $updateFields) . " WHERE id = ?";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($values);
            $this->sendSuccess(200, ['message' => 'Attendance record updated']);
        } catch (PDOException $e) {
            $this->logError('Update failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to update attendance record');
        }
    }

    // Handle DELETE requests
    public function delete($data) {
        if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT)) {
            $this->sendError(400, 'Invalid or missing ID');
        }

        try {
            $stmt = $this->pdo->prepare("DELETE FROM staff_attendance WHERE id = ?");
            $stmt->execute([$data['id']]);
            if ($stmt->rowCount()) {
                $this->sendSuccess(200, ['message' => 'Attendance record deleted']);
            } else {
                $this->sendError(404, 'Attendance record not found');
            }
        } catch (PDOException $e) {
            $this->logError('Delete failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to delete attendance record');
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $data = json_decode(file_get_contents('php://input'), true) ?: [];

        switch ($method) {
            case 'GET':
                $this->get($_GET);
                break;
            case 'POST':
                $this->post($data);
                break;
            case 'PUT':
                $this->put($data);
                break;
            case 'DELETE':
                $this->delete($data);
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new StaffAttendanceController();
$controller->handleRequest();
?>