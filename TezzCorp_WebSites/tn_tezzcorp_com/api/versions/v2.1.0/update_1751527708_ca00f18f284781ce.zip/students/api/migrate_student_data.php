<?php

class StudentDataMigrator {
    private $endpointUrl;
    private $logFile;
    private $authToken;

    public function __construct($endpointUrl = 'https://www.radiantpublicschoolchanptia.in/app/students/api/student_master.php', $authToken = 'iuryhtowefh98y89wehfiwefbuu') {
        $this->endpointUrl = $endpointUrl;
        $this->authToken = $authToken;
        $this->logFile = __DIR__ . '/logs/migration.log';

        // Ensure logs directory exists
        $logDir = dirname($this->logFile);
        if (!file_exists($logDir)) {
            mkdir($logDir, 0755, true);
        }
    }

    private function logMessage($message) {
        $logEntry = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
        file_put_contents($this->logFile, $logEntry, FILE_APPEND);
        echo htmlspecialchars($logEntry) . "<br>";
    }

    public function migrateFromSqlFile($sqlFilePath) {
        // Validate auth token
        if (!isset($_GET['token']) || $_GET['token'] !== $this->authToken) {
            http_response_code(403);
            echo "Unauthorized access. Invalid or missing token.";
            exit;
        }

        if (!file_exists($sqlFilePath)) {
            $this->logMessage("SQL file not found: $sqlFilePath");
            http_response_code(400);
            echo "SQL file not found.";
            exit;
        }

        echo "<h2>Migration Started</h2>";

        // Read SQL file content
        $sqlContent = file_get_contents($sqlFilePath);
        // Split into individual statements
        $sqlStatements = array_filter(array_map('trim', explode(';', $sqlContent)), function ($stmt) {
            return !empty($stmt) && strpos($stmt, 'INSERT INTO `students`') !== false;
        });

        $recordsProcessed = 0;
        $recordsFailed = 0;

        foreach ($sqlStatements as $index => $statement) {
            $this->logMessage("Processing statement #$index: " . substr($statement, 0, 100) . (strlen($statement) > 100 ? '...' : ''));

            // Extract fields and values using a more robust parser
            if (!preg_match("/INSERT INTO `students` \((.*?)\) VALUES \((.*?)\)/si", $statement, $matches)) {
                $this->logMessage("Failed to parse INSERT statement: $statement");
                $recordsFailed++;
                continue;
            }

            $fields = array_map('trim', explode(',', str_replace('`', '', $matches[1])));
            $values = $this->parseSqlValues($matches[2]);

            if (count($fields) !== count($values)) {
                $this->logMessage("Field and value count mismatch in statement #$index: Fields: " . count($fields) . ", Values: " . count($values));
                $this->logMessage("Fields: " . implode(', ', $fields));
                $this->logMessage("Values: " . implode(', ', array_map(function ($v) { return json_encode($v); }, $values)));
                $recordsFailed++;
                continue;
            }

            $record = array_combine($fields, $values);
            $this->logMessage("Parsed record: " . json_encode($record, JSON_UNESCAPED_UNICODE));

            if ($this->migrateRecord($record, $index)) {
                $recordsProcessed++;
            } else {
                $recordsFailed++;
            }
        }

        $summary = "Migration completed. Processed: $recordsProcessed, Failed: $recordsFailed";
        $this->logMessage($summary);
        echo "<h3>$summary</h3>";
    }

    private function parseSqlValues($valuesString) {
        $values = [];
        $current = '';
        $inQuotes = false;
        $quoteChar = null;
        $length = strlen($valuesString);

        for ($i = 0; $i < $length; $i++) {
            $char = $valuesString[$i];

            if ($char === "'" || $char === '"') {
                if ($inQuotes && $char === $quoteChar && ($i === 0 || $valuesString[$i - 1] !== '\\')) {
                    $inQuotes = false;
                    $quoteChar = null;
                    continue;
                } elseif (!$inQuotes) {
                    $inQuotes = true;
                    $quoteChar = $char;
                    continue;
                }
            }

            if ($char === ',' && !$inQuotes) {
                $trimmed = trim($current);
                if ($trimmed === 'NULL' || $trimmed === '') {
                    $values[] = null;
                } else {
                    // Remove surrounding quotes if present
                    if (preg_match('/^[\'"]?(.*?)[\'"]?$/', $trimmed, $match)) {
                        $values[] = $match[1];
                    } else {
                        $values[] = $trimmed;
                    }
                }
                $current = '';
                continue;
            }

            $current .= $char;
        }

        // Handle the last value
        $trimmed = trim($current);
        if ($trimmed === 'NULL' || $trimmed === '') {
            $values[] = null;
        } else {
            if (preg_match('/^[\'"]?(.*?)[\'"]?$/', $trimmed, $match)) {
                $values[] = $match[1];
            } else {
                $values[] = $trimmed;
            }
        }

        return $values;
    }

    private function migrateRecord($record, $index) {
        try {
            // Map old table fields to new students table fields
            $studentData = [
                'id' => $record['id'] ?? null,
                'registration_no' => $record['registration_no'] === '' ? null : ($record['registration_no'] ?? null),
                'admission_number' => $record['admission_no'] === '' ? null : ($record['admission_no'] ?? null),
                'session' => $record['session'] === '' ? null : ($record['session'] ?? null),
                'roll_no' => $record['roll_no'] === '' ? null : ($record['roll_no'] ?? null),
                'full_name' => $record['student_name'] === '' ? null : ($record['student_name'] ?? null),
                'date_of_birth' => ($record['dob'] ?? null) === '0000-00-00' ? null : ($record['dob'] === '' ? null : ($record['dob'] ?? null)),
                'age_year' => $record['age_year'] === '' ? null : ($record['age_year'] ?? null),
                'age_months' => $record['age_months'] === '' ? null : ($record['age_months'] ?? null),
                'age_days' => $record['age_days'] === '' ? null : ($record['age_days'] ?? null),
                'nationality' => $record['nationality'] === '' ? null : ($record['nationality'] ?? null),
                'gender' => ($record['gender'] ?? '') === '' ? null : ucfirst(strtolower($record['gender'] ?? '')),
                'social_category' => $record['category'] === '' ? null : ($record['category'] ?? null),
                'current_school' => $record['current_school'] === '' ? null : ($record['current_school'] ?? null),
                'applying_class' => $record['applying_class'] === '' ? null : ($record['applying_class'] ?? null),
                'current_class' => $record['class'] === '' ? null : ($record['class'] ?? null),
                'medium_of_instruction' => $record['medium'] === '' ? null : ($record['medium'] ?? null),
                'languages' => $record['languages'] === '' ? null : ($record['languages'] ?? null),
                'aadhaar_number' => $record['aadhar'] === '' ? null : ($record['aadhar'] ?? null),
                'father_name' => $record['father_name'] === '' ? null : ($record['father_name'] ?? null),
                'father_dob' => ($record['father_dob'] ?? null) === '0000-00-00' ? null : ($record['father_dob'] === '' ? null : ($record['father_dob'] ?? null)),
                'father_nationality' => $record['father_nationality'] === '' ? null : ($record['father_nationality'] ?? null),
                'father_qualification' => $record['father_qualification'] === '' ? null : ($record['father_qualification'] ?? null),
                'father_occupation' => $record['father_occupation'] === '' ? null : ($record['father_occupation'] ?? null),
                'father_designation' => $record['father_designation'] === '' ? null : ($record['father_designation'] ?? null),
                'father_organization' => $record['father_organization'] === '' ? null : ($record['father_organization'] ?? null),
                'father_office_address' => $record['father_office_address'] === '' ? null : ($record['father_office_address'] ?? null),
                'father_mobile' => $record['father_mobile'] === '' ? null : ($record['father_mobile'] ?? null),
                'mother_name' => $record['mother_name'] === '' ? null : ($record['mother_name'] ?? null),
                'mother_dob' => ($record['mother_dob'] ?? null) === '0000-00-00' ? null : ($record['mother_dob'] === '' ? null : ($record['mother_dob'] ?? null)),
                'mother_nationality' => $record['mother_nationality'] === '' ? null : ($record['mother_nationality'] ?? null),
                'mother_qualification' => $record['mother_qualification'] === '' ? null : ($record['mother_qualification'] ?? null),
                'mother_occupation' => $record['mother_occupation'] === '' ? null : ($record['mother_occupation'] ?? null),
                'mother_designation' => $record['mother_designation'] === '' ? null : ($record['mother_designation'] ?? null),
                'mother_organization' => $record['mother_organization'] === '' ? null : ($record['mother_organization'] ?? null),
                'mother_office_address' => $record['mother_office_address'] === '' ? null : ($record['mother_office_address'] ?? null),
                'mother_mobile' => $record['mother_mobile'] === '' ? null : ($record['mother_mobile'] ?? null),
                'residential_address' => $record['residential_address'] === '' ? null : ($record['residential_address'] ?? null),
                'permanent_address' => $record['permanent_address'] === '' ? null : ($record['permanent_address'] ?? null),
                'email_address' => $record['email'] === '' ? null : ($record['email'] ?? null),
                'ex_student' => $record['ex_student'] === '' ? null : ($record['ex_student'] ?? null),
                'staff_child' => ($record['staff_child'] ?? '') === 'No' ? 0 : ($record['staff_child'] === '' ? null : ($record['staff_child'] ?? null)),
                'contribution' => $record['contribution'] === '' ? null : ($record['contribution'] ?? null),
                'elaborate_choices' => $record['elaborate_choices'] === '' ? null : ($record['elaborate_choices'] ?? null),
                'additional_transport' => ($record['transport'] ?? '') === 'no' ? 0 : ($record['transport'] === '' ? null : ($record['transport'] ?? null)),
                'date' => $record['date'] === '' ? null : ($record['date'] ?? null),
                'rte' => $record['rti'] === '' ? null : ($record['rti'] ?? null),
                // New fields set to null
                'school_name' => null,
                'u_dise_code' => null,
                'religion' => null,
                'mother_tongue' => null,
                'habitation' => null,
                'is_bpl' => null,
                'is_disadvantaged_group' => null,
                'free_education_rte' => null,
                'previous_class' => null,
                'previous_year_status' => null,
                'days_attended_previous_year' => null,
                'disability_type' => null,
                'cwsn_facilities' => null,
                'uniform_sets' => null,
                'free_textbooks' => null,
                'free_transport' => null,
                'free_escort' => null,
                'mdm_beneficiary' => null,
                'free_hostel' => null,
                'additional_email' => null,
                'is_homeless' => null,
                'last_exam_passed' => null,
                'stream' => null,
                'trade_sector' => null,
                'iron_folic_acid' => null,
                'deworming_tablets' => null,
                'vitamin_a_supplement' => null,
                'bank_account_number' => null,
                'ifsc_code' => null,
                'mobile_number' => null,
                'id_card' => null,
                'otp' => null,
            ];

            // Log mapped fields
            $this->logMessage("Mapped fields for record #$index: " . json_encode($studentData, JSON_UNESCAPED_UNICODE));

            // Handle document fields
            $documentFields = [
                'progress_report' => $record['progress_report'] ?? null,
                'birth_certificate' => $record['birth_certificate'] ?? null,
                'slc' => $record['slc'] ?? null,
                'residential_proof' => $record['residential_proof'] ?? null,
                'father_photo' => $record['father_photo'] ?? null,
                'student_photo' => $record['student_photo'] ?? null,
                'mother_photo' => $record['mother_photo'] ?? null,
            ];

            $documents = [];
            foreach ($documentFields as $field => $value) {
                if ($value && $value !== 'NULL' && !empty(trim($value))) {
                    $documents[$field] = trim($value);
                    $this->logMessage("Mapped document for record #$index: $field = $value");
                }
            }

            // Add documents to student data if any exist
            if (!empty($documents)) {
                $studentData['documents'] = $documents;
            }

            // Send HTTP POST request to student_master.php
            $this->logMessage("Sending POST request for record #$index: " . json_encode($studentData, JSON_UNESCAPED_UNICODE));
            $ch = curl_init($this->endpointUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($studentData));
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            // Log response
            $this->logMessage("Received response for record #$index: HTTP $httpCode - " . $response);

            // Parse response
            $responseData = json_decode($response, true);

            if ($httpCode === 201 && isset($responseData['status']) && $responseData['status'] === 'success') {
                $this->logMessage("Successfully migrated record #$index: {$record['student_name']} (Registration: {$record['registration_no']})");
                return true;
            } else {
                $errorMessage = $responseData['message'] ?? 'Unknown error';
                $this->logMessage("Failed to migrate record #$index: {$record['student_name']} (Registration: {$record['registration_no']}) - HTTP $httpCode: $errorMessage");
                return false;
            }
        } catch (Exception $e) {
            $this->logMessage("Error migrating record #$index: {$record['student_name']} (Registration: {$record['registration_no']}) - {$e->getMessage()}");
            return false;
        }
    }
}

// Handle web request
header('Content-Type: text/html; charset=UTF-8');
echo "<html><body><pre>";

// Initialize migrator
$migrator = new StudentDataMigrator('https://www.radiantpublicschoolchanptia.in/app/students/api/student_master.php', 'iuryhtowefh98y89wehfiwefbuu');

// Get SQL file path from query parameter or default to a relative path
$sqlFilePath = isset($_GET['sql_file']) ? $_GET['sql_file'] : __DIR__ . '/old_students.sql';

try {
    $migrator->migrateFromSqlFile($sqlFilePath);
} catch (Exception $e) {
    echo "Fatal error: " . htmlspecialchars($e->getMessage());
}

echo "</pre></body></html>";
?>