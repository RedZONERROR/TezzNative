<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Favicon and Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/favicon/favicon-16x16.png">
    <link rel="manifest" href="assets/favicon/site.webmanifest">
    
    <!-- Canonical URL -->
    <link rel="canonical" href="https://www.newtechpublicschool.in/">
    
    <title>Privacy Policy - New Tech Public School, Tilangahi Math</title>
    <link rel="stylesheet" href="assets/css/privacy-policy.css">
</head>
<body>
    <header class="header">
        <h1>New Tech Public School</h1>
        <p>Your Privacy is Our Priority</p>
    </header>
    <main class="policy-content">
        <section>
            <h2>Privacy Policy</h2>
            <p>At New Tech Public School, we respect and protect the privacy of our students, parents, and staff. This policy outlines how we collect, use, and safeguard your personal information.</p>
        </section>
        <section>
            <h3>Information We Collect</h3>
            <ul>
                <li>Student details such as name, age, and contact information.</li>
                <li>Parental or guardian contact details.</li>
                <li>Academic records and other school-related data.</li>
            </ul>
        </section>
        <section>
            <h3>How We Use Your Information</h3>
            <p>The collected information is used for:</p>
            <ul>
                <li>Academic management and communication.</li>
                <li>Enhancing the educational experience.</li>
                <li>Compliance with legal requirements.</li>
            </ul>
        </section>
        <section>
            <h3>Data Security</h3>
            <p>We take appropriate measures to ensure the security of your data and prevent unauthorized access.</p>
        </section>
        <section>
            <h3>Contact Us</h3>
            <p>If you have questions about our Privacy Policy, please contact us:</p>
            <address>
                New Tech Public School,<br>
                Tilangahi Math, Bairiya, West Champaran,<br>
                Bihar - 845438.<br>
                Phone: +91 6200288978<br>
                Email: info@newtechpublicschool.in
            </address>
        </section>
    </main>
    <footer class="footer">
        <p>© 2024 New Tech Public School. All Rights Reserved.</p>
    </footer>
</body>
</html>