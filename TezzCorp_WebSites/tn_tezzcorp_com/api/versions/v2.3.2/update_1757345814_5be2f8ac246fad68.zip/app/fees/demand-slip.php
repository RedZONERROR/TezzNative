<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Demand Slip Generation - AI-ERP 2.0</title>
    <style>
        .btn-loading .spinner-border {
            display: inline-block;
        }
        .spinner-border {
            display: none;
            width: 1rem;
            height: 1rem;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!-- Sidebar End -->
        <div class="page-wrapper">
            <!-- Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!-- Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Generate Demand Slips</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Demand Slips
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Demand Slip Generation Form -->
                    <div class="card card-body">
                        <form id="demandSlipForm">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="class_id" class="form-label">Select Class</label>
                                    <select id="class_id" name="class_id" class="form-control" required>
                                        <option value="">Select a class</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="month" class="form-label">Select Month(s)</label>
                                    <select id="month" name="month[]" class="form-control" required multiple>
                                        <option value="1">January</option>
                                        <option value="2">February</option>
                                        <option value="3">March</option>
                                        <option value="4">April</option>
                                        <option value="5">May</option>
                                        <option value="6">June</option>
                                        <option value="7">July</option>
                                        <option value="8">August</option>
                                        <option value="9">September</option>
                                        <option value="10">October</option>
                                        <option value="11">November</option>
                                        <option value="12">December</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="issue_date" class="form-label">Issue Date</label>
                                    <input type="date" id="issue_date" name="issue_date" class="form-control" required>
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="due_date" class="form-label">Due Date</label>
                                    <input type="date" id="due_date" name="due_date" class="form-control" required>
                                    <span class="validation-text text-danger"></span>
                                </div>
                            </div>

                            <div class="text-end mt-4">
                                <button type="submit" class="btn btn-success" id="generate-demand-slips">Generate Demand Slips
                                    <div class="spinner-border text-light btn-loading" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- Student List -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-4 col-xl-3">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search" placeholder="Search Students..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="card card-body">
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <th>Student's Name</th>
                                        <th>Father's Name</th>
                                        <th>Pending Amount (₹)</th>
                                    </thead>
                                    <tbody id="student_list_table_body">
                                        <!-- Data will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="../assets/js/vendor.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        $(document).ready(function() {
            const months = {
                1: 'January', 2: 'February', 3: 'March', 4: 'April', 5: 'May', 6: 'June',
                7: 'July', 8: 'August', 9: 'September', 10: 'October', 11: 'November', 12: 'December'
            };

            let siteSettings = {};

            // Load classes
            function loadClasses() {
                $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 50, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        const classes = response.data || [];
                        $('#class_id').empty().append('<option value="">Select a class</option>');
                        classes.forEach(cls => {
                            $('#class_id').append(`<option value="${cls.id}">${cls.class_name}</option>`);
                        });
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load classes: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Load students and their pending fees for selected months
            function loadStudents(classId, months) {
                if (!classId) {
                    $('#student_list_table_body').empty();
                    return;
                }
                $.ajax({
                    url: 'api/fee_collection_master.php',
                    type: 'GET',
                    data: { personal_class: classId },
                    dataType: 'json',
                    success: function(response) {
                        const students = response.data || [];
                        $('#student_list_table_body').empty();
                        students.forEach(student => {
                            $.ajax({
                                url: 'api/fee_collection_master.php',
                                type: 'GET',
                                data: { student_id: student.id },
                                dataType: 'json',
                                success: function(feeResponse) {
                                    let totalPending = 0;
                                    const selectedMonths = months.map(Number);

                                    // Calculate pending fees for selected months
                                    if (feeResponse.data && feeResponse.data.current_fees) {
                                        feeResponse.data.current_fees.forEach(fee => {
                                            let amount = 0;
                                            if (fee.frequency === 'monthly') {
                                                const pendingMonths = fee.pending_months.filter(month => selectedMonths.includes(Number(month)));
                                                amount = (parseFloat(fee.amount) || 0) * pendingMonths.length;
                                            } else if (fee.frequency === 'other' && fee.pending_collections > 0) {
                                                amount = (parseFloat(fee.amount) || 0) * Math.min(fee.pending_collections, selectedMonths.length);
                                            } else if (fee.frequency === 'annual' && !fee.is_fully_paid) {
                                                amount = parseFloat(fee.remaining_balance) || 0;
                                            }
                                            totalPending += amount;
                                        });
                                    }
                                    if (feeResponse.data && feeResponse.data.pending_fees) {
                                        feeResponse.data.pending_fees.forEach(pending => {
                                            totalPending += parseFloat(pending.pending_amount) || 0;
                                        });
                                    }

                                    $('#student_list_table_body').append(`
                                        <tr data-student-id="${student.id}">
                                            <td>${student.full_name || 'N/A'}</td>
                                            <td>${student.father_name || 'N/A'}</td>
                                            <td>${totalPending.toFixed(2)}</td>
                                        </tr>
                                    `);
                                },
                                error: function(xhr, status, error) {
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Error',
                                        text: 'Failed to load fees for student: ' + (xhr.responseJSON?.error || error)
                                    });
                                }
                            });
                        });
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load students: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Handle class selection
            $('#class_id').on('change', function() {
                const classId = $(this).val();
                const months = $('#month').val() || [];
                loadStudents(classId, months);
            });

            // Handle month selection
            $('#month').on('change', function() {
                const classId = $('#class_id').val();
                const months = $(this).val() || [];
                loadStudents(classId, months);
            });

            // Fetch site settings
            function fetchSiteSettings() {
                return $.ajax({
                    url: 'api/site_settings.php',
                    type: 'GET',
                    dataType: 'json'
                }).then(function(response) {
                    return response.data || {
                        school_name: 'GREENWOOD PUBLIC SCHOOL',
                        address: '123 Education Street, Knowledge City, State - 123456',
                        phone: '(555) 123-4567'
                    };
                }).fail(function() {
                    return {
                        school_name: 'GREENWOOD PUBLIC SCHOOL',
                        address: '123 Education Street, Knowledge City, State - 123456',
                        phone: '(555) 123-4567'
                    };
                });
            }

            // Handle form submission
            $('#demandSlipForm').on('submit', function(e) {
                e.preventDefault();

                if (!this.checkValidity()) {
                    this.reportValidity();
                    return;
                }

                const classId = $('#class_id').val();
                const months = $('#month').val() || [];
                const issueDate = $('#issue_date').val();
                const dueDate = $('#due_date').val();
                if (!classId) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Class Selected',
                        text: 'Please select a class to generate demand slips.'
                    });
                    return;
                }
                if (!months.length) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Months Selected',
                        text: 'Please select at least one month.'
                    });
                    return;
                }
                if (!issueDate || !dueDate) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Missing Dates',
                        text: 'Please select both issue and due dates.'
                    });
                    return;
                }

                $('#generate-demand-slips').addClass('btn-loading');

                fetchSiteSettings().then((settings) => {
                    siteSettings = settings;

                    // Fetch students for the selected class
                    $.ajax({
                        url: 'api/fee_collection_master.php',
                        type: 'GET',
                        data: { personal_class: classId },
                        dataType: 'json',
                        success: function(response) {
                            const students = response.data || [];
                            if (students.length === 0) {
                                $('#generate-demand-slips').removeClass('btn-loading');
                                Swal.fire({
                                    icon: 'warning',
                                    title: 'No Students',
                                    text: 'No students found for the selected class.'
                                });
                                return;
                            }

                            let demandSlips = [];
                            let studentIndex = 0;

                            function fetchNextStudentFees() {
                                if (studentIndex >= students.length) {
                                    // Filter out empty slips
                                    demandSlips = demandSlips.filter(slip => slip.student_name && slip.student_name !== 'N/A' && slip.total_amount > 0);
                                    if (demandSlips.length === 0) {
                                        $('#generate-demand-slips').removeClass('btn-loading');
                                        Swal.fire({
                                            icon: 'warning',
                                            title: 'No Valid Slips',
                                            text: 'No students with pending fees for the selected months.'
                                        });
                                        return;
                                    }
                                    // Generate PDF
                                    generatePDF(demandSlips);
                                    return;
                                }

                                const student = students[studentIndex];
                                $.ajax({
                                    url: 'api/fee_collection_master.php',
                                    type: 'GET',
                                    data: { student_id: student.id },
                                    dataType: 'json',
                                    success: function(feeResponse) {
                                        const feeData = feeResponse.data || {};
                                        let fees = [];
                                        let totalPending = 0;
                                        const selectedMonths = months.map(Number);

                                        // Process current fees for the selected months
                                        if (feeData.current_fees) {
                                            feeData.current_fees.forEach(fee => {
                                                let qty = 0;
                                                let amount = 0;
                                                if (fee.frequency === 'monthly') {
                                                    const pendingMonths = fee.pending_months.filter(month => selectedMonths.includes(Number(month)));
                                                    qty = pendingMonths.length;
                                                    amount = (parseFloat(fee.amount) || 0) * qty;
                                                } else if (fee.frequency === 'other' && fee.pending_collections > 0) {
                                                    qty = Math.min(fee.pending_collections, selectedMonths.length);
                                                    amount = (parseFloat(fee.amount) || 0) * qty;
                                                } else if (fee.frequency === 'annual' && !fee.is_fully_paid) {
                                                    qty = 1;
                                                    amount = parseFloat(fee.remaining_balance) || 0;
                                                }
                                                if (amount > 0) {
                                                    fees.push({
                                                        description: fee.particular + (qty > 1 ? ` (${qty} months)` : ''),
                                                        qty: qty || 1,
                                                        amount: amount
                                                    });
                                                    totalPending += amount;
                                                }
                                            });
                                        }

                                        // Process pending fees
                                        if (feeData.pending_fees) {
                                            feeData.pending_fees.forEach(pending => {
                                                const amount = parseFloat(pending.pending_amount) || 0;
                                                if (amount > 0) {
                                                    fees.push({
                                                        description: pending.particular || 'Pending Fee',
                                                        qty: 1,
                                                        amount: amount
                                                    });
                                                    totalPending += amount;
                                                }
                                            });
                                        }

                                        // Add student data to demand slips
                                        demandSlips.push({
                                            student_name: feeData.student_name || 'N/A',
                                            father_name: feeData.father_name || 'N/A',
                                            class_name: feeData.class_name || 'N/A',
                                            roll_no: student.roll_no || 'N/A',
                                            fees: fees,
                                            total_amount: totalPending,
                                            issue_date: issueDate,
                                            due_date: dueDate
                                        });

                                        studentIndex++;
                                        fetchNextStudentFees();
                                    },
                                    error: function(xhr, status, error) {
                                        $('#generate-demand-slips').removeClass('btn-loading');
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Error',
                                            text: 'Failed to load fees for student: ' + (xhr.responseJSON?.error || error)
                                        });
                                    }
                                });
                            }

                            fetchNextStudentFees();
                        },
                        error: function(xhr, status, error) {
                            $('#generate-demand-slips').removeClass('btn-loading');
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to load students: ' + (xhr.responseJSON?.error || error)
                            });
                        }
                    });
                });
            });

            // Generate PDF
            function generatePDF(demandSlips) {
                // Group slips into sets of 6
                const slipGroups = [];
                for (let i = 0; i < demandSlips.length; i += 6) {
                    slipGroups.push(demandSlips.slice(i, i + 6));
                }

                // Generate HTML for PDF
                let htmlContent = `
                    <!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="UTF-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <title>School Demand Slip</title>
                        <style>
                            * {
                                margin: 0;
                                padding: 0;
                                box-sizing: border-box;
                            }
                            @page {
                                size: A4;
                                margin: 10mm;
                            }
                            body {
                                font-family: 'Arial', sans-serif;
                                font-size: 11px;
                                line-height: 1.3;
                                color: #333;
                                background: white;
                            }
                            .page-container {
                                width: 190mm;
                                height: 277mm;
                                display: grid;
                                grid-template-columns: 1fr 1fr 1fr;
                                grid-template-rows: 1fr 1fr;
                                gap: 5mm;
                                padding-top: 10px;
                                margin: 0 auto;
                            }
                            .demand-slip {
                                border: 2px solid #2563eb;
                                border-radius: 4px;
                                padding: 6px;
                                background: white;
                                position: relative;
                                height: 135mm;
                            }
                            .slip-header {
                                text-align: center;
                                border-bottom: 2px solid #2563eb;
                                padding-bottom: 4px;
                                margin-bottom: 6px;
                                background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
                                margin: -6px -6px 6px -6px;
                                padding: 6px;
                            }
                            .school-name {
                                font-size: 12px;
                                font-weight: bold;
                                color: #1e40af;
                                margin-bottom: 2px;
                            }
                            .school-address {
                                font-size: 8px;
                                color: #64748b;
                                margin-bottom: 3px;
                            }
                            .slip-title {
                                font-size: 10px;
                                font-weight: bold;
                                color: #dc2626;
                                background: #fef2f2;
                                padding: 2px 6px;
                                border-radius: 10px;
                                display: inline-block;
                            }
                            .slip-number {
                                position: absolute;
                                top: 6px;
                                right: 6px;
                                background: #2563eb;
                                color: white;
                                padding: 2px 5px;
                                border-radius: 3px;
                                font-size: 8px;
                                font-weight: bold;
                            }
                            .form-section {
                                margin-bottom: 6px;
                            }
                            .form-row {
                                display: flex;
                                margin-bottom: 3px;
                                align-items: center;
                            }
                            .form-row.two-col {
                                justify-content: space-between;
                            }
                            .form-field {
                                display: flex;
                                align-items: center;
                                flex: 1;
                            }
                            .form-field.half {
                                flex: 0 0 48%;
                            }
                            .form-label {
                                font-weight: bold;
                                color: #374151;
                                margin-right: 3px;
                                min-width: fit-content;
                            }
                            .form-input {
                                border-bottom: 1px solid #9ca3af;
                                flex: 1;
                                padding: 1px 3px;
                                min-height: 14px;
                                margin-left: 3px;
                            }
                            .items-table {
                                width: 100%;
                                border-collapse: collapse;
                                margin: 5px 0;
                                font-size: 9px;
                            }
                            .items-table th {
                                background: #f1f5f9;
                                border: 1px solid #cbd5e1;
                                padding: 3px;
                                text-align: left;
                                font-weight: bold;
                                color: #475569;
                            }
                            .items-table td {
                                border: 1px solid #cbd5e1;
                                padding: 3px;
                                height: 18px;
                            }
                            .items-table .amount-col {
                                text-align: right;
                                width: 50px;
                            }
                            .total-section {
                                background: #fef3c7;
                                border: 1px solid #f59e0b;
                                border-radius: 4px;
                                padding: 5px;
                                margin: 5px 0;
                            }
                            .total-row {
                                display: flex;
                                justify-content: space-between;
                                align-items: center;
                                font-weight: bold;
                                color: #92400e;
                            }
                            .total-amount {
                                font-size: 12px;
                                color: #dc2626;
                            }
                            .footer-note {
                                position: absolute;
                                bottom: 6px;
                                left: 6px;
                                right: 6px;
                                font-size: 7px;
                                color: #6b7280;
                                text-align: center;
                                border-top: 1px solid #e5e7eb;
                                padding-top: 3px;
                            }
                            @media print {
                                body {
                                    -webkit-print-color-adjust: exact;
                                    print-color-adjust: exact;
                                }
                                .page-container {
                                    page-break-inside: avoid;
                                }
                            }
                        </style>
                    </head>
                    <body>
                `;

                slipGroups.forEach((group, pageIndex) => {
                    htmlContent += `<div class="page-container">`;
                    group.forEach((slip, index) => {
                        const slipNumber = `DS-${(pageIndex * 6 + index + 1).toString().padStart(3, '0')}`;
                        htmlContent += `
                            <div class="demand-slip">
                                <div class="slip-number">${slipNumber}</div>
                                <div class="slip-header">
                                    <div class="school-name">${siteSettings.school_name}</div>
                                    <div class="school-address">${siteSettings.address} | Phone: ${siteSettings.phone}</div>
                                    <div class="slip-title">DEMAND SLIP</div>
                                </div>
                                <div class="form-section">
                                    <div class="form-row">
                                        <div class="form-field">
                                            <span class="form-label">Student Name:</span>
                                            <div class="form-input">${slip.student_name}</div>
                                        </div>
                                    </div>
                                    <div class="form-row two-col">
                                        <div class="form-field half">
                                            <span class="form-label">Class:</span>
                                            <div class="form-input">${slip.class_name}</div>
                                        </div>
                                        <div class="form-field half">
                                            <span class="form-label">Roll No:</span>
                                            <div class="form-input">${slip.roll_no}</div>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-field">
                                            <span class="form-label">Parent/Guardian:</span>
                                            <div class="form-input">${slip.father_name}</div>
                                        </div>
                                    </div>
                                </div>
                                <table class="items-table">
                                    <thead>
                                        <tr>
                                            <th>Description</th>
                                            <th>Qty</th>
                                            <th class="amount-col">Amount (₹)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${slip.fees.map(fee => `
                                            <tr>
                                                <td>${fee.description}</td>
                                                <td>${fee.qty}</td>
                                                <td class="amount-col">${fee.amount.toFixed(2)}</td>
                                            </tr>
                                        `).join('')}
                                        ${Array.from({length: 4 - slip.fees.length}).map(() => `
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td class="amount-col"></td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                                <div class="total-section">
                                    <div class="total-row">
                                        <span>TOTAL AMOUNT:</span>
                                        <span class="total-amount">₹ ${slip.total_amount.toFixed(2)}</span>
                                    </div>
                                </div>
                                <div class="form-row two-col">
                                    <div class="form-field half">
                                        <span class="form-label">Due Date:</span>
                                        <div class="form-input">
                                            ${new Date(slip.due_date).toLocaleDateString('en-GB')}
                                        </div>
                                    </div>
                                    <div class="form-field half">
                                        <span class="form-label">Issue Date:</span>
                                        <div class="form-input">
                                            ${new Date(slip.issue_date).toLocaleDateString('en-GB')}
                                        </div>
                                    </div>
                                </div>
                                <div class="footer-note">
                                    Please retain this slip as proof of payment demand. Contact school office for any queries.
                                </div>
                            </div>
                        `;
                    });
                    htmlContent += `</div>`;
                });

                htmlContent += `
                    </body>
                    </html>
                `;

                // Store HTML content in sessionStorage
                sessionStorage.setItem('demandSlipHtml', htmlContent);

                // Open popup window with the demand slip
                const popup = window.open('/app/settings/templates/demand-slip.html', 'DemandSlipPDF', 'width=800,height=600');
                if (!popup) {
                    $('#generate-demand-slips').removeClass('btn-loading');
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Popup blocked. Please allow popups and try again.'
                    });
                    return;
                }

                $('#generate-demand-slips').removeClass('btn-loading');
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Demand slips generated successfully.'
                });
            }

            // Search functionality
            $('#input-search').on('input', function() {
                const search = $(this).val().toLowerCase();
                $('#student_list_table_body tr').each(function() {
                    const name = $(this).find('td:eq(0)').text().toLowerCase();
                    const fatherName = $(this).find('td:eq(1)').text().toLowerCase();
                    const rollNo = $(this).find('td:eq(2)').text().toLowerCase();
                    $(this).toggle(name.includes(search) || fatherName.includes(search) || rollNo.includes(search));
                });
            });

            // Initialize
            loadClasses();

            // Set current month as default
            const currentMonth = new Date().getMonth() + 1;
            $('#month').val([currentMonth]);

            // Set default dates
            const today = new Date().toISOString().split('T')[0];
            const dueDate = new Date();
            dueDate.setDate(dueDate.getDate() + 7);
            $('#issue_date').val(today);
            $('#due_date').val(dueDate.toISOString().split('T')[0]);
        });
    </script>
</body>
</html>