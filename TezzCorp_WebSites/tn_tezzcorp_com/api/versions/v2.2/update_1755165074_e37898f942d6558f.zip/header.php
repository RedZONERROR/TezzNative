<nav class="navbar" id="navbar">
    <div class="nav-container">
        <div class="nav-brand">
            <div class="brand-icon">
                <img style="width: 50px;" src="<?php echo $fetch['logo']; ?>" alt="<?php echo $fetch['school_name']; ?>">
            </div>
            <!--<span class="brand-text">EduVision Academy</span>-->
        </div>
        
        <div class="nav-menu" id="nav-menu">
            <?php
            $current_page = basename($_SERVER['PHP_SELF']);
            ?>
            
            <a href="index.php" class="nav-link <?php if ($current_page == 'index.php') echo 'active'; ?>">Home</a>
            <a href="about.php" class="nav-link <?php if ($current_page == 'about.php') echo 'active'; ?>">About</a>
            <a href="educators.php" class="nav-link <?php if ($current_page == 'educators.php') echo 'active'; ?>">Faculty</a>
            <a href="contact.php" class="nav-link <?php if ($current_page == 'contact.php') echo 'active'; ?>">Contact</a>
            
            <div class="nav-actions">
                <button class="theme-toggle" id="theme-toggle" aria-label="Toggle theme">
                    <i class="fas fa-moon"></i>
                </button>
                <a href="login.php" class="btn btn-primary">
                    <i class="fas fa-user"></i>
                    Login
                </a>
            </div>
        </div>
        
        <button class="mobile-toggle" id="mobile-toggle" aria-label="Toggle menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</nav>