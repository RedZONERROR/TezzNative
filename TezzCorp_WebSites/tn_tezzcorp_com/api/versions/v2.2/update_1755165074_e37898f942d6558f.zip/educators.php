<?php
require_once 'conn.php';

$query = mysqli_query($conn, "SELECT school_name, logo, favicon, email, address, phone, tagline, footer_text, transport_head_mobile, fees_collection_mobile, whatsapp_number, calling_number, facebook_url, twitter_url, instagram_url, instagram_url FROM site_settings");
$fetch = mysqli_fetch_array($query);

$count_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM staff");
$count = mysqli_fetch_assoc($count_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Faculty - <?php echo $fetch['school_name']; ?></title>
    <meta name="description" content="Meet our exceptional faculty at <?php echo $fetch['school_name']; ?>. Experienced educators dedicated to student success and academic excellence.">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="base.css">
    <link rel="stylesheet" href="educators.css">
    
    <!-- Favicon -->
    <?php
    if (!empty($fetch['favicon'])) {
        $favicon = htmlspecialchars($fetch['favicon'], ENT_QUOTES, 'UTF-8');
        $ext = pathinfo($favicon, PATHINFO_EXTENSION);
        
        // Set MIME type based on extension
        $mimeType = 'image/png'; // default
        if ($ext === 'jpg' || $ext === 'jpeg') {
            $mimeType = 'image/jpeg';
        } elseif ($ext === 'ico') {
            $mimeType = 'image/x-icon';
        }
    
        echo '<link rel="icon" type="' . $mimeType . '" href="' . $favicon . '">';
    }
    ?>
</head>
<body>
    <!-- Navigation -->
    <?php include 'header.php'; ?>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <div class="page-header-content">
                <h1>Our Exceptional Faculty</h1>
                <p>Meet the dedicated educators who inspire, guide, and empower our students to achieve their full potential.</p>
            </div>
        </div>
    </section>

    <!-- Department Stats -->
    <section class="section department-stats">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">Faculty Excellence</div>
                <h2 class="section-title">
                    Our Faculty by the 
                    <span class="gradient-text">Numbers</span>
                </h2>
                <p class="section-description">
                    Our diverse and experienced faculty brings together expertise from 
                    around the world to provide exceptional education.
                </p>
            </div>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-chalkboard-teacher"></i>
                    </div>
                    <div class="stat-number">150+</div>
                    <div class="stat-label">Expert Educators</div>
                    <div class="stat-description">Highly qualified teachers with advanced degrees and years of experience</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-graduation-cap"></i>
                    </div>
                    <div class="stat-number">95%</div>
                    <div class="stat-label">Advanced Degrees</div>
                    <div class="stat-description">Faculty members holding Master's or Doctoral degrees in their fields</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-award"></i>
                    </div>
                    <div class="stat-number">25+</div>
                    <div class="stat-label">Teaching Awards</div>
                    <div class="stat-description">Recognition for excellence in education and innovative teaching methods</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-globe"></i>
                    </div>
                    <div class="stat-number">20+</div>
                    <div class="stat-label">Countries</div>
                    <div class="stat-description">International faculty bringing global perspectives to our classrooms</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Educators Section -->
    <section class="section educators-section">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">Meet Our Team</div>
                <h2 class="section-title">
                    Dedicated Educators Committed to 
                    <span class="gradient-text">Excellence</span>
                </h2>
                <p class="section-description">
                    Our faculty members are not just teachers, but mentors, innovators, 
                    and lifelong learners who inspire students every day.
                </p>
            </div>
            
            <div class="educators-filter">
                <button class="filter-btn active" data-filter="all">All Faculty</button>
                <button class="filter-btn" data-filter="elementary">Elementary</button>
                <button class="filter-btn" data-filter="middle">Middle School</button>
                <button class="filter-btn" data-filter="high">High School</button>
                <button class="filter-btn" data-filter="admin">Administration</button>
            </div>
            
            <div class="educators-grid">
                <div class="educator-card" data-category="admin">
                    <div class="educator-image">
                        <div class="image-placeholder">
                            <i class="fas fa-user-tie"></i>
                        </div>
                    </div>
                    <div class="educator-info">
                        <h3 class="educator-name">Dr. Sarah Mitchell</h3>
                        <div class="educator-title">Principal & CEO</div>
                        <p class="educator-description">With over 20 years in educational leadership, Dr. Mitchell brings a vision for innovative learning and student success. She holds a Ph.D. in Educational Administration from Harvard University.</p>
                        <div class="educator-specialties">
                            <h4>Specialties</h4>
                            <div class="specialties-list">
                                <span class="specialty-tag">Educational Leadership</span>
                                <span class="specialty-tag">Curriculum Development</span>
                                <span class="specialty-tag">Strategic Planning</span>
                            </div>
                        </div>
                        <div class="educator-contact">
                            <a href="mailto:s.mitchell@eduvision.edu" class="contact-btn">
                                <i class="fas fa-envelope"></i>
                                Email
                            </a>
                            <a href="#" class="contact-btn">
                                <i class="fas fa-calendar"></i>
                                Schedule
                            </a>
                        </div>
                    </div>
                </div>

                <div class="educator-card" data-category="high">
                    <div class="educator-image">
                        <div class="image-placeholder">
                            <i class="fas fa-flask"></i>
                        </div>
                    </div>
                    <div class="educator-info">
                        <h3 class="educator-name">Prof. Michael Chen</h3>
                        <div class="educator-title">Science Department Head</div>
                        <p class="educator-description">Professor Chen leads our science department with expertise in chemistry and physics. His innovative lab experiments and research projects inspire students to pursue STEM careers.</p>
                        <div class="educator-specialties">
                            <h4>Specialties</h4>
                            <div class="specialties-list">
                                <span class="specialty-tag">Chemistry</span>
                                <span class="specialty-tag">Physics</span>
                                <span class="specialty-tag">Research Methods</span>
                            </div>
                        </div>
                        <div class="educator-contact">
                            <a href="mailto:m.chen@eduvision.edu" class="contact-btn">
                                <i class="fas fa-envelope"></i>
                                Email
                            </a>
                            <a href="#" class="contact-btn">
                                <i class="fas fa-calendar"></i>
                                Schedule
                            </a>
                        </div>
                    </div>
                </div>

                <div class="educator-card" data-category="middle">
                    <div class="educator-image">
                        <div class="image-placeholder">
                            <i class="fas fa-calculator"></i>
                        </div>
                    </div>
                    <div class="educator-info">
                        <h3 class="educator-name">Ms. Emily Rodriguez</h3>
                        <div class="educator-title">Mathematics Teacher</div>
                        <p class="educator-description">Ms. Rodriguez makes mathematics accessible and engaging for all students. Her creative teaching methods and patient approach help students build confidence in mathematical concepts.</p>
                        <div class="educator-specialties">
                            <h4>Specialties</h4>
                            <div class="specialties-list">
                                <span class="specialty-tag">Algebra</span>
                                <span class="specialty-tag">Geometry</span>
                                <span class="specialty-tag">Problem Solving</span>
                            </div>
                        </div>
                        <div class="educator-contact">
                            <a href="mailto:<?php echo $fetch['email']; ?>" class="contact-btn">
                                <i class="fas fa-envelope"></i>
                                Email
                            </a>
                            <a href="contact.php" class="contact-btn">
                                <i class="fas fa-calendar"></i>
                                Schedule
                            </a>
                        </div>
                    </div>
                </div>

                <div class="educator-card" data-category="elementary">
                    <div class="educator-image">
                        <div class="image-placeholder">
                            <i class="fas fa-book-reader"></i>
                        </div>
                    </div>
                    <div class="educator-info">
                        <h3 class="educator-name">Mrs. Jennifer Thompson</h3>
                        <div class="educator-title">Elementary Teacher</div>
                        <p class="educator-description">Mrs. Thompson creates a nurturing and stimulating environment for young learners. Her expertise in early childhood education helps build strong foundations for lifelong learning.</p>
                        <div class="educator-specialties">
                            <h4>Specialties</h4>
                            <div class="specialties-list">
                                <span class="specialty-tag">Early Childhood</span>
                                <span class="specialty-tag">Reading</span>
                                <span class="specialty-tag">Creative Arts</span>
                            </div>
                        </div>
                        <div class="educator-contact">
                            <a href="mailto:<?php echo $fetch['email']; ?>" class="contact-btn">
                                <i class="fas fa-envelope"></i>
                                Email
                            </a>
                            <a href="contact.php" class="contact-btn">
                                <i class="fas fa-calendar"></i>
                                Schedule
                            </a>
                        </div>
                    </div>
                </div>

                <div class="educator-card" data-category="high">
                    <div class="educator-image">
                        <div class="image-placeholder">
                            <i class="fas fa-globe-americas"></i>
                        </div>
                    </div>
                    <div class="educator-info">
                        <h3 class="educator-name">Dr. James Wilson</h3>
                        <div class="educator-title">History & Social Studies</div>
                        <p class="educator-description">Dr. Wilson brings history to life through engaging storytelling and interactive lessons. His passion for global cultures and historical analysis inspires critical thinking in students.</p>
                        <div class="educator-specialties">
                            <h4>Specialties</h4>
                            <div class="specialties-list">
                                <span class="specialty-tag">World History</span>
                                <span class="specialty-tag">Political Science</span>
                                <span class="specialty-tag">Critical Thinking</span>
                            </div>
                        </div>
                        <div class="educator-contact">
                            <a href="mailto:<?php echo $fetch['email']; ?>" class="contact-btn">
                                <i class="fas fa-envelope"></i>
                                Email
                            </a>
                            <a href="contact.php" class="contact-btn">
                                <i class="fas fa-calendar"></i>
                                Schedule
                            </a>
                        </div>
                    </div>
                </div>

                <div class="educator-card" data-category="middle">
                    <div class="educator-image">
                        <div class="image-placeholder">
                            <i class="fas fa-language"></i>
                        </div>
                    </div>
                    <div class="educator-info">
                        <h3 class="educator-name">Ms. Maria Garcia</h3>
                        <div class="educator-title">Language Arts Teacher</div>
                        <p class="educator-description">Ms. Garcia fosters a love for literature and writing in her students. Her bilingual expertise and cultural sensitivity create an inclusive learning environment for all students.</p>
                        <div class="educator-specialties">
                            <h4>Specialties</h4>
                            <div class="specialties-list">
                                <span class="specialty-tag">Literature</span>
                                <span class="specialty-tag">Creative Writing</span>
                                <span class="specialty-tag">ESL</span>
                            </div>
                        </div>
                        <div class="educator-contact">
                            <a href="mailto:<?php echo $fetch['email']; ?>" class="contact-btn">
                                <i class="fas fa-envelope"></i>
                                Email
                            </a>
                            <a href="contact.php" class="contact-btn">
                                <i class="fas fa-calendar"></i>
                                Schedule
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Join Our Team Section -->
    <section class="section join-team">
        <div class="container">
            <div class="join-content">
                <h2 class="join-title">
                    Join Our Team of 
                    <span class="gradient-text">Exceptional Educators</span>
                </h2>
                <p class="join-description">
                    Are you passionate about education and making a difference in students' lives? 
                    We're always looking for talented educators to join our team.
                </p>
                
                <div class="join-features">
                    <div class="join-feature">
                        <i class="fas fa-heart"></i>
                        <h4>Supportive Environment</h4>
                        <p>Work in a collaborative and supportive environment that values your professional growth.</p>
                    </div>
                    <div class="join-feature">
                        <i class="fas fa-graduation-cap"></i>
                        <h4>Professional Development</h4>
                        <p>Access to continuous learning opportunities and professional development programs.</p>
                    </div>
                    <div class="join-feature">
                        <i class="fas fa-users"></i>
                        <h4>Amazing Community</h4>
                        <p>Be part of a community that values innovation, creativity, and student success.</p>
                    </div>
                </div>
                
                <div class="join-actions">
                    <a href="contact.php" class="btn btn-primary btn-large">
                        <i class="fas fa-paper-plane"></i>
                        Apply Now
                    </a>
                    <a href="about.php" class="btn btn-secondary btn-large">
                        <i class="fas fa-info-circle"></i>
                        Learn More
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include 'footer.php'; ?>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="script.js"></script>
</body>
</html>