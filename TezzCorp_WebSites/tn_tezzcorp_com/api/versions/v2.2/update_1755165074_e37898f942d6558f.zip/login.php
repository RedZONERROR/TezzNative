<?php
require_once 'conn.php';

$query = mysqli_query($conn, "SELECT school_name, logo, favicon, email, address, phone, tagline, footer_text, transport_head_mobile, fees_collection_mobile, whatsapp_number, calling_number, facebook_url, twitter_url, instagram_url FROM site_settings");
$fetch = mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo htmlspecialchars($fetch['school_name'], ENT_QUOTES, 'UTF-8'); ?></title>
    <meta name="description" content="Login to <?php echo htmlspecialchars($fetch['school_name'], ENT_QUOTES, 'UTF-8'); ?> portal. Access for students, parents, staff, administrators, and accountants.">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="base.css">
    <link rel="stylesheet" href="login.css?v=2">
    
    <!-- Favicon -->
    <?php
    if (!empty($fetch['favicon'])) {
        $favicon = htmlspecialchars($fetch['favicon'], ENT_QUOTES, 'UTF-8');
        $ext = pathinfo($favicon, PATHINFO_EXTENSION);
        
        // Set MIME type based on extension
        $mimeType = 'image/png'; // default
        if ($ext === 'jpg' || $ext === 'jpeg') {
            $mimeType = 'image/jpeg';
        } elseif ($ext === 'ico') {
            $mimeType = 'image/x-icon';
        }
    
        echo '<link rel="icon" type="' . $mimeType . '" href="' . $favicon . '">';
    }
    ?>
</head>
<body>
    <div class="login-page">
        <!-- Back to Home Link -->
        <div class="back-to-home">
            <a href="index.php">
                <i class="fas fa-arrow-left"></i>
                Back to Home
            </a>
        </div>

        <div class="login-container">
            <div class="login-content">
                <div class="login-image">
                    <div class="login-shape"></div>
                    <div class="login-text">
                        <h2>Welcome to <?php echo htmlspecialchars($fetch['school_name'], ENT_QUOTES, 'UTF-8'); ?></h2>
                        <p>Access your personalized portal to stay connected with your educational journey. Our secure platform provides easy access to all your academic resources.</p>
                        <div class="login-features">
                            <div class="feature-item">
                                <i class="fas fa-shield-alt"></i>
                                <span>Secure Access</span>
                            </div>
                            <div class="feature-item">
                                <i class="fas fa-clock"></i>
                                <span>24/7 Availability</span>
                            </div>
                            <div class="feature-item">
                                <i class="fas fa-mobile-alt"></i>
                                <span>Mobile Friendly</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="login-form-container">
                    <div class="login-tabs">
                        <button class="tab-btn active" data-tab="admin">Admin</button>
                        <button class="tab-btn" data-tab="accountant">Accountant</button>
                    </div>

                    <!-- Admin Login Form -->
                    <form class="login-form active" id="admin-form">
                        <h3>Admin Login</h3>
                        <div class="form-group">
                            <label for="admin-username">Admin Username</label>
                            <div class="input-group">
                                <i class="fas fa-user-shield"></i>
                                <input type="text" id="admin-username" name="username" placeholder="Enter admin username" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="admin-password">Password</label>
                            <div class="input-group">
                                <i class="fas fa-lock"></i>
                                <input type="password" id="admin-password" name="password" placeholder="Enter your password" required>
                                <span onclick="togglePassword('admin-password')" class="password-toggle"><i class="fas fa-eye"></i></span>
                            </div>
                        </div>
                        
                        <div class="form-options">
                            <label class="checkbox-container">
                                <input type="checkbox" name="remember">
                                Remember me
                            </label>
                            <a href="#" class="forgot-password">Forgot Password?</a>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-large">
                            <i class="fas fa-sign-in-alt"></i>
                            Admin Login
                        </button>
                        
                        <div class="login-help">
                            <p>System issues? <a href="contact.php">Contact IT</a></p>
                        </div>
                    </form>

                    <!-- Accountant Login Form -->
                    <form class="login-form" id="accountant-form">
                        <h3>Accountant Login</h3>
                        <div class="form-group">
                            <label for="accountant-email">Email Address</label>
                            <div class="input-group">
                                <i class="fas fa-calculator"></i>
                                <input type="email" id="accountant-username" name="username" placeholder="Enter your email" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="accountant-password">Password</label>
                            <div class="input-group">
                                <i class="fas fa-lock"></i>
                                <input type="password" id="accountant-password" name="password" placeholder="Enter your password" required>
                                <span onclick="togglePassword('accountant-password')" class="password-toggle"><i class="fas fa-eye"></i></span>
                            </div>
                        </div>
                        
                        <div class="form-options">
                            <label class="checkbox-container">
                                <input type="checkbox" name="remember">
                                Remember me
                            </label>
                            <a href="#" class="forgot-password">Forgot Password?</a>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-large">
                            <i class="fas fa-sign-in-alt"></i>
                            Login
                        </button>
                        
                        <div class="login-help">
                            <p>Financial queries? <a href="contact.php">Contact Finance</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Password toggle functionality
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const icon = input.nextElementSibling.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }

        // Tab switching
        const tabs = document.querySelectorAll('.tab-btn');
        const forms = document.querySelectorAll('.login-form');

        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                tabs.forEach(t => t.classList.remove('active'));
                forms.forEach(f => f.classList.remove('active'));
                
                tab.classList.add('active');
                document.getElementById(`${tab.dataset.tab}-form`).classList.add('active');
            });
        });

        // Login form submissions with AJAX and feedback
        const loginForms = document.querySelectorAll('.login-form');
        loginForms.forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();

                const submitButton = this.querySelector('button[type="submit"]');
                const originalText = submitButton.textContent;

                submitButton.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Logging in...`;
                submitButton.disabled = true;

                // Animation for button
                gsap.to(submitButton, {
                    scale: 0.98,
                    duration: 0.1,
                    yoyo: true,
                    repeat: 1
                });

                // Prepare form data
                const formData = new FormData(this);
                const data = {};
                formData.forEach((value, key) => {
                    data[key] = value;
                });

                // Determine endpoint based on form
                const endpoint = this.id === 'admin-form' ? 'api/login.php' : 'api/login.php';

                // Send AJAX request
                fetch(endpoint, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data),
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Redirect to dashboard
                        window.location.href = 'app/';
                    } else {
                        // Show error message
                        const demoMessage = document.createElement('div');
                        demoMessage.className = 'demo-message';
                        demoMessage.textContent = data.message || 'Demo: Login failed';
                        demoMessage.style.cssText = `
                            position: fixed;
                            top: 50%;
                            left: 50%;
                            transform: translate(-50%, -50%);
                            background: var(--bg-primary);
                            color: var(--text-primary);
                            padding: 2rem;
                            border-radius: 15px;
                            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
                            z-index: 10000;
                            border: 1px solid var(--border-color);
                            text-align: center;
                            min-width: 300px;
                        `;

                        document.body.appendChild(demoMessage);

                        gsap.fromTo(demoMessage,
                            { scale: 0.8, opacity: 0 },
                            { scale: 1, opacity: 1, duration: 0.3, ease: 'back.out(1.7)' }
                        );

                        setTimeout(() => {
                            gsap.to(demoMessage, {
                                scale: 0.8,
                                opacity: 0,
                                duration: 0.2,
                                ease: 'power2.in',
                                onComplete: () => {
                                    document.body.removeChild(demoMessage);
                                }
                            });
                        }, 2000);
                    }
                    submitButton.innerHTML = originalText;
                    submitButton.disabled = false;
                })
                .catch(error => {
                    console.error('Error:', error);
                    const demoMessage = document.createElement('div');
                    demoMessage.className = 'demo-message';
                    demoMessage.textContent = 'An error occurred. Please try again.';
                    demoMessage.style.cssText = `
                        position: fixed;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        background: var(--bg-primary);
                        color: var(--text-primary);
                        padding: 2rem;
                        border-radius: 15px;
                        box-shadow: 0 20px 40px rgba(0,0,0,0.2);
                        z-index: 10000;
                        border: 1px solid var(--border-color);
                        text-align: center;
                        min-width: 300px;
                    `;

                    document.body.appendChild(demoMessage);

                    gsap.fromTo(demoMessage,
                        { scale: 0.8, opacity: 0 },
                        { scale: 1, opacity: 1, duration: 0.3, ease: 'back.out(1.7)' }
                    );

                    setTimeout(() => {
                        gsap.to(demoMessage, {
                            scale: 0.8,
                            opacity: 0,
                            duration: 0.2,
                            ease: 'power2.in',
                            onComplete: () => {
                                document.body.removeChild(demoMessage);
                            }
                        });
                    }, 2000);

                    submitButton.innerHTML = originalText;
                    submitButton.disabled = false;
                });
            });
        });
    </script>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="script.js"></script>
</body>
</html>