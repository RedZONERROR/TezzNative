// Performance optimization
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    new EduVisionApp();
});

function togglePassword(id) {
    const input = document.getElementById(id);
    const icon = input.nextElementSibling.querySelector('i');

    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Theme Functions with Enhanced Transitions
class EduVisionApp {
    constructor() {
        // Class properties for state management
        this.currentHeroSlide = 0;
        this.heroSlides = [];
        this.heroAutoPlay = null;
        this.currentTestimonialSlide = 0;
        this.testimonialSlides = [];
        this.testimonialAutoPlay = null;
        this.isAnimating = false;
        this.startX = 0;
        this.endX = 0;
        this.startY = 0;
        this.endY = 0;

        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeComponents();
        this.setupIntersectionObserver();
        this.initializeCounters();
        this.setupTheme();
    }

    setupEventListeners() {
        // Mobile menu toggle
        const mobileToggle = document.getElementById('mobile-toggle');
        const navMenu = document.getElementById('nav-menu');

        if (mobileToggle && navMenu) {
            mobileToggle.addEventListener('click', () => {
                navMenu.classList.toggle('active');
                mobileToggle.classList.toggle('active');
            });

            // Close menu when clicking on links
            navMenu.querySelectorAll('.nav-link').forEach(link => {
                link.addEventListener('click', () => {
                    navMenu.classList.remove('active');
                    mobileToggle.classList.remove('active');
                });
            });
        }

        // Navbar scroll effect
        const navbar = document.getElementById('navbar');
        if (navbar) {
            window.addEventListener('scroll', this.handleNavbarScroll.bind(this));
        }

        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', this.handleSmoothScroll.bind(this));
        });

        // Scroll indicator (if present on index.html)
        const scrollIndicator = document.querySelector('.scroll-indicator');
        if (scrollIndicator) {
            scrollIndicator.addEventListener('click', () => {
                document.querySelector('#programs').scrollIntoView({
                    behavior: 'smooth'
                });
            });
        }
    }

    handleNavbarScroll() {
        const navbar = document.getElementById('navbar');
        if (navbar) {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        }
    }

    handleSmoothScroll(e) {
        e.preventDefault();
        const target = document.querySelector(e.currentTarget.getAttribute('href'));
        if (target) {
            const offsetTop = target.offsetTop - 80; // Adjust for fixed navbar height
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    }

    initializeComponents() {
        this.initHeroSlider();
        this.initTestimonialSlider();
        this.initGallery();
        this.initFAQ();
        this.initLoginTabs();
        this.initContactForm();
        this.initLazyLoading();
        this.initParallax();
        this.initEducatorFilters(); // New: for educators.html
    }

    initHeroSlider() {
        this.heroSlides = document.querySelectorAll('.hero-slide');
        const prevBtn = document.getElementById('hero-prev');
        const nextBtn = document.getElementById('hero-next');
        const dots = document.querySelectorAll('.hero-dot');

        if (this.heroSlides.length === 0) return;

        // Initialize first slide
        this.updateHeroSlider();

        // Event listeners with enhanced feedback
        if (prevBtn) {
            prevBtn.addEventListener('click', () => {
                if (!this.isAnimating) {
                    gsap.to(prevBtn, { scale: 0.9, duration: 0.1, yoyo: true, repeat: 1 });
                    this.prevHeroSlide();
                }
            });
        }

        if (nextBtn) {
            nextBtn.addEventListener('click', () => {
                if (!this.isAnimating) {
                    gsap.to(nextBtn, { scale: 0.9, duration: 0.1, yoyo: true, repeat: 1 });
                    this.nextHeroSlide();
                }
            });
        }

        dots.forEach((dot, index) => {
            dot.addEventListener('click', () => {
                if (!this.isAnimating && index !== this.currentHeroSlide) {
                    gsap.to(dot, { scale: 0.8, duration: 0.1, yoyo: true, repeat: 1 });
                    this.goToHeroSlide(index);
                }
            });
        });

        // Auto-play with enhanced controls
        this.startHeroAutoPlay();

        // Pause on hover with smooth transition
        const heroSection = document.querySelector('.hero');
        if (heroSection) {
            heroSection.addEventListener('mouseenter', () => {
                this.stopHeroAutoPlay();
                gsap.to('.hero-controls', { opacity: 1, duration: 0.3 });
            });

            heroSection.addEventListener('mouseleave', () => {
                this.startHeroAutoPlay();
                gsap.to('.hero-controls', { opacity: 0.7, duration: 0.3 });
            });
        }

        // Enhanced touch/swipe support
        if (heroSection) {
            heroSection.addEventListener('touchstart', (e) => {
                this.startX = e.touches[0].clientX;
                this.startY = e.touches[0].clientY;
            }, { passive: true });

            heroSection.addEventListener('touchend', (e) => {
                this.endX = e.changedTouches[0].clientX;
                this.endY = e.changedTouches[0].clientY;
                this.handleHeroSwipe();
            }, { passive: true });
        }
    }

    handleHeroSwipe() {
        const threshold = 50;
        const diffX = this.startX - this.endX;
        const diffY = Math.abs(this.startY - this.endY);

        // Only trigger if horizontal swipe is greater than vertical
        if (Math.abs(diffX) > threshold && diffY < threshold * 2) {
            if (diffX > 0) {
                this.nextHeroSlide();
            } else {
                this.prevHeroSlide();
            }
        }
    }

    updateHeroSlider() {
        if (this.isAnimating) return;
        this.isAnimating = true;

        const tl = gsap.timeline({
            onComplete: () => {
                this.isAnimating = false;
            }
        });

        // Fade out current slide
        this.heroSlides.forEach((slide, index) => {
            if (index !== this.currentHeroSlide && slide.classList.contains('active')) {
                tl.to(slide, { opacity: 0, duration: 0.5, ease: 'power2.out' }, 0);
            }
        });

        // Fade in new slide
        const activeSlide = this.heroSlides[this.currentHeroSlide];
        tl.to(activeSlide, { opacity: 1, duration: 0.8, ease: 'power2.out' }, 0.3);

        // Update classes
        this.heroSlides.forEach((slide, index) => {
            slide.classList.toggle('active', index === this.currentHeroSlide);
        });

        const dots = document.querySelectorAll('.hero-dot');
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === this.currentHeroSlide);
            if (index === this.currentHeroSlide) {
                gsap.to(dot, { scale: 1.3, duration: 0.3, ease: 'back.out(1.7)' });
            } else {
                gsap.to(dot, { scale: 1, duration: 0.3, ease: 'power2.out' });
            }
        });

        // Animate slide content with premium effects
        if (activeSlide) {
            const title = activeSlide.querySelector('.hero-title');
            const subtitle = activeSlide.querySelector('.hero-subtitle');
            const buttons = activeSlide.querySelector('.hero-buttons');
            const elements = activeSlide.querySelectorAll('.floating-element');

            tl.fromTo(title,
                { y: 60, opacity: 0, rotationX: 15 },
                { y: 0, opacity: 1, rotationX: 0, duration: 1, ease: 'power3.out' }, 0.5
            );

            tl.fromTo(subtitle,
                { y: 40, opacity: 0 },
                { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out' }, 0.7
            );

            tl.fromTo(buttons,
                { y: 30, opacity: 0, scale: 0.9 },
                { y: 0, opacity: 1, scale: 1, duration: 0.6, ease: 'back.out(1.7)' }, 0.9
            );

            tl.fromTo(elements,
                { scale: 0, opacity: 0, rotation: -180 },
                { scale: 1, opacity: 1, rotation: 0, duration: 1, ease: 'back.out(1.7)', stagger: 0.2 }, 1.1
            );
        }
    }

    nextHeroSlide() {
        this.currentHeroSlide = (this.currentHeroSlide + 1) % this.heroSlides.length;
        this.updateHeroSlider();
    }

    prevHeroSlide() {
        this.currentHeroSlide = (this.currentHeroSlide - 1 + this.heroSlides.length) % this.heroSlides.length;
        this.updateHeroSlider();
    }

    goToHeroSlide(index) {
        this.currentHeroSlide = index;
        this.updateHeroSlider();
    }

    startHeroAutoPlay() {
        this.stopHeroAutoPlay();
        if (!prefersReducedMotion) {
            this.heroAutoPlay = setInterval(this.nextHeroSlide.bind(this), 7000);
        }
    }

    stopHeroAutoPlay() {
        if (this.heroAutoPlay) {
            clearInterval(this.heroAutoPlay);
            this.heroAutoPlay = null;
        }
    }

    initTestimonialSlider() {
        const slider = document.getElementById('testimonials-slider');
        const prevBtn = document.getElementById('testimonial-prev');
        const nextBtn = document.getElementById('testimonial-next');
        const dots = document.querySelectorAll('.testimonials-dots .dot');

        if (!slider) return;

        this.testimonialSlides = slider.querySelectorAll('.testimonial-card');
        const totalSlides = this.testimonialSlides.length;

        const showSlide = (index) => {
            this.testimonialSlides.forEach((slide, i) => {
                slide.classList.toggle('active', i === index);
            });

            dots.forEach((dot, i) => {
                dot.classList.toggle('active', i === index);
            });
        };

        const nextSlide = () => {
            this.currentTestimonialSlide = (this.currentTestimonialSlide + 1) % totalSlides;
            showSlide(this.currentTestimonialSlide);
        };

        const prevSlide = () => {
            this.currentTestimonialSlide = (this.currentTestimonialSlide - 1 + totalSlides) % totalSlides;
            showSlide(this.currentTestimonialSlide);
        };

        // Event listeners
        if (nextBtn) nextBtn.addEventListener('click', nextSlide);
        if (prevBtn) prevBtn.addEventListener('click', prevSlide);

        dots.forEach((dot, index) => {
            dot.addEventListener('click', () => {
                this.currentTestimonialSlide = index;
                showSlide(this.currentTestimonialSlide);
            });
        });

        // Auto-play
        this.testimonialAutoPlay = setInterval(nextSlide, 6000);

        // Initialize first slide
        showSlide(0);
    }

    setupIntersectionObserver() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Apply AOS-like animation
                    gsap.fromTo(entry.target,
                        { opacity: 0, y: 30 },
                        { opacity: 1, y: 0, duration: 0.6, ease: 'power2.out' }
                    );
                    observer.unobserve(entry.target); // Stop observing once animated
                }
            });
        }, observerOptions);

        // Observe elements with data-aos attribute
        document.querySelectorAll('[data-aos]').forEach(el => {
            // Set initial state for elements that will be animated by AOS
            gsap.set(el, { opacity: 0, y: 30 });
            observer.observe(el);
        });
    }

    initializeCounters() {
        const counters = document.querySelectorAll('.stat-number');

        const animateCounter = (counter) => {
            const target = parseInt(counter.getAttribute('data-target'));
            const duration = 2000;
            const step = target / (duration / 16); // ~60 frames per second

            let current = 0;
            const updateCounter = () => {
                if (current < target) {
                    current += step;
                    counter.textContent = Math.floor(current);
                    requestAnimationFrame(updateCounter);
                } else {
                    counter.textContent = target;
                }
            };

            updateCounter();
        };

        const counterObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounter(entry.target);
                    counterObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });

        counters.forEach(counter => {
            counter.textContent = '0'; // Initialize to 0
            counterObserver.observe(counter);
        });
    }

    setupTheme() {
        const themeToggle = document.getElementById('theme-toggle');
        const currentTheme = localStorage.getItem('theme') || 'light';

        // Set initial theme
        document.documentElement.setAttribute('data-theme', currentTheme);
        this.updateThemeIcon(currentTheme);

        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                const currentTheme = document.documentElement.getAttribute('data-theme');
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

                document.documentElement.setAttribute('data-theme', newTheme);
                localStorage.setItem('theme', newTheme);
                this.updateThemeIcon(newTheme);

                // Animate theme transition (body background)
                gsap.to('body', {
                    duration: 0.3,
                    ease: 'power2.out',
                    onComplete: () => {
                        document.body.classList.remove('theme-transitioning');
                    }
                });

                // Animate toggle button
                gsap.to(themeToggle, {
                    rotation: 360,
                    duration: 0.5,
                    ease: 'back.out(1.7)'
                });
            });
        }
    }

    updateThemeIcon(theme) {
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            const icon = themeToggle.querySelector('i');
            icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    initGallery() {
        const lightbox = document.getElementById('lightbox');
        if (!lightbox) return;

        let currentImageIndex = 0;
        let galleryImages = [];

        const updateGalleryImages = () => {
            const visibleItems = document.querySelectorAll('.gallery-item:not([style*="display: none"])');
            galleryImages = Array.from(visibleItems).map(item => ({
                src: item.querySelector('img')?.dataset.src || '', // Use data-src for lazy loaded images
                title: item.querySelector('.gallery-info h3')?.textContent || '',
                description: item.querySelector('.gallery-info p')?.textContent || ''
            }));
        }

        updateGalleryImages(); // Initial population

        // Open lightbox
        document.querySelectorAll('.gallery-item').forEach((item, index) => {
            item.addEventListener('click', () => {
                currentImageIndex = Array.from(document.querySelectorAll('.gallery-item:not([style*="display: none"])')).indexOf(item);
                showLightboxImage(currentImageIndex);
            });
        });

        const showLightboxImage = (index) => {
            if (galleryImages.length === 0) return;
            currentImageIndex = index;
            const img = document.getElementById('lightbox-img');
            const title = document.getElementById('lightbox-title');
            const description = document.getElementById('lightbox-description');

            img.src = galleryImages[currentImageIndex].src;
            title.textContent = galleryImages[currentImageIndex].title;
            description.textContent = galleryImages[currentImageIndex].description;

            lightbox.classList.add('active');
        };

        // Close lightbox
        document.querySelector('.lightbox-close')?.addEventListener('click', () => {
            lightbox.classList.remove('active');
        });

        // Navigate lightbox
        document.getElementById('lightbox-prev')?.addEventListener('click', () => {
            currentImageIndex = (currentImageIndex - 1 + galleryImages.length) % galleryImages.length;
            showLightboxImage(currentImageIndex);
        });

        document.getElementById('lightbox-next')?.addEventListener('click', () => {
            currentImageIndex = (currentImageIndex + 1) % galleryImages.length;
            showLightboxImage(currentImageIndex);
        });

        // Enhanced filter functionality
        const filterButtons = document.querySelectorAll('.gallery-filter .filter-btn');
        const galleryItems = document.querySelectorAll('.gallery-grid .gallery-item');

        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                const filter = this.getAttribute('data-filter');

                // Update active button with animation
                filterButtons.forEach(btn => {
                    btn.classList.remove('active');
                    gsap.to(btn, { scale: 1, duration: 0.2 });
                });
                this.classList.add('active');
                gsap.to(this, { scale: 1.05, duration: 0.2, yoyo: true, repeat: 1 });

                // Filter items with staggered animation
                const tl = gsap.timeline();

                galleryItems.forEach((item, index) => {
                    const category = item.getAttribute('data-category');
                    const shouldShow = filter === 'all' || category === filter;

                    if (shouldShow) {
                        item.style.display = 'block';
                        tl.fromTo(item,
                            { scale: 0.8, opacity: 0, y: 20 },
                            {
                                scale: 1,
                                opacity: 1,
                                y: 0,
                                duration: 0.4,
                                ease: 'back.out(1.7)'
                            }, index * 0.05
                        );
                    } else {
                        tl.to(item, {
                            scale: 0.8,
                            opacity: 0,
                            duration: 0.3,
                            ease: 'power2.out',
                            onComplete: () => {
                                item.style.display = 'none';
                            }
                        }, 0);
                    }
                });

                // Update galleryImages array after filtering is complete
                setTimeout(updateGalleryImages, 500);
            });
        });
    }

    initFAQ() {
        const faqItems = document.querySelectorAll('.faq-item');

        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            const answer = item.querySelector('.faq-answer');

            if (question && answer) {
                question.addEventListener('click', function() {
                    const isActive = item.classList.contains('active');

                    // Close all other items with animation
                    faqItems.forEach(otherItem => {
                        if (otherItem !== item && otherItem.classList.contains('active')) {
                            otherItem.classList.remove('active');
                            const otherAnswer = otherItem.querySelector('.faq-answer');
                            gsap.to(otherAnswer, { height: 0, duration: 0.3, ease: 'power2.out' });
                            gsap.to(otherItem.querySelector('.faq-question i'), { rotation: 0, duration: 0.3 });
                        }
                    });

                    // Toggle current item with enhanced animation
                    if (!isActive) {
                        item.classList.add('active');
                        gsap.fromTo(answer,
                            { height: 0 },
                            { height: 'auto', duration: 0.4, ease: 'power2.out' }
                        );
                        gsap.to(question.querySelector('i'), { rotation: 45, duration: 0.3 });
                    } else {
                        item.classList.remove('active');
                        gsap.to(answer, { height: 0, duration: 0.3, ease: 'power2.out' });
                        gsap.to(question.querySelector('i'), { rotation: 0, duration: 0.3 });
                    }
                });
            }
        });
    }

    initLoginTabs() {
        const tabButtons = document.querySelectorAll('.tab-btn');
        const loginForms = document.querySelectorAll('.login-form');

        tabButtons.forEach(button => {
            button.addEventListener('click', function() {
                const targetTab = this.getAttribute('data-tab');

                // Update active tab button with animation
                tabButtons.forEach(btn => {
                    btn.classList.remove('active');
                    gsap.to(btn, { scale: 1, duration: 0.2 });
                });
                this.classList.add('active');
                gsap.to(this, { scale: 1.02, duration: 0.2, yoyo: true, repeat: 1 });

                // Show corresponding form with fade animation
                loginForms.forEach(form => {
                    if (form.classList.contains('active')) {
                        gsap.to(form, {
                            opacity: 0,
                            y: -20,
                            duration: 0.2,
                            onComplete: () => {
                                form.classList.remove('active');
                            }
                        });
                    }

                    if (form.id === `${targetTab}-form`) {
                        setTimeout(() => {
                            form.classList.add('active');
                            gsap.fromTo(form,
                                { opacity: 0, y: 20 },
                                { opacity: 1, y: 0, duration: 0.3, ease: 'power2.out' }
                            );
                        }, 200);
                    }
                });
            });
        });
    }

    initContactForm() {
        const contactForm = document.getElementById('contact-form');

        if (contactForm) {
            // Add input focus animations
            const inputs = contactForm.querySelectorAll('input, textarea, select');
            inputs.forEach(input => {
                input.addEventListener('focus', () => {
                    gsap.to(input, { scale: 1.02, duration: 0.2, ease: 'power2.out' });
                });

                input.addEventListener('blur', () => {
                    gsap.to(input, { scale: 1, duration: 0.2, ease: 'power2.out' });
                });
            });

            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();

                const submitButton = this.querySelector('button[type="submit"]');
                const originalText = submitButton.textContent;

                // Enhanced loading animation
                submitButton.textContent = 'Sending...';
                submitButton.disabled = true;

                gsap.to(submitButton, {
                    scale: 0.95,
                    duration: 0.1,
                    yoyo: true,
                    repeat: 1
                });

                // Simulate form submission with progress
                let progress = 0;
                const progressInterval = setInterval(() => {
                    progress += Math.random() * 30;
                    if (progress >= 100) {
                        progress = 100;
                        clearInterval(progressInterval);

                        // Success animation
                        gsap.to(submitButton, {
                            backgroundColor: '#10b981',
                            duration: 0.3,
                            ease: 'power2.out'
                        });

                        submitButton.textContent = 'Sent Successfully!';

                        setTimeout(() => {
                            // Show success message
                            const successMessage = document.createElement('div');
                            successMessage.className = 'success-message';
                            successMessage.textContent = 'Thank you for your message! We will get back to you soon.';
                            successMessage.style.cssText = `
                                position: fixed;
                                top: 20px;
                                right: 20px;
                                background: #10b981;
                                color: white;
                                padding: 1rem 2rem;
                                border-radius: 10px;
                                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
                                z-index: 10000;
                                transform: translateX(400px);
                            `;

                            document.body.appendChild(successMessage);

                            gsap.to(successMessage, {
                                x: -400,
                                duration: 0.5,
                                ease: 'back.out(1.7)'
                            });

                            setTimeout(() => {
                                gsap.to(successMessage, {
                                    x: 400,
                                    duration: 0.3,
                                    ease: 'power2.in',
                                    onComplete: () => {
                                        document.body.removeChild(successMessage);
                                    }
                                });
                            }, 3000);

                            this.reset(); // This refers to the form element itself, which has a .reset() method
                            submitButton.textContent = originalText;
                            submitButton.disabled = false;
                            gsap.to(submitButton, {
                                backgroundColor: '',
                                duration: 0.3
                            });
                        }, 1000);
                    }
                }, 100);
            });
        }

        // Login form submissions with enhanced feedback (present on login.html)
        const loginForms = document.querySelectorAll('.login-form');
        loginForms.forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();

                const submitButton = this.querySelector('button[type="submit"]');
                const originalText = submitButton.textContent;

                submitButton.textContent = 'Logging in...';
                submitButton.disabled = true;

                // Add loading spinner
                const spinner = document.createElement('i');
                spinner.className = 'fas fa-spinner fa-spin';
                spinner.style.marginRight = '8px';
                submitButton.prepend(spinner);

                gsap.to(submitButton, {
                    scale: 0.98,
                    duration: 0.1,
                    yoyo: true,
                    repeat: 1
                });

                setTimeout(() => {
                    // Remove spinner
                    submitButton.removeChild(spinner);

                    // Show demo message
                    const demoMessage = document.createElement('div');
                    demoMessage.className = 'demo-message';
                    demoMessage.textContent = 'Demo: Login functionality would redirect to dashboard';
                    demoMessage.style.cssText = `
                        position: fixed;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        background: var(--bg-primary);
                        color: var(--text-primary);
                        padding: 2rem;
                        border-radius: 15px;
                        box-shadow: 0 20px 40px rgba(0,0,0,0.2);
                        z-index: 10000;
                        border: 1px solid var(--border-color);
                        text-align: center;
                        min-width: 300px;
                    `;

                    document.body.appendChild(demoMessage);

                    gsap.fromTo(demoMessage,
                        { scale: 0.8, opacity: 0 },
                        { scale: 1, opacity: 1, duration: 0.3, ease: 'back.out(1.7)' }
                    );

                    setTimeout(() => {
                        gsap.to(demoMessage, {
                            scale: 0.8,
                            opacity: 0,
                            duration: 0.2,
                            ease: 'power2.in',
                            onComplete: () => {
                                document.body.removeChild(demoMessage);
                            }
                        });
                    }, 2000);

                    submitButton.textContent = originalText;
                    submitButton.disabled = false;
                }, 2000);
            });
        });
    }

    initLazyLoading() {
        const images = document.querySelectorAll('img[data-src]');

        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.remove('lazy');
                    imageObserver.unobserve(img);
                }
            });
        });

        images.forEach(img => imageObserver.observe(img));
    }

    initParallax() {
        if (prefersReducedMotion) return;

        const parallaxElements = document.querySelectorAll('.hero-shape'); // Only on index.html

        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const rate = scrolled * -0.5;

            parallaxElements.forEach((element, index) => {
                const speed = (index + 1) * 0.3;
                gsap.to(element, {
                    y: rate * speed,
                    duration: 0.1,
                    ease: 'none'
                });
            });
        });
    }

    initEducatorFilters() {
        const filterButtons = document.querySelectorAll('.educators-filter .filter-btn');
        const educatorCards = document.querySelectorAll('.educators-grid .educator-card');

        if (filterButtons.length === 0 || educatorCards.length === 0) return;

        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                const filter = this.getAttribute('data-filter');

                filterButtons.forEach(btn => {
                    btn.classList.remove('active');
                    gsap.to(btn, { scale: 1, duration: 0.2 });
                });
                this.classList.add('active');
                gsap.to(this, { scale: 1.05, duration: 0.2, yoyo: true, repeat: 1 });

                const tl = gsap.timeline();

                educatorCards.forEach((card, index) => {
                    const category = card.getAttribute('data-category');
                    const shouldShow = filter === 'all' || category === filter;

                    if (shouldShow) {
                        card.style.display = 'block';
                        tl.fromTo(card,
                            { scale: 0.8, opacity: 0, y: 20 },
                            {
                                scale: 1,
                                opacity: 1,
                                y: 0,
                                duration: 0.4,
                                ease: 'back.out(1.7)'
                            }, index * 0.05
                        );
                    } else {
                        tl.to(card, {
                            scale: 0.8,
                            opacity: 0,
                            duration: 0.3,
                            ease: 'power2.out',
                            onComplete: () => {
                                card.style.display = 'none';
                            }
                        }, 0);
                    }
                });
            });
        });
    }
}

// Utility functions
const debounce = (func, wait) => {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
};

const throttle = (func, limit) => {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
};

// Handle page load
window.addEventListener('load', () => {
    document.body.classList.add('loaded');
});

// Handle resize events
window.addEventListener('resize', debounce(() => {
    // Handle responsive adjustments
}, 250));

// Performance monitoring
if ('performance' in window) {
    window.addEventListener('load', () => {
        setTimeout(() => {
            const perfData = performance.getEntriesByType('navigation')[0];
            if (perfData) {
                console.log('Page load time:', Math.round(perfData.loadEventEnd - perfData.loadEventStart), 'ms');
            }
        }, 0);
    });
}