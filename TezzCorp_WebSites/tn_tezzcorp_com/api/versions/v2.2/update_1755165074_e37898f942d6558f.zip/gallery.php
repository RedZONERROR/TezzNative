<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery - EduVision Academy</title>
    <meta name="description" content="Explore our campus life through photos and videos. See our facilities, events, and student activities at EduVision Academy.">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="base.css">
    <link rel="stylesheet" href="gallery.css">
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🎓</text></svg>">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar" id="navbar">
        <div class="nav-container">
            <div class="nav-brand">
                <div class="brand-icon">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <span class="brand-text">EduVision Academy</span>
            </div>
            
            <div class="nav-menu" id="nav-menu">
                <a href="index.php" class="nav-link">Home</a>
                <a href="about.php" class="nav-link">About</a>
                <a href="programs.php" class="nav-link">Programs</a>
                <a href="educators.php" class="nav-link">Faculty</a>
                <a href="gallery.php" class="nav-link active">Gallery</a>
                <a href="contact.php" class="nav-link">Contact</a>
                
                <div class="nav-actions">
                    <button class="theme-toggle" id="theme-toggle" aria-label="Toggle theme">
                        <i class="fas fa-moon"></i>
                    </button>
                    <a href="login.php" class="btn btn-primary">
                        <i class="fas fa-user"></i>
                        Login
                    </a>
                </div>
            </div>
            
            <button class="mobile-toggle" id="mobile-toggle" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </nav>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <div class="page-header-content">
                <h1>Campus Gallery</h1>
                <p>Explore our vibrant campus life, facilities, and memorable moments through our photo gallery.</p>
            </div>
        </div>
    </section>

    <!-- Gallery Stats -->
    <section class="section gallery-stats">
        <div class="container">
            <div class="gallery-stats-grid">
                <div class="gallery-stat">
                    <div class="gallery-stat-icon">
                        <i class="fas fa-camera"></i>
                    </div>
                    <div class="gallery-stat-number">500+</div>
                    <div class="gallery-stat-label">Photos</div>
                </div>
                <div class="gallery-stat">
                    <div class="gallery-stat-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="gallery-stat-number">50+</div>
                    <div class="gallery-stat-label">Events</div>
                </div>
                <div class="gallery-stat">
                    <div class="gallery-stat-icon">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="gallery-stat-number">25+</div>
                    <div class="gallery-stat-label">Facilities</div>
                </div>
                <div class="gallery-stat">
                    <div class="gallery-stat-icon">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <div class="gallery-stat-number">100+</div>
                    <div class="gallery-stat-label">Achievements</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Gallery Section -->
    <section class="section gallery-section">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">Our Gallery</div>
                <h2 class="section-title">
                    Capturing Moments of 
                    <span class="gradient-text">Excellence</span>
                </h2>
                <p class="section-description">
                    From classroom activities to special events, explore the vibrant 
                    life at EduVision Academy through our comprehensive gallery.
                </p>
            </div>
            
            <div class="gallery-filter">
                <button class="filter-btn active" data-filter="all">All Photos</button>
                <button class="filter-btn" data-filter="campus">Campus</button>
                <button class="filter-btn" data-filter="events">Events</button>
                <button class="filter-btn" data-filter="sports">Sports</button>
                <button class="filter-btn" data-filter="academics">Academics</button>
                <button class="filter-btn" data-filter="arts">Arts</button>
            </div>
            
            <div class="gallery-grid">
                <div class="gallery-item" data-category="campus">
                    <div class="gallery-image">
                        <div class="image-placeholder">
                            <i class="fas fa-building"></i>
                        </div>
                        <div class="gallery-overlay">
                            <button class="gallery-overlay-btn" onclick="openLightbox(this)">
                                <i class="fas fa-expand"></i>
                                View
                            </button>
                        </div>
                    </div>
                    <div class="gallery-info">
                        <h3>Main Campus Building</h3>
                        <p>Our state-of-the-art main building houses modern classrooms, laboratories, and administrative offices.</p>
                        <div class="gallery-meta">
                            <span class="gallery-category">Campus</span>
                            <span>March 2024</span>
                        </div>
                    </div>
                </div>

                <div class="gallery-item" data-category="events">
                    <div class="gallery-image">
                        <div class="image-placeholder">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <div class="gallery-overlay">
                            <button class="gallery-overlay-btn" onclick="openLightbox(this)">
                                <i class="fas fa-expand"></i>
                                View
                            </button>
                        </div>
                    </div>
                    <div class="gallery-info">
                        <h3>Graduation Ceremony 2024</h3>
                        <p>Celebrating the achievements of our graduating class with families and faculty members.</p>
                        <div class="gallery-meta">
                            <span class="gallery-category">Events</span>
                            <span>June 2024</span>
                        </div>
                    </div>
                </div>

                <div class="gallery-item" data-category="academics">
                    <div class="gallery-image">
                        <div class="image-placeholder">
                            <i class="fas fa-microscope"></i>
                        </div>
                        <div class="gallery-overlay">
                            <button class="gallery-overlay-btn" onclick="openLightbox(this)">
                                <i class="fas fa-expand"></i>
                                View
                            </button>
                        </div>
                    </div>
                    <div class="gallery-info">
                        <h3>Science Laboratory</h3>
                        <p>Students conducting experiments in our fully equipped science laboratory with modern equipment.</p>
                        <div class="gallery-meta">
                            <span class="gallery-category">Academics</span>
                            <span>February 2024</span>
                        </div>
                    </div>
                </div>

                <div class="gallery-item" data-category="sports">
                    <div class="gallery-image">
                        <div class="image-placeholder">
                            <i class="fas fa-basketball-ball"></i>
                        </div>
                        <div class="gallery-overlay">
                            <button class="gallery-overlay-btn" onclick="openLightbox(this)">
                                <i class="fas fa-expand"></i>
                                View
                            </button>
                        </div>
                    </div>
                    <div class="gallery-info">
                        <h3>Basketball Championship</h3>
                        <p>Our varsity basketball team celebrating their regional championship victory.</p>
                        <div class="gallery-meta">
                            <span class="gallery-category">Sports</span>
                            <span>March 2024</span>
                        </div>
                    </div>
                </div>

                <div class="gallery-item" data-category="arts">
                    <div class="gallery-image">
                        <div class="image-placeholder">
                            <i class="fas fa-palette"></i>
                        </div>
                        <div class="gallery-overlay">
                            <button class="gallery-overlay-btn" onclick="openLightbox(this)">
                                <i class="fas fa-expand"></i>
                                View
                            </button>
                        </div>
                    </div>
                    <div class="gallery-info">
                        <h3>Art Exhibition</h3>
                        <p>Student artwork displayed during our annual art exhibition showcasing creative talents.</p>
                        <div class="gallery-meta">
                            <span class="gallery-category">Arts</span>
                            <span>April 2024</span>
                        </div>
                    </div>
                </div>

                <div class="gallery-item" data-category="campus">
                    <div class="gallery-image">
                        <div class="image-placeholder">
                            <i class="fas fa-book"></i>
                        </div>
                        <div class="gallery-overlay">
                            <button class="gallery-overlay-btn" onclick="openLightbox(this)">
                                <i class="fas fa-expand"></i>
                                View
                            </button>
                        </div>
                    </div>
                    <div class="gallery-info">
                        <h3>Library & Learning Center</h3>
                        <p>Our modern library provides a quiet space for study and research with extensive digital resources.</p>
                        <div class="gallery-meta">
                            <span class="gallery-category">Campus</span>
                            <span>January 2024</span>
                        </div>
                    </div>
                </div>

                <div class="gallery-item" data-category="events">
                    <div class="gallery-image">
                        <div class="image-placeholder">
                            <i class="fas fa-flask"></i>
                        </div>
                        <div class="gallery-overlay">
                            <button class="gallery-overlay-btn" onclick="openLightbox(this)">
                                <i class="fas fa-expand"></i>
                                View
                            </button>
                        </div>
                    </div>
                    <div class="gallery-info">
                        <h3>Science Fair 2024</h3>
                        <p>Students presenting their innovative science projects at our annual science fair competition.</p>
                        <div class="gallery-meta">
                            <span class="gallery-category">Events</span>
                            <span>March 2024</span>
                        </div>
                    </div>
                </div>

                <div class="gallery-item" data-category="sports">
                    <div class="gallery-image">
                        <div class="image-placeholder">
                            <i class="fas fa-running"></i>
                        </div>
                        <div class="gallery-overlay">
                            <button class="gallery-overlay-btn" onclick="openLightbox(this)">
                                <i class="fas fa-expand"></i>
                                View
                            </button>
                        </div>
                    </div>
                    <div class="gallery-info">
                        <h3>Track & Field Day</h3>
                        <p>Annual sports day featuring track and field events with participation from all grade levels.</p>
                        <div class="gallery-meta">
                            <span class="gallery-category">Sports</span>
                            <span>May 2024</span>
                        </div>
                    </div>
                </div>

                <div class="gallery-item" data-category="academics">
                    <div class="gallery-image">
                        <div class="image-placeholder">
                            <i class="fas fa-laptop-code"></i>
                        </div>
                        <div class="gallery-overlay">
                            <button class="gallery-overlay-btn" onclick="openLightbox(this)">
                                <i class="fas fa-expand"></i>
                                View
                            </button>
                        </div>
                    </div>
                    <div class="gallery-info">
                        <h3>Computer Lab</h3>
                        <p>Students learning programming and digital skills in our modern computer laboratory.</p>
                        <div class="gallery-meta">
                            <span class="gallery-category">Academics</span>
                            <span>February 2024</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Lightbox -->
    <div class="lightbox" id="lightbox">
        <div class="lightbox-content">
            <button class="lightbox-close" onclick="closeLightbox()">
                <i class="fas fa-times"></i>
            </button>
            <button class="lightbox-nav lightbox-prev" onclick="prevImage()">
                <i class="fas fa-chevron-left"></i>
            </button>
            <button class="lightbox-nav lightbox-next" onclick="nextImage()">
                <i class="fas fa-chevron-right"></i>
            </button>
            <img class="lightbox-image" id="lightbox-image" src="/placeholder.svg" alt="">
            <div class="lightbox-info">
                <h3 id="lightbox-title"></h3>
                <p id="lightbox-description"></p>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="footer-brand">
                        <div class="brand-icon">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <span class="brand-text">EduVision Academy</span>
                    </div>
                    <p class="footer-description">
                        Empowering minds, shaping futures. Excellence in education 
                        since 1999 with a commitment to nurturing tomorrow's leaders.
                    </p>
                    <div class="social-links">
                        <a href="#" class="social-link" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="social-link" aria-label="Twitter">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="social-link" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" class="social-link" aria-label="LinkedIn">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a href="#" class="social-link" aria-label="YouTube">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h4 class="footer-title">Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="admissions.php">Admissions</a></li>
                        <li><a href="educators.php">Faculty</a></li>
                        <li><a href="news.php">News & Events</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4 class="footer-title">Programs</h4>
                    <ul class="footer-links">
                        <li><a href="#">Elementary School</a></li>
                        <li><a href="#">Middle School</a></li>
                        <li><a href="#">High School</a></li>
                        <li><a href="#">Summer Programs</a></li>
                        <li><a href="#">After School Care</a></li>
                        <li><a href="#">Online Learning</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4 class="footer-title">Contact Info</h4>
                    <div class="contact-info">
                        <div class="contact-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>123 Education Street<br>Learning City, LC 12345</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-phone"></i>
                            <span>+1 (555) 123-4567</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-envelope"></i>
                            <span>info@eduvision.edu</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-clock"></i>
                            <span>Mon - Fri: 8:00 AM - 5:00 PM</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom">
                <div class="footer-bottom-content">
                    <p>&copy; 2024 EduVision Academy. All rights reserved.</p>
                    <div class="footer-bottom-links">
                        <a href="#">Privacy Policy</a>
                        <a href="#">Terms of Service</a>
                        <a href="#">Cookie Policy</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="script.js"></script>
</body>
</html>