<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include the database connection file
include '../conn.php';

// Check if the connection was successful
if (!$conn) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

// Fetch teacher details
$teachers = [];
$query = "SELECT name, qualification, photo FROM users WHERE role = 'Teacher'";
$result = $conn->query($query);

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $teachers[] = $row;
    }

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($teachers);
} else {
    // Handle query error
    http_response_code(500);
    echo json_encode(['error' => 'Query failed: ' . $conn->error]);
}
?>