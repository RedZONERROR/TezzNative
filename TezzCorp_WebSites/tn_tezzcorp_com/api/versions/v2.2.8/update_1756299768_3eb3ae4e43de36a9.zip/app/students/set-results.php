<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Set Student's Result - AI-ERP 2.0</title>
    <style>
        .staff-photo {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 50%;
        }
        .btn-loading .fa-spinner {
            display: inline-block;
        }
        .btn-loading .btn-text, .btn-loading .ti {
            display: none;
        }
        .fa-spinner {
            display: none;
            font-size: 0.9rem;
        }
        .pagination {
            margin-top: 1rem;
        }
        .marks-input {
            width: 80px;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Set Result</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Students
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Student Management -->
                    <div class="widget-content searchable-container list">
                        <div class="card card-body">
                            <div class="row">
                                <div class="col-md-3 col-xl-2">
                                    <form class="position-relative">
                                        <input type="text" class="form-control product-search ps-5" id="input-search"
                                            placeholder="Search Students..." />
                                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                                    </form>
                                </div>
                                <div class="col-md-3 col-xl-2">
                                    <select class="form-select" id="class-filter">
                                        <option value="">All Classes</option>
                                        <!-- Classes will be populated dynamically -->
                                    </select>
                                </div>
                                <div class="col-md-6 col-xl-8 text-end d-flex justify-content-md-end justify-content-center mt-3 mt-md-0">
                                    <a href="admission.php" id="btn-add-student"
                                        class="btn btn-primary d-flex align-items-center">
                                        <i class="ti ti-user-plus text-white me-1 fs-5"></i> Add Student
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="card card-body">
                            <div class="d-flex justify-content-center">
                                <div class="spinner-border text-primary" role="status" id="table-loader">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table search-table align-middle text-nowrap">
                                    <thead class="header-item">
                                        <th>Photo</th>
                                        <th>Name</th>
                                        <th>Class</th>
                                        <th>Mobile Number</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody id="student_list_table_body">
                                        <!-- Data will load dynamically -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <nav aria-label="Page navigation" id="pagination-nav">
                                <ul class="pagination justify-content-center">
                                    <!-- Pagination controls -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- View Modal -->
    <div class="modal fade" id="viewStudentModal" tabindex="-1" aria-labelledby="viewStudentModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewStudentModalLabel">Student Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Name:</strong> <span id="view-name"></span></p>
                    <p><strong>Class:</strong> <span id="view-class"></span></p>
                    <p><strong>Status:</strong> <span id="view-status"></span></p>
                    <p><strong>Photo:</strong><br><img id="view-photo" class="staff-photo" alt="Student Photo"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Marks Entry Modal -->
    <div class="modal fade" id="marksEntryModal" tabindex="-1" aria-labelledby="marksEntryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="marksEntryModalLabel">Enter Marks for <span id="marks-student-name"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="marks-form">
                        <input type="hidden" id="marks-uid">
                        <input type="hidden" id="marks-class-id">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="marks-session" class="form-label">Session</label>
                                <select class="form-select" id="marks-session" required>
                                    <!-- Sessions will be populated dynamically -->
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="marks-term" class="form-label">Term</label>
                                <select class="form-select" id="marks-term" required>
                                    <option value="">Select Term</option>
                                    <option value="FIRST TERMINAL">1st Term</option>
                                    <option value="SECOND TERMINAL">2nd Term</option>
                                    <option value="ANNUAL">3rd Term</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Subject</th>
                                            <th>Marks Obtained</th>
                                            <th>Max Marks</th>
                                        </tr>
                                    </thead>
                                    <tbody id="marks-table-body">
                                        <!-- Subjects and marks inputs will be populated dynamically -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary btn-save-marks">
                        <i class="fas fa-spinner fa-spin"></i>
                        <span class="btn-text">Save Marks</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        hljs.initHighlightingOnLoad();
        document.querySelectorAll("pre.code-view > code").forEach((codeBlock) => {
            codeBlock.textContent = codeBlock.innerHTML;
        });

        $(document).ready(function() {
            // Pagination state
            let currentPage = 1;
            const perPage = 10;
            const pageRange = 10;
            let classOptions = [];
            let sessionOptions = ['2023-2024', '2024-2025', '2025-2026'];
            let originalMarks = {}; // Store original marks for comparison

            // Fetch sessions
            function fetchSessions() {
                const sessionSelect = $('#marks-session');
                sessionSelect.empty();
                sessionSelect.append('<option value="">Select Session</option>');
                sessionOptions.forEach(session => {
                    sessionSelect.append(`<option value="${session}">${session}</option>`);
                });
            }

            // Fetch classes from class_master.php
            function fetchClasses() {
                return $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 100, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Class Master API Response:', response);
                        if (response.data && Array.isArray(response.data)) {
                            classOptions = response.data;
                            const classFilter = $('#class-filter');
                            classFilter.empty();
                            classFilter.append('<option value="">All Classes</option>');
                            classOptions.forEach(cls => {
                                classFilter.append(`<option value="${cls.id}">${cls.class_name}</option>`);
                            });
                        } else {
                            console.warn('No valid classes found in response:', response);
                            classOptions = [];
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Failed to load classes:', {
                            status: status,
                            error: error,
                            response: xhr.responseJSON || xhr.responseText
                        });
                        Swal.fire({
                            icon: 'warning',
                            title: 'Warning',
                            text: 'Failed to load class options. Please try again later.'
                        });
                    }
                });
            }

            // Fetch subjects by class ID
            function fetchSubjects(classId) {
                return $.ajax({
                    url: 'api/subject_master.php',
                    type: 'GET',
                    data: { class: classId, status: 'active', perPage: 100 },
                    dataType: 'json'
                }).then(response => {
                    console.log('Subject Master API Response:', response);
                    if (response.data && Array.isArray(response.data)) {
                        return response.data;
                    } else {
                        console.warn('No valid subjects found in response:', response);
                        return [];
                    }
                }).catch(xhr => {
                    console.error('Failed to load subjects:', {
                        status: xhr.status,
                        error: xhr.statusText,
                        response: xhr.responseJSON || xhr.responseText
                    });
                    Swal.fire({
                        icon: 'warning',
                        title: 'Warning',
                        text: 'Failed to load subjects. Please try again later.'
                    });
                    return [];
                });
            }

            // Fetch existing results for a student, session, and term
            function fetchResults(uid, classId, session, term) {
                return $.ajax({
                    url: 'api/result_master.php',
                    type: 'GET',
                    data: { uid: uid, class_id: classId, session: session, term: term },
                    dataType: 'json'
                }).then(response => {
                    console.log('Result Master API Response:', response);
                    if (response.status === 'success' && Array.isArray(response.data)) {
                        return response.data;
                    }
                    return [];
                }).catch(xhr => {
                    console.error('Failed to load results:', {
                        status: xhr.status,
                        error: xhr.statusText,
                        response: xhr.responseJSON || xhr.responseText
                    });
                    return [];
                });
            }

            // Fetch students data with pagination and class filter
            function fetchStudents(page = 1, classId = '') {
                $('#table-loader').show();
                $('#student_list_table_body').empty();

                const params = { page: page, perPage: perPage };
                if (classId) params.class = classId;

                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: params,
                    dataType: 'json',
                    success: function(response) {
                        console.log('Student API Response:', response);
                        const students = response.data || [];
                        const meta = response.meta || { page: page, totalPages: Math.ceil(students.length / perPage), totalItems: students.length };
                        console.log('Meta:', meta);
                        renderStudentTable(students);
                        renderPagination(meta);
                        $('#table-loader').hide();
                    },
                    error: function(xhr, status, error) {
                        $('#table-loader').hide();
                        console.error('Student AJAX Error:', xhr.responseJSON, status, error);
                        renderPagination({ page: 1, totalPages: 1, totalItems: 0 });
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load student data: ' + (xhr.responseJSON?.message || error)
                        });
                    }
                });
            }

            // Render student table
            function renderStudentTable(students) {
                const tbody = $('#student_list_table_body');
                tbody.empty();
                if (students.length === 0) {
                    tbody.append('<tr><td colspan="6" class="text-center">No students found.</td></tr>');
                    return;
                }
                students.forEach((s) => {
                    const photo = s.student_photo ? `/${s.student_photo}` : '/app/students/assets/images/profile/user-1.jpg';
                    const row = `
                        <tr data-uid="${s.uid}" data-class-id="${s.class}">
                            <td><img src="${photo}" class="staff-photo" alt="${s.full_name || 'Photo'}"></td>
                            <td>${s.full_name || '-'} - ${s.father_name || '-'}</td>
                            <td>${s.class_name || '-'}</td>
                            <td>${s.mobile_number || '-'}</td>
                            <td>
                                <span class="badge ${
                                    s.status === 'active' ? 'bg-success' :
                                    s.status === 'inactive' ? 'bg-warning' :
                                    s.status === 'deleted' ? 'bg-danger' :
                                    'bg-secondary'
                                }">
                                    ${s.status || '-'}
                                </span>
                            </td>
                            <td>
                                <button class="set-marks btn btn-sm btn-warning" data-uid="${s.uid}" data-name="${s.full_name}" data-class-id="${s.class}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-pencil"></i>
                                </button>
                                <button class="view-student btn btn-sm btn-info" data-uid="${s.uid}">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <i class="ti ti-eye"></i>
                                </button>
                            </td>
                        </tr>`;
                    tbody.append(row);
                });
            }

            // Render pagination with a range of 10 pages
            function renderPagination(meta) {
                const pagination = $('#pagination-nav ul');
                pagination.empty();

                const currentPage = meta.page || 1;
                const totalPages = meta.totalPages || 1;

                const pageRangeStart = Math.floor((currentPage - 1) / pageRange) * pageRange + 1;
                const pageRangeEnd = Math.min(pageRangeStart + pageRange - 1, totalPages);

                pagination.append(`
                    <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
                    </li>
                `);

                for (let p = pageRangeStart; p <= pageRangeEnd; p++) {
                    pagination.append(`
                        <li class="page-item ${p === currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${p}">${p}</a>
                        </li>
                    `);
                }

                pagination.append(`
                    <li class="page-item ${currentPage >= totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
                    </li>
                `);
            }

            // Pagination click
            $(document).on('click', '#pagination-nav a', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && page !== currentPage) {
                    currentPage = page;
                    const classId = $('#class-filter').val();
                    fetchStudents(page, classId);
                }
            });

            // Search functionality
            $('#input-search').on('keyup', function() {
                const search = $(this).val().toLowerCase();
                $('#student_list_table_body tr').each(function() {
                    const text = $(this).text().toLowerCase();
                    $(this).toggle(text.includes(search));
                });
            });

            // Class filter change
            $('#class-filter').on('change', function() {
                currentPage = 1;
                const classId = $(this).val();
                fetchStudents(currentPage, classId);
            });

            // View student
            $(document).on('click', '.view-student', function() {
                const uid = $(this).data('uid');
                $(this).addClass('btn-loading');
                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: { uid: uid },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status !== 'success' || !response.data) {
                            throw new Error(response.message || 'No student data found');
                        }
                        const student = response.data[0] || {};
                        $('#view-name').text(student.full_name || '-');
                        $('#view-class').text(student.class_name || '-');
                        $('#view-status').text(student.status || '-');
                        $('#view-photo').attr('src', student.student_photo ? `/${student.student_photo}` : '/app/students/assets/images/profile/user-1.jpg');
                        $('#viewStudentModal').modal('show');
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load student details: ' + (xhr.responseJSON?.message || error)
                        });
                    },
                    complete: function() {
                        $('.view-student[data-uid="' + uid + '"]').removeClass('btn-loading');
                    }
                });
            });

            // Set marks
            $(document).on('click', '.set-marks', function() {
                const uid = $(this).data('uid');
                const name = $(this).data('name');
                const classId = $(this).data('class-id');
                $('#marks-uid').val(uid);
                $('#marks-class-id').val(classId);
                $('#marks-student-name').text(name);

                // Fetch subjects and existing results in parallel
                $.when(fetchSubjects(classId), fetchResults(uid, classId, $('#marks-session').val(), $('#marks-term').val())).then((subjects, results) => {
                    const tbody = $('#marks-table-body');
                    tbody.empty();
                    originalMarks = {}; // Reset original marks

                    if (!Array.isArray(subjects) || subjects.length === 0) {
                        tbody.append('<tr><td colspan="3" class="text-center">No subjects found for this class.</td></tr>');
                        $('#marksEntryModal').modal('show');
                        return;
                    }

                    // Create a map of existing results for quick lookup
                    const resultMap = {};
                    if (Array.isArray(results)) {
                        results.forEach(result => {
                            resultMap[result.subject_id] = result.marks_obtained;
                            originalMarks[result.subject_id] = result.marks_obtained; // Store original marks
                        });
                    }

                    // Populate marks table with subjects and existing marks
                    subjects.forEach(subject => {
                        const marksObtained = resultMap[subject.id] !== undefined ? resultMap[subject.id] : '';
                        tbody.append(`
                            <tr>
                                <td>${subject.subject || '-'}</td>
                                <td><input type="number" class="form-control marks-input" name="marks[${subject.id}]" min="0" max="${subject.full_marks}" value="${marksObtained}" data-original="${marksObtained}"></td>
                                <td>${subject.full_marks || '-'}</td>
                            </tr>
                        `);
                    });
                    $('#marksEntryModal').modal('show');
                }).catch(error => {
                    console.error('Error in fetchSubjects or fetchResults:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to load subjects or results for the selected class.'
                    });
                });
            });

            // Update session and term to fetch existing results
            $('#marks-session, #marks-term').on('change', function() {
                const uid = $('#marks-uid').val();
                const classId = $('#marks-class-id').val();
                const session = $('#marks-session').val();
                const term = $('#marks-term').val();

                if (uid && classId && session && term) {
                    fetchResults(uid, classId, session, term).then(results => {
                        originalMarks = {}; // Reset original marks
                        const resultMap = {};
                        if (Array.isArray(results)) {
                            results.forEach(result => {
                                resultMap[result.subject_id] = result.marks_obtained;
                                originalMarks[result.subject_id] = result.marks_obtained; // Store original marks
                            });
                        }
                        $('#marks-table-body input').each(function() {
                            const name = $(this).attr('name');
                            const subjectId = name.match(/\[(\d+)\]/)[1];
                            const marksObtained = resultMap[subjectId] !== undefined ? resultMap[subjectId] : '';
                            $(this).val(marksObtained).attr('data-original', marksObtained);
                        });
                    }).catch(error => {
                        console.error('Error fetching results on session/term change:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load existing results.'
                        });
                    });
                }
            });

            // Save marks
            $('.btn-save-marks').on('click', function() {
                if (!$('#marks-form')[0].checkValidity()) {
                    $('#marks-form')[0].reportValidity();
                    return;
                }

                $(this).addClass('btn-loading');
                const uid = $('#marks-uid').val();
                const classId = $('#marks-class-id').val();
                const session = $('#marks-session').val();
                const term = $('#marks-term').val();
                const newMarks = [];
                const updatedMarks = [];

                $('#marks-table-body input').each(function() {
                    const name = $(this).attr('name');
                    const subjectId = name.match(/\[(\d+)\]/)[1];
                    const marksObtained = $(this).val();
                    const originalMarksObtained = $(this).attr('data-original');
                    const maxMarks = parseInt($(this).attr('max'));

                    if (marksObtained !== '') {
                        const marksInt = parseInt(marksObtained);
                        if (marksInt >= 0) {
                            if (!originalMarks[subjectId]) {
                                // New marks (no existing record)
                                newMarks.push({
                                    subject_id: parseInt(subjectId),
                                    marks_obtained: marksInt,
                                    max_marks: maxMarks
                                });
                            } else if (marksInt !== parseInt(originalMarksObtained)) {
                                // Changed marks (existing record)
                                updatedMarks.push({
                                    subject_id: parseInt(subjectId),
                                    marks_obtained: marksInt,
                                    max_marks: maxMarks
                                });
                            }
                        }
                    }
                });

                if (newMarks.length === 0 && updatedMarks.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Changes',
                        text: 'No marks were entered or changed.'
                    });
                    $('.btn-save-marks').removeClass('btn-loading');
                    return;
                }

                $.ajax({
                    url: 'api/result_master.php',
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        uid: uid,
                        class_id: classId,
                        session: session,
                        term: term,
                        newMarks: newMarks,
                        updatedMarks: updatedMarks
                    }),
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success',
                                text: response.message || 'Marks saved successfully'
                            });
                            $('#marksEntryModal').modal('hide');
                        } else {
                            throw new Error(response.message || 'Failed to save marks');
                        }
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to save marks: ' + (xhr.responseJSON?.message || error)
                        });
                    },
                    complete: function() {
                        $('.btn-save-marks').removeClass('btn-loading');
                    }
                });
            });

            // Initial load
            fetchSessions();
            fetchClasses().then(() => {
                fetchStudents(currentPage);
            });
        });
    </script>
</body>
</html>