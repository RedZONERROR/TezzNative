<?php
require_once 'conn.php';

$query = mysqli_query($conn, "SELECT school_name, logo, favicon, email, address, phone, tagline, footer_text, transport_head_mobile, fees_collection_mobile, whatsapp_number, calling_number, facebook_url, twitter_url, instagram_url, linkedin_url, youtube_url FROM site_settings");
$fetch = mysqli_fetch_array($query);

$count_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM staff");
$count = mysqli_fetch_assoc($count_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - <?php echo $fetch['school_name']; ?></title>
    <meta name="description" content="Get in touch with <?php echo $fetch['school_name']; ?>. Find our contact information, office hours, and send us a message.">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="base.css">
    <link rel="stylesheet" href="contact.css">
    
    <!-- Favicon -->
    <?php
    if (!empty($fetch['favicon'])) {
        $favicon = htmlspecialchars($fetch['favicon'], ENT_QUOTES, 'UTF-8');
        $ext = pathinfo($favicon, PATHINFO_EXTENSION);
        
        // Set MIME type based on extension
        $mimeType = 'image/png'; // default
        if ($ext === 'jpg' || $ext === 'jpeg') {
            $mimeType = 'image/jpeg';
        } elseif ($ext === 'ico') {
            $mimeType = 'image/x-icon';
        }
    
        echo '<link rel="icon" type="' . $mimeType . '" href="' . $favicon . '">';
    }
    ?>
</head>
<body>
    <!-- Navigation -->
    <?php include 'header.php'; ?>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <div class="page-header-content">
                <h1>Contact Us</h1>
                <p>Get in touch with our team. We're here to help and answer any questions you may have.</p>
            </div>
        </div>
    </section>

    <!-- Contact Form Section -->
    <section class="section contact-form-section">
        <div class="container">
            <div class="contact-content">
                <div class="contact-info">
                    <h3>Get in Touch</h3>
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="contact-details">
                            <h4>Visit Our Campus</h4>
                            <p><?php echo $fetch['address']; ?></p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <div class="contact-details">
                            <h4>Call Us</h4>
                            <p><?php echo $fetch['phone']; ?></p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="contact-details">
                            <h4>Email Us</h4>
                            <p><?php echo $fetch['email']; ?></p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="contact-details">
                            <h4>Office Hours</h4>
                            <p>Monday - Friday: 8:00 AM - 5:00 PM<br>Saturday: 9:00 AM - 2:00 PM<br>Sunday: Closed</p>
                        </div>
                    </div>
                </div>
                
                <div class="contact-form">
                    <h3>Send us a Message</h3>
                    <form id="contact-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="first-name">First Name *</label>
                                <input type="text" id="first-name" name="firstName" required>
                            </div>
                            <div class="form-group">
                                <label for="last-name">Last Name *</label>
                                <input type="text" id="last-name" name="lastName" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone Number</label>
                                <input type="tel" id="phone" name="phone">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="subject">Subject *</label>
                            <select id="subject" name="subject" required>
                                <option value="">Select a subject</option>
                                <option value="admissions">Admissions Inquiry</option>
                                <option value="academics">Academic Programs</option>
                                <option value="support">Student Support</option>
                                <option value="general">General Information</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="message">Message *</label>
                            <textarea id="message" name="message" placeholder="Tell us how we can help you..." required></textarea>
                        </div>
                        <button type="submit" class="submit-btn">
                            <i class="fas fa-paper-plane"></i>
                            Send Message
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Map Section -->
    <section class="section map-section">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">Find Us</div>
                <h2 class="section-title">
                    Visit Our 
                    <span class="gradient-text">Campus</span>
                </h2>
                <p class="section-description">
                    Located in the heart of Learning City, our campus is easily accessible 
                    and provides a beautiful environment for learning.
                </p>
            </div>
            <div class="map-container">
                <div class="map-placeholder">
                    <i class="fas fa-map-marked-alt"></i>
                    Interactive Map Coming Soon
                </div>
            </div>
        </div>
    </section>

    <!-- Office Hours Section -->
    <section class="section office-hours">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">Office Hours</div>
                <h2 class="section-title">
                    When We're 
                    <span class="gradient-text">Available</span>
                </h2>
                <p class="section-description">
                    Our dedicated staff is available during these hours to assist you 
                    with any questions or concerns.
                </p>
            </div>
            <div class="hours-grid">
                <div class="hours-card">
                    <div class="hours-icon">
                        <i class="fas fa-building"></i>
                    </div>
                    <h3>Main Office</h3>
                    <ul class="hours-list">
                        <li><span class="day">Monday - Friday</span><span>8:00 AM - 5:00 PM</span></li>
                        <li><span class="day">Saturday</span><span>9:00 AM - 2:00 PM</span></li>
                        <li><span class="day">Sunday</span><span>Closed</span></li>
                    </ul>
                </div>
                <div class="hours-card">
                    <div class="hours-icon">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <h3>Admissions Office</h3>
                    <ul class="hours-list">
                        <li><span class="day">Monday - Friday</span><span>8:30 AM - 4:30 PM</span></li>
                        <li><span class="day">Saturday</span><span>10:00 AM - 1:00 PM</span></li>
                        <li><span class="day">Sunday</span><span>By Appointment</span></li>
                    </ul>
                </div>
                <div class="hours-card">
                    <div class="hours-icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <h3>Student Support</h3>
                    <ul class="hours-list">
                        <li><span class="day">Monday - Friday</span><span>7:30 AM - 6:00 PM</span></li>
                        <li><span class="day">Saturday</span><span>9:00 AM - 3:00 PM</span></li>
                        <li><span class="day">Sunday</span><span>Emergency Only</span></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="section faq-section">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">FAQ</div>
                <h2 class="section-title">
                    Frequently Asked 
                    <span class="gradient-text">Questions</span>
                </h2>
                <p class="section-description">
                    Find answers to common questions about our programs, admissions, 
                    and campus life.
                </p>
            </div>
            <div class="faq-container">
                <div class="faq-item">
                    <button class="faq-question">
                        What are the admission requirements?
                        <i class="fas fa-plus"></i>
                    </button>
                    <div class="faq-answer">
                        <p>Our admission requirements vary by grade level. Generally, we require completed application forms, academic transcripts, recommendation letters, and an interview. For specific requirements for your child's grade level, please contact our admissions office.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        What is the student-to-teacher ratio?
                        <i class="fas fa-plus"></i>
                    </button>
                    <div class="faq-answer">
                        <p>We maintain small class sizes with an average student-to-teacher ratio of 12:1 in elementary grades and 15:1 in middle and high school. This ensures personalized attention and optimal learning outcomes for each student.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        Do you offer financial aid or scholarships?
                        <i class="fas fa-plus"></i>
                    </button>
                    <div class="faq-answer">
                        <p>Yes, we offer need-based financial aid and merit scholarships. Our financial aid program is designed to make quality education accessible to families from diverse economic backgrounds. Please contact our admissions office for more information about available options.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        What extracurricular activities are available?
                        <i class="fas fa-plus"></i>
                    </button>
                    <div class="faq-answer">
                        <p>We offer a wide range of extracurricular activities including sports teams, music and arts programs, debate club, robotics, student government, community service clubs, and many more. These activities help students develop leadership skills and pursue their passions.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        How can parents stay involved in their child's education?
                        <i class="fas fa-plus"></i>
                    </button>
                    <div class="faq-answer">
                        <p>We encourage parent involvement through our Parent-Teacher Association, volunteer opportunities, regular parent-teacher conferences, and our online parent portal where you can track your child's progress, assignments, and school communications.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include 'footer.php'; ?>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="script.js"></script>
</body>
</html>