<?php
require_once 'conn.php';

$query = mysqli_query($conn, "SELECT school_name, logo, favicon, email, address, phone, tagline, footer_text, transport_head_mobile, fees_collection_mobile, whatsapp_number, calling_number, facebook_url, twitter_url, instagram_url, linkedin_url, youtube_url FROM site_settings");
$fetch = mysqli_fetch_array($query);

$total_staff_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM staff WHERE status = 'active'");
$total_staff = mysqli_fetch_assoc($total_staff_query)['total'];

$teachers_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM staff WHERE status = 'active' AND role = 'Teacher'");
$teachers_count = mysqli_fetch_assoc($teachers_query)['total'];

$principals_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM staff WHERE status = 'active' AND role = 'Principal'");
$principals_count = mysqli_fetch_assoc($principals_query)['total'];

$support_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM staff WHERE status = 'active' AND role = 'Support Staff'");
$support_count = mysqli_fetch_assoc($support_query)['total'];

$staff_query = mysqli_query($conn, "SELECT * FROM staff WHERE status = 'active' ORDER BY role DESC, name ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Faculty - <?php echo $fetch['school_name']; ?></title>
    <meta name="description" content="Meet our exceptional faculty at <?php echo $fetch['school_name']; ?>. Experienced educators dedicated to student success and academic excellence.">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="base.css">
    <link rel="stylesheet" href="educators.css">
    
    <!-- Adding custom CSS for proper image display -->
    <style>
    .educator-image {
        width: 100%;
        height: 280px;
        border-radius: 12px;
        overflow: hidden;
        position: relative;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .educator-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        object-position: center;
        transition: transform 0.3s ease;
    }
    
    .educator-card:hover .educator-image img {
        transform: scale(1.05);
    }
    
    .image-placeholder {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        font-size: 3rem;
        opacity: 0.8;
    }
    
    .educator-card {
        background: white;
        border-radius: 16px;
        padding: 0;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
        overflow: hidden;
        margin-bottom: 2rem;
    }
    
    .educator-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
    }
    
    .educator-info {
        padding: 1.5rem;
    }
    
    .educator-name {
        font-size: 1.25rem;
        font-weight: 600;
        color: #1a1a1a;
        margin-bottom: 0.5rem;
    }
    
    .educator-title {
        color: #6366f1;
        font-weight: 500;
        margin-bottom: 1rem;
        font-size: 0.9rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .educator-description {
        color: #666;
        font-size: 0.9rem;
        line-height: 1.6;
        margin-bottom: 1rem;
    }
    
    .educator-specialties h4 {
        font-size: 0.85rem;
        font-weight: 600;
        color: #1a1a1a;
        margin-bottom: 0.5rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .specialties-list {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
        margin-bottom: 1rem;
    }
    
    .specialty-tag {
        background: #f3f4f6;
        color: #374151;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 500;
    }
    
    .educator-contact {
        display: flex;
        gap: 0.75rem;
        margin-top: 1rem;
    }
    
    .contact-btn {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        padding: 0.75rem;
        background: #f8fafc;
        color: #64748b;
        text-decoration: none;
        border-radius: 8px;
        font-size: 0.85rem;
        font-weight: 500;
        transition: all 0.2s ease;
        border: 1px solid #e2e8f0;
    }
    
    .contact-btn:hover {
        background: #6366f1;
        color: white;
        border-color: #6366f1;
        transform: translateY(-1px);
    }
    
    .educators-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
        gap: 2rem;
        margin-top: 3rem;
    }
    
    @media (max-width: 768px) {
        .educators-grid {
            grid-template-columns: 1fr;
            gap: 1.5rem;
        }
        
        .educator-image {
            height: 240px;
        }
    }
    </style>

    <!-- Favicon -->
    <?php
    if (!empty($fetch['favicon'])) {
        $favicon = htmlspecialchars($fetch['favicon'], ENT_QUOTES, 'UTF-8');
        $ext = pathinfo($favicon, PATHINFO_EXTENSION);
        
        // Set MIME type based on extension
        $mimeType = 'image/png'; // default
        if ($ext === 'jpg' || $ext === 'jpeg') {
            $mimeType = 'image/jpeg';
        } elseif ($ext === 'ico') {
            $mimeType = 'image/x-icon';
        }
    
        echo '<link rel="icon" type="' . $mimeType . '" href="' . $favicon . '">';
    }
    ?>
</head>
<body>
    <!-- Navigation -->
    <?php include 'header.php'; ?>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <div class="page-header-content">
                <h1>Our Exceptional Faculty</h1>
                <p>Meet the dedicated educators who inspire, guide, and empower our students to achieve their full potential.</p>
            </div>
        </div>
    </section>

    <!-- Educators Section -->
    <section class="section educators-section">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">Meet Our Team</div>
                <h2 class="section-title">
                    Dedicated Educators Committed to 
                    <span class="gradient-text">Excellence</span>
                </h2>
                <p class="section-description">
                    Our faculty members are not just teachers, but mentors, innovators, 
                    and lifelong learners who inspire students every day.
                </p>
            </div>
            
            <!-- Updated filter buttons to match database roles -->
            <div class="educators-filter">
                <button class="filter-btn active" data-filter="all">All Faculty</button>
                <button class="filter-btn" data-filter="Teacher">Teachers</button>
                <button class="filter-btn" data-filter="Principal">Principals</button>
                <button class="filter-btn" data-filter="Support Staff">Support Staff</button>
            </div>
            
            <div class="educators-grid">
                <!-- Dynamic staff cards from database -->
                <?php while ($staff = mysqli_fetch_assoc($staff_query)): ?>
                <div class="educator-card" data-category="<?php echo htmlspecialchars($staff['role']); ?>">
                    <div class="educator-image">
                        <?php if (!empty($staff['photo']) && file_exists($staff['photo'])): ?>
                            <img src="<?php echo htmlspecialchars($staff['photo']); ?>" alt="<?php echo htmlspecialchars($staff['name']); ?>" loading="lazy">
                        <?php else: ?>
                            <div class="image-placeholder">
                                <?php 
                                $icon = 'fas fa-user';
                                if ($staff['role'] === 'Principal') {
                                    $icon = 'fas fa-user-tie';
                                } elseif ($staff['role'] === 'Teacher') {
                                    $icon = 'fas fa-chalkboard-teacher';
                                } elseif ($staff['role'] === 'Support Staff') {
                                    $icon = 'fas fa-users-cog';
                                }
                                ?>
                                <i class="<?php echo $icon; ?>"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="educator-info">
                        <h3 class="educator-name"><?php echo htmlspecialchars($staff['name']); ?></h3>
                        <div class="educator-title"><?php echo htmlspecialchars($staff['role']); ?></div>
                        
                        <?php if (!empty($staff['qualification'])): ?>
                        <p class="educator-description">
                            <?php 
                            $description = '';
                            if ($staff['role'] === 'Principal') {
                                $description = 'Educational leader with ' . htmlspecialchars($staff['qualification']) . ' qualification, dedicated to providing vision and guidance for academic excellence.';
                            } elseif ($staff['role'] === 'Teacher') {
                                $description = 'Experienced educator with ' . htmlspecialchars($staff['qualification']) . ' qualification, committed to inspiring and guiding students towards success.';
                            } else {
                                $description = 'Dedicated team member with ' . htmlspecialchars($staff['qualification']) . ' qualification, ensuring smooth operations and student support.';
                            }
                            echo $description;
                            ?>
                        </p>
                        <?php endif; ?>
                        
                        <?php if (!empty($staff['qualification'])): ?>
                        <div class="educator-specialties">
                            <h4>Qualification</h4>
                            <div class="specialties-list">
                                <span class="specialty-tag"><?php echo htmlspecialchars($staff['qualification']); ?></span>
                                <?php if (!empty($staff['doj'])): ?>
                                    <span class="specialty-tag">Since <?php echo date('Y', strtotime($staff['doj'])); ?></span>
                                <?php endif; ?>
                                <?php if ($staff['gender']): ?>
                                    <span class="specialty-tag"><?php echo htmlspecialchars($staff['gender']); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <!-- Join Our Team Section -->
    <section class="section join-team">
        <div class="container">
            <div class="join-content">
                <h2 class="join-title">
                    Join Our Team of 
                    <span class="gradient-text">Exceptional Educators</span>
                </h2>
                <p class="join-description">
                    Are you passionate about education and making a difference in students' lives? 
                    We're always looking for talented educators to join our team.
                </p>
                
                <div class="join-features">
                    <div class="join-feature">
                        <i class="fas fa-heart"></i>
                        <h4>Supportive Environment</h4>
                        <p>Work in a collaborative and supportive environment that values your professional growth.</p>
                    </div>
                    <div class="join-feature">
                        <i class="fas fa-graduation-cap"></i>
                        <h4>Professional Development</h4>
                        <p>Access to continuous learning opportunities and professional development programs.</p>
                    </div>
                    <div class="join-feature">
                        <i class="fas fa-users"></i>
                        <h4>Amazing Community</h4>
                        <p>Be part of a community that values innovation, creativity, and student success.</p>
                    </div>
                </div>
                
                <div class="join-actions">
                    <a href="contact.php" class="btn btn-primary btn-large">
                        <i class="fas fa-paper-plane"></i>
                        Apply Now
                    </a>
                    <a href="about.php" class="btn btn-secondary btn-large">
                        <i class="fas fa-info-circle"></i>
                        Learn More
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include 'footer.php'; ?>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="script.js"></script>
    
    <!-- Add filtering JavaScript for educators -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const filterButtons = document.querySelectorAll('.filter-btn');
        const educatorCards = document.querySelectorAll('.educator-card');
        
        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                const filter = this.getAttribute('data-filter');
                
                // Update active button
                filterButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                
                // Filter cards
                educatorCards.forEach(card => {
                    const category = card.getAttribute('data-category');
                    
                    if (filter === 'all' || category === filter) {
                        card.style.display = 'block';
                        card.style.opacity = '1';
                    } else {
                        card.style.display = 'none';
                        card.style.opacity = '0';
                    }
                });
            });
        });
    });
    </script>
</body>
</html>