<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <div class="footer-brand">
                    <div class="brand-icon">
                        <img style="width: 50px;" src="<?php echo $fetch['logo']; ?>" alt="<?php echo $fetch['school_name']; ?>">
                    </div>
                    <span class="brand-text"><?php echo $fetch['school_name']; ?></span>
                </div>
                <p class="footer-description">
                    <?php echo $fetch['tagline']; ?>
                </p>
                <div class="social-links">
                    <a href="<?php echo $fetch['facebook_url']; ?>" class="social-link" aria-label="Facebook">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="<?php echo $fetch['twitter_url']; ?>" class="social-link" aria-label="Twitter">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="<?php echo $fetch['instagram_url']; ?>" class="social-link" aria-label="Instagram">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="<?php echo $fetch['linkedin_url']; ?>" class="social-link" aria-label="LinkedIn">
                        <i class="fab fa-linkedin-in"></i>
                    </a>
                    <a href="<?php echo $fetch['youtube_url']; ?>" class="social-link" aria-label="YouTube">
                        <i class="fab fa-youtube"></i>
                    </a>
                </div>
            </div>
            
            <div class="footer-section">
                <h4 class="footer-title">Quick Links</h4>
                <ul class="footer-links">
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="contact.php">Admissions</a></li>
                    <li><a href="educators.php">Faculty</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4 class="footer-title">Programs</h4>
                <ul class="footer-links">
                    <li><a href="contact.php">Elementary School</a></li>
                    <li><a href="contact.php">Middle School</a></li>
                    <li><a href="contact.php">High School</a></li>
                    <li><a href="contact.php">Summer Programs</a></li>
                    <li><a href="contact.php">Online Learning</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4 class="footer-title">Contact Info</h4>
                <div class="contact-info">
                    <div class="contact-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <span><?php echo $fetch['address']; ?></span>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-phone"></i>
                        <span><?php echo $fetch['phone']; ?></span>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-envelope"></i>
                        <span><?php echo $fetch['email']; ?></span>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-clock"></i>
                        <span>Mon - Fri: 8:00 AM - 3:00 PM</span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <div class="footer-bottom-content">
                <p><?php echo $fetch['footer_text']; ?></p>
                <div class="footer-bottom-links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Service</a>
                    <a href="#">Cookie Policy</a>
                </div>
            </div>
        </div>
    </div>
</footer>