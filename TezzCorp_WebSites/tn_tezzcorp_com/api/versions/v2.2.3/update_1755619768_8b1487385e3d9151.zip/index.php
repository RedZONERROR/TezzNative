<?php
require_once 'conn.php';

$query = mysqli_query($conn, "SELECT school_name, logo, favicon, email, address, phone, tagline, footer_text, transport_head_mobile, fees_collection_mobile, whatsapp_number, calling_number, facebook_url, twitter_url, instagram_url, linkedin_url, youtube_url FROM site_settings");
$fetch = mysqli_fetch_array($query);

$count_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM staff");
$count = mysqli_fetch_assoc($count_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $fetch['school_name']; ?> - Excellence in Education</title>
    <meta name="description" content="Leading educational institution providing world-class education with modern teaching methods and innovative learning approaches.">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="base.css">
    <link rel="stylesheet" href="home.css">
    
    <!-- Favicon -->
    <?php
    if (!empty($fetch['favicon'])) {
        $favicon = htmlspecialchars($fetch['favicon'], ENT_QUOTES, 'UTF-8');
        $ext = pathinfo($favicon, PATHINFO_EXTENSION);
        
        // Set MIME type based on extension
        $mimeType = 'image/png'; // default
        if ($ext === 'jpg' || $ext === 'jpeg') {
            $mimeType = 'image/jpeg';
        } elseif ($ext === 'ico') {
            $mimeType = 'image/x-icon';
        }
    
        echo '<link rel="icon" type="' . $mimeType . '" href="' . $favicon . '">';
    }
    ?>
</head>
<body>
    <!-- Navigation -->
    <?php include 'header.php'; ?>

    <!-- Hero Section -->
    <section class="hero" id="hero">
        <div class="hero-background">
            <div class="hero-shape shape-1"></div>
            <div class="hero-shape shape-2"></div>
            <div class="hero-shape shape-3"></div>
        </div>
        
        <div class="container">
            <div class="hero-content">
                <div class="hero-text">
                    <div class="hero-badge">
                        <i class="fas fa-star"></i>
                        <span><?php echo $fetch['school_name']; ?></span>
                    </div>
                    
                    <h1 class="hero-title">
                        Shaping Tomorrow's
                        <span class="gradient-text">Leaders</span>
                        Through Excellence
                    </h1>
                    
                    <p class="hero-description">
                        Experience world-class education with innovative teaching methods, 
                        cutting-edge facilities, and personalized learning approaches that 
                        prepare students for global success.
                    </p>
                    
                    <div class="hero-actions">
                        <a href="#programs" class="btn btn-primary btn-large">
                            <i class="fas fa-rocket"></i>
                            Explore Programs
                        </a>
                        <a href="tel:<?php echo $fetch['phone']; ?>" class="btn btn-secondary btn-large">
                            <i class="fas fa-phone"></i>
                            Call Now
                        </a>
                    </div>
                    
                    <div class="hero-stats">
                        <div class="stat-item">
                            <div class="stat-number" data-target="<?php echo $count['total']; ?>">0</div>
                            <div class="stat-label">Expert Faculty</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number" data-target="25">0</div>
                            <div class="stat-label">Years Excellence</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number" data-target="98">0</div>
                            <div class="stat-label">Success Rate</div>
                        </div>
                    </div>
                </div>
                
                <div class="hero-visual">
                    <div class="hero-illustration">
                        <div class="floating-element element-1">
                            <i class="fas fa-book-open"></i>
                        </div>
                        <div class="floating-element element-2">
                            <i class="fas fa-atom"></i>
                        </div>
                        <div class="floating-element element-3">
                            <i class="fas fa-microscope"></i>
                        </div>
                        <div class="floating-element element-4">
                            <i class="fas fa-calculator"></i>
                        </div>
                        <div class="floating-element element-5">
                            <i class="fas fa-palette"></i>
                        </div>
                        <div class="floating-element element-6">
                            <i class="fas fa-globe"></i>
                        </div>
                        
                        <div class="main-illustration">
                            <div class="laptop-container">
                                <div class="laptop-screen">
                                    <div class="screen-content">
                                        <div class="code-line"></div>
                                        <div class="code-line short"></div>
                                        <div class="code-line"></div>
                                        <div class="code-line medium"></div>
                                    </div>
                                </div>
                                <div class="laptop-base"></div>
                            </div>
                            
                            <div class="education-text">EDUCATION</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="scroll-indicator">
            <div class="scroll-arrow">
                <i class="fas fa-chevron-down"></i>
            </div>
        </div>
    </section>

    <!-- Programs Section -->
    <section class="programs section" id="programs">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">Our Programs</div>
                <h2 class="section-title">
                    Comprehensive Education for 
                    <span class="gradient-text">Every Stage</span>
                </h2>
                <p class="section-description">
                    From early childhood to advanced studies, we offer world-class 
                    educational programs designed to nurture growth and excellence.
                </p>
            </div>
            
            <?php
            // Query all active classes
            $class_query = mysqli_query($conn, "SELECT class_name FROM class WHERE status = 'active'");
            $has_above_class_8 = false;
            
            // Mappings for words to numbers
            $wordToNumber = [
                'one' => 1,
                'two' => 2,
                'three' => 3,
                'four' => 4,
                'five' => 5,
                'six' => 6,
                'seven' => 7,
                'eight' => 8,
                'nine' => 9,
                'ten' => 10,
                'eleven' => 11,
                'twelve' => 12
            ];
            
            // Mappings for Roman numerals to numbers
            $romanToNumber = [
                'i' => 1,
                'ii' => 2,
                'iii' => 3,
                'iv' => 4,
                'v' => 5,
                'vi' => 6,
                'vii' => 7,
                'viii' => 8,
                'ix' => 9,
                'x' => 10,
                'xi' => 11,
                'xii' => 12
            ];
            
            while ($row = mysqli_fetch_assoc($class_query)) {
                $class_name = strtolower($row['class_name']); // Normalize case
            
                // Split by dash or space to get the first part
                $firstPart = preg_split('/[\s\-]/', $class_name)[0];
            
                // Determine the numeric value
                if (is_numeric($firstPart)) {
                    $classNum = (int)$firstPart;
                } elseif (isset($wordToNumber[$firstPart])) {
                    $classNum = $wordToNumber[$firstPart];
                } elseif (isset($romanToNumber[$firstPart])) {
                    $classNum = $romanToNumber[$firstPart];
                } else {
                    $classNum = 0; // Unknown format
                }
            
                if ($classNum > 8) {
                    $has_above_class_8 = true;
                    break;
                }
            }
            ?>
            
            <div class="programs-grid">
            
                <!-- Elementary School Card -->
                <div class="program-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="program-icon">
                        <i class="fas fa-seedling"></i>
                    </div>
                    <h3 class="program-title">Elementary School</h3>
                    <p class="program-description">
                        Building strong foundations with creative learning, critical thinking, 
                        and character development in a nurturing environment.
                    </p>
                    <div class="program-features">
                        <div class="feature-item"><i class="fas fa-check"></i><span>Interactive Learning</span></div>
                        <div class="feature-item"><i class="fas fa-check"></i><span>Small Class Sizes</span></div>
                        <div class="feature-item"><i class="fas fa-check"></i><span>Creative Arts</span></div>
                    </div>
                    <a href="contact.php" class="program-link">Learn More <i class="fas fa-arrow-right"></i></a>
                </div>
            
                <!-- Middle School Card -->
                <div class="program-card featured" data-aos="fade-up" data-aos-delay="200">
                    <div class="featured-badge">Most Popular</div>
                    <div class="program-icon">
                        <i class="fas fa-brain"></i>
                    </div>
                    <h3 class="program-title">Middle School</h3>
                    <p class="program-description">
                        Developing critical thinking, leadership skills, and academic 
                        excellence through innovative teaching methodologies.
                    </p>
                    <div class="program-features">
                        <div class="feature-item"><i class="fas fa-check"></i><span>STEM Focus</span></div>
                        <div class="feature-item"><i class="fas fa-check"></i><span>Leadership Training</span></div>
                        <div class="feature-item"><i class="fas fa-check"></i><span>Advanced Labs</span></div>
                    </div>
                    <a href="contact.php" class="program-link">Learn More <i class="fas fa-arrow-right"></i></a>
                </div>
            
                <!-- High School Card (Only show if any class is above 8) -->
                <?php if ($has_above_class_8): ?>
                <div class="program-card" data-aos="fade-up" data-aos-delay="300">
                    <div class="program-icon">
                        <i class="fas fa-graduation-cap"></i>
                    </div>
                    <h3 class="program-title">High School</h3>
                    <p class="program-description">
                        College preparation with advanced placement courses, career guidance, 
                        and university admission support.
                    </p>
                    <div class="program-features">
                        <div class="feature-item"><i class="fas fa-check"></i><span>AP Courses</span></div>
                        <div class="feature-item"><i class="fas fa-check"></i><span>College Prep</span></div>
                        <div class="feature-item"><i class="fas fa-check"></i><span>Career Guidance</span></div>
                    </div>
                    <a href="contact.php" class="program-link">Learn More <i class="fas fa-arrow-right"></i></a>
                </div>
                <?php endif; ?>
            
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features section">
        <div class="container">
            <div class="features-content">
                <div class="features-text">
                    <div class="section-badge">Why Choose Us</div>
                    <h2 class="section-title">
                        Excellence in 
                        <span class="gradient-text">Education</span>
                    </h2>
                    <p class="section-description">
                        We combine traditional values with modern innovation to provide 
                        an exceptional educational experience that prepares students for success.
                    </p>
                    
                    <div class="features-list">
                        <div class="feature-item" data-aos="fade-right" data-aos-delay="100">
                            <div class="feature-icon">
                                <i class="fas fa-award"></i>
                            </div>
                            <div class="feature-content">
                                <h4>Award-Winning Faculty</h4>
                                <p>Learn from industry experts and renowned educators with years of experience.</p>
                            </div>
                        </div>
                        
                        <div class="feature-item" data-aos="fade-right" data-aos-delay="200">
                            <div class="feature-icon">
                                <i class="fas fa-laptop-code"></i>
                            </div>
                            <div class="feature-content">
                                <h4>Modern Technology</h4>
                                <p>State-of-the-art facilities with cutting-edge technology for enhanced learning.</p>
                            </div>
                        </div>
                        
                        <div class="feature-item" data-aos="fade-right" data-aos-delay="300">
                            <div class="feature-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <div class="feature-content">
                                <h4>Small Class Sizes</h4>
                                <p>Personalized attention with optimal student-to-teacher ratios for better learning.</p>
                            </div>
                        </div>
                        
                        <div class="feature-item" data-aos="fade-right" data-aos-delay="400">
                            <div class="feature-icon">
                                <i class="fas fa-globe-americas"></i>
                            </div>
                            <div class="feature-content">
                                <h4>Global Perspective</h4>
                                <p>International curriculum and exchange programs for global exposure.</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="features-visual" data-aos="fade-left">
                    <div class="visual-container">
                        <div class="visual-card card-1">
                            <div class="card-icon">
                                <i class="fas fa-chart-line"></i>
                            </div>
                            <div class="card-content">
                                <h5>98% Success Rate</h5>
                                <p>University Admissions</p>
                            </div>
                        </div>
                        
                        <div class="visual-card card-2">
                            <div class="card-icon">
                                <i class="fas fa-trophy"></i>
                            </div>
                            <div class="card-content">
                                <h5>50+ Awards</h5>
                                <p>Academic Excellence</p>
                            </div>
                        </div>
                        
                        <div class="visual-card card-3">
                            <div class="card-icon">
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="card-content">
                                <h5>4.9/5 Rating</h5>
                                <p>Parent Satisfaction</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="testimonials section">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">Testimonials</div>
                <h2 class="section-title">
                    What Our Community 
                    <span class="gradient-text">Says</span>
                </h2>
                <p class="section-description">
                    Hear from parents, students, and alumni about their transformative 
                    experiences at EduVision Academy.
                </p>
            </div>
            
            <div class="testimonials-slider" id="testimonials-slider">
                <div class="testimonial-card active" data-aos="fade-up">
                    <div class="testimonial-content">
                        <div class="quote-icon">
                            <i class="fas fa-quote-left"></i>
                        </div>
                        <p class="testimonial-text">
                            "<?php echo $fetch['school_name']; ?> has exceeded our expectations in every way. 
                            The personalized attention, innovative teaching methods, and 
                            supportive environment have helped our daughter thrive academically 
                            and personally."
                        </p>
                        <div class="testimonial-author">
                            <div class="author-avatar">
                                <img src="/placeholder.svg?height=60&width=60&text=SJ" alt="Sarah Johnson">
                            </div>
                            <div class="author-info">
                                <h4>Sarah Johnson</h4>
                                <p>Parent of Grade 8 Student</p>
                                <div class="rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="testimonial-card" data-aos="fade-up">
                    <div class="testimonial-content">
                        <div class="quote-icon">
                            <i class="fas fa-quote-left"></i>
                        </div>
                        <p class="testimonial-text">
                            "The teachers at <?php echo $fetch['school_name']; ?> don't just teach subjects; 
                            they inspire students to think critically, ask questions, and 
                            pursue their passions. My son has developed confidence and 
                            leadership skills that will serve him throughout his life."
                        </p>
                        <div class="testimonial-author">
                            <div class="author-avatar">
                                <img src="/placeholder.svg?height=60&width=60&text=MC" alt="Michael Chen">
                            </div>
                            <div class="author-info">
                                <h4>Michael Chen</h4>
                                <p>Parent of class 7 Student</p>
                                <div class="rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="testimonial-card" data-aos="fade-up">
                    <div class="testimonial-content">
                        <div class="quote-icon">
                            <i class="fas fa-quote-left"></i>
                        </div>
                        <p class="testimonial-text">
                            "As an student, I can confidently say that <?php echo $fetch['school_name']; ?> 
                            prepared me exceptionally well for university and beyond. 
                            The rigorous academics, combined with character development, 
                            gave me the foundation for success in my career."
                        </p>
                        <div class="testimonial-author">
                            <div class="author-avatar">
                                <img src="/placeholder.svg?height=60&width=60&text=ER" alt="Emily Rodriguez">
                            </div>
                            <div class="author-info">
                                <h4>Rishu Kumar</h4>
                                <p>Class 8</p>
                                <div class="rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="testimonials-controls">
                <button class="testimonial-btn prev" id="testimonial-prev">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <div class="testimonials-dots" id="testimonials-dots">
                    <button class="dot active" data-slide="0"></button>
                    <button class="dot" data-slide="1"></button>
                    <button class="dot" data-slide="2"></button>
                </div>
                <button class="testimonial-btn next" id="testimonial-next">
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta section">
        <div class="container">
            <div class="cta-content" data-aos="fade-up">
                <div class="cta-text">
                    <h2 class="cta-title">
                        Ready to Start Your 
                        <span class="gradient-text">Educational Journey?</span>
                    </h2>
                    <p class="cta-description">
                        Join thousands of students who have chosen excellence. 
                        Apply now and become part of our thriving academic community.
                    </p>
                </div>
                <div class="cta-actions">
                    <a href="contact.php" class="btn btn-primary btn-large">
                        <i class="fas fa-paper-plane"></i>
                        Apply Now
                    </a>
                    <a href="contact.php" class="btn btn-secondary btn-large">
                        <i class="fas fa-calendar"></i>
                        Schedule Visit
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include 'footer.php'; ?>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="script.js"></script>
</body>
</html>