<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Favicon and Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/favicon/favicon-16x16.png">
    <link rel="manifest" href="assets/favicon/site.webmanifest">
    
    <!-- Canonical URL -->
    <link rel="canonical" href="https://www.swamivivekanandnationalschool.in/">
    
    <title>Terms and Conditions - New Tech Public School, Tilangahi Math</title>
    <link rel="stylesheet" href="assets/css/terms-conditions.css">
</head>
<body>
    <header class="header">
        <h1>New Tech Public School</h1>
        <p>Empowering Education with Ethics</p>
    </header>
    <main class="terms-content">
        <section>
            <h2>Terms and Conditions</h2>
            <p>Welcome to New Tech Public School! These terms and conditions outline the rules and regulations for using our services, website, and participating in school activities.</p>
        </section>
        <section>
            <h3>Acceptance of Terms</h3>
            <p>By enrolling in the school or using our website, you agree to adhere to these terms and conditions. If you do not agree, please refrain from using our services.</p>
        </section>
        <section>
            <h3>Code of Conduct</h3>
            <ul>
                <li>Students must respect the school’s rules and regulations.</li>
                <li>Any form of misconduct, including bullying, will not be tolerated.</li>
                <li>Parents/guardians are responsible for ensuring timely fee payments.</li>
            </ul>
        </section>
        <section>
            <h3>Fees and Payments</h3>
            <p>Fees must be paid on time to avoid penalties. Late payments may incur additional charges. Fee structures and payment methods are subject to change and will be communicated to parents.</p>
        </section>
        <section>
            <h3>Website Use</h3>
            <p>
                By accessing our website:
                <ul>
                    <li>You agree to not misuse the content or resources provided.</li>
                    <li>Unauthorized attempts to breach security are prohibited.</li>
                    <li>The school reserves the right to modify or remove any content without notice.</li>
                </ul>
            </p>
        </section>
        <section>
            <h3>Liability</h3>
            <p>New Tech Public School is not responsible for any loss or damage caused due to unforeseen circumstances, including natural calamities or third-party actions.</p>
        </section>
        <section>
            <h3>Changes to Terms</h3>
            <p>The school reserves the right to revise these terms and conditions at any time. Changes will be communicated to parents and students as necessary.</p>
        </section>
        
        <section
          <div class="school-header">
            <h3>TERMS AND CONDITIONS FOR TEACHERS</h3>
          </div>
        
          <div class="terms-list">
            <ol>
              <li>You will get only one casual leave in a month.</li>
              <li>The salary of that day will be deducted on the second leave in the month.</li>
              <li>It will be mandatory to give a written application to the Principal sir for taking leave. (In case of emergency, inform on the phone but the application must be made on the second day.)</li>
              <li>Always have to reach school on time.</li>
              <li>If you are late due to any reason, you will inform the Principal sir on the phone. If the information is not given, a late will be written in the attendance register.</li>
              <li>One CL will be counted for three consecutive days of late arrival.</li>
              <li>It will be mandatory to follow the orders of the Principal Sir.</li>
              <li>School work has to complete on time. Not doing so would be considered Indiscipline.</li>
              <li>It is strictly forbidden to give physical punishment to any student.</li>
              <li>Two days salary will be deducted for absenteeism without notice.</li>
              <li>It is strictly forbidden to misbehave with any child or staff. Doing so can result in loss of your job.</li>
              <li>For talking or conspiring against the school, you will be removed from the job as well as legal action will be taken against you.</li>
              <li>In the event of leaving the school due to any reason, it will be mandatory to give a written application to the Principal sir one month before, otherwise, the salary for that month will not be given.</li>
              <li>It will be necessary to participate in any work organized in the interest of school.</li>
              <li>You can also be called on holiday if required.</li>
              <li>Talking to your colleagues while on duty will be considered as indiscipline.</li>
              <li>Your salary can be stopped if indiscipline is proved.</li>
              <li>If you are caught doing any wrong thing or behaving in a wrong way, the school have full right to punish you.</li>
            </ol>
          </div>
        
          <div class="declaration">
            <p>I have read and understood all the points thoroughly. I have no objection on any point. I am signing voluntarily.</p>
          </div>
        </section>
        
        <section>
            <h3>Contact Us</h3>
            <p>For any questions about these Terms and Conditions, please contact:</p>
            <address>
                New Tech Public School,<br>
                Tilangahi Math, Bairiya, West Champaran,<br>
                Bihar - 845438.<br>
                Phone: +91 6200288978<br>
                Email: info@newtechpublicschool.in
            </address>
        </section>
    </main>
    <footer class="footer">
        <p>© 2024 New Tech Public School. All Rights Reserved.</p>
    </footer>
</body>
</html>