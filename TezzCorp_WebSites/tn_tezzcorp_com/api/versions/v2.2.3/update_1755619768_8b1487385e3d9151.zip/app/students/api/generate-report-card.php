<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/fpdf/fpdf.php';

// Check if this is a download request
if (isset($_GET['download']) && $_GET['download'] === 'pdf') {
    // Set headers for PDF download
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="report_cards_' . date('Y-m-d_H-i-s') . '.pdf"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    
    // Process the download request
    $controller = new ReportCardController();
    $controller->downloadReportCard();
    exit;
}

// Regular JSON API headers
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

class ReportCardController {
    private $pdo;
    private $logger;

    public function __construct() {
        try {
            $this->pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    private function validateInput(array $data): array {
        $errors = [];
        $validData = [];

        if (!isset($data['class_id']) || !filter_var($data['class_id'], FILTER_VALIDATE_INT) || $data['class_id'] <= 0) {
            $errors[] = 'class_id must be a valid integer';
        } else {
            $validData['class_id'] = (int)$data['class_id'];
        }

        if (!isset($data['session']) || empty(trim($data['session']))) {
            $errors[] = 'session is required';
        } else {
            $validData['session'] = trim($data['session']);
        }

        if (!isset($data['term']) || empty(trim($data['term']))) {
            $errors[] = 'term is required';
        } else {
            $validData['term'] = trim($data['term']);
        }

        if (!isset($data['students']) || !is_array($data['students']) || empty($data['students'])) {
            $errors[] = 'At least one student must be selected';
        } else {
            $validData['students'] = array_map('trim', $data['students']);
            foreach ($validData['students'] as $uid) {
                if (empty($uid)) {
                    $errors[] = 'Invalid student UID';
                    break;
                }
            }
        }

        // Optional signature fields
        $validData['dept_examination_signature'] = $data['dept_examination_signature'] ?? null;
        $validData['class_teacher_signature'] = $data['class_teacher_signature'] ?? null;
        $validData['principal_signature'] = $data['principal_signature'] ?? null;

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return $validData;
    }

    private function handleFileUpload($file, $uploadDir = 'uploads/signatures/') {
        if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
            return null;
        }

        $uploadPath = $_SERVER['DOCUMENT_ROOT'] . '/' . $uploadDir;
        if (!file_exists($uploadPath)) {
            mkdir($uploadPath, 0755, true);
        }

        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($file['type'], $allowedTypes)) {
            throw new Exception('Invalid file type. Only JPEG, PNG, and GIF are allowed.');
        }

        $maxSize = 2 * 1024 * 1024; // 2MB
        if ($file['size'] > $maxSize) {
            throw new Exception('File size too large. Maximum 2MB allowed.');
        }

        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'signature_' . uniqid() . '.' . $extension;
        $fullPath = $uploadPath . $filename;

        if (move_uploaded_file($file['tmp_name'], $fullPath)) {
            return $uploadDir . $filename;
        }

        throw new Exception('Failed to upload file.');
    }

    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    private function logInfo(string $message): void {
        ($this->logger)('INFO: ' . $message);
    }

    private function getTemplateFile() {
        try {
            $stmt = $this->pdo->prepare("SELECT template_file FROM templates WHERE template_type = ? AND status = ?");
            $stmt->execute(['marksheet', 'active']);
            $template = $stmt->fetch();
            return $template ? $template['template_file'] : '1.png';
        } catch (PDOException $e) {
            $this->logError('Template query failed: ' . $e->getMessage());
            return '1.png';
        }
    }

    private function validateAndProcessImage($imagePath) {
        if (!file_exists($imagePath)) {
            $this->logError("Image file does not exist: $imagePath");
            return false;
        }

        if (!is_readable($imagePath)) {
            $this->logError("Image file is not readable: $imagePath");
            return false;
        }

        $fileSize = filesize($imagePath);
        if ($fileSize === false || $fileSize === 0) {
            $this->logError("Image file is empty or unreadable: $imagePath (Size: $fileSize)");
            return false;
        }

        $imageInfo = getimagesize($imagePath);
        if ($imageInfo === false) {
            $this->logError("Invalid image file or corrupted: $imagePath");
            return false;
        }

        $supportedTypes = [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF];
        if (!in_array($imageInfo[2], $supportedTypes)) {
            $this->logError("Unsupported image format: $imagePath (Type: " . $imageInfo[2] . ")");
            return false;
        }

        return true;
    }

    private function calculateRank($class_id, $session, $term, $student_totals) {
        try {
            $sql = "SELECT r.uid, SUM(r.marks_obtained) as total_marks
                    FROM results r
                    JOIN subject s ON r.subject_id = s.id
                    WHERE r.class_id = ? AND r.session = ? AND r.term = ?
                    AND UPPER(s.subject) NOT IN ('MUSIC', 'SANITATION')
                    GROUP BY r.uid
                    ORDER BY total_marks DESC";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$class_id, $session, $term]);
            $all_students = $stmt->fetchAll();

            $ranks = [];
            $current_rank = 1;
            $previous_total = null;
            $position = 1;

            foreach ($all_students as $student) {
                $uid = $student['uid'];
                $total = $student['total_marks'];

                if ($total !== $previous_total) {
                    $current_rank = $position;
                }

                if (isset($student_totals[$uid])) {
                    $ranks[$uid] = $current_rank;
                }

                $previous_total = $total;
                $position++;
            }

            return $ranks;
        } catch (PDOException $e) {
            $this->logError('Rank calculation failed: ' . $e->getMessage());
            return [];
        }
    }

    private function generatePDF($validData) {
        $template_file = $this->getTemplateFile();

        $placeholders = implode(',', array_fill(0, count($validData['students']), '?'));
        $sql = "SELECT r.uid, r.subject_id, r.marks_obtained, r.max_marks, s.subject, s.passing_marks,
                       sm.full_name, sm.father_name, sm.mother_name, sm.date_of_birth,
                       sm.roll_no, cm.class_name, d.student_photo
                FROM results r
                JOIN subject s ON r.subject_id = s.id
                JOIN students sm ON r.uid = sm.uid
                JOIN documents d ON sm.uid = d.uid
                JOIN class cm ON r.class_id = cm.id
                WHERE r.class_id = ? AND r.session = ? AND r.term = ? AND r.uid IN ($placeholders)";

        $stmt = $this->pdo->prepare($sql);
        $params = array_merge([$validData['class_id'], $validData['session'], $validData['term']], $validData['students']);
        $stmt->execute($params);

        $report_cards = [];
        $student_totals = [];

        while ($row = $stmt->fetch()) {
            $uid = $row['uid'];
            
            if (!isset($report_cards[$uid])) {
                $report_cards[$uid] = [
                    'full_name' => $row['full_name'],
                    'father_name' => $row['father_name'],
                    'mother_name' => $row['mother_name'],
                    'date_of_birth' => $row['date_of_birth'],
                    'roll_no' => $row['roll_no'],
                    'class_name' => $row['class_name'],
                    'student_photo' => $row['student_photo'],
                    'session' => $validData['session'],
                    'term' => $validData['term'],
                    'subjects' => []
                ];
                $student_totals[$uid] = 0;
            }

            $report_cards[$uid]['subjects'][] = [
                'subject_id' => $row['subject_id'],
                'subject' => $row['subject'],
                'marks_obtained' => $row['marks_obtained'],
                'max_marks' => $row['max_marks'],
                'passing_marks' => $row['passing_marks']
            ];

            $student_totals[$uid] += $row['marks_obtained'];
        }

        if (empty($report_cards)) {
            throw new Exception('No results found for the selected criteria');
        }

        $ranks = $this->calculateRank($validData['class_id'], $validData['session'], $validData['term'], $student_totals);

        $pdf = new FPDF();
        $image_path = $_SERVER['DOCUMENT_ROOT'] . '/app/settings/templates/marksheet/' . $template_file;

        if (!file_exists($image_path)) {
            throw new Exception('Template image not found: ' . $image_path);
        }

        foreach ($report_cards as $uid => &$card) {
            $total_max = array_sum(array_column($card['subjects'], 'max_marks'));
            $total_passing_marks = array_sum(array_column($card['subjects'], 'passing_marks'));
            $total_obt = array_sum(array_column($card['subjects'], 'marks_obtained'));
            $percentage = $total_max > 0 ? ($total_obt / $total_max) * 100 : 0;
            $rank = $ranks[$uid] ?? 'N/A';

            $card['total_marks'] = $total_obt;
            $card['total_max_marks'] = $total_max;
            $card['total_passing_marks'] = $total_passing_marks;
            $card['percentage'] = $percentage;
            $card['rank'] = $rank;

            $pdf->AddPage();
            $pdf->Image($image_path, 0, 0, 210, 297);
            $pdf->SetFont('Arial', 'B', 12);

            // Student photo handling
            $photo_path = $card['student_photo'];
            $photo = $_SERVER['DOCUMENT_ROOT'] . '/' . ltrim($photo_path, '/');
            
            if ($this->validateAndProcessImage($photo)) {
                try {
                    $pdf->Image($photo, 161, 72, 33.5, 37);
                } catch (Exception $e) {
                    $this->logError("FPDF Image error for $photo: " . $e->getMessage());
                    $pdf->SetXY(161, 72);
                    $pdf->SetFont('Arial', '', 8);
                    $pdf->Cell(33.5, 37, 'Photo\nNot Available', 1, 0, 'C');
                }
            } else {
                $pdf->SetXY(161, 72);
                $pdf->SetFont('Arial', '', 8);
                $pdf->Cell(33.5, 37, 'Photo\nNot Available', 1, 0, 'C');
            }
            
            // FOR SWAMI VIVEKANAND NATIONAL SCHOOL
            
            if ($template_file == '1.png') {

                // Font size 12
                $pdf->SetFont('Arial', 'B', 12);
                
                // Convert session from "YYYY-YYYY" to "YYYY-YY"
                if (!empty($card['session']) && preg_match('/^(\d{4})-(\d{4})$/', $card['session'], $matches)) {
                    $sessionFormatted = $matches[1] . '-' . substr($matches[2], 2);
                } else {
                    $sessionFormatted = $card['session']; // fallback if not matching pattern
                }
                
                // Uppercase text with formatted session
                $titleText = strtoupper($card['term'] . " Examination " . $sessionFormatted);
                
                // Text color red
                $pdf->SetTextColor(255, 0, 0);
                
                // Measure text width
                $textWidth = $pdf->GetStringWidth($titleText);
                
                // Padding around text (3mm horizontal, 2mm vertical)
                $paddingX = 3;
                $paddingY = 2;
                $rectWidth = $textWidth + ($paddingX * 2);
                $rectHeight = 12 / 2 + $paddingY * 2; // half of font size + padding
                
                // Position (centered horizontally on page)
                $x = ($pdf->GetPageWidth() - $rectWidth) / 2;
                $y = 46;
                
                // Draw rectangle
                $pdf->Rect($x, $y, $rectWidth, $rectHeight);
                
                // Print text inside rectangle (manually setting XY)
                $pdf->SetXY($x + $paddingX, $y + $paddingY - 1);
                $pdf->Cell($textWidth, $rectHeight - $paddingY, $titleText, 0, 0, 'C');
                
                // Reset text color
                $pdf->SetTextColor(0, 0, 0);
                
                $pdf->SetFont('Arial', 'B', 12);

                $pdf->SetXY(52, 72);
                $pdf->Cell(0, 10, $card['full_name'], 0, 1);
                $pdf->SetXY(52, 81);
                $pdf->Cell(0, 10, $card['father_name'], 0, 1);
                $pdf->SetXY(52, 90.5);
                $pdf->Cell(0, 10, $card['mother_name'], 0, 1);
                $pdf->SetXY(52, 99.8);
                $pdf->Cell(0, 10, $card['class_name'] . ' / ' . $card['roll_no'], 0, 1);
                
                // Split normal and grade subjects
                $normalSubjects = [];
                $gradeSubjects = [];
                foreach ($card['subjects'] as $subject) {
                    $name = strtoupper(trim($subject['subject']));
                    if (in_array($name, ['MUSIC', 'SANITATION'])) {
                        $gradeSubjects[] = $subject;
                    } else {
                        $normalSubjects[] = $subject;
                    }
                }
                
                // Subject Table Header
                $pdf->SetXY(15.3, 110);
                $pdf->Cell(89.7, 10, 'Subject', 1, 0, 'C');
                $pdf->Cell(30, 10, 'Max Marks', 1, 0, 'C');
                $pdf->Cell(30, 10, 'Pass Marks', 1, 0, 'C');
                $pdf->Cell(30, 10, 'Obt. Marks', 1, 0, 'C');
                $pdf->Ln();
                
                $y_pos = 120;
                $total_max = 0;
                $total_pass = 0;
                $total_obt = 0;
                
                // Normal subjects
                foreach ($normalSubjects as $subject) {
                    $pdf->SetXY(15.3, $y_pos);
                    $pdf->Cell(89.7, 10, $subject['subject'], 1, 0, 'L');
                    $pdf->Cell(30, 10, $subject['max_marks'], 1, 0, 'C');
                    $pdf->Cell(30, 10, $subject['passing_marks'], 1, 0, 'C');
                    $pdf->Cell(30, 10, $subject['marks_obtained'], 1, 0, 'C');
                
                    $total_max += $subject['max_marks'];
                    $total_pass += $subject['passing_marks'];
                    $total_obt  += $subject['marks_obtained'];
                
                    $y_pos += 10;
                }
                
                // Total row for normal subjects
                $pdf->SetXY(15.3, $y_pos);
                $pdf->SetFont('Arial', 'B', 14);
                $pdf->Cell(89.7, 10, 'Total', 1, 0, 'C');
                $pdf->Cell(30, 10, $total_max, 1, 0, 'C');
                $pdf->Cell(30, 10, $total_pass, 1, 0, 'C');
                $pdf->Cell(30, 10, $total_obt, 1, 0, 'C');
                $pdf->SetFont('Arial', 'B', 12);
                $y_pos += 10;
                
                // Grade subjects last
                foreach ($gradeSubjects as $subject) {
                    $marks = $subject['marks_obtained'];
                    if ($marks >= 90)      $grade = 'A+';
                    elseif ($marks >= 80) $grade = 'A';
                    elseif ($marks >= 70) $grade = 'B+';
                    elseif ($marks >= 60) $grade = 'B';
                    elseif ($marks >= 50) $grade = 'C+';
                    elseif ($marks >= 40) $grade = 'C';
                    else                  $grade = 'F';
                
                    $pdf->SetXY(15.3, $y_pos);
                    $pdf->Cell(89.7, 10, $subject['subject'], 1, 0, 'L');
                    $pdf->Cell(30, 10, '', 1, 0, 'C'); // No Max Marks
                    $pdf->Cell(30, 10, '', 1, 0, 'C'); // No Pass Marks
                    $pdf->Cell(30, 10, $grade, 1, 0, 'C');
                
                    $y_pos += 10;
                }
                
                // Summary Table - Single Row with 6 columns
                $percentage = ($total_max > 0) ? ($total_obt / $total_max) * 100 : 0;
                
                // Check if any subject has marks less than passing marks
                $hasFailedSubject = false;
                foreach ($normalSubjects as $subject) {
                    if ($subject['marks_obtained'] < $subject['passing_marks']) {
                        $hasFailedSubject = true;
                        break;
                    }
                }
                
                // Determine Pass/Fail
                if (!$hasFailedSubject && $percentage >= 35) {
                    $result = 'Pass';
                    $resultColor = [0, 128, 0]; // green
                } else {
                    $result = 'Fail';
                    $resultColor = [255, 0, 0]; // red
                }
                
                $row_height = 10;
                $col_width = 29.95; // Width for each of the 6 columns
                
                $pdf->SetXY(15.3, $y_pos);
                
                // Headers
                $pdf->Cell($col_width, $row_height, 'Percentage', 1, 0, 'C');
                $pdf->Cell($col_width, $row_height, number_format($percentage, 2) . "%", 1, 0, 'C');
                $pdf->Cell($col_width, $row_height, 'Rank', 1, 0, 'C');
                $pdf->Cell($col_width, $row_height, $rank, 1, 0, 'C');
                $pdf->Cell($col_width, $row_height, 'Result', 1, 0, 'C');
                
                // Result cell with color
                list($r, $g, $b) = $resultColor;
                $pdf->SetTextColor($r, $g, $b);
                $pdf->Cell($col_width, $row_height, $result, 1, 0, 'C');
                $pdf->SetTextColor(0, 0, 0); // reset to black
                
                $pdf->Ln();
    
                // Add signatures as images at the bottom (no table)
                $y_pos = 265; // Add some space
                
                // Department of Examination signature
                if ($validData['dept_examination_signature']) {
                    $dept_sig_path = $_SERVER['DOCUMENT_ROOT'] . '/' . $validData['dept_examination_signature'];
                    if ($this->validateAndProcessImage($dept_sig_path)) {
                        try {
                            $pdf->Image($dept_sig_path, 45, $y_pos, 15, 8);
                        } catch (Exception $e) {
                            $this->logError("Department signature error: " . $e->getMessage());
                        }
                    }
                }
    
                // Class Teacher signature
                if ($validData['class_teacher_signature']) {
                    $class_teacher_sig_path = $_SERVER['DOCUMENT_ROOT'] . '/' . $validData['class_teacher_signature'];
                    if ($this->validateAndProcessImage($class_teacher_sig_path)) {
                        try {
                            $pdf->Image($class_teacher_sig_path, 90, $y_pos, 15, 8);
                        } catch (Exception $e) {
                            $this->logError("Class teacher signature error: " . $e->getMessage());
                        }
                    }
                }
    
                // Principal signature
                if ($validData['principal_signature']) {
                    $principal_sig_path = $_SERVER['DOCUMENT_ROOT'] . '/' . $validData['principal_signature'];
                    if ($this->validateAndProcessImage($principal_sig_path)) {
                        try {
                            $pdf->Image($principal_sig_path, 130, $y_pos, 15, 8);
                        } catch (Exception $e) {
                            $this->logError("Principal signature error: " . $e->getMessage());
                        }
                    }
                }
                
            // FOR NEW TECH PUBLIC SCHOOL
                
            } elseif ($template_file == '3.png') {
                
                // Font size 12
                $pdf->SetFont('Arial', 'B', 12);
                
                // Convert session from "YYYY-YYYY" to "YYYY-YY"
                if (!empty($card['session']) && preg_match('/^(\d{4})-(\d{4})$/', $card['session'], $matches)) {
                    $sessionFormatted = $matches[1] . '-' . substr($matches[2], 2);
                } else {
                    $sessionFormatted = $card['session']; // fallback if not matching pattern
                }
                
                // Uppercase text with formatted session
                $titleText = strtoupper($card['term'] . " Examination " . $sessionFormatted);
                
                // Text color red
                $pdf->SetTextColor(255, 0, 0);
                
                // Measure text width
                $textWidth = $pdf->GetStringWidth($titleText);
                
                // Padding around text (3mm horizontal, 2mm vertical)
                $paddingX = 3;
                $paddingY = 2;
                $rectWidth = $textWidth + ($paddingX * 2);
                $rectHeight = 12 / 2 + $paddingY * 2; // half of font size + padding
                
                // Position (centered horizontally on page)
                $x = ($pdf->GetPageWidth() - $rectWidth) / 2;
                $y = 46;
                
                // Draw rectangle
                $pdf->Rect($x, $y, $rectWidth, $rectHeight);
                
                // Print text inside rectangle (manually setting XY)
                $pdf->SetXY($x + $paddingX, $y + $paddingY - 1);
                $pdf->Cell($textWidth, $rectHeight - $paddingY, $titleText, 0, 0, 'C');
                
                // Reset text color
                $pdf->SetTextColor(0, 0, 0);
                
                $pdf->SetFont('Arial', 'B', 12);
                
                $pdf->SetXY(52, 72);
                $pdf->Cell(0, 10, $card['full_name'], 0, 1);
                $pdf->SetXY(52, 81);
                $pdf->Cell(0, 10, $card['father_name'], 0, 1);
                $pdf->SetXY(52, 90.5);
                $pdf->Cell(0, 10, $card['mother_name'], 0, 1);
                $pdf->SetXY(52, 99.8);
                $pdf->Cell(0, 10, $card['class_name'] . ' / ' . $card['roll_no'], 0, 1);
                
                // Subject Table Header (Added Grade column)
                $pdf->SetXY(15.3, 110);
                $pdf->Cell(74.7, 10, 'Subject', 1, 0, 'C'); // adjusted width
                $pdf->Cell(30, 10, 'Max Marks', 1, 0, 'C');
                $pdf->Cell(30, 10, 'Pass Marks', 1, 0, 'C');
                $pdf->Cell(30, 10, 'Obt. Marks', 1, 0, 'C');
                $pdf->Cell(15, 10, 'Grade', 1, 0, 'C'); // new grade column
                $pdf->Ln();
                
                $y_pos = 120;
                $total_max = 0;
                $total_pass = 0;
                $total_obt = 0;
                
                // Function to get grade from marks
                function getGrade($marks) {
                    if ($marks >= 90)      return 'A+';
                    elseif ($marks >= 80) return 'A';
                    elseif ($marks >= 70) return 'B+';
                    elseif ($marks >= 60) return 'B';
                    elseif ($marks >= 50) return 'C+';
                    elseif ($marks >= 40) return 'C';
                    else                  return 'F';
                }
                
                // All subjects with grades
                foreach ($card['subjects'] as $subject) {
                    $grade = getGrade($subject['marks_obtained']);
                
                    $pdf->SetXY(15.3, $y_pos);
                    $pdf->Cell(74.7, 10, strtoupper($subject['subject']), 1, 0, 'L');
                    $pdf->Cell(30, 10, $subject['max_marks'], 1, 0, 'C');
                    $pdf->Cell(30, 10, $subject['passing_marks'], 1, 0, 'C');
                    $pdf->Cell(30, 10, $subject['marks_obtained'], 1, 0, 'C');
                    $pdf->Cell(15, 10, $grade, 1, 0, 'C');
                
                    $total_max += $subject['max_marks'];
                    $total_pass += $subject['passing_marks'];
                    $total_obt  += $subject['marks_obtained'];
                
                    $y_pos += 10;
                }
                
                // Total row
                $pdf->SetXY(15.3, $y_pos);
                $pdf->SetFont('Arial', 'B', 14);
                $pdf->Cell(74.7, 10, 'Total', 1, 0, 'C');
                $pdf->Cell(30, 10, $total_max, 1, 0, 'C');
                $pdf->Cell(30, 10, $total_pass, 1, 0, 'C');
                $pdf->Cell(30, 10, $total_obt, 1, 0, 'C');
                $pdf->Cell(15, 10, '', 1, 0, 'C'); // no grade for total
                $pdf->SetFont('Arial', 'B', 12);
                $y_pos += 10;
                
                // Summary Table - Single Row with 6 columns
                $percentage = ($total_max > 0) ? ($total_obt / $total_max) * 100 : 0;
                
                // Check if any subject has marks less than passing marks
                $hasFailedSubject = false;
                foreach ($normalSubjects as $subject) {
                    if ($subject['marks_obtained'] < $subject['passing_marks']) {
                        $hasFailedSubject = true;
                        break;
                    }
                }
                
                // Determine Pass/Fail
                if (!$hasFailedSubject && $percentage >= 35) {
                    $result = 'Pass';
                    $resultColor = [0, 128, 0]; // green
                } else {
                    $result = 'Fail';
                    $resultColor = [255, 0, 0]; // red
                }
                
                $row_height = 10;
                $col_width = 29.95; // Width for each of the 6 columns
                
                $pdf->SetXY(15.3, $y_pos);
                
                // Headers
                $pdf->Cell($col_width, $row_height, 'Percentage', 1, 0, 'C');
                $pdf->Cell($col_width, $row_height, number_format($percentage, 2) . "%", 1, 0, 'C');
                $pdf->Cell($col_width, $row_height, 'Rank', 1, 0, 'C');
                $pdf->Cell($col_width, $row_height, $rank, 1, 0, 'C');
                $pdf->Cell($col_width, $row_height, 'Result', 1, 0, 'C');
                
                // Result cell with color
                list($r, $g, $b) = $resultColor;
                $pdf->SetTextColor($r, $g, $b);
                $pdf->Cell($col_width, $row_height, $result, 1, 0, 'C');
                $pdf->SetTextColor(0, 0, 0); // reset to black
                
                $pdf->Ln();
                
                // Signatures
                $y_pos = 265;
                
                if ($validData['class_teacher_signature']) {
                    $class_teacher_sig_path = $_SERVER['DOCUMENT_ROOT'] . '/' . $validData['class_teacher_signature'];
                    if ($this->validateAndProcessImage($class_teacher_sig_path)) {
                        try {
                            $pdf->Image($class_teacher_sig_path, 42, $y_pos, 15, 8);
                        } catch (Exception $e) {
                            $this->logError("Class teacher signature error: " . $e->getMessage());
                        }
                    }
                }
                
                if ($validData['principal_signature']) {
                    $principal_sig_path = $_SERVER['DOCUMENT_ROOT'] . '/' . $validData['principal_signature'];
                    if ($this->validateAndProcessImage($principal_sig_path)) {
                        try {
                            $pdf->Image($principal_sig_path, 100, $y_pos, 15, 8);
                        } catch (Exception $e) {
                            $this->logError("Principal signature error: " . $e->getMessage());
                        }
                    }
                }
                
            // FOR M.G.O. PUBLIC SCHOOL
            
            } else {
                
                $date = date('d-m-Y');

                // Student information
                $pdf->SetFont('Arial', 'B', 12);
                
                $pdf->SetXY(14.2, 63);
                $pdf->Cell(0, 10, "Date: " . $date, 0, 1);
                
                $pdf->SetXY(154.8, 63);
                $pdf->Cell(0, 10, "Session: " . $card['session'], 0, 1);
                
                $pdf->SetXY(52, 72);
                $pdf->Cell(0, 10, $card['full_name'], 0, 1);
                $pdf->SetXY(52, 81);
                $pdf->Cell(0, 10, $card['father_name'], 0, 1);
                $pdf->SetXY(52, 90.5);
                $pdf->Cell(0, 10, $card['mother_name'], 0, 1);
                $pdf->SetXY(52, 99.8);
                $pdf->Cell(0, 10, $card['class_name'], 0, 1);
                $pdf->SetXY(41, 109.6);
                $pdf->Cell(0, 10, $card['roll_no'], 0, 1);
                $pdf->SetXY(136, 109.6);
                $pdf->Cell(0, 10, $card['date_of_birth'], 0, 1);
    
                // Subject Table Header (using original widths)
                $pdf->SetXY(15.3, 120);
                $pdf->Cell(89.7, 10, 'Subject', 1, 0, 'C');
                $pdf->Cell(30, 10, 'Max Marks', 1, 0, 'C');
                $pdf->Cell(30, 10, 'Pass Marks', 1, 0, 'C');
                $pdf->Cell(30, 10, 'Obt. Marks', 1, 0, 'C');
                $pdf->Ln();
    
                // Subject Table Data
                $y_pos = 130;
                foreach ($card['subjects'] as $subject) {
                    $pdf->SetXY(15.3, $y_pos);
                    $pdf->Cell(89.7, 10, $subject['subject'], 1, 0, 'L');
                    $pdf->Cell(30, 10, $subject['max_marks'], 1, 0, 'C');
                    $pdf->Cell(30, 10, number_format($subject['passing_marks'], 2), 1, 0, 'C');
                    $pdf->Cell(30, 10, $subject['marks_obtained'], 1, 0, 'C');
                    $y_pos += 10;
                }
    
                // Summary Table - Single Row with 6 columns
                $percentage = ($total_max > 0) ? ($total_obt / $total_max) * 100 : 0;
                
                // Check if any subject has marks less than passing marks
                $hasFailedSubject = false;
                foreach ($normalSubjects as $subject) {
                    if ($subject['marks_obtained'] < $subject['passing_marks']) {
                        $hasFailedSubject = true;
                        break;
                    }
                }
                
                // Determine Pass/Fail
                if (!$hasFailedSubject && $percentage >= 35) {
                    $result = 'Pass';
                    $resultColor = [0, 128, 0]; // green
                } else {
                    $result = 'Fail';
                    $resultColor = [255, 0, 0]; // red
                }
                
                $row_height = 10;
                $col_width = 29.95; // Width for each of the 6 columns
                
                $pdf->SetXY(15.3, $y_pos);
                
                // Headers
                $pdf->Cell($col_width, $row_height, 'Percentage', 1, 0, 'C');
                $pdf->Cell($col_width, $row_height, number_format($percentage, 2) . "%", 1, 0, 'C');
                $pdf->Cell($col_width, $row_height, 'Rank', 1, 0, 'C');
                $pdf->Cell($col_width, $row_height, $rank, 1, 0, 'C');
                $pdf->Cell($col_width, $row_height, 'Result', 1, 0, 'C');
                
                // Result cell with color
                list($r, $g, $b) = $resultColor;
                $pdf->SetTextColor($r, $g, $b);
                $pdf->Cell($col_width, $row_height, $result, 1, 0, 'C');
                $pdf->SetTextColor(0, 0, 0); // reset to black
                
                $pdf->Ln();
    
                // Add signatures as images at the bottom (no table)
                $y_pos = 265; // Add some space

                // Class Teacher signature
                if ($validData['class_teacher_signature']) {
                    $class_teacher_sig_path = $_SERVER['DOCUMENT_ROOT'] . '/' . $validData['class_teacher_signature'];
                    if ($this->validateAndProcessImage($class_teacher_sig_path)) {
                        try {
                            $pdf->Image($class_teacher_sig_path, 42, $y_pos, 15, 8);
                        } catch (Exception $e) {
                            $this->logError("Class teacher signature error: " . $e->getMessage());
                        }
                    }
                }
    
                // Principal signature
                if ($validData['principal_signature']) {
                    $principal_sig_path = $_SERVER['DOCUMENT_ROOT'] . '/' . $validData['principal_signature'];
                    if ($this->validateAndProcessImage($principal_sig_path)) {
                        try {
                            $pdf->Image($principal_sig_path, 100, $y_pos, 15, 8);
                        } catch (Exception $e) {
                            $this->logError("Principal signature error: " . $e->getMessage());
                        }
                    }
                }
                
            }
            
        }

        return ['pdf' => $pdf, 'report_cards' => $report_cards];
    }

    public function downloadReportCard() {
        if (!isset($_SESSION['uid']) || !in_array($_SESSION['role'], ['Super Admin', 'Admin', 'Accountant'])) {
            http_response_code(403);
            echo 'Unauthorized access';
            exit;
        }

        $data = [
            'class_id' => $_POST['class_id'] ?? $_SESSION['download_class_id'] ?? '',
            'session' => $_POST['session'] ?? $_SESSION['download_session'] ?? '',
            'term' => $_POST['term'] ?? $_SESSION['download_term'] ?? '',
            'students' => $_POST['students'] ?? $_SESSION['download_students'] ?? [],
            'dept_examination_signature' => $_SESSION['download_dept_examination_signature'] ?? null,
            'class_teacher_signature' => $_SESSION['download_class_teacher_signature'] ?? null,
            'principal_signature' => $_SESSION['download_principal_signature'] ?? null
        ];

        try {
            $validData = $this->validateInput($data);
            $result = $this->generatePDF($validData);
            
            $this->logInfo("PDF download initiated for " . count($result['report_cards']) . " students");
            
            // Output PDF directly for download
            echo $result['pdf']->Output('S');
            
        } catch (Exception $e) {
            $this->logError('PDF download failed: ' . $e->getMessage());
            http_response_code(500);
            echo 'Failed to generate PDF: ' . $e->getMessage();
        }
    }

    public function generateReportCard() {
        if (!isset($_SESSION['uid']) || !in_array($_SESSION['role'], ['Super Admin', 'Admin', 'Accountant'])) {
            $this->sendError(403, 'Unauthorized access');
        }

        try {
            // Handle file uploads
            $dept_examination_signature = null;
            $class_teacher_signature = null;
            $principal_signature = null;

            if (isset($_FILES['dept_examination_signature'])) {
                $dept_examination_signature = $this->handleFileUpload($_FILES['dept_examination_signature']);
            }

            if (isset($_FILES['class_teacher_signature'])) {
                $class_teacher_signature = $this->handleFileUpload($_FILES['class_teacher_signature']);
            }

            if (isset($_FILES['principal_signature'])) {
                $principal_signature = $this->handleFileUpload($_FILES['principal_signature']);
            }

            $data = [
                'class_id' => $_POST['class_id'] ?? '',
                'session' => $_POST['session'] ?? '',
                'term' => $_POST['term'] ?? '',
                'students' => $_POST['students'] ?? [],
                'dept_examination_signature' => $dept_examination_signature,
                'class_teacher_signature' => $class_teacher_signature,
                'principal_signature' => $principal_signature
            ];

            $validData = $this->validateInput($data);
            
            // Store data in session for download
            $_SESSION['download_class_id'] = $validData['class_id'];
            $_SESSION['download_session'] = $validData['session'];
            $_SESSION['download_term'] = $validData['term'];
            $_SESSION['download_students'] = $validData['students'];
            $_SESSION['download_dept_examination_signature'] = $validData['dept_examination_signature'];
            $_SESSION['download_class_teacher_signature'] = $validData['class_teacher_signature'];
            $_SESSION['download_principal_signature'] = $validData['principal_signature'];
            
            $result = $this->generatePDF($validData);
            
            $this->logInfo("Report card generation successful for " . count($result['report_cards']) . " students");
            
            // Create download URL
            $downloadUrl = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '?download=pdf';
            
            $this->sendSuccess(200, [
                'success' => true,
                'data' => [
                    'report_cards' => array_values($result['report_cards']),
                    'download_url' => $downloadUrl,
                    'message' => 'Report cards generated successfully. Use the download_url to download the PDF.'
                ]
            ]);

        } catch (PDOException $e) {
            $this->logError('Query failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to generate report cards');
        } catch (Exception $e) {
            $this->logError('PDF generation failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to generate PDF: ' . $e->getMessage());
        }
    }

    public function handleRequest() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->generateReportCard();
        } else {
            $this->sendError(405, 'Method not allowed');
        }
    }
}

// Create logs directory if it doesn't exist
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

$controller = new ReportCardController();
$controller->handleRequest();
?>