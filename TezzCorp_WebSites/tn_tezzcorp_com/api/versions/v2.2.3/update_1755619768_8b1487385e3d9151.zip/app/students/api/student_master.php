<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class StudentMasterController {
    private $pdo;
    private $logger;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    // Send JSON error response with status
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode([
            'status' => 'error',
            'message' => $message
        ]);
        exit;
    }

    // Send JSON success response with status
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode(array_merge([
            'status' => 'success'
        ], $data));
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Log debug message
    private function logDebug(string $message): void {
        ($this->logger)('DEBUG: ' . $message);
    }

    // Generate a custom UID in the format STU6835D492AB3CD
    private function generateUid(): string {
        $prefix = 'STU';
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomPartLength = 13; // To make total length 16 (3 for STU + 13 random)
        $maxAttempts = 10;
        $attempt = 0;

        while ($attempt < $maxAttempts) {
            $randomPart = '';
            for ($i = 0; $i < $randomPartLength; $i++) {
                $randomPart .= $characters[rand(0, strlen($characters) - 1)];
            }
            $uid = $prefix . $randomPart;

            // Check if the UID already exists
            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE uid = ?");
            $stmt->execute([$uid]);
            if (!$stmt->fetch()) {
                return $uid; // UID is unique
            }
            $attempt++;
        }

        throw new Exception('Failed to generate a unique UID after ' . $maxAttempts . ' attempts');
    }

    // Validate and sanitize input data
    private function validateInput(array $data, bool $isUpdate = false): array {
        $errors = [];
        $studentData = [];
        $documents = [];

        // Define fields expected in the students table
        $studentFields = [
            'aadhaar_number' => ['required' => false, 'type' => 'string', 'pattern' => '/^\d{12}$/', 'error' => 'aadhaar_number must be a 12-digit number'],
            'full_name' => ['required' => true, 'type' => 'string'],
            'date_of_birth' => ['required' => true, 'type' => 'date'],
            'gender' => ['required' => true, 'type' => 'enum', 'values' => ['Male', 'Female', 'Other']],
            'mobile_number' => ['required' => true, 'type' => 'string', 'pattern' => '/^\d{10}$/', 'error' => 'mobile_number must be a 10-digit number'],
            'age_year' => ['required' => false, 'type' => 'integer'],
            'age_months' => ['required' => false, 'type' => 'integer'],
            'age_days' => ['required' => false, 'type' => 'integer'],
            'nationality' => ['required' => false, 'type' => 'string'],
            'category' => ['required' => false, 'type' => 'enum', 'values' => ['General', 'OBC', 'EBC', 'SC', 'ST']],
            'languages' => ['required' => false, 'type' => 'string'],
            'id_card' => ['required' => false, 'type' => 'string'],
            'father_name' => ['required' => false, 'type' => 'string'],
            'mother_name' => ['required' => false, 'type' => 'string'],
            'father_dob' => ['required' => false, 'type' => 'date'],
            'father_nationality' => ['required' => false, 'type' => 'string'],
            'father_qualification' => ['required' => false, 'type' => 'string'],
            'father_occupation' => ['required' => false, 'type' => 'string'],
            'father_designation' => ['required' => false, 'type' => 'string'],
            'father_organization' => ['required' => false, 'type' => 'string'],
            'father_office_address' => ['required' => false, 'type' => 'string'],
            'father_mobile' => ['required' => false, 'type' => 'string', 'pattern' => '/^\d{10}$/', 'error' => 'father_mobile must be a 10-digit number'],
            'mother_dob' => ['required' => false, 'type' => 'date'],
            'mother_nationality' => ['required' => false, 'type' => 'string'],
            'mother_qualification' => ['required' => false, 'type' => 'string'],
            'mother_occupation' => ['required' => false, 'type' => 'string'],
            'mother_designation' => ['required' => false, 'type' => 'string'],
            'mother_organization' => ['required' => false, 'type' => 'string'],
            'mother_office_address' => ['required' => false, 'type' => 'string'],
            'mother_mobile' => ['required' => false, 'type' => 'string', 'pattern' => '/^\d{10}$/', 'error' => 'mother_mobile must be a 10-digit number'],
            'last_exam_passed' => ['required' => false, 'type' => 'string'],
            'stream' => ['required' => false, 'type' => 'string'],
            'trade_sector' => ['required' => false, 'type' => 'string'],
            'applying_class' => ['required' => false, 'type' => 'string'],
            'class' => ['required' => false, 'type' => 'integer'],
            'medium' => ['required' => false, 'type' => 'enum', 'values' => ['English', 'Hindi', 'Regional']],
            'contribution' => ['required' => false, 'type' => 'string'],
            'elaborate_choices' => ['required' => false, 'type' => 'string'],
            'rte' => ['required' => false, 'type' => 'string'],
            'email_address' => ['required' => false, 'type' => 'email'],
            'additional_email' => ['required' => false, 'type' => 'email'],
            'residential_address' => ['required' => false, 'type' => 'string'],
            'permanent_address' => ['required' => false, 'type' => 'string'],
            'bank_account_number' => ['required' => false, 'type' => 'string'],
            'ifsc_code' => ['required' => false, 'type' => 'string'],
            'registration_no' => ['required' => false, 'type' => 'string'],
            'session' => ['required' => false, 'type' => 'string'],
            'roll_no' => ['required' => false, 'type' => 'string'],
            'current_school' => ['required' => false, 'type' => 'string'],
            'additional_transport' => ['required' => false, 'type' => 'string'],
            'transport' => ['required' => false, 'type' => 'integer']
        ];

        // Validate student fields
        foreach ($studentFields as $field => $rules) {
            if (isset($data[$field]) && !empty(trim($data[$field]))) {
                $value = trim($data[$field]);

                // Type validation
                switch ($rules['type']) {
                    case 'string':
                        $studentData[$field] = $value;
                        break;
                    case 'integer':
                        if (filter_var($value, FILTER_VALIDATE_INT) === false) {
                            $errors[] = "$field must be an integer";
                        } else {
                            $studentData[$field] = (int)$value;
                        }
                        break;
                    case 'date':
                        $date = DateTime::createFromFormat('Y-m-d', $value);
                        if (!$date || $date->format('Y-m-d') !== $value) {
                            $errors[] = "$field must be a valid date (YYYY-MM-DD)";
                        } else {
                            $studentData[$field] = $value;
                        }
                        break;
                    case 'email':
                        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                            $errors[] = "$field must be a valid email address";
                        } else {
                            $studentData[$field] = $value;
                        }
                        break;
                    case 'enum':
                        if (!in_array($value, $rules['values'], true)) {
                            $errors[] = "$field must be one of: " . implode(', ', $rules['values']);
                        } else {
                            $studentData[$field] = $value;
                        }
                        break;
                }

                // Pattern validation
                if (isset($rules['pattern']) && !preg_match($rules['pattern'], $value)) {
                    $errors[] = $rules['error'];
                }
            } elseif ($rules['required'] && !$isUpdate) {
                $errors[] = "$field is required";
            }
        }

        // Check for existing student with the same aadhaar_number (excluding current student during update)
        if (isset($studentData['aadhaar_number']) && isset($data['uid'])) {
            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE aadhaar_number = ? AND uid != ?");
            $stmt->execute([$studentData['aadhaar_number'], $data['uid']]);
            if ($stmt->fetch()) {
                $errors[] = "A student with aadhaar_number " . $studentData['aadhaar_number'] . " already exists";
            }
        } elseif (isset($studentData['aadhaar_number'])) {
            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE aadhaar_number = ?");
            $stmt->execute([$studentData['aadhaar_number']]);
            if ($stmt->fetch()) {
                $errors[] = "A student with aadhaar_number " . $studentData['aadhaar_number'] . " already exists";
            }
        }

        // Handle document fields
        $documentFields = [
            'aadhaar_card_upload', 'progress_report', 'birth_certificate', 'slc',
            'residential_proof', 'father_photo', 'student_photo', 'mother_photo'
        ];

        foreach ($documentFields as $field) {
            if (isset($data[$field]) && !empty($data[$field]) && $data[$field] !== '(binary)') {
                $documents[$field] = $data[$field];
            }
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        return ['studentData' => $studentData, 'documents' => $documents];
    }

    // Handle GET request to fetch students
    public function get() {
        $uid = isset($_GET['uid']) ? trim($_GET['uid']) : null;
        $class = isset($_GET['class']) ? filter_var($_GET['class'], FILTER_VALIDATE_INT) : null;
        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $perPage = isset($_GET['perPage']) ? max(1, (int)$_GET['perPage']) : 10;
    
        try {
            if ($uid) {
                // Fetch a single student by UID
                $stmt = $this->pdo->prepare("
                    SELECT s.*, 
                        c.class_name,
                        d.aadhaar_card_upload, 
                        d.progress_report, 
                        d.birth_certificate, 
                        d.slc, 
                        d.residential_proof, 
                        d.father_photo, 
                        d.student_photo, 
                        d.mother_photo
                    FROM students s
                    LEFT JOIN class c ON s.class = c.id
                    LEFT JOIN documents d ON s.uid = d.uid
                    WHERE s.uid = ?
                ");
                $stmt->execute([$uid]);
                $student = $stmt->fetch();
    
                if (!$student) {
                    $this->sendError(404, 'Student not found');
                }
    
                $this->sendSuccess(200, ['data' => [$student]]);
            } else {
                // Fetch all students with pagination and optional class filter
                $offset = ($page - 1) * $perPage;
    
                // Build the query with optional class filter
                $query = "
                    SELECT s.*, 
                        c.class_name,
                        d.aadhaar_card_upload, 
                        d.progress_report, 
                        d.birth_certificate, 
                        d.slc, 
                        d.residential_proof, 
                        d.father_photo, 
                        d.student_photo, 
                        d.mother_photo
                    FROM students s
                    LEFT JOIN class c ON s.class = c.id
                    LEFT JOIN documents d ON s.uid = d.uid
                ";
                $countQuery = "SELECT COUNT(*) FROM students s";
                $params = [];
                $countParams = [];
    
                // Add class filter if provided
                if ($class !== null) {
                    if ($class === false || $class <= 0) {
                        $this->sendError(400, 'Invalid class');
                    }
                    $query .= " WHERE s.class = ?";
                    $countQuery .= " WHERE s.class = ?";
                    $params[] = $class;
                    $countParams[] = $class;
                }
    
                // Add pagination to the main query
                $query .= " ORDER BY s.created_at DESC LIMIT ? OFFSET ?";
                $params[] = $perPage;
                $params[] = $offset;
    
                // Get total count for pagination
                $countStmt = $this->pdo->prepare($countQuery);
                $countStmt->execute($countParams);
                $totalItems = (int)$countStmt->fetchColumn();
                $totalPages = max(1, ceil($totalItems / $perPage));
    
                // Fetch students with pagination
                $stmt = $this->pdo->prepare($query);
                $stmt->execute($params);
                $students = $stmt->fetchAll();
    
                $this->sendSuccess(200, [
                    'data' => $students,
                    'meta' => [
                        'page' => $page,
                        'totalPages' => $totalPages,
                        'totalItems' => $totalItems
                    ]
                ]);
            }
        } catch (Exception $e) {
            $this->logError('Failed to fetch students: ' . $e->getMessage());
            $this->sendError(500, 'Failed to fetch students: ' . $e->getMessage());
        }
    }

    // Handle POST request to register a student or approve students
    public function post($data) {
        // Check if this is an approval action
        if (isset($data['action']) && $data['action'] === 'approve' && isset($data['uids'])) {
            $this->approve($data['uids']);
        }

        // Otherwise, proceed with student registration
        $validated = $this->validateInput($data);
        $studentData = $validated['studentData'];
        $documents = $validated['documents'];

        try {
            // Start a transaction to ensure atomicity
            $this->pdo->beginTransaction();

            // Generate a unique UID
            $uid = $this->generateUid();
            $this->logDebug('Generated UID: ' . $uid);

            // Set default status for new student
            $studentData['status'] = 'inactive';

            // Debug: Log student data being inserted
            $this->logDebug('Inserting into students table with data: ' . json_encode($studentData));

            // Step 1: Insert into students table with the custom UID
            $studentFields = array_keys($studentData);
            $studentFields[] = 'uid'; // Add uid to the fields
            $placeholders = array_fill(0, count($studentFields), '?');
            $sql = "INSERT INTO students (" . implode(',', $studentFields) . ", created_at) VALUES (" . implode(',', $placeholders) . ", NOW())";
            $this->logDebug('Executing SQL: ' . $sql . ' with values: ' . json_encode(array_merge(array_values($studentData), [$uid])));
            $stmt = $this->pdo->prepare($sql);
            $values = array_values($studentData);
            $values[] = $uid; // Append the custom UID
            $stmt->execute($values);

            // Check if the insert was successful by checking the affected rows
            if ($stmt->rowCount() === 0) {
                throw new Exception('No rows inserted into students table');
            }

            // Verify the student record exists by querying with aadhaar_number and uid
            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE uid = ?");
            $stmt->execute([$uid]);
            $record = $stmt->fetch();
            if (!$record) {
                throw new Exception('Failed to find student record with UID: ' . $uid);
            }
            $this->logDebug('Found student with UID: ' . $uid);

            // Step 2: Insert into documents table if there are any documents
            if (!empty($documents)) {
                $this->logDebug('Inserting into documents table with data: ' . json_encode($documents));
                $documentFields = array_keys($documents);
                $documentFields[] = 'uid'; // Add uid to the fields
                $placeholders = array_fill(0, count($documentFields), '?');
                $sql = "INSERT INTO documents (" . implode(',', $documentFields) . ") VALUES (" . implode(',', $placeholders) . ")";
                $this->logDebug('Executing SQL: ' . $sql . ' with values: ' . json_encode(array_merge(array_values($documents), [$uid])));
                $stmt = $this->pdo->prepare($sql);

                // Prepare values: document paths + uid
                $values = array_values($documents);
                $values[] = $uid; // Append uid
                $stmt->execute($values);
            }

            // Commit the transaction
            $this->pdo->commit();
            $this->logDebug('Student and documents inserted successfully for UID: ' . $uid);
            $this->sendSuccess(201, ['message' => 'Student registered successfully', 'uid' => $uid]);
        } catch (Exception $e) {
            // Rollback the transaction on error
            $this->pdo->rollBack();
            $this->logError('Failed to register student: ' . $e->getMessage());
            $this->sendError(500, 'Failed to register student: ' . $e->getMessage());
        }
    }

    // Handle PUT request to update a student
    public function put() {
        $data = json_decode(file_get_contents('php://input'), true);
        $uid = isset($data['uid']) ? trim($data['uid']) : null;

        if (!$uid) {
            $this->sendError(400, 'UID is required');
        }

        // Validate input
        $validated = $this->validateInput($data, true);
        $studentData = $validated['studentData'];
        $documents = $validated['documents'];

        try {
            $this->pdo->beginTransaction();

            // Check if the student exists
            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE uid = ?");
            $stmt->execute([$uid]);
            if (!$stmt->fetch()) {
                $this->sendError(404, 'Student not found');
            }

            // Update students table
            if (!empty($studentData)) {
                $fields = array_keys($studentData);
                $setClause = implode(', ', array_map(fn($field) => "$field = ?", $fields));
                $sql = "UPDATE students SET $setClause WHERE uid = ?";
                $stmt = $this->pdo->prepare($sql);
                $values = array_values($studentData);
                $values[] = $uid;
                $stmt->execute($values);

                if ($stmt->rowCount() === 0 && count($studentData) > 0) {
                    $this->logDebug('No changes made to students table for UID: ' . $uid);
                }
            }

            // Update documents table
            if (!empty($documents)) {
                // Check if a document record exists
                $stmt = $this->pdo->prepare("SELECT uid FROM documents WHERE uid = ?");
                $stmt->execute([$uid]);
                if ($stmt->fetch()) {
                    // Update existing record
                    $fields = array_keys($documents);
                    $setClause = implode(', ', array_map(fn($field) => "$field = ?", $fields));
                    $sql = "UPDATE documents SET $setClause WHERE uid = ?";
                    $stmt = $this->pdo->prepare($sql);
                    $values = array_values($documents);
                    $values[] = $uid;
                    $stmt->execute($values);
                } else {
                    // Insert new record
                    $documentFields = array_keys($documents);
                    $documentFields[] = 'uid';
                    $placeholders = array_fill(0, count($documentFields), '?');
                    $sql = "INSERT INTO documents (" . implode(',', $documentFields) . ") VALUES (" . implode(',', $placeholders) . ")";
                    $stmt = $this->pdo->prepare($sql);
                    $values = array_values($documents);
                    $values[] = $uid;
                    $stmt->execute($values);
                }
            }

            $this->pdo->commit();
            $this->logDebug('Student updated successfully for UID: ' . $uid);
            $this->sendSuccess(200, ['message' => 'Student updated successfully']);
        } catch (Exception $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to update student: ' . $e->getMessage());
            $this->sendError(500, 'Failed to update student: ' . $e->getMessage());
        }
    }

    // Handle DELETE request to mark a student as deleted
    public function delete() {
        $input = json_decode(file_get_contents('php://input'), true);
        $uid = isset($input['uid']) ? trim($input['uid']) : null;

        if (!$uid) {
            $this->sendError(400, 'UID is required');
        }

        try {
            $this->pdo->beginTransaction();

            // Check if the student exists
            $stmt = $this->pdo->prepare("SELECT uid FROM students WHERE uid = ?");
            $stmt->execute([$uid]);
            if (!$stmt->fetch()) {
                $this->sendError(404, 'Student not found');
            }

            // Mark the student as deleted
            $stmt = $this->pdo->prepare("UPDATE students SET status = 'deleted' WHERE uid = ?");
            $stmt->execute([$uid]);

            if ($stmt->rowCount() === 0) {
                throw new Exception('Failed to mark student as deleted');
            }

            $this->pdo->commit();
            $this->logDebug('Student marked as deleted successfully for UID: ' . $uid);
            $this->sendSuccess(200, ['message' => 'Student marked as deleted successfully']);
        } catch (Exception $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to delete student: ' . $e->getMessage());
            $this->sendError(500, 'Failed to delete student: ' . $e->getMessage());
        }
    }

    // Handle approval of students
    private function approve(array $uids) {
        if (empty($uids)) {
            $this->sendError(400, 'No UIDs provided for approval');
        }

        try {
            $this->pdo->beginTransaction();

            // Validate all UIDs exist
            $placeholders = array_fill(0, count($uids), '?');
            $sql = "SELECT uid FROM students WHERE uid IN (" . implode(',', $placeholders) . ")";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($uids);
            $existingUids = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);

            if (count($existingUids) !== count($uids)) {
                $missingUids = array_diff($uids, $existingUids);
                $this->sendError(404, 'Students not found: ' . implode(', ', $missingUids));
            }

            // Update status to active
            $sql = "UPDATE students SET status = 'active' WHERE uid IN (" . implode(',', $placeholders) . ")";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($uids);

            if ($stmt->rowCount() === 0) {
                throw new Exception('No students were updated during approval');
            }

            $this->pdo->commit();
            $this->logDebug('Students approved successfully: ' . implode(', ', $uids));
            $this->sendSuccess(200, ['message' => 'Students approved successfully']);
        } catch (Exception $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to approve students: ' . $e->getMessage());
            $this->sendError(500, 'Failed to approve students: ' . $e->getMessage());
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];

        switch ($method) {
            case 'GET':
                $this->get();
                break;

            case 'POST':
                $data = $_POST ?: json_decode(file_get_contents('php://input'), true) ?: [];
                $this->post($data);
                break;

            case 'PUT':
                $this->put();
                break;

            case 'DELETE':
                $this->delete();
                break;

            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new StudentMasterController();
$controller->handleRequest();
?>