<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class SpecialDiscountController {
    private $pdo;
    private $logger;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    private function validateInput(array $data, bool $isUpdate = false): array {
        $this->logError('Validating input: ' . json_encode($data));
        $errors = [];
        $validData = [];

        // Define validation rules
        $fields = [
            'student_id' => ['type' => 'integer', 'required' => !$isUpdate],
            'particular_id' => ['type' => 'integer', 'required' => !$isUpdate],
            'discount_type' => ['type' => 'string', 'enum' => ['percentage', 'fixed'], 'required' => !$isUpdate],
            'discount_value' => ['type' => 'decimal', 'min' => 0, 'required' => !$isUpdate],
            'special_amount' => ['type' => 'decimal', 'min' => 0, 'required' => $isUpdate],
            'reason' => ['type' => 'string', 'max_length' => 255, 'required' => false],
            'status' => ['type' => 'string', 'enum' => ['active', 'inactive'], 'required' => $isUpdate],
            'applicable_months' => ['type' => 'array', 'required' => false],
        ];

        // Validate id for updates
        if ($isUpdate) {
            if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT) || $data['id'] <= 0) {
                $errors[] = "id must be a valid integer";
            } else {
                $validData['id'] = (int)$data['id'];
            }
        }

        // Validate other fields
        foreach ($fields as $field => $rules) {
            if (array_key_exists($field, $data)) {
                $value = $data[$field];

                // Handle NULL or empty strings for optional fields
                if ($value === '' && !$rules['required']) {
                    $value = null;
                }

                // Type checking
                if ($value !== null) {
                    switch ($rules['type']) {
                        case 'string':
                            if (!is_string($value)) {
                                $errors[] = "$field must be a string";
                            } elseif (isset($rules['max_length']) && strlen($value) > $rules['max_length']) {
                                $errors[] = "$field must not exceed {$rules['max_length']} characters";
                            }
                            break;
                        case 'integer':
                            if (!filter_var($value, FILTER_VALIDATE_INT) || $value <= 0) {
                                $errors[] = "$field must be a valid positive integer";
                            } else {
                                $value = (int)$value;
                            }
                            break;
                        case 'decimal':
                            if (!is_numeric($value) || $value < 0) {
                                $errors[] = "$field must be a valid positive number";
                            } else {
                                $value = (float)$value;
                            }
                            if (isset($rules['min']) && $value < $rules['min']) {
                                $errors[] = "$field must be at least {$rules['min']}";
                            }
                            break;
                        case 'array':
                            if (!is_array($value)) {
                                $errors[] = "$field must be an array";
                            } else {
                                foreach ($value as $month) {
                                    if (!filter_var($month, FILTER_VALIDATE_INT) || $month < 1 || $month > 12) {
                                        $errors[] = "applicable_months must contain valid month numbers (1-12)";
                                        break;
                                    }
                                }
                            }
                            break;
                    }

                    // Enum validation
                    if (isset($rules['enum']) && !in_array($value, $rules['enum'], true)) {
                        $errors[] = "$field must be one of: " . implode(', ', $rules['enum']);
                    }
                }

                $validData[$field] = $value;
            } elseif ($rules['required']) {
                $errors[] = "$field is required";
            }
        }

        // Additional validation for discount_type and discount_value
        if (isset($validData['discount_type']) && isset($validData['discount_value'])) {
            if ($validData['discount_type'] === 'percentage' && $validData['discount_value'] > 100) {
                $errors[] = "Percentage discount cannot exceed 100%";
            }
        }

        // Ensure applicable_months is properly formatted
        if (isset($validData['applicable_months']) && is_array($validData['applicable_months']) && !empty($validData['applicable_months'])) {
            $validData['applicable_months'] = implode(',', $validData['applicable_months']);
        } else {
            $validData['applicable_months'] = 'all';
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        $this->logError('Validated data: ' . json_encode($validData));
        return $validData;
    }

    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['status' => 'error', 'message' => $message]);
        exit;
    }

    private function sendSuccess(int $code, string $message, array $data = []): void {
        http_response_code($code);
        echo json_encode(['status' => 'success', 'message' => $message, 'data' => $data]);
        exit;
    }

    private function logError(string $message): void {
        ($this->logger)('SpecialDiscountController: ' . $message);
    }

    public function get($request) {
        // Build WHERE clause based on filters
        $conditions = [];
        $params = [];
        
        if (isset($request['class_id']) && filter_var($request['class_id'], FILTER_VALIDATE_INT)) {
            $conditions[] = 's.class = ?';
            $params[] = $request['class_id'];
        }
        
        if (isset($request['particular_id']) && filter_var($request['particular_id'], FILTER_VALIDATE_INT)) {
            $conditions[] = 'ss.particular_id = ?';
            $params[] = $request['particular_id'];
        }
        
        if (isset($request['status']) && in_array($request['status'], ['active', 'inactive'])) {
            $conditions[] = 'ss.status = ?';
            $params[] = $request['status'];
        }

        $whereClause = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

        if (isset($request['id']) && filter_var($request['id'], FILTER_VALIDATE_INT)) {
            $conditions[] = 'ss.id = ?';
            $params[] = $request['id'];
            $whereClause = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

            $stmt = $this->pdo->prepare("
                SELECT ss.*, 
                       s.full_name as student_name, 
                       s.uid as student_uid, 
                       c.class_name, 
                       p.particular,
                       CAST(fs.amount AS DECIMAL(10,2)) as original_amount, 
                       fs.frequency,
                       CAST(ss.discount_percentage AS DECIMAL(10,2)) as discount_percentage,
                       CAST(ss.special_amount AS DECIMAL(10,2)) as special_amount
                FROM special_structure ss
                JOIN students s ON ss.student_uid = s.uid
                JOIN class c ON s.class = c.id
                JOIN particulars p ON ss.particular_id = p.id
                LEFT JOIN (
                    SELECT particular_id, class_id, amount, frequency
                    FROM fee_structure
                    WHERE status = 'active'
                    AND id IN (
                        SELECT MAX(id)
                        FROM fee_structure
                        WHERE status = 'active'
                        GROUP BY particular_id, class_id
                    )
                ) fs ON fs.particular_id = ss.particular_id AND fs.class_id = s.class
                $whereClause
            ");
            $stmt->execute($params);
            $entry = $stmt->fetch();

            if ($entry) {
                $this->sendSuccess(200, 'Special discount fetched successfully', $entry);
            } else {
                $this->sendSuccess(200, 'No special discount found', []);
            }
        } else {
            $stmt = $this->pdo->prepare("
                SELECT ss.*, 
                       s.full_name as student_name, 
                       s.uid as student_uid, 
                       c.class_name, 
                       p.particular,
                       CAST(fs.amount AS DECIMAL(10,2)) as original_amount, 
                       fs.frequency,
                       CAST(ss.discount_percentage AS DECIMAL(10,2)) as discount_percentage,
                       CAST(ss.special_amount AS DECIMAL(10,2)) as special_amount
                FROM special_structure ss
                JOIN students s ON ss.student_uid = s.uid
                JOIN class c ON s.class = c.id
                JOIN particulars p ON ss.particular_id = p.id
                LEFT JOIN (
                    SELECT particular_id, class_id, amount, frequency
                    FROM fee_structure
                    WHERE status = 'active'
                    AND id IN (
                        SELECT MAX(id)
                        FROM fee_structure
                        WHERE status = 'active'
                        GROUP BY particular_id, class_id
                    )
                ) fs ON fs.particular_id = ss.particular_id AND fs.class_id = s.class
                $whereClause
                ORDER BY ss.created_on DESC
            ");
            $stmt->execute($params);
            $entries = $stmt->fetchAll();

            $this->sendSuccess(200, 'Special discounts fetched successfully', $entries);
        }
    }

    public function post() {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) {
            $input = $_POST;
        }
        $validData = $this->validateInput($input);

        // Fetch student details to get class_id and student_uid
        $stmt = $this->pdo->prepare("SELECT uid, class FROM students WHERE id = ? AND status = 'active'");
        $stmt->execute([$validData['student_id']]);
        $student = $stmt->fetch();
        if (!$student) {
            $this->sendError(404, 'Student not found or inactive');
        }

        // Fetch original amount from fee_structure for the student's class
        $stmt = $this->pdo->prepare("
            SELECT amount
            FROM fee_structure
            WHERE particular_id = ? AND class_id = ? AND status = 'active'
            ORDER BY id DESC
            LIMIT 1
        ");
        $stmt->execute([$validData['particular_id'], $student['class']]);
        $fee = $stmt->fetch();
        if (!$fee) {
            $this->sendError(400, 'No active fee structure found for this particular and class');
        }
        $original_amount = (float)$fee['amount'];

        // Calculate special_amount and discount_percentage
        $discount_value = (float)$validData['discount_value'];
        if ($validData['discount_type'] === 'percentage') {
            $special_amount = $original_amount * (1 - $discount_value / 100);
            $discount_percentage = $discount_value;
        } else {
            $special_amount = $original_amount - $discount_value;
            $discount_percentage = ($original_amount > 0) ? ($discount_value / $original_amount) * 100 : 0;
        }

        if ($special_amount < 0) {
            $this->sendError(400, 'Special amount cannot be negative');
        }

        try {
            $this->pdo->beginTransaction();

            $stmt = $this->pdo->prepare("
                INSERT INTO special_structure (
                    student_uid, particular_id, special_amount, 
                    discount_percentage, applicable_months, reason, status, created_on
                ) VALUES (?, ?, ?, ?, ?, ?, 'active', NOW())
            ");
            $stmt->execute([
                $student['uid'],
                $validData['particular_id'],
                $special_amount,
                $discount_percentage,
                $validData['applicable_months'],
                $validData['reason']
            ]);

            $this->pdo->commit();
            $this->sendSuccess(201, 'Special discount created successfully');
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to create special discount: ' . $e->getMessage());
            $this->sendError(500, 'Failed to create special discount');
        }
    }

    public function put() {
        $input = json_decode(file_get_contents('php://input'), true);
        $validData = $this->validateInput($input, true);

        try {
            $this->pdo->beginTransaction();

            // Fetch original_amount for discount_percentage calculation
            $stmt = $this->pdo->prepare("
                SELECT ss.particular_id, s.class
                FROM special_structure ss
                JOIN students s ON ss.student_uid = s.uid
                WHERE ss.id = ?
            ");
            $stmt->execute([$validData['id']]);
            $discount = $stmt->fetch();
            if (!$discount) {
                $this->pdo->rollBack();
                $this->sendError(404, 'Special discount not found');
            }

            // Fetch original_amount from fee_structure
            $stmt = $this->pdo->prepare("
                SELECT amount
                FROM fee_structure
                WHERE particular_id = ? AND class_id = ? AND status = 'active'
                ORDER BY id DESC
                LIMIT 1
            ");
            $stmt->execute([$discount['particular_id'], $discount['class']]);
            $fee = $stmt->fetch();
            if (!$fee) {
                $this->pdo->rollBack();
                $this->sendError(400, 'No active fee structure found for this particular and class');
            }
            $original_amount = (float)$fee['amount'];

            $special_amount = (float)$validData['special_amount'];
            $discount_percentage = ($original_amount > 0) ? (($original_amount - $special_amount) / $original_amount) * 100 : 0;

            if ($special_amount < 0) {
                $this->pdo->rollBack();
                $this->sendError(400, 'Special amount cannot be negative');
            }

            $stmt = $this->pdo->prepare("
                UPDATE special_structure 
                SET special_amount = ?, discount_percentage = ?, status = ?, reason = ?, updated_on = NOW()
                WHERE id = ?
            ");
            $stmt->execute([
                $special_amount,
                $discount_percentage,
                $validData['status'],
                $validData['reason'],
                $validData['id']
            ]);

            $this->pdo->commit();
            $this->sendSuccess(200, 'Special discount updated successfully');
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            $this->logError('Failed to update special discount: ' . $e->getMessage());
            $this->sendError(500, 'Failed to update special discount');
        }
    }

    public function delete($request) {
        $id = isset($request['id']) ? filter_var($request['id'], FILTER_VALIDATE_INT) : false;
        if (!$id) {
            $this->sendError(400, 'Invalid ID');
        }

        try {
            $stmt = $this->pdo->prepare("DELETE FROM special_structure WHERE id = ?");
            $stmt->execute([$id]);
            if ($stmt->rowCount() > 0) {
                $this->sendSuccess(200, 'Special discount deleted successfully');
            } else {
                $this->sendSuccess(200, 'Special discount not found', []);
            }
        } catch (PDOException $e) {
            $this->logError('Failed to delete special discount: ' . $e->getMessage());
            $this->sendError(500, 'Failed to delete special discount');
        }
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];

        switch ($method) {
            case 'GET':
                $this->get($_GET);
                break;
            case 'POST':
                $this->post();
                break;
            case 'PUT':
                $this->put();
                break;
            case 'DELETE':
                $this->delete($_GET);
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists($_SERVER['DOCUMENT_ROOT'] . '/logs')) {
    mkdir($_SERVER['DOCUMENT_ROOT'] . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new SpecialDiscountController();
$controller->handleRequest();
?>