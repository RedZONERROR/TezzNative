<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

class ClassParticularsController {
    private $pdo;
    private $logger;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    // Send JSON error response
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['status' => 'error', 'message' => $message]);
        exit;
    }

    // Send JSON success response
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode([
            'status' => 'success',
            'message' => 'Class particulars fetched successfully',
            'data' => $data
        ]);
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    public function getClassParticulars($request) {
        if (!isset($request['class_id']) || !filter_var($request['class_id'], FILTER_VALIDATE_INT)) {
            $this->sendError(400, 'Valid class_id is required');
        }

        $classId = (int)$request['class_id'];

        try {
            $stmt = $this->pdo->prepare("
                SELECT DISTINCT fs.particular_id, p.particular, fs.amount, fs.frequency, fs.custom_frequency
                FROM fee_structure fs
                JOIN particulars p ON fs.particular_id = p.id
                WHERE fs.class_id = ? AND fs.status = 'active'
                ORDER BY p.particular ASC
            ");
            $stmt->execute([$classId]);
            $particulars = $stmt->fetchAll();

            $this->sendSuccess(200, $particulars);
        } catch (PDOException $e) {
            $this->logError('Failed to fetch class particulars: ' . $e->getMessage());
            $this->sendError(500, 'Failed to fetch class particulars');
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];

        switch ($method) {
            case 'GET':
                $this->getClassParticulars($_GET);
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new ClassParticularsController();
$controller->handleRequest();
?>