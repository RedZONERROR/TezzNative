<?php
session_start();
if (!isset($_SESSION['uid'])) {
    header("location: ../../login");
    die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- Select2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" />
    <!-- Select2 Bootstrap 5 Theme -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">

    <title>Fee Collection - AI-ERP 2.0</title>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }

        .card-header {
            background-color: #fff;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            padding: 1rem 1.5rem;
        }

        .table {
            margin-bottom: 0;
        }

        .table thead th {
            background-color: #e9ecef;
            text-transform: uppercase;
            font-size: 0.85rem;
            font-weight: 600;
            color: #495057;
        }

        .table tbody tr:hover {
            background-color: #f1f3f5;
        }

        .table td, .table th {
            vertical-align: middle;
            padding: 0.75rem;
        }

        .badge {
            font-size: 0.75rem;
            padding: 0.35em 0.65em;
        }

        .btn {
            border-radius: 0.375rem;
            transition: all 0.2s ease;
        }

        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }

        .btn i {
            margin-right: 0.25rem;
        }

        .btn-loading .fa-spinner {
            display: inline-block;
        }

        .btn-loading .btn-text, .btn-loading .ti {
            display: none;
        }

        .fa-spinner {
            display: none;
            font-size: 0.9rem;
        }

        .table-loader {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 10;
        }

        .table-container {
            position: relative;
        }

        .form-label {
            font-weight: 500;
            color: #495057;
        }

        .form-select, .form-control {
            border-radius: 0.375rem;
            transition: all 0.2s ease;
        }

        .form-select:focus, .form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }

        .modal-content {
            border-radius: 0.75rem;
        }

        .modal-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }

        .modal-footer {
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }

        .select2-container {
            width: 100% !important;
            z-index: 1055 !important;
        }

        .select2-container--bootstrap-5 .select2-selection {
            border-radius: 0.375rem;
            border: 1px solid #ced4da;
            min-height: 38px;
            display: flex;
            align-items: center;
        }

        .select2-container--bootstrap-5 .select2-selection--multiple .select2-selection__choice {
            background-color: #0d6efd;
            color: white;
            border-radius: 0.25rem;
        }

        .select2-container--bootstrap-5 .select2-selection--single .select2-selection__rendered {
            line-height: 38px;
        }

        .select2-container--bootstrap-5 .select2-selection--multiple .select2-selection__rendered {
            line-height: normal;
        }

        .select2-container .select2-dropdown {
            z-index: 1056 !important;
        }

        .select-loading::after {
            content: "Loading...";
            color: #6c757d;
            font-size: 0.875rem;
            margin-left: 0.5rem;
            display: inline-block;
        }

        #collections_count_container {
            display: none;
        }

        .receipt-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 40px;
            font-family: 'Poppins', Arial, sans-serif;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            background-color: #fff;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
        }

        .receipt-watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-45deg);
            font-size: 120px;
            opacity: 0.03;
            font-weight: 700;
            white-space: nowrap;
            pointer-events: none;
            z-index: 0;
        }

        .receipt-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #2563eb;
            padding-bottom: 20px;
            margin-bottom: 30px;
            position: relative;
            z-index: 1;
        }

        .school-logo img {
            max-height: 90px;
            max-width: 180px;
            object-fit: contain;
        }

        .school-info h2 {
            margin: 0;
            font-size: 1.8rem;
            color: #2563eb;
            font-weight: 600;
            letter-spacing: -0.5px;
        }

        .school-info p {
            margin: 4px 0;
            font-size: 0.95rem;
            color: #64748b;
        }

        .receipt-title h3 {
            text-align: center;
            background-color: #2563eb;
            color: white;
            padding: 8px 30px;
            border-radius: 30px;
            font-size: 1.2rem;
            font-weight: 500;
            letter-spacing: 1px;
            text-transform: uppercase;
            box-shadow: 0 4px 6px rgba(37, 99, 235, 0.2);
            margin: 20px 0;
        }

        .receipt-sections {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
            position: relative;
            z-index: 1;
        }

        .receipt-section {
            background-color: #f8fafc;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.03);
        }

        .receipt-section h4 {
            font-size: 1rem;
            color: #475569;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 1px dashed #e2e8f0;
        }

        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .info-item {
            margin-bottom: 8px;
        }

        .info-label {
            font-size: 0.85rem;
            color: #64748b;
        }

        .info-value {
            font-size: 0.95rem;
            font-weight: 500;
            color: #1e293b;
        }

        .payment-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-bottom: 30px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .payment-table th, .payment-table td {
            padding: 12px 15px;
            text-align: left;
            font-size: 0.95rem;
        }

        .payment-table th {
            background-color: #2563eb;
            color: white;
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }

        .payment-table td {
            background-color: white;
            border-bottom: 1px solid #e2e8f0;
        }

        .payment-table tr:last-child td {
            border-bottom: none;
        }

        .amount-row td {
            font-weight: 600;
            color: #2563eb;
        }

        .receipt-footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            position: relative;
            z-index: 1;
        }

        .verification-section {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .verification-code {
            font-family: monospace;
            background-color: #f8fafc;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 0.9rem;
            margin-top: 5px;
            letter-spacing: 1px;
        }

        .thank-you h4 {
            color: #2563eb;
            font-size: 1.2rem;
            margin-bottom: 5px;
        }

        .thank-you p {
            color: #64748b;
            font-size: 0.9rem;
        }

        .date-filter-container {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .select-all-checkbox {
            margin-right: 0.5rem;
        }

        @media print {
            body {
                background-color: white;
            }
            .receipt-container {
                margin: 0;
                padding: 20px;
                border: none;
                box-shadow: none;
                max-width: 100%;
            }
            .payment-table th {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                background-color: #2563eb !important;
                color: white !important;
            }
            .receipt-title h3 {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                background-color: #2563eb !important;
                color: white !important;
            }
            .no-print {
                display: none;
            }
        }

        @media (max-width: 576px) {
            .table {
                font-size: 0.875rem;
            }

            .btn-sm {
                padding: 0.2rem 0.4rem;
                font-size: 0.75rem;
            }

            .card-header {
                padding: 0.75rem 1rem;
            }

            .receipt-container {
                padding: 10px;
            }

            .school-logo img {
                max-height: 60px;
            }

            .school-info h2 {
                font-size: 1.2rem;
            }

            .receipt-table th, .receipt-table td {
                font-size: 0.8rem;
                padding: 8px;
            }

            .date-filter-container {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card mb-3">
                        <div class="card-body py-3">
                            <div class="d-flex align-items-center justify-content-between flex-wrap">
                                <h4 class="card-title mb-0">Fee Collection</h4>
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb mb-0">
                                        <li class="breadcrumb-item d-flex align-items-center">
                                            <a class="text-muted text-decoration-none d-flex" href="/app" aria-label="Home">
                                                <iconify-icon icon="solar:home-2-line-duotone" class="fs-5"></iconify-icon>
                                            </a>
                                        </li>
                                        <li class="breadcrumb-item">
                                            <span class="badge bg-primary-subtle text-primary fw-medium">Fee Collection</span>
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>

                    <!-- Fee Collection Section -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title mb-0">Collect Fees</h4>
                                </div>
                                <div class="card-body">
                                    <form class="row g-3 mb-4">
                                        <div class="col-md-6">
                                            <label for="student_class" class="form-label">Class <span class="text-danger">*</span></label>
                                            <div class="position-relative">
                                                <select class="form-select" id="student_class" name="student_class" aria-label="Select class">
                                                    <option value="">Select Class</option>
                                                    <!-- Class will be fetched dynamically -->
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="student_info" class="form-label">Student <span class="text-danger">*</span></label>
                                            <div class="position-relative">
                                                <select class="form-select" id="student_info" name="student_info" aria-label="Select student" disabled>
                                                    <option value="">Select or search for a student...</option>
                                                    <!-- This details will be fetched dynamically -->
                                                </select>
                                            </div>
                                        </div>
                                    </form>

                                    <!-- Applicable Fees Table -->
                                    <div class="table-container mt-4">
                                        <div class="table-loader">
                                            <div class="spinner-border text-primary" role="status">
                                                <span class="visually-hidden">Loading...</span>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Particular</th>
                                                        <th scope="col">Amount</th>
                                                        <th scope="col">Frequency</th>
                                                        <th scope="col">Pending</th>
                                                        <th scope="col">Remaining Balance</th>
                                                        <th scope="col">Status</th>
                                                        <th scope="col">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="fee_table_body">
                                                    <!-- Fees will load dynamically -->
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <!-- Payment History Table -->
                                    <div class="table-container mt-4">
                                        <div class="card-header d-flex justify-content-between align-items-center">
                                            <h4 class="card-title mb-0">Payment History</h4>
                                            <div class="d-flex align-items-center">
                                                <div class="date-filter-container me-2">
                                                    <div>
                                                        <label for="start_date" class="form-label">Start Date</label>
                                                        <input type="date" class="form-control" id="start_date" name="start_date">
                                                    </div>
                                                    <div>
                                                        <label for="end_date" class="form-label">End Date</label>
                                                        <input type="date" class="form-control" id="end_date" name="end_date">
                                                    </div>
                                                </div>
                                                <button id="refresh_history" class="btn btn-sm btn-outline-secondary me-2">
                                                    <i class="fas fa-sync-alt"></i> Refresh
                                                </button>
                                                <button id="print_selected" class="btn btn-sm btn-outline-info me-2" disabled>
                                                    <i class="fas fa-print"></i> Print Selected
                                                </button>
                                                <div id="history_export_buttons" class="btn-group btn-group-sm" role="group">
                                                    <!-- Export buttons will be added dynamically -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="table-loader">
                                            <div class="spinner-border text-primary" role="status">
                                                <span class="visually-hidden">Loading...</span>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-hover" id="history_table">
                                                <thead>
                                                    <tr>
                                                        <th scope="col"><input type="checkbox" id="select_all_history" class="select-all-checkbox"></th>
                                                        <th scope="col">Particular</th>
                                                        <th scope="col">Amount Collected</th>
                                                        <th scope="col">Discount</th>
                                                        <th scope="col">Remaining Balance</th>
                                                        <th scope="col">Payment Month</th>
                                                        <th scope="col">Payment Date</th>
                                                        <th scope="col">Payment Method</th>
                                                        <th scope="col">Status</th>
                                                        <th scope="col">Session</th>
                                                        <th scope="col">Remarks</th>
                                                        <th scope="col">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="history_table_body">
                                                    <!-- History will load dynamically -->
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Collect Fee Modal -->
                    <div class="modal fade" id="collectFeeModal" tabindex="-1" aria-labelledby="collectFeeModalTitle" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="collectFeeModalTitle">Collect Fee</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form id="collectFeeForm" class="needs-validation" novalidate>
                                        <input type="hidden" id="fee_structure_id">
                                        <input type="hidden" id="fee_frequency" value="">
                                        <div class="mb-3">
                                            <label for="particular" class="form-label">Particular</label>
                                            <input type="text" class="form-control" id="particular" readonly>
                                        </div>
                                        <div class="mb-3">
                                            <label for="fee_amount" class="form-label">Amount (Per Collection)</label>
                                            <input type="number" class="form-control" id="fee_amount" readonly>
                                        </div>
                                        <div class="mb-3" id="payment_month_container">
                                            <label for="payment_month" class="form-label">Payment Month <span class="text-danger">*</span></label>
                                            <select class="form-control" id="payment_month" name="payment_month" multiple required aria-label="Select payment months">
                                                <!-- Populated dynamically -->
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select at least one payment month.
                                            </div>
                                        </div>
                                        <div class="mb-3" id="collections_count_container">
                                            <label for="collections_count" class="form-label">Number of Collections to Pay <span class="text-danger">*</span></label>
                                            <select class="form-control" id="collections_count" name="collections_count" required>
                                                <!-- Populated dynamically -->
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select the number of collections to pay.
                                            </div>
                                        </div>
                                        <div class="mb-3" id="annual_label" style="display: none;">
                                            <label class="form-label">Payment Period</label>
                                            <p class="form-control-plaintext text-info">Annual</p>
                                        </div>
                                        <div class="mb-3">
                                            <label for="remaining_balance" class="form-label">Remaining Balance</label>
                                            <input type="number" class="form-control" id="remaining_balance" readonly>
                                        </div>
                                        <div class="mb-3">
                                            <label for="discount" class="form-label">Discount</label>
                                            <input type="number" step="0.01" class="form-control" id="discount" name="discount" value="0.00">
                                            <div class="invalid-feedback">
                                                Please enter a valid discount amount.
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="amount_collected" class="form-label">Amount Collected <span class="text-danger">*</span></label>
                                            <input type="number" step="0.01" class="form-control" id="amount_collected" name="amount_collected" required readonly>
                                            <div class="invalid-feedback">
                                                Please enter the amount collected.
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="payment_date" class="form-label">Payment Date <span class="text-danger">*</span></label>
                                            <input type="date" class="form-control" id="payment_date" name="payment_date" required>
                                            <div class="invalid-feedback">
                                                Please select a payment date.
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="payment_method" class="form-label">Payment Method <span class="text-danger">*</span></label>
                                            <select class="form-control" id="payment_method" name="payment_method" required aria-label="Select payment method">
                                                <option value="cash">Cash</option>
                                                <option value="card">Card</option>
                                                <option value="online">Online</option>
                                                <option value="cheque">Cheque</option>
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select a payment method.
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="session" class="form-label">Session <span class="text-danger">*</span></label>
                                            <select class="form-control" id="session" name="session" required aria-label="Select session">
                                                <!-- Populated dynamically -->
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select a session.
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="remarks" class="form-label">Remarks</label>
                                            <textarea class="form-control" id="remarks" name="remarks" rows="3"></textarea>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button id="btn-collect" class="btn btn-primary">
                                        <i class="fas fa-spinner fa-spin btn-loading"></i>
                                        <span class="btn-text">Collect Fee</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="dark-transparent sidebartoggler"></div>
    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script src="../assets/js/index.global.min.js"></script>
    <!-- DataTables JS and Dependencies -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>

    <script>
        $(document).ready(function() {
            // Initialize Select2
            $('#student_info').select2({
                theme: 'bootstrap-5',
                placeholder: "Select or search for a student...",
                allowClear: true,
                width: '100%',
                dropdownParent: $('#main-wrapper')
            });
            $('#student_class').select2({
                theme: 'bootstrap-5',
                placeholder: "Select a class...",
                allowClear: true,
                width: '100%',
                dropdownParent: $('#main-wrapper')
            });
            $('#payment_month').select2({
                theme: 'bootstrap-5',
                width: '100%',
                multiple: true,
                placeholder: 'Select payment month(s)...',
                dropdownParent: $('#collectFeeModal')
            });
            $('#collections_count').select2({
                theme: 'bootstrap-5',
                width: '100%',
                dropdownParent: '#collectFeeModal'
            });
            $('#session').select2({
                theme: 'bootstrap-5',
                width: '100%',
                dropdownParent: '#collectFeeModal'
            });

            let selectedStudentId = null;
            let studentTransportStatus = null; // Store transport status
            const currentDate = new Date();
            const currentMonth = currentDate.getMonth() + 1;
            const currentYear = currentDate.getFullYear();

            let sessionStartYear = currentMonth >= 4 ? currentYear : currentYear - 1;
            const currentSession = `${sessionStartYear}-${sessionStartYear + 1}`;

            const sessions = [];
            for (let i = -1; i <= 1; i++) {
                const startYear = sessionStartYear + i;
                sessions.push(`${startYear}-${startYear + 1}`);
            }

            const sessionSelect = $('#session');
            sessionSelect.empty();
            sessions.forEach(session => {
                sessionSelect.append(`<option value="${session}" ${session === currentSession ? 'selected' : ''}>${session}</option>`);
            });

            const sessionMonths = [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3];
            const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

            const today = currentDate.toISOString().split('T')[0];
            $('#payment_date').val(today);
            $('#start_date').val(today);
            $('#end_date').val(today);

            $('.table-loader').hide();

            function loadClasses() {
                $('#student_class').parent().addClass('select-loading');
                $.ajax({
                    url: 'api/class_master.php',
                    method: 'GET',
                    data: { perPage: 100, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        if (Array.isArray(response.data)) {
                            $('#student_class').empty().append('<option value="">Select Class</option>');
                            response.data.forEach(function(item) {
                                $('#student_class').append(`<option value="${item.id}">${item.class_name}</option>`);
                            });
                        } else {
                            Swal.fire({
                                icon: 'warning',
                                title: 'Warning',
                                text: response.message || 'No classes found.'
                            });
                            $('#student_class').empty().append('<option value="">No classes available</option>');
                        }
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: xhr.responseJSON?.message || 'Failed to load classes.'
                        });
                        $('#student_class').empty().append('<option value="">No classes available</option>');
                    },
                    complete: function() {
                        $('#student_class').parent().removeClass('select-loading');
                    }
                });
            }

            loadClasses();

            $('#student_class').on('change', function() {
                var selectedClass = $(this).val();
                $('#student_info').prop('disabled', true).val(null).trigger('change');
                $('#student_info').empty().append('<option value="">Select or search for a student...</option>');
                $('#fee_table_body').empty();
                $('#history_table_body').empty();
                initHistoryTableExport([]);
                selectedStudentId = null;
                studentTransportStatus = null;

                if (selectedClass) {
                    loadStudentsByClass(selectedClass);
                }
            });

            function loadStudentsByClass(selectedClass) {
                $('#student_info').parent().addClass('select-loading');
                $.ajax({
                    url: `api/fee_collection_master.php?personal_class=${selectedClass}`,
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success' && Array.isArray(response.data)) {
                            var studentData = response.data.map(function(student) {
                                return {
                                    id: student.id,
                                    text: student.full_name + ' - ' + student.father_name
                                };
                            });
                            $('#student_info').empty().select2({
                                theme: 'bootstrap-5',
                                placeholder: "Select or search for a student...",
                                allowClear: true,
                                data: studentData
                            });
                            $('#student_info').prop('disabled', studentData.length === 0);
                        } else {
                            Swal.fire({
                                icon: 'warning',
                                title: 'No Students Found',
                                text: response.message || 'No students found for the selected class.'
                            });
                            $('#student_info').empty().select2({
                                theme: 'bootstrap-5',
                                data: [],
                                placeholder: "No students available"
                            });
                            $('#student_info').prop('disabled', true);
                        }
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: xhr.responseJSON?.message || 'Failed to load students.'
                        });
                        $('#student_info').empty().select2({
                            theme: 'bootstrap-5',
                            data: [],
                            placeholder: "No students available"
                        });
                        $('#student_info').prop('disabled', true);
                    },
                    complete: function() {
                        $('#student_info').parent().removeClass('select-loading');
                    }
                });
            }

            $('#student_info').on('change', function() {
                selectedStudentId = $(this).val();
                if (selectedStudentId) {
                    loadApplicableFees(selectedStudentId);
                    loadPaymentHistory(selectedStudentId);
                } else {
                    $('#fee_table_body').empty();
                    $('#history_table_body').empty();
                    initHistoryTableExport([]);
                    studentTransportStatus = null;
                }
            });

            function loadApplicableFees(studentId) {
                $('.table-loader').show();
                $.ajax({
                    url: `api/fee_collection_master.php?student_id=${studentId}`,
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            studentTransportStatus = response.data.transport_status || 0;
                            renderFeeTable(response.data.current_fees || []);
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: response.message || 'Failed to load fees.'
                            });
                            $('#fee_table_body').empty();
                        }
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: xhr.responseJSON?.message || 'Failed to load fees.'
                        });
                        $('#fee_table_body').empty();
                    },
                    complete: function() {
                        $('.table-loader').hide();
                    }
                });
            }

            function renderFeeTable(fees) {
                const tbody = $('#fee_table_body');
                tbody.empty();

                // Filter out Transport Fee if transport_status is 0 or null
                const filteredFees = fees.filter(fee => {
                    if (fee.particular === 'Transport Fee' && (!studentTransportStatus || studentTransportStatus === 0)) {
                        return false;
                    }
                    return true;
                });

                const seenFeeIds = new Set();
                const uniqueFees = filteredFees.filter(fee => {
                    if (seenFeeIds.has(fee.id)) {
                        console.warn(`Duplicate fee_structure_id found: ${fee.id}`);
                        return false;
                    }
                    seenFeeIds.add(fee.id);
                    return true;
                });

                if (uniqueFees.length === 0) {
                    tbody.append(`<tr><td colspan="7" class="text-center text-muted">No pending fees found for the current session (${currentSession}).</td></tr>`);
                    return;
                }

                uniqueFees.forEach(fee => {
                    const frequency = fee.frequency || 'monthly';
                    let pendingMonths = Array.isArray(fee.pending_months) ? fee.pending_months : [];
                    const pendingCollections = fee.pending_collections || 0;
                    const remainingBalance = parseFloat(fee.remaining_balance || 0);
                    const isFullyPaid = fee.is_fully_paid || (pendingCollections === 0 && remainingBalance <= 0);

                    let frequencyDisplay = frequency.charAt(0).toUpperCase() + frequency.slice(1);
                    if (frequency === 'other') {
                        frequencyDisplay = `Every ${fee.custom_frequency} Month${fee.custom_frequency > 1 ? 's' : ''}`;
                    }

                    let pendingDisplay = '';
                    if (frequency === 'annual') {
                        pendingDisplay = 'Annual';
                    } else if (frequency === 'other') {
                        pendingDisplay = `${pendingCollections} Collection${pendingCollections !== 1 ? 's' : ''}`;
                    } else {
                        pendingDisplay = pendingMonths.length > 0 
                            ? pendingMonths.map(m => months[m - 1]).join(', ')
                            : 'None';
                    }

                    let status = '';
                    let statusClass = '';
                    if (isFullyPaid) {
                        status = 'Paid';
                        statusClass = 'bg-success-subtle text-success';
                    } else {
                        let hasOverdue = false;
                        if (frequency === 'monthly') {
                            hasOverdue = pendingMonths.some(m => {
                                const monthYear = m >= 4 ? sessionStartYear : sessionStartYear + 1;
                                const monthDate = new Date(monthYear, m - 1, 1);
                                return monthDate < currentDate;
                            });
                        } else {
                            hasOverdue = true;
                        }
                        status = hasOverdue ? 'Not Paid' : 'Upcoming';
                        statusClass = hasOverdue ? 'bg-danger-subtle text-danger' : 'bg-warning-subtle text-warning';
                    }

                    tbody.append(`
                        <tr data-id="${fee.id}" data-pending='${JSON.stringify(pendingMonths)}'>
                            <td>${fee.particular || 'N/A'}</td>
                            <td>₹${parseFloat(fee.amount || 0).toFixed(2)}</td>
                            <td>${frequencyDisplay}</td>
                            <td>${pendingDisplay}</td>
                            <td>₹${remainingBalance.toFixed(2)}</td>
                            <td><span class="badge ${statusClass}">${status}</span></td>
                            <td>
                                ${!isFullyPaid && (frequency !== 'monthly' || pendingMonths.length > 0) ? `
                                <button class="collect-fee btn btn-sm btn-primary" data-id="${fee.id}" 
                                        data-particular="${fee.particular}" data-amount="${fee.amount}" 
                                        data-pending='${JSON.stringify(pendingMonths)}'
                                        data-pending-collections="${pendingCollections}"
                                        data-frequency='${frequency}'
                                        data-custom-frequency="${fee.custom_frequency || 1}"
                                        data-remaining-balance="${remainingBalance}">
                                    <i class="fas fa-spinner fa-spin btn-loading"></i>
                                    <span class="btn-text"><i class="fas fa-money-bill-wave"></i> Collect</span>
                                </button>
                                ` : '<span class="text-muted">Fully Paid</span>'}
                            </td>
                        </tr>
                    `);
                });
            }

            function loadPaymentHistory(studentId) {
                $('.table-loader').show();
                const startDate = $('#start_date').val();
                const endDate = $('#end_date').val();
                const url = `api/fee_collection_master.php?student_id=${studentId}&history=true${startDate ? `&start_date=${startDate}` : ''}${endDate ? `&end_date=${endDate}` : ''}`;
                $.ajax({
                    url: url,
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            renderHistoryTable(response.data || []);
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: response.message || 'Failed to load payment history.'
                            });
                            $('#history_table_body').empty();
                            initHistoryTableExport([]);
                        }
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: xhr.responseJSON?.message || 'Failed to load payment history.'
                        });
                        $('#history_table_body').empty();
                        initHistoryTableExport([]);
                    },
                    complete: function() {
                        $('.table-loader').hide();
                    }
                });
            }

            function initHistoryTableExport(historyData) {
                if ($('#history_table').hasClass('dataTable')) {
                    $('#history_table').DataTable().destroy();
                    $('#history_export_buttons').empty();
                }

                const dataSet = historyData.map(record => [
                    `<input type="checkbox" class="history-checkbox" data-id="${record.id}" data-record='${JSON.stringify(record)}'>`,
                    record.particular || 'N/A',
                    `₹${parseFloat(record.amount_collected || 0).toFixed(2)}`,
                    `₹${parseFloat(record.discount || 0).toFixed(2)}`,
                    `₹${parseFloat(record.remaining_balance || 0).toFixed(2)}`,
                    record.payment_month_name || '-',
                    record.payment_date ? new Date(record.payment_date).toLocaleDateString('en-IN') : '-',
                    record.payment_method ? (record.payment_method.charAt(0).toUpperCase() + record.payment_method.slice(1)) : '-',
                    record.status === 'completed' ? '<span class="badge bg-success-subtle text-success">Completed</span>' : '<span class="badge bg-danger-subtle text-danger">Failed</span>',
                    record.session || 'N/A',
                    record.remarks || '-',
                    `
                        <button class="print-receipt btn btn-sm btn-outline-info me-1" data-record='${JSON.stringify(record)}'>
                            <i class="fas fa-print"></i> Print
                        </button>
                        <button class="delete-payment btn btn-sm btn-outline-danger" data-id="${record.id}">
                            <i class="fas fa-trash-alt"></i> Delete
                        </button>
                    `
                ]);

                $('#history_table').DataTable({
                    data: dataSet,
                    columns: [
                        { title: "" },
                        { title: "Particular" },
                        { title: "Amount Collected" },
                        { title: "Discount" },
                        { title: "Remaining Balance" },
                        { title: "Payment Month" },
                        { title: "Payment Date" },
                        { title: "Payment Method" },
                        { title: "Status" },
                        { title: "Session" },
                        { title: "Remarks" },
                        { title: "Action" }
                    ],
                    dom: 'Bfrtip',
                    buttons: [
                        {
                            extend: 'print',
                            text: '<i class="fas fa-print"></i> Print All',
                            className: 'btn btn-primary btn-sm me-1',
                            exportOptions: { columns: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] }
                        },
                        {
                            extend: 'excelHtml5',
                            text: '<i class="fas fa-file-excel"></i> Excel',
                            className: 'btn btn-success btn-sm me-1',
                            exportOptions: { columns: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] }
                        },
                        {
                            extend: 'pdfHtml5',
                            text: '<i class="fas fa-file-pdf"></i> PDF',
                            className: 'btn btn-danger btn-sm',
                            exportOptions: { columns: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] }
                        }
                    ],
                    paging: false,
                    searching: false,
                    ordering: false,
                    info: false,
                    autoWidth: false,
                    destroy: true,
                    initComplete: function() {
                        $('#history_export_buttons').empty().append($('.dt-buttons'));
                    }
                });

                $('.history-checkbox').on('change', function() {
                    $('#print_selected').prop('disabled', $('.history-checkbox:checked').length === 0);
                });

                $('#select_all_history').on('change', function() {
                    $('.history-checkbox').prop('checked', this.checked);
                    $('#print_selected').prop('disabled', $('.history-checkbox:checked').length === 0);
                });
            }

            function renderHistoryTable(history) {
                initHistoryTableExport(history);
            }

            function escapeHtml(unsafe) {
                if (unsafe == null) return '';
                return String(unsafe)
                    .replace(/&/g, "&amp;")
                    .replace(/</g, "&lt;")
                    .replace(/>/g, "&gt;")
                    .replace(/"/g, "&quot;")
                    .replace(/'/g, "&#039;");
            }

            $(document).on('click', '.print-receipt', function() {
                const record = $(this).data('record');
                printReceipts([record]);
            });

            $(document).on('click', '#print_selected', function() {
                const selectedRecords = $('.history-checkbox:checked').map(function() {
                    return $(this).data('record');
                }).get();
                if (selectedRecords.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Selection',
                        text: 'Please select at least one payment record to print.'
                    });
                    return;
                }
                printReceipts(selectedRecords);
            });

            function printReceipts(records) {
                const printWindow = window.open('', '_blank');
                let totalAmount = 0, totalDiscount = 0, totalCollected = 0, totalRemaining = 0;

                records.forEach(record => {
                    totalAmount += parseFloat(record.amount_collected || 0) + parseFloat(record.discount || 0) + parseFloat(record.remaining_balance || 0);
                    totalDiscount += parseFloat(record.discount || 0);
                    totalCollected += parseFloat(record.amount_collected || 0);
                    totalRemaining += parseFloat(record.remaining_balance || 0);
                });

                let receiptHtml = `
                    <html>
                    <head>
                        <title>Payment Receipt - ${escapeHtml(records[0]?.school_name || "School")}</title>
                        <style>
                            @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
                            :root {
                                --primary-color: #2563eb;
                                --primary-light: #dbeafe;
                                --secondary-color: #475569;
                                --accent-color: #f59e0b;
                                --light-gray: #f8fafc;
                                --border-color: #e2e8f0;
                                --text-primary: #1e293b;
                                --text-secondary: #64748b;
                            }
                            body { 
                                font-family: 'Poppins', Arial, sans-serif;
                                margin: 0; 
                                padding: 0;
                                background-color: #f1f5f9;
                                color: var(--text-primary);
                                line-height: 1.4;
                            }
                            .receipt-container {
                                /* Optimized for A4 page dimensions */
                                max-width: 720px;
                                margin: 20px auto;
                                padding: 25px;
                                border: 1px solid var(--border-color);
                                border-radius: 8px;
                                background-color: #fff;
                                box-shadow: 0 6px 15px rgba(0, 0, 0, 0.05);
                                position: relative;
                            }
                            .receipt-watermark {
                                position: absolute;
                                top: 50%;
                                left: 50%;
                                transform: translate(-50%, -50%) rotate(-45deg);
                                /* Reduced watermark size for better fit */
                                font-size: 80px;
                                opacity: 0.03;
                                font-weight: 700;
                                white-space: nowrap;
                                pointer-events: none;
                                z-index: 0;
                            }
                            .receipt-header {
                                display: flex;
                                justify-content: space-between;
                                align-items: center;
                                border-bottom: 2px solid var(--primary-color);
                                /* Reduced padding for better space utilization */
                                padding-bottom: 15px;
                                margin-bottom: 20px;
                                position: relative;
                                z-index: 1;
                            }
                            .school-logo img {
                                /* Slightly smaller logo for A4 fit */
                                max-height: 70px;
                                max-width: 140px;
                                object-fit: contain;
                            }
                            .school-info h2 {
                                margin: 0;
                                /* Reduced font size for better fit */
                                font-size: 1.5rem;
                                color: var(--primary-color);
                                font-weight: 600;
                                letter-spacing: -0.5px;
                            }
                            .school-info p {
                                margin: 3px 0;
                                /* Slightly smaller font for contact info */
                                font-size: 0.85rem;
                                color: var(--text-secondary);
                            }
                            .receipt-title h3 {
                                text-align: center;
                                background-color: var(--primary-color);
                                color: white;
                                /* Reduced padding for more compact title */
                                padding: 6px 25px;
                                border-radius: 25px;
                                font-size: 1.1rem;
                                font-weight: 500;
                                letter-spacing: 0.8px;
                                text-transform: uppercase;
                                box-shadow: 0 3px 5px rgba(37, 99, 235, 0.2);
                                /* Reduced margins */
                                margin: 15px 0;
                            }
                            .receipt-sections {
                                display: grid;
                                grid-template-columns: 1fr 1fr;
                                /* Reduced gap for better space usage */
                                gap: 20px;
                                margin-bottom: 20px;
                                position: relative;
                                z-index: 1;
                            }
                            .receipt-section h4 {
                                /* Slightly smaller section headers */
                                font-size: 0.95rem;
                                color: var(--secondary-color);
                                margin-bottom: 12px;
                                padding-bottom: 6px;
                                border-bottom: 1px dashed var(--border-color);
                            }
                            .info-grid {
                                display: grid;
                                grid-template-columns: 1fr 1fr;
                                /* Reduced gap */
                                gap: 8px;
                            }
                            .info-item {
                                /* Reduced margin */
                                margin-bottom: 6px;
                            }
                            .info-label {
                                font-size: 0.8rem;
                                color: var(--text-secondary);
                            }
                            .info-value {
                                /* Slightly smaller value text */
                                font-size: 0.9rem;
                                font-weight: 500;
                                color: var(--text-primary);
                            }
                            .payment-table {
                                width: 100%;
                                border-collapse: separate;
                                border-spacing: 0;
                                /* Reduced margin */
                                margin-bottom: 20px;
                                border-radius: 8px;
                                overflow: hidden;
                                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
                                /* Added responsive table behavior */
                                font-size: 0.8rem;
                            }
                            .payment-table th, .payment-table td {
                                /* Reduced padding for more compact table */
                                padding: 8px 6px;
                                text-align: left;
                                font-size: 0.8rem;
                            }
                            .payment-table th {
                                background-color: var(--primary-color);
                                color: white;
                                font-weight: 500;
                                text-transform: uppercase;
                                font-size: 0.75rem;
                                letter-spacing: 0.3px;
                            }
                            .payment-table td {
                                background-color: white;
                                border-bottom: 1px solid var(--border-color);
                                /* Added word break for long content */
                                word-break: break-word;
                            }
                            .payment-table tr:last-child td {
                                border-bottom: none;
                            }
                            .amount-row td {
                                font-weight: 600;
                                color: var(--primary-color);
                            }
                            .receipt-footer {
                                /* Reduced margins */
                                margin-top: 25px;
                                padding-top: 15px;
                                border-top: 1px solid var(--border-color);
                                display: flex;
                                justify-content: space-between;
                                position: relative;
                                z-index: 1;
                            }
                            .verification-section {
                                display: flex;
                                flex-direction: column;
                                align-items: flex-start;
                            }
                            .verification-code {
                                font-family: monospace;
                                background-color: var(--light-gray);
                                padding: 4px 8px;
                                border-radius: 3px;
                                /* Slightly smaller verification code */
                                font-size: 0.8rem;
                                margin-top: 4px;
                                letter-spacing: 0.8px;
                            }
                            .thank-you h4 {
                                color: var(--primary-color);
                                /* Reduced thank you heading size */
                                font-size: 1.1rem;
                                margin-bottom: 4px;
                            }
                            .thank-you p {
                                color: var(--text-secondary);
                                /* Smaller thank you text */
                                font-size: 0.85rem;
                            }
                            @media print {
                                body {
                                    background-color: white;
                                }
                                .receipt-container {
                                    /* Optimized print layout for A4 */
                                    margin: 0;
                                    padding: 15px;
                                    border: none;
                                    box-shadow: none;
                                    max-width: 100%;
                                    width: 95%;
                                }
                                .payment-table {
                                    /* Ensure table fits on printed page */
                                    font-size: 0.75rem;
                                }
                                .payment-table th, .payment-table td {
                                    padding: 6px 4px;
                                }
                                .payment-table th, .receipt-title h3 {
                                    -webkit-print-color-adjust: exact;
                                    print-color-adjust: exact;
                                    background-color: var(--primary-color) !important;
                                    color: white !important;
                                }
                                /* Added responsive behavior for narrow tables */
                                @page {
                                    size: A4;
                                    margin: 0.5in;
                                }
                            }
                            /* Added responsive design for smaller screens */
                            @media (max-width: 768px) {
                                .receipt-container {
                                    margin: 10px;
                                    padding: 15px;
                                }
                                .receipt-sections {
                                    grid-template-columns: 1fr;
                                    gap: 15px;
                                }
                                .payment-table {
                                    font-size: 0.75rem;
                                }
                                .payment-table th, .payment-table td {
                                    padding: 6px 4px;
                                }
                            }
                        </style>
                    </head>
                    <body>
                        <div class="receipt-container">
                            <div class="receipt-watermark">${escapeHtml(records[0]?.school_name || "RECEIPT")}</div>
                            <div class="receipt-header">
                                <div class="school-logo">
                                    <img src="${escapeHtml(records[0]?.logo || "")}" alt="${escapeHtml(records[0]?.school_name || "School")} Logo">
                                </div>
                                <div class="school-info">
                                    <h2>${escapeHtml(records[0]?.school_name || "School Name")}</h2>
                                    <p>${escapeHtml(records[0]?.address || "Address not provided")}</p>
                                    <p>Phone: ${escapeHtml(records[0]?.phone || "Not provided")}</p>
                                </div>
                            </div>
                            <div class="receipt-title">
                                <h3>Official Payment Receipt</h3>
                            </div>
                            <div class="receipt-sections">
                                <div class="receipt-section">
                                    <h4>Student Information</h4>
                                    <div class="info-grid">
                                        <div class="info-item">
                                            <div class="info-label">Student Name</div>
                                            <div class="info-value">${escapeHtml(records[0]?.student_name || "N/A")}</div>
                                        </div>
                                        <div class="info-item">
                                            <div class="info-label">Father's Name</div>
                                            <div class="info-value">${escapeHtml(records[0]?.father_name || "N/A")}</div>
                                        </div>
                                        <div class="info-item">
                                            <div class="info-label">Class</div>
                                            <div class="info-value">${escapeHtml(records[0]?.class_name || "N/A")}</div>
                                        </div>
                                        <div class="info-item">
                                            <div class="info-label">Session</div>
                                            <div class="info-value">${escapeHtml(records[0]?.session || "N/A")}</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="receipt-section">
                                    <h4>Payment Information</h4>
                                    <div class="info-grid">
                                        <div class="info-item">
                                            <div class="info-label">Receipt No.</div>
                                            <div class="info-value">${records.map((r) => "#" + escapeHtml(r.id || "N/A")).join(", ")}</div>
                                        </div>
                                        <div class="info-item">
                                            <div class="info-label">Generated on</div>
                                            <div class="info-value">${new Date().toLocaleDateString("en-IN", {
                                              day: "numeric",
                                              month: "long",
                                              year: "numeric",
                                              hour: "2-digit",
                                              minute: "2-digit",
                                            })}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="payment-details">
                                <table class="payment-table">
                                    <thead>
                                        <tr>
                                            <th>Receipt No.</th>
                                            <th>Particular</th>
                                            <th>Payment Date</th>
                                            <th>Payment Month</th>
                                            <th>Amount</th>
                                            <th>Discount</th>
                                            <th>Collected</th>
                                            <th>Remaining</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${records
                                          .map(
                                            (record) => `
                                            <tr>
                                                <td>#${escapeHtml(record.id || "N/A")}</td>
                                                <td>${escapeHtml(record.particular || "Fees")}</td>
                                                <td>${record.payment_date ? new Date(record.payment_date).toLocaleDateString("en-IN") : "-"}</td>
                                                <td>${escapeHtml(record.payment_month_name || "-")}</td>
                                                <td>₹${(Number.parseFloat(record.amount_collected || 0) + Number.parseFloat(record.discount || 0) + Number.parseFloat(record.remaining_balance || 0)).toFixed(2)}</td>
                                                <td>₹${Number.parseFloat(record.discount || 0).toFixed(2)}</td>
                                                <td>₹${Number.parseFloat(record.amount_collected || 0).toFixed(2)}</td>
                                                <td>₹${Number.parseFloat(record.remaining_balance || 0).toFixed(2)}</td>
                                            </tr>
                                        `,
                                          )
                                          .join("")}
                                        <tr class="amount-row">
                                            <td colspan="4"><strong>Total</strong></td>
                                            <td>₹${totalAmount.toFixed(2)}</td>
                                            <td>₹${totalDiscount.toFixed(2)}</td>
                                            <td>₹${totalCollected.toFixed(2)}</td>
                                            <td>₹${totalRemaining.toFixed(2)}</td>
                                        </tr>
                                    </tbody>
                                </table>
                                ${
                                  records.some((r) => r.remarks)
                                    ? `
                                <div class="receipt-section">
                                    <h4>Remarks</h4>
                                    ${records.map((r) => (r.remarks ? `<div class="info-value">Receipt #${escapeHtml(r.id)}: ${escapeHtml(r.remarks)}</div>` : "")).join("")}
                                </div>
                                `
                                    : ""
                                }
                            </div>
                            <div class="receipt-footer">
                                <div class="verification-section">
                                    <div class="info-label">Verification Code</div>
                                    <div class="verification-code">${records.map((r) => `${escapeHtml(r.id || "000")}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`).join(", ")}</div>
                                    <div class="info-label" style="margin-top: 10px;">Generated on</div>
                                    <div class="info-value">${new Date().toLocaleDateString("en-IN", {
                                      day: "numeric",
                                      month: "long",
                                      year: "numeric",
                                      hour: "2-digit",
                                      minute: "2-digit",
                                    })}</div>
                                </div>
                                <div class="thank-you">
                                    <h4>Thank You!</h4>
                                    <p>This is a computer-generated receipt.<br>No signature required.</p>
                                </div>
                            </div>
                        </div>
                    </body>
                    </html>
                `;

                printWindow.document.write(receiptHtml);
                printWindow.document.close();
                printWindow.print();
            }

            $(document).on('click', '.delete-payment', function() {
                const paymentId = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You are about to delete this payment record. This action cannot be undone.",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: `api/fee_collection_master.php?payment_id=${paymentId}`,
                            method: 'DELETE',
                            dataType: 'json',
                            success: function(response) {
                                if (response.status === 'success') {
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Deleted!',
                                        text: response.message,
                                        timer: 1500,
                                        showConfirmButton: false
                                    }).then(() => {
                                        loadApplicableFees(selectedStudentId);
                                        loadPaymentHistory(selectedStudentId);
                                    });
                                } else {
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Error',
                                        text: response.message || 'Failed to delete payment record.'
                                    });
                                }
                            },
                            error: function(xhr) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: xhr.responseJSON?.message || 'Failed to delete payment record.'
                                });
                            }
                        });
                    }
                });
            });

            $('#start_date, #end_date').on('change', function() {
                if (selectedStudentId) {
                    loadPaymentHistory(selectedStudentId);
                }
            });

            $('#collectFeeModal').on('hidden.bs.modal', function() {
                $('#collectFeeForm')[0].reset();
                $('#collectFeeForm').removeClass('was-validated');
                $('#fee_structure_id').val('');
                $('#fee_frequency').val('');
                $('#particular').val('');
                $('#fee_amount').val('');
                $('#remaining_balance').val('');
                $('#discount').val('0.00');
                $('#amount_collected').val('');
                $('#payment_method').val('cash');
                $('#payment_date').val(today);
                $('#session').val(currentSession).trigger('change');
                $('#remarks').val('');
                $('#payment_month').empty().prop('multiple', false).attr('disabled', false).trigger('change');
                $('#collections_count').empty().trigger('change');
                $('#payment_month_container').show();
                $('#collections_count_container').hide();
                $('#annual_label').hide();
                $('#payment_month, #discount, #collections_count').off('change.autoAmount input.autoAmount');
                $('#btn-collect').prop('disabled', false);
            });

            $(document).on('click', '.collect-fee', function() {
                const feeId = $(this).data('id');
                const particular = $(this).data('particular');
                const amount = parseFloat($(this).data('amount')) || 0;
                let pendingMonths = $(this).data('pending');
                const pendingCollections = parseInt($(this).data('pending-collections')) || 0;
                const frequency = $(this).data('frequency') || 'monthly';
                const customFrequency = parseInt($(this).data('custom-frequency')) || 1;
                const remainingBalance = parseFloat($(this).data('remaining-balance')) || 0;

                $('#fee_structure_id').val(feeId);
                $('#fee_frequency').val(frequency);
                $('#particular').val(particular);
                $('#fee_amount').val(amount.toFixed(2));
                $('#remaining_balance').val(remainingBalance.toFixed(2));
                $('#session').val(currentSession).trigger('change');

                if (typeof pendingMonths === 'string') {
                    try {
                        pendingMonths = JSON.parse(pendingMonths);
                    } catch (e) {
                        console.error('Failed to parse pendingMonths:', e);
                        pendingMonths = [];
                    }
                }
                if (!Array.isArray(pendingMonths)) {
                    pendingMonths = [];
                }

                const monthSelect = $('#payment_month');
                const collectionsSelect = $('#collections_count');
                if (frequency === 'annual') {
                    $('#payment_month_container').hide();
                    $('#collections_count_container').hide();
                    $('#annual_label').show();
                    monthSelect.empty().append(`<option value="${currentMonth}" selected>${months[currentMonth - 1]}</option>`);
                    monthSelect.prop('multiple', false).attr('disabled', true);

                    const expectedAmount = amount - parseFloat($('#discount').val() || 0);
                    $('#amount_collected').val(remainingBalance > 0 ? remainingBalance.toFixed(2) : expectedAmount.toFixed(2));

                    $('#discount').off('input.autoAmount').on('input.autoAmount', function() {
                        const discount = parseFloat($(this).val()) || 0;
                        const expectedAmount = parseFloat($('#fee_amount').val()) - discount;
                        $('#amount_collected').val(expectedAmount.toFixed(2));
                    });
                } else if (frequency === 'other') {
                    $('#payment_month_container').show();
                    $('#collections_count_container').show();
                    $('#annual_label').hide();

                    monthSelect.empty();
                    const availableMonths = sessionMonths.map(month => month);
                    availableMonths.forEach(month => {
                        monthSelect.append(`<option value="${month}">${months[month - 1]}</option>`);
                    });
                    monthSelect.val(currentMonth).trigger('change');
                    monthSelect.prop('multiple', false).attr('disabled', false);

                    collectionsSelect.empty();
                    for (let i = 1; i <= pendingCollections; i++) {
                        collectionsSelect.append(`<option value="${i}">${i} Collection${i > 1 ? 's' : ''}</option>`);
                    }
                    collectionsSelect.val('1').trigger('change');

                    function updateAmountCollected() {
                        const collectionsCount = parseInt($('#collections_count').val()) || 1;
                        const perCollection = parseFloat($('#fee_amount').val()) || 0;
                        const discount = parseFloat($('#discount').val()) || 0;
                        const totalExpected = (perCollection * collectionsCount) - discount;
                        $('#amount_collected').val(totalExpected.toFixed(2));
                    }

                    $('#collections_count, #discount').off('change.autoAmount input.autoAmount').on('change.autoAmount input.autoAmount', updateAmountCollected);
                    updateAmountCollected();
                } else {
                    $('#payment_month_container').show();
                    $('#collections_count_container').hide();
                    $('#annual_label').hide();
                    monthSelect.empty();

                    if (pendingMonths.length === 0) {
                        monthSelect.append(`<option value="" disabled>No pending months available</option>`);
                        monthSelect.prop('multiple', true).attr('disabled', true);
                        $('#btn-collect').prop('disabled', true);
                        Swal.fire({
                            icon: 'info',
                            title: 'No Pending Months',
                            text: 'There are no pending months to collect for this fee.'
                        });
                    } else {
                        pendingMonths.forEach(month => {
                            monthSelect.append(`<option value="${month}">${months[month - 1]}</option>`);
                        });
                        monthSelect.prop('multiple', true).attr('disabled', false);
                        monthSelect.val([]).trigger('change');
                        $('#btn-collect').prop('disabled', false);
                    }

                    function updateAmountCollected() {
                        const selectedMonths = $('#payment_month').val() || [];
                        const perMonth = parseFloat($('#fee_amount').val()) || 0;
                        const discount = parseFloat($('#discount').val()) || 0;
                        const totalExpected = (perMonth * selectedMonths.length) - discount;
                        $('#amount_collected').val(totalExpected.toFixed(2));
                    }

                    $('#payment_month, #discount').off('change.autoAmount input.autoAmount').on('change.autoAmount input.autoAmount', updateAmountCollected);
                    updateAmountCollected();
                }

                $('#collectFeeModal').modal('show');
            });

            $('#btn-collect').on('click', function(e) {
                e.preventDefault();
                const form = $('#collectFeeForm')[0];
                const btn = $(this);
                const frequency = $('#fee_frequency').val();
                const feeId = $('#fee_structure_id').val();

                // Validate form
                if (form.checkValidity()) {
                    form.classList.add('was-validated');
                    Swal.fire({
                        icon: 'error',
                        title: 'Validation Error',
                        text: 'Please fill out all required fields correctly.'
                    });
                    return;
                }

                let paymentMonth = $('#payment_month').val();
                if (!Array.isArray(paymentMonth)) {
                    paymentMonth = paymentMonth ? [paymentMonth] : [];
                }

                if (frequency !== 'annual' && paymentMonth.length === 0) {
                    $('#payment_month').addClass('is-invalid');
                    Swal.fire({
                        icon: 'error',
                        title: 'Missing Selection',
                        text: 'Please select at least one payment month.'
                    });
                    return;
                }

                if (frequency === 'other') {
                    const collectionsCount = parseInt($('#collections_count').val()) || 0;
                    if (collectionsCount <= 0) {
                        $('#collections_count').addClass('is-invalid');
                        Swal.fire({
                            icon: 'error',
                            title: 'Missing Selection',
                            text: 'Please select the number of collections to pay.'
                        });
                        return;
                    }
                }

                btn.addClass('btn-loading').prop('disabled', true);

                const data = {
                    student_id: selectedStudentId,
                    fee_structure_id: feeId,
                    amount_collected: parseFloat($('#amount_collected').val()) || 0,
                    discount: parseFloat($('#discount').val()) || 0,
                    payment_month: paymentMonth,
                    payment_date: $('#payment_date').val(),
                    payment_method: $('#payment_method').val(),
                    remarks: $('#remarks').val() || null,
                    session: $('#session').val()
                };

                if (frequency === 'other') {
                    data.collections_count = parseInt($('#collections_count').val()) || 1;
                }

                $.ajax({
                    url: 'api/fee_collection_master.php',
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(data),
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success',
                                text: response.message,
                                timer: 1500,
                                showConfirmButton: false
                            }).then(() => {
                                $('#collectFeeModal').modal('hide');
                                loadApplicableFees(selectedStudentId);
                                loadPaymentHistory(selectedStudentId);
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: response.message || 'Failed to collect fee.'
                            });
                        }
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: xhr.responseJSON?.message || 'Failed to collect fee.'
                        });
                    },
                    complete: function() {
                        btn.removeClass('btn-loading').prop('disabled', false);
                    }
                });
            });

            $('#refresh_history').on('click', function() {
                if (selectedStudentId) {
                    loadPaymentHistory(selectedStudentId);
                } else {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Student Selected',
                        text: 'Please select a student to refresh payment history.'
                    });
                }
            });
        });
    </script>
</body>
</html>