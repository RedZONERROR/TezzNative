<?php
session_start();
if (!isset($_SESSION['uid'])) {
    header("location: ../../login");
    die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- Select2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" />
    <!-- Select2 Bootstrap 5 Theme -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">

    <title>Special Discount Management - AI-ERP 2.0</title>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }

        .card-header {
            background-color: #fff;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            padding: 1rem 1.5rem;
        }

        .table {
            margin-bottom: 0;
        }

        .table thead th {
            background-color: #e9ecef;
            text-transform: uppercase;
            font-size: 0.85rem;
            font-weight: 600;
            color: #495057;
        }

        .table tbody tr:hover {
            background-color: #f1f3f5;
        }

        .table td, .table th {
            vertical-align: middle;
            padding: 0.75rem;
        }

        .badge {
            font-size: 0.75rem;
            padding: 0.35em 0.65em;
        }

        .btn {
            border-radius: 0.375rem;
            transition: all 0.2s ease;
        }

        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }

        .btn i {
            margin-right: 0.25rem;
        }

        .form-label {
            font-weight: 500;
            color: #495057;
        }

        .form-select, .form-control {
            border-radius: 0.375rem;
            transition: all 0.2s ease;
        }

        .form-select:focus, .form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }

        .modal-content {
            border-radius: 0.75rem;
        }

        .modal-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }

        .modal-footer {
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }

        .select2-container {
            width: 100% !important;
            z-index: 1055 !important;
        }

        .select2-container--bootstrap-5 .select2-selection {
            border-radius: 0.375rem;
            border: 1px solid #ced4da;
            min-height: 38px;
            display: flex;
            align-items: center;
        }

        .select2-container .select2-dropdown {
            z-index: 1056 !important;
        }

        .discount-preview {
            background-color: #e7f3ff;
            border: 1px solid #b3d9ff;
            border-radius: 0.375rem;
            padding: 1rem;
            margin-top: 1rem;
        }

        .discount-preview h6 {
            color: #0066cc;
            margin-bottom: 0.5rem;
        }

        .discount-preview .row {
            margin-bottom: 0.5rem;
        }

        .discount-preview .row:last-child {
            margin-bottom: 0;
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card mb-3">
                        <div class="card-body py-3">
                            <div class="d-flex align-items-center justify-content-between flex-wrap">
                                <h4 class="card-title mb-0">Special Discount Management</h4>
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb mb-0">
                                        <li class="breadcrumb-item d-flex align-items-center">
                                            <a class="text-muted text-decoration-none d-flex" href="/app" aria-label="Home">
                                                <iconify-icon icon="solar:home-2-line-duotone" class="fs-5"></iconify-icon>
                                            </a>
                                        </li>
                                        <li class="breadcrumb-item">
                                            <span class="badge bg-primary-subtle text-primary fw-medium">Special Discounts</span>
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>

                    <!-- Special Discount Management Section -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h4 class="card-title mb-0">Manage Special Discounts</h4>
                                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addSpecialDiscountModal">
                                        <i class="fas fa-plus"></i> Add Special Discount
                                    </button>
                                </div>
                                <div class="card-body">
                                    <!-- Filter Section -->
                                    <div class="row g-3 mb-4">
                                        <div class="col-md-4">
                                            <label for="filter_class" class="form-label">Filter by Class</label>
                                            <select class="form-select" id="filter_class" name="filter_class">
                                                <option value="">All Classes</option>
                                                <!-- Classes will be loaded dynamically -->
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="filter_particular" class="form-label">Filter by Particular</label>
                                            <select class="form-select" id="filter_particular" name="filter_particular">
                                                <option value="">All Particulars</option>
                                                <!-- Particulars will be loaded dynamically -->
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="filter_status" class="form-label">Filter by Status</label>
                                            <select class="form-select" id="filter_status" name="filter_status">
                                                <option value="">All Status</option>
                                                <option value="active">Active</option>
                                                <option value="inactive">Inactive</option>
                                            </select>
                                        </div>
                                    </div>

                                    <!-- Special Discounts Table -->
                                    <div class="table-responsive">
                                        <table class="table table-hover" id="special_discounts_table">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Student</th>
                                                    <th scope="col">Class</th>
                                                    <th scope="col">Particular</th>
                                                    <th scope="col">Original Amount</th>
                                                    <th scope="col">Special Amount</th>
                                                    <th scope="col">Discount %</th>
                                                    <th scope="col">Frequency</th>
                                                    <th scope="col">Status</th>
                                                    <th scope="col">Created On</th>
                                                    <th scope="col">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody id="special_discounts_body">
                                                <!-- Special discounts will load dynamically -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Add Special Discount Modal -->
                    <div class="modal fade" id="addSpecialDiscountModal" tabindex="-1" aria-labelledby="addSpecialDiscountModalTitle">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="addSpecialDiscountModalTitle">Add Special Discount</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form id="addSpecialDiscountForm" class="needs-validation" novalidate>
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label for="student_class_add" class="form-label">Class <span class="text-danger">*</span></label>
                                                <select class="form-select" id="student_class_add" name="student_class_add" required>
                                                    <option value="">Select Class</option>
                                                    <!-- Classes will be loaded dynamically -->
                                                </select>
                                                <div class="invalid-feedback">Please select a class.</div>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="student_info_add" class="form-label">Student <span class="text-danger">*</span></label>
                                                <select class="form-select" id="student_info_add" name="student_info_add" required disabled>
                                                    <option value="">Select Student</option>
                                                    <!-- Students will be loaded dynamically -->
                                                </select>
                                                <div class="invalid-feedback">Please select a student.</div>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="particular_add" class="form-label">Particular <span class="text-danger">*</span></label>
                                                <select class="form-select" id="particular_add" name="particular_add" required disabled>
                                                    <option value="">Select Particular</option>
                                                    <!-- Particulars will be loaded dynamically -->
                                                </select>
                                                <div class="invalid-feedback">Please select a particular.</div>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="original_amount" class="form-label">Original Amount</label>
                                                <input type="number" step="0.01" class="form-control" id="original_amount" readonly>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="discount_type" class="form-label">Discount Type <span class="text-danger">*</span></label>
                                                <select class="form-select" id="discount_type" name="discount_type" required>
                                                    <option value="">Select Discount Type</option>
                                                    <option value="percentage">Percentage</option>
                                                    <option value="fixed">Fixed Amount</option>
                                                </select>
                                                <div class="invalid-feedback">Please select a discount type.</div>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="discount_value" class="form-label">Discount Value <span class="text-danger">*</span></label>
                                                <input type="number" step="0.01" class="form-control" id="discount_value" name="discount_value" required>
                                                <div class="invalid-feedback">Please enter a discount value.</div>
                                                <small class="form-text text-muted" id="discount_help">Enter percentage (0-100) or fixed amount</small>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="applicable_months_add" class="form-label">Applicable Months</label>
                                                <select class="form-control" id="applicable_months_add" name="applicable_months_add" multiple>
                                                    <option value="1">January</option>
                                                    <option value="2">February</option>
                                                    <option value="3">March</option>
                                                    <option value="4">April</option>
                                                    <option value="5">May</option>
                                                    <option value="6">June</option>
                                                    <option value="7">July</option>
                                                    <option value="8">August</option>
                                                    <option value="9">September</option>
                                                    <option value="10">October</option>
                                                    <option value="11">November</option>
                                                    <option value="12">December</option>
                                                </select>
                                                <small class="form-text text-muted">Leave empty for all months</small>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="frequency_add" class="form-label">Frequency</label>
                                                <input type="text" class="form-control" id="frequency_add" readonly>
                                            </div>
                                            <div class="col-12">
                                                <label for="reason_add" class="form-label">Reason for Special Discount</label>
                                                <textarea class="form-control" id="reason_add" name="reason_add" rows="3" placeholder="Enter reason for providing special discount..."></textarea>
                                            </div>
                                        </div>

                                        <!-- Discount Preview -->
                                        <div class="discount-preview" id="discount_preview" style="display: none;">
                                            <h6><i class="fas fa-calculator"></i> Discount Preview</h6>
                                            <div class="row">
                                                <div class="col-6"><strong>Original Amount:</strong></div>
                                                <div class="col-6" id="preview_original">₹0.00</div>
                                            </div>
                                            <div class="row">
                                                <div class="col-6"><strong>Discount:</strong></div>
                                                <div class="col-6" id="preview_discount">₹0.00</div>
                                            </div>
                                            <div class="row">
                                                <div class="col-6"><strong>Special Amount:</strong></div>
                                                <div class="col-6 text-success" id="preview_special"><strong>₹0.00</strong></div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button id="btn-add-discount" class="btn btn-primary">
                                        <i class="fas fa-spinner fa-spin" style="display: none;"></i>
                                        <span class="btn-text">Add Special Discount</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Edit Special Discount Modal -->
                    <div class="modal fade" id="editSpecialDiscountModal" tabindex="-1" aria-labelledby="editSpecialDiscountModalTitle">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editSpecialDiscountModalTitle">Edit Special Discount</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form id="editSpecialDiscountForm" class="needs-validation" novalidate>
                                        <input type="hidden" id="edit_discount_id">
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label for="edit_student_name" class="form-label">Student</label>
                                                <input type="text" class="form-control" id="edit_student_name" readonly>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="edit_particular_name" class="form-label">Particular</label>
                                                <input type="text" class="form-control" id="edit_particular_name" readonly>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="edit_original_amount" class="form-label">Original Amount</label>
                                                <input type="number" step="0.01" class="form-control" id="edit_original_amount" readonly>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="edit_special_amount" class="form-label">Special Amount <span class="text-danger">*</span></label>
                                                <input type="number" step="0.01" class="form-control" id="edit_special_amount" name="edit_special_amount" required>
                                                <div class="invalid-feedback">Please enter a special amount.</div>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="edit_status" class="form-label">Status <span class="text-danger">*</span></label>
                                                <select class="form-select" id="edit_status" name="edit_status" required>
                                                    <option value="active">Active</option>
                                                    <option value="inactive">Inactive</option>
                                                </select>
                                                <div class="invalid-feedback">Please select a status.</div>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="edit_discount_percentage" class="form-label">Discount Percentage</label>
                                                <input type="number" step="0.01" class="form-control" id="edit_discount_percentage" readonly>
                                            </div>
                                            <div class="col-12">
                                                <label for="edit_reason" class="form-label">Reason for Special Discount</label>
                                                <textarea class="form-control" id="edit_reason" name="edit_reason" rows="3"></textarea>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button id="btn-update-discount" class="btn btn-primary">
                                        <i class="fas fa-spinner fa-spin" style="display: none;"></i>
                                        <span class="btn-text">Update Special Discount</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="dark-transparent sidebartoggler"></div>
    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>

    <script>
        $(document).ready(function() {
            // Initialize Select2
            $('#student_info_add, #particular_add, #applicable_months_add').select2({
                theme: 'bootstrap-5',
                dropdownParent: $('#addSpecialDiscountModal'),
                placeholder: 'Select an option',
                allowClear: true
            });

            // Initialize DataTable
            let specialDiscountsTable = $('#special_discounts_table').DataTable({
                responsive: true,
                pageLength: 25,
                dom: 'Bfrtip',
                buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
                order: [[8, 'desc']], // Sort by created date
                columnDefs: [
                    { targets: [9], orderable: false } // Actions column
                ]
            });

            // Handle modal show/hide to manage focus and ARIA
            $('#addSpecialDiscountModal, #editSpecialDiscountModal').on('show.bs.modal', function() {
                $('#main-wrapper').removeAttr('aria-hidden');
            }).on('hidden.bs.modal', function() {
                $('#main-wrapper').removeAttr('aria-hidden');
                // Reset forms
                $('#addSpecialDiscountForm')[0].reset();
                $('#editSpecialDiscountForm')[0].reset();
                $('#student_info_add, #particular_add, #applicable_months_add').val(null).trigger('change');
                $('#student_info_add, #particular_add').prop('disabled', true).html('<option value="">Select Student/Particular</option>');
                $('#original_amount, #frequency_add').val('');
                $('#discount_preview').hide();
            });

            // Load initial data
            loadClasses();
            loadParticulars();
            loadSpecialDiscounts();

            // Load classes
            function loadClasses() {
                $.ajax({
                    url: 'api/class_master.php',
                    method: 'GET',
                    data: { perPage: 100, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Classes response:', response);
                        if (response && response.data && Array.isArray(response.data)) {
                            let options = '<option value="">Select Class</option>';
                            response.data.forEach(function(item) {
                                options += `<option value="${item.id}">${item.class_name}</option>`;
                            });
                            $('#student_class_add, #filter_class').html(options).trigger('change');
                        } else {
                            console.warn('No classes found or invalid response:', response);
                            Swal.fire('Warning', 'No active classes found', 'warning');
                            $('#student_class_add, #filter_class').html('<option value="">No Classes Available</option>');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Classes load error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to load classes', 'error');
                        $('#student_class_add, #filter_class').html('<option value="">No Classes Available</option>');
                    }
                });
            }

            // Load particulars for filter
            function loadParticulars() {
                $.ajax({
                    url: 'api/particulars_master.php',
                    method: 'GET',
                    data: { status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Particulars response:', response);
                        if (response && response.data && Array.isArray(response.data)) {
                            let options = '<option value="">All Particulars</option>';
                            response.data.forEach(function(item) {
                                options += `<option value="${item.id}">${item.particular}</option>`;
                            });
                            $('#filter_particular').html(options).trigger('change');
                        } else {
                            console.warn('No particulars found or invalid response:', response);
                            Swal.fire('Warning', 'No particulars found', 'warning');
                            $('#filter_particular').html('<option value="">No Particulars Available</option>');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Particulars load error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to load particulars', 'error');
                        $('#filter_particular').html('<option value="">No Particulars Available</option>');
                    }
                });
            }

            // Load students when class is selected
            $('#student_class_add').change(function() {
                const classId = $(this).val();
                if (classId) {
                    loadStudents(classId);
                    loadClassParticulars(classId);
                } else {
                    $('#student_info_add, #particular_add').prop('disabled', true).html('<option value="">Select Student/Particular</option>');
                    $('#student_info_add, #particular_add').val(null).trigger('change');
                    $('#original_amount, #frequency_add').val('');
                }
            });

            // Load students for selected class
            function loadStudents(classId) {
                $.ajax({
                    url: `api/fee_collection_master.php?personal_class=${classId}`,
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        console.log('Students response:', response);
                        if (response && response.status === 'success' && Array.isArray(response.data)) {
                            let options = '<option value="">Select Student</option>';
                            response.data.forEach(function(student) {
                                options += `<option value="${student.id}">${student.full_name} (${student.father_name})</option>`;
                            });
                            $('#student_info_add').prop('disabled', false).html(options);
                            $('#student_info_add').val(null).trigger('change');
                        } else {
                            console.warn('No students found or invalid response:', response);
                            Swal.fire('Warning', 'No students found for this class', 'warning');
                            $('#student_info_add').prop('disabled', true).html('<option value="">No Students Available</option>');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Students load error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to load students', 'error');
                        $('#student_info_add').prop('disabled', true).html('<option value="">No Students Available</option>');
                    }
                });
            }

            // Load particulars for selected class from particulars_master.php
            function loadClassParticulars(classId) {
                $.ajax({
                    url: `api/particulars_master.php`,
                    method: 'GET',
                    data: { status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Class particulars response:', response);
                        if (response && response.data && Array.isArray(response.data)) {
                            let options = '<option value="">Select Particular</option>';
                            response.data.forEach(function(item) {
                                options += `<option value="${item.id}">${item.particular}</option>`;
                            });
                            $('#particular_add').prop('disabled', false).html(options).trigger('change');
                        } else {
                            console.warn('No particulars found for class or invalid response:', response);
                            Swal.fire('Warning', 'No particulars found', 'warning');
                            $('#particular_add').prop('disabled', true).html('<option value="">No Particulars Available</option>');
                            $('#original_amount, #frequency_add').val('');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Class particulars load error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to load particulars for class', 'error');
                        $('#particular_add').prop('disabled', true).html('<option value="">No Particulars Available</option>');
                        $('#original_amount, #frequency_add').val('');
                    }
                });
            }

            // Fetch fee structure for selected particular and class
            function loadFeeStructureForParticular(classId, particularId) {
                $.ajax({
                    url: `api/fee_structure_master.php`,
                    method: 'GET',
                    data: { class_id: classId, perPage: 10000, particular_id: particularId, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Fee structure response:', response);
                        if (response && response.data && Array.isArray(response.data)) {
                            // Filter for the exact class_id and particular_id
                            const matchingItem = response.data.find(item => 
                                parseInt(item.class_id) === parseInt(classId) && 
                                parseInt(item.particular_id) === parseInt(particularId)
                            );
                            
                            if (matchingItem) {
                                const amount = parseFloat(matchingItem.amount) || 0;
                                const frequency = matchingItem.frequency === 'other' && matchingItem.custom_frequency 
                                    ? `${matchingItem.custom_frequency} times` 
                                    : matchingItem.frequency;
                                
                                $('#original_amount').val(amount.toFixed(2));
                                $('#frequency_add').val(frequency ? frequency.charAt(0).toUpperCase() + frequency.slice(1) : '');
                                calculateDiscount();
                            } else {
                                console.warn('No matching fee structure found for class_id:', classId, 'particular_id:', particularId);
                                Swal.fire('Warning', 'No fee structure found for this particular and class', 'warning');
                                $('#original_amount, #frequency_add').val('');
                                $('#discount_preview').hide();
                            }
                        } else {
                            console.warn('No fee structure found or invalid response:', response);
                            Swal.fire('Warning', 'No fee structure found for this particular and class', 'warning');
                            $('#original_amount, #frequency_add').val('');
                            $('#discount_preview').hide();
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Fee structure load error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to load fee structure', 'error');
                        $('#original_amount, #frequency_add').val('');
                        $('#discount_preview').hide();
                    }
                });
            }

            // Update original amount and frequency when particular is selected
            $('#particular_add').change(function() {
                const particularId = $(this).val();
                const classId = $('#student_class_add').val();
                
                if (particularId && classId) {
                    loadFeeStructureForParticular(classId, particularId);
                } else {
                    $('#original_amount, #frequency_add').val('');
                    $('#discount_preview').hide();
                }
            });

            // Calculate discount when discount type or value changes
            $('#discount_type, #discount_value').on('input change', function() {
                calculateDiscount();
            });

            // Calculate and preview discount
            function calculateDiscount() {
                const originalAmount = parseFloat($('#original_amount').val()) || 0;
                const discountType = $('#discount_type').val();
                const discountValue = parseFloat($('#discount_value').val()) || 0;

                if (originalAmount > 0 && discountType && discountValue > 0) {
                    let discountAmount = 0;
                    let specialAmount = 0;

                    if (discountType === 'percentage') {
                        if (discountValue > 100) {
                            $('#discount_value').val(100);
                            return;
                        }
                        discountAmount = (originalAmount * discountValue) / 100;
                        specialAmount = originalAmount - discountAmount;
                        $('#discount_help').text('Enter percentage (0-100)');
                    } else if (discountType === 'fixed') {
                        if (discountValue > originalAmount) {
                            $('#discount_value').val(originalAmount);
                            return;
                        }
                        discountAmount = discountValue;
                        specialAmount = originalAmount - discountAmount;
                        $('#discount_help').text('Enter fixed amount (max: ₹' + originalAmount.toFixed(2) + ')');
                    }

                    // Update preview
                    $('#preview_original').text('₹' + originalAmount.toFixed(2));
                    $('#preview_discount').text('₹' + discountAmount.toFixed(2));
                    $('#preview_special').text('₹' + specialAmount.toFixed(2));
                    $('#discount_preview').show();
                } else {
                    $('#discount_preview').hide();
                }
            }

            // Load special discounts
            function loadSpecialDiscounts() {
                const classFilter = $('#filter_class').val();
                const particularFilter = $('#filter_particular').val();
                const statusFilter = $('#filter_status').val();
                
                $.ajax({
                    url: 'api/special_discount_master.php',
                    method: 'GET',
                    data: {
                        class_id: classFilter,
                        particular_id: particularFilter,
                        status: statusFilter
                    },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Special discounts response:', response);
                        if (response && response.status === 'success') {
                            updateSpecialDiscountsTable(response.data || []);
                        } else {
                            console.warn('Invalid special discounts response:', response);
                            updateSpecialDiscountsTable([]);
                            Swal.fire('Warning', response?.message || 'No special discounts found', 'warning');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Special discounts load error:', xhr.responseText);
                        updateSpecialDiscountsTable([]);
                        Swal.fire('Error', 'Failed to load special discounts', 'error');
                    }
                });
            }

            // Update special discounts table
            function updateSpecialDiscountsTable(data) {
                specialDiscountsTable.clear();
                
                if (!Array.isArray(data) || data.length === 0) {
                    specialDiscountsTable.draw();
                    return;
                }

                data.forEach(function(discount) {
                    const statusBadge = discount.status === 'active' 
                        ? '<span class="badge bg-success">Active</span>'
                        : '<span class="badge bg-secondary">Inactive</span>';
                    
                    const discountPercentage = discount.discount_percentage != null && parseFloat(discount.discount_percentage) > 0 
                        ? parseFloat(discount.discount_percentage).toFixed(2) + '%'
                        : 'N/A';

                    const originalAmount = discount.original_amount != null 
                        ? '₹' + parseFloat(discount.original_amount).toFixed(2)
                        : 'N/A';

                    const specialAmount = discount.special_amount != null 
                        ? '₹' + parseFloat(discount.special_amount).toFixed(2)
                        : 'N/A';

                    const frequency = discount.frequency 
                        ? discount.frequency.charAt(0).toUpperCase() + discount.frequency.slice(1)
                        : 'N/A';

                    const createdOn = discount.created_on 
                        ? new Date(discount.created_on).toLocaleDateString()
                        : 'N/A';

                    const actions = `
                        <div class="btn-group btn-group-sm" role="group">
                            <button class="btn btn-outline-primary btn-edit" data-id="${discount.id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-outline-danger btn-delete" data-id="${discount.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    `;

                    specialDiscountsTable.row.add([
                        discount.student_name || 'N/A',
                        discount.class_name || 'N/A',
                        discount.particular || 'N/A',
                        originalAmount,
                        specialAmount,
                        discountPercentage,
                        frequency,
                        statusBadge,
                        createdOn,
                        actions
                    ]);
                });
                
                specialDiscountsTable.draw();
            }

            // Add special discount
            $('#btn-add-discount').click(function() {
                if (!$('#addSpecialDiscountForm')[0].checkValidity()) {
                    $('#addSpecialDiscountForm')[0].reportValidity();
                    return;
                }

                const formData = {
                    student_id: $('#student_info_add').val(),
                    particular_id: $('#particular_add').val(),
                    discount_type: $('#discount_type').val(),
                    discount_value: $('#discount_value').val(),
                    applicable_months: $('#applicable_months_add').val(),
                    reason: $('#reason_add').val()
                };

                $(this).prop('disabled', true).find('.fa-spinner').show();

                $.ajax({
                    url: 'api/special_discount_master.php',
                    method: 'POST',
                    data: JSON.stringify(formData),
                    contentType: 'application/json',
                    dataType: 'json',
                    success: function(response) {
                        console.log('Add discount response:', response);
                        if (response.status === 'success') {
                            Swal.fire('Success', response.message, 'success');
                            $('#addSpecialDiscountModal').modal('hide');
                            loadSpecialDiscounts();
                        } else {
                            Swal.fire('Error', response.message || 'Failed to add special discount', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Add discount error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to add special discount', 'error');
                    },
                    complete: function() {
                        $('#btn-add-discount').prop('disabled', false).find('.fa-spinner').hide();
                    }
                });
            });

            // Edit special discount
            $(document).on('click', '.btn-edit', function() {
                const discountId = $(this).data('id');
                
                $.ajax({
                    url: `api/special_discount_master.php?id=${discountId}`,
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        console.log('Edit discount response:', response);
                        if (response && response.status === 'success' && response.data) {
                            const discount = response.data;
                            $('#edit_discount_id').val(discount.id);
                            $('#edit_student_name').val(discount.student_name || '');
                            $('#edit_particular_name').val(discount.particular || '');
                            $('#edit_original_amount').val(discount.original_amount != null ? parseFloat(discount.original_amount).toFixed(2) : '');
                            $('#edit_special_amount').val(discount.special_amount != null ? parseFloat(discount.special_amount).toFixed(2) : '');
                            $('#edit_status').val(discount.status || 'active');
                            $('#edit_discount_percentage').val(discount.discount_percentage != null ? parseFloat(discount.discount_percentage).toFixed(2) : '');
                            $('#edit_reason').val(discount.reason || '');
                            
                            $('#editSpecialDiscountModal').modal('show');
                        } else {
                            Swal.fire('Error', response?.message || 'Invalid discount data', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Edit discount error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to load discount details', 'error');
                    }
                });
            });

            // Update special discount
            $('#btn-update-discount').click(function() {
                if (!$('#editSpecialDiscountForm')[0].checkValidity()) {
                    $('#editSpecialDiscountForm')[0].reportValidity();
                    return;
                }

                const formData = {
                    id: $('#edit_discount_id').val(),
                    special_amount: $('#edit_special_amount').val(),
                    status: $('#edit_status').val(),
                    reason: $('#edit_reason').val()
                };

                $(this).prop('disabled', true).find('.fa-spinner').show();

                $.ajax({
                    url: 'api/special_discount_master.php',
                    method: 'PUT',
                    data: JSON.stringify(formData),
                    contentType: 'application/json',
                    dataType: 'json',
                    success: function(response) {
                        console.log('Update discount response:', response);
                        if (response.status === 'success') {
                            Swal.fire('Success', response.message, 'success');
                            $('#editSpecialDiscountModal').modal('hide');
                            loadSpecialDiscounts();
                        } else {
                            Swal.fire('Error', response.message || 'Failed to update special discount', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Update discount error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to update special discount', 'error');
                    },
                    complete: function() {
                        $('#btn-update-discount').prop('disabled', false).find('.fa-spinner').hide();
                    }
                });
            });

            // Delete special discount
            $(document).on('click', '.btn-delete', function() {
                const discountId = $(this).data('id');
                
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'This will permanently delete the special discount!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: `api/special_discount_master.php?id=${discountId}`,
                            method: 'DELETE',
                            dataType: 'json',
                            success: function(response) {
                                console.log('Delete discount response:', response);
                                if (response.status === 'success') {
                                    Swal.fire('Deleted!', response.message, 'success');
                                    loadSpecialDiscounts();
                                } else {
                                    Swal.fire('Error', response.message || 'Failed to delete special discount', 'error');
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error('Delete discount error:', xhr.responseText);
                                Swal.fire('Error', 'Failed to delete special discount', 'error');
                            }
                        });
                    }
                });
            });

            // Filter functionality
            $('#filter_class, #filter_particular, #filter_status').change(function() {
                loadSpecialDiscounts();
            });
        });
    </script>
</body>
</html>