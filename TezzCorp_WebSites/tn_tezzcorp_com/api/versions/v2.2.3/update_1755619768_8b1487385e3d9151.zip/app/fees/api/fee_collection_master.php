<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Enable error logging for production debugging
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', $_SERVER['DOCUMENT_ROOT'] . '/logs/error.log');

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class FeeCollectionMaster {
    private $pdo;
    private $months = [
        1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June',
        7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
    ];

    public function __construct() {
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Database connection failed');
            exit();
        }
    }

    /**
     * Calculate the academic session based on the date.
     * Session starts in April and ends in March next year.
     * @param string $date Date in YYYY-MM-DD format
     * @return string Session in YYYY-YYYY format (e.g., "2025-2026")
     */
    private function calculateSession($date) {
        $dateTime = DateTime::createFromFormat('Y-m-d', $date);
        if (!$dateTime) {
            error_log("Invalid date format for session calculation: $date");
            return null;
        }
        $year = (int)$dateTime->format('Y');
        $month = (int)$dateTime->format('m');
        $session = $month >= 4 ? "$year-" . ($year + 1) : ($year - 1) . "-$year";
        error_log("Calculated session for date $date: $session");
        return $session;
    }

    /**
     * Get the academic session for a student.
     * @param int $student_id
     * @param string $payment_date
     * @param string|null $override_session Optional session override
     * @return string|null Session in YYYY-YYYY format
     */
    private function getStudentSession($student_id, $payment_date, $override_session = null) {
        if ($override_session !== null) {
            if (!preg_match('/^\d{4}-\d{4}$/', $override_session) || (int)substr($override_session, 5) !== (int)substr($override_session, 0, 4) + 1) {
                error_log("Invalid session format provided: $override_session");
                return null;
            }
            error_log("Using overridden session for student_id $student_id: $override_session");
            return $override_session;
        }

        try {
            $stmt = $this->pdo->prepare("SELECT session FROM students WHERE id = ?");
            $stmt->execute([$student_id]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($student && !empty($student['session'])) {
                error_log("Fetched session from students table for student_id $student_id: {$student['session']}");
                return $student['session'];
            }
            $session = $this->calculateSession($payment_date);
            error_log("Using calculated session for student_id $student_id based on payment_date $payment_date: $session");
            return $session;
        } catch (PDOException $e) {
            error_log("Failed to fetch student session for student_id $student_id: " . $e->getMessage());
            return $this->calculateSession($payment_date);
        }
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        switch ($method) {
            case 'GET':
                $this->handleGet();
                break;
            case 'POST':
                $this->handlePost();
                break;
            case 'DELETE':
                $this->handleDelete();
                break;
            default:
                $this->sendResponse(405, 'error', 'Method not allowed');
        }
    }

    private function handleGet() {
        if (isset($_GET['personal_class'])) {
            $class_id = filter_var($_GET['personal_class'], FILTER_VALIDATE_INT);
            if ($class_id === false || $class_id <= 0) {
                $this->sendResponse(400, 'error', 'Invalid class ID');
                return;
            }
            $this->getStudentsByClass($class_id);
            return;
        }

        if (!isset($_GET['student_id'])) {
            $this->sendResponse(400, 'error', 'Student ID is required');
            return;
        }

        $student_id = filter_var($_GET['student_id'], FILTER_VALIDATE_INT);
        if ($student_id === false || $student_id <= 0) {
            $this->sendResponse(400, 'error', 'Invalid student ID');
            return;
        }

        $fetch_history = isset($_GET['history']) && $_GET['history'] === 'true';
        if ($fetch_history) {
            $start_date = isset($_GET['start_date']) ? filter_var($_GET['start_date'], FILTER_SANITIZE_STRING) : null;
            $end_date = isset($_GET['end_date']) ? filter_var($_GET['end_date'], FILTER_SANITIZE_STRING) : null;
            $this->getPaymentHistory($student_id, $start_date, $end_date);
        } else {
            $this->getApplicableFees($student_id);
        }
    }

    private function getApplicableFees($student_id) {
        try {
            // Fetch student details including transport status
            $stmt = $this->pdo->prepare("
                SELECT s.class, s.uid, s.transport, s.transport_id, s.full_name, s.father_name, c.class_name
                FROM students s
                JOIN class c ON s.class = c.id
                WHERE s.id = ? AND s.status = 'active'
            ");
            $stmt->execute([$student_id]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$student) {
                $this->sendResponse(404, 'error', 'Student not found or inactive');
                return;
            }

            $class_id = $student['class'];
            $student_uid = $student['uid'];
            $transport = $student['transport'] ?? 0;
            $transport_id = $student['transport_id'] ?? null;

            // Determine current session
            $current_date = date('Y-m-d');
            $current_session = $this->calculateSession($current_date);
            if (!$current_session) {
                $this->sendResponse(500, 'error', 'Unable to determine current session');
                return;
            }

            // Fetch special discounts
            $stmt = $this->pdo->prepare("
                SELECT ss.*, p.particular, fs.frequency, fs.custom_frequency, fs.applicable_months
                FROM special_structure ss
                JOIN particulars p ON ss.particular_id = p.id
                JOIN fee_structure fs ON fs.particular_id = ss.particular_id AND fs.class_id = ?
                WHERE ss.student_uid = ? AND ss.status = 'active'
            ");
            $stmt->execute([$class_id, $student_uid]);
            $special_discounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $special_discount_map = array_column($special_discounts, null, 'particular_id');

            // Fetch applicable fee structures
            $stmt = $this->pdo->prepare("
                SELECT fs.id, fs.particular_id, p.particular, fs.amount, fs.applicable_months, fs.frequency, fs.custom_frequency
                FROM fee_structure fs
                JOIN particulars p ON fs.particular_id = p.id
                JOIN (
                    SELECT particular_id, MAX(id) as max_id
                    FROM fee_structure
                    WHERE class_id = ? AND status = 'active'
                    GROUP BY particular_id
                ) latest ON fs.id = latest.max_id
                WHERE fs.class_id = ? AND fs.status = 'active'
            ");
            $stmt->execute([$class_id, $class_id]);
            $fees = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Handle transport fee
            if ($transport == 1) {
                $transport_fee = null;
                $transport_particular_id = null;
                if ($transport_id !== null) {
                    $stmt = $this->pdo->prepare("
                        SELECT transport_fees AS amount
                        FROM transport
                        WHERE id = ? AND status = 'active'
                    ");
                    $stmt->execute([$transport_id]);
                    $transport_fee = $stmt->fetch(PDO::FETCH_ASSOC);
                }
                if (!$transport_fee) {
                    $stmt = $this->pdo->prepare("
                        SELECT id AS particular_id, amount
                        FROM particulars
                        WHERE particular = 'Transport Fee' AND status = 'active'
                        LIMIT 1
                    ");
                    $stmt->execute();
                    $transport_fee = $stmt->fetch(PDO::FETCH_ASSOC);
                    $transport_particular_id = $transport_fee['particular_id'] ?? null;
                }
                if ($transport_fee) {
                    $fees[] = [
                        'id' => 'transport_' . ($transport_id ?? $transport_particular_id),
                        'particular_id' => $transport_id ?? $transport_particular_id,
                        'particular' => 'Transport Fee',
                        'amount' => (float)$transport_fee['amount'],
                        'applicable_months' => 'all',
                        'frequency' => 'monthly',
                        'custom_frequency' => null
                    ];
                }
            }

            // Fetch payment history for the session
            $stmt = $this->pdo->prepare("
                SELECT fee_structure_id, payment_month, amount_collected, discount, remaining_balance, session, status
                FROM fee_collections
                WHERE student_id = ? AND session = ?
            ");
            $stmt->execute([$student_id, $current_session]);
            $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $paid_info_by_fee = [];
            foreach ($payments as $payment) {
                $fee_id = $payment['fee_structure_id'];
                if (!isset($paid_info_by_fee[$fee_id])) {
                    $paid_info_by_fee[$fee_id] = [
                        'collections' => [],
                        'total_amount' => 0,
                        'total_discount' => 0,
                        'remaining_balance' => 0
                    ];
                }
                if ($payment['status'] === 'completed') {
                    $collections = array_map('intval', explode(',', $payment['payment_month']));
                    $paid_info_by_fee[$fee_id]['collections'] = array_unique(array_merge($paid_info_by_fee[$fee_id]['collections'], $collections));
                }
                $paid_info_by_fee[$fee_id]['total_amount'] += (float)$payment['amount_collected'];
                $paid_info_by_fee[$fee_id]['total_discount'] += (float)$payment['discount'];
                $paid_info_by_fee[$fee_id]['remaining_balance'] += (float)$payment['remaining_balance'];
            }

            $filtered_fees = [];
            $processed_fee_ids = [];
            foreach ($fees as $fee) {
                $fee_id = $fee['id'];
                if (in_array($fee_id, $processed_fee_ids)) continue;
                $processed_fee_ids[] = $fee_id;

                $particular_id = $fee['particular_id'];
                if (isset($special_discount_map[$particular_id])) {
                    $special = $special_discount_map[$particular_id];
                    $fee['amount'] = (float)$special['special_amount'];
                    $fee['has_special_discount'] = true;
                    $fee['discount_percentage'] = $special['discount_percentage'];
                } else {
                    $fee['has_special_discount'] = false;
                    $fee['discount_percentage'] = 0;
                }

                $applicable_months = $fee['applicable_months'] === 'all' ? range(1, 12) : array_map('intval', explode(',', $fee['applicable_months']));
                $paid_info = $paid_info_by_fee[$fee_id] ?? ['collections' => [], 'total_amount' => 0, 'total_discount' => 0, 'remaining_balance' => 0];
                $paid_collections = $paid_info['collections'];
                $total_paid = $paid_info['total_amount'];
                $total_discount = $paid_info['total_discount'];

                if ($fee['frequency'] === 'annual') {
                    $expected_amount = $fee['amount'] - $total_discount;
                    $fee['is_fully_paid'] = $total_paid >= $expected_amount - 0.01;
                    $fee['pending_months'] = $fee['is_fully_paid'] ? [] : $applicable_months;
                    $fee['remaining_balance'] = $fee['is_fully_paid'] ? 0 : max(0, $expected_amount - $total_paid);
                } elseif ($fee['frequency'] === 'other') {
                    $custom_frequency = (int)$fee['custom_frequency'] ?: 1;
                    $max_collections = floor(12 / $custom_frequency);
                    $paid_count = count($paid_collections);
                    $pending_count = max(0, $max_collections - $paid_count);
                    $fee['is_fully_paid'] = $pending_count === 0;
                    $fee['pending_months'] = [];
                    $fee['pending_collections'] = $pending_count;
                    $fee['remaining_balance'] = $fee['is_fully_paid'] ? 0 : max(0, ($pending_count * $fee['amount']) - $total_discount);
                } else { // monthly
                    $pending_months = array_diff($applicable_months, $paid_collections);
                    $fee['is_fully_paid'] = empty($pending_months);
                    $fee['pending_months'] = array_values($pending_months);
                    $fee['pending_collections'] = count($pending_months);
                    $fee['remaining_balance'] = max(0, (count($pending_months) * $fee['amount']) - $total_discount);
                }

                if (!$fee['is_fully_paid']) {
                    $filtered_fees[] = $fee;
                }
            }

            $this->sendResponse(200, 'success', "Applicable fees fetched for session $current_session", [
                'current_fees' => $filtered_fees,
                'transport_status' => $transport,
                'student_name' => $student['full_name'],
                'father_name' => $student['father_name'],
                'class_name' => $student['class_name']
            ]);
        } catch (PDOException $e) {
            error_log("Failed to fetch fees: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch fees');
        }
    }

    private function getPaymentHistory($student_id, $start_date = null, $end_date = null) {
        try {
            $query = "
                SELECT fc.id, fc.amount_collected, fc.discount, fc.remarks, fc.remaining_balance, 
                       fc.payment_month, fc.payment_date, fc.payment_method, fc.status, fc.created_on, fc.session,
                       fs.particular_id, p.particular, fs.amount AS fee_amount, fs.frequency, fs.custom_frequency,
                       s.full_name AS student_name, s.father_name, c.class_name,
                       ss.school_name, ss.logo, ss.address, ss.phone
                FROM fee_collections fc
                JOIN fee_structure fs ON fc.fee_structure_id = fs.id
                JOIN particulars p ON fs.particular_id = p.id
                JOIN students s ON fc.student_id = s.id
                JOIN class c ON s.class = c.id
                CROSS JOIN site_settings ss
                WHERE fc.student_id = ? AND fc.session = ?
            ";
            $params = [$student_id, $this->calculateSession(date('Y-m-d'))];
            if ($start_date && $end_date) {
                $query .= " AND fc.payment_date BETWEEN ? AND ?";
                $params[] = $start_date;
                $params[] = $end_date;
            } elseif ($start_date) {
                $query .= " AND fc.payment_date >= ?";
                $params[] = $start_date;
            } elseif ($end_date) {
                $query .= " AND fc.payment_date <= ?";
                $params[] = $end_date;
            }
            $query .= " ORDER BY fc.payment_date DESC";

            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($history as &$record) {
                $months_arr = array_map('intval', explode(',', $record['payment_month']));
                $record['payment_month_name'] = implode(', ', array_map(fn($m) => $this->months[$m], $months_arr));
                $record['frequency_display'] = $record['frequency'] === 'other' ? "Every {$record['custom_frequency']} Month" . ($record['custom_frequency'] > 1 ? 's' : '') : ucfirst($record['frequency']);
            }

            $this->sendResponse(200, 'success', 'Payment history fetched successfully', $history);
        } catch (PDOException $e) {
            error_log("Failed to fetch payment history: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch payment history');
        }
    }

    private function handlePost() {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) {
            $this->sendResponse(400, 'error', 'Invalid or missing JSON data');
            return;
        }

        $required_fields = ['student_id', 'fee_structure_id', 'amount_collected', 'payment_date', 'payment_method', 'session'];
        foreach ($required_fields as $field) {
            if (!isset($input[$field]) || (is_string($input[$field]) && trim($input[$field]) === '')) {
                $this->sendResponse(400, 'error', "Missing or empty required field: $field");
                return;
            }
        }

        $student_id = filter_var($input['student_id'], FILTER_VALIDATE_INT);
        $fee_structure_id = $input['fee_structure_id'];
        $amount_collected = filter_var($input['amount_collected'], FILTER_VALIDATE_FLOAT);
        $discount = isset($input['discount']) ? filter_var($input['discount'], FILTER_VALIDATE_FLOAT) : 0;
        $remarks = isset($input['remarks']) ? filter_var($input['remarks'], FILTER_SANITIZE_STRING) : null;
        $payment_month = isset($input['payment_month']) && is_array($input['payment_month']) ? array_map('intval', $input['payment_month']) : [];
        $payment_date = filter_var($input['payment_date'], FILTER_SANITIZE_STRING);
        $payment_method = filter_var($input['payment_method'], FILTER_SANITIZE_STRING);
        $session = filter_var($input['session'], FILTER_SANITIZE_STRING);
        $collections_count = isset($input['collections_count']) ? filter_var($input['collections_count'], FILTER_VALIDATE_INT) : 1;

        if ($student_id <= 0 || $amount_collected < 0 || $discount < 0 || $collections_count <= 0) {
            $this->sendResponse(400, 'error', 'Invalid input values');
            return;
        }

        if (empty($payment_month) && $input['fee_frequency'] !== 'annual') {
            $this->sendResponse(400, 'error', 'Payment month is required for non-annual fees');
            return;
        }

        if (!in_array($payment_method, ['cash', 'card', 'online', 'cheque'])) {
            $this->sendResponse(400, 'error', 'Invalid payment method');
            return;
        }

        $session = $this->getStudentSession($student_id, $payment_date, $session);
        if (!$session) {
            $this->sendResponse(400, 'error', 'Invalid academic session');
            return;
        }

        try {
            $stmt = $this->pdo->prepare("SELECT uid, class, transport, transport_id FROM students WHERE id = ? AND status = 'active'");
            $stmt->execute([$student_id]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$student) {
                $this->sendResponse(404, 'error', 'Student not found or inactive');
                return;
            }
            $student_uid = $student['uid'];
            $class_id = $student['class'];
            $transport = $student['transport'] ?? 0;
            $transport_id = $student['transport_id'] ?? null;

            $is_transport_fee = strpos($fee_structure_id, 'transport_') === 0;
            $particular_id = null;
            $fee_amount = null;
            $frequency = 'monthly';
            $custom_frequency = 1;
            $applicable_months = 'all';

            if ($is_transport_fee) {
                if ($transport != 1) {
                    $this->sendResponse(400, 'error', 'Transport fee not applicable for this student');
                    return;
                }
                if ($transport_id !== null) {
                    $stmt = $this->pdo->prepare("SELECT transport_fees AS amount FROM transport WHERE id = ? AND status = 'active'");
                    $stmt->execute([$transport_id]);
                    $transport_fee = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($transport_fee) {
                        $fee_amount = (float)$transport_fee['amount'];
                        $particular_id = $transport_id;
                    }
                }
                if (!$fee_amount) {
                    $stmt = $this->pdo->prepare("SELECT id AS particular_id, amount FROM particulars WHERE particular = 'Transport Fee' AND status = 'active' LIMIT 1");
                    $stmt->execute();
                    $particular_fee = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($particular_fee) {
                        $fee_amount = (float)$particular_fee['amount'];
                        $particular_id = $particular_fee['particular_id'];
                    } else {
                        $this->sendResponse(400, 'error', 'Transport fee not found');
                        return;
                    }
                }
            } else {
                $fee_structure_id_int = filter_var($fee_structure_id, FILTER_VALIDATE_INT);
                if ($fee_structure_id_int === false || $fee_structure_id_int <= 0) {
                    $this->sendResponse(400, 'error', 'Invalid fee structure ID');
                    return;
                }
                $stmt = $this->pdo->prepare("
                    SELECT fs.id, fs.amount, fs.applicable_months, fs.frequency, fs.custom_frequency, p.particular, p.id AS particular_id
                    FROM fee_structure fs
                    JOIN particulars p ON fs.particular_id = p.id
                    WHERE fs.id = ? AND fs.class_id = ?
                ");
                $stmt->execute([$fee_structure_id_int, $class_id]);
                $fee_structure = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$fee_structure) {
                    $this->sendResponse(400, 'error', 'Fee structure not applicable');
                    return;
                }
                $particular_id = $fee_structure['particular_id'];
                $fee_amount = (float)$fee_structure['amount'];
                $frequency = $fee_structure['frequency'];
                $custom_frequency = (int)$fee_structure['custom_frequency'] ?: 1;
                $applicable_months = $fee_structure['applicable_months'];
            }

            // Apply special discount
            if (!$is_transport_fee) {
                $stmt = $this->pdo->prepare("
                    SELECT special_amount
                    FROM special_structure
                    WHERE student_uid = ? AND particular_id = ? AND status = 'active'
                    LIMIT 1
                ");
                $stmt->execute([$student_uid, $particular_id]);
                $special = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($special) {
                    $fee_amount = (float)$special['special_amount'];
                }
            }

            // Validate payment
            $stmt = $this->pdo->prepare("
                SELECT id, payment_month, amount_collected, discount, status, session
                FROM fee_collections
                WHERE student_id = ? AND fee_structure_id = ? AND session = ?
            ");
            $stmt->execute([$student_id, $fee_structure_id, $session]);
            $existing = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $already_paid_collections = [];
            $total_paid = 0;
            $total_discount = 0;
            foreach ($existing as $payment) {
                if ($payment['status'] === 'completed') {
                    $collections = array_map('intval', explode(',', $payment['payment_month']));
                    $already_paid_collections = array_unique(array_merge($already_paid_collections, $collections));
                }
                $total_paid += (float)$payment['amount_collected'];
                $total_discount += (float)$payment['discount'];
            }
            $total_discount += $discount;

            $applicable_months_array = $applicable_months === 'all' ? range(1, 12) : array_map('intval', explode(',', $applicable_months));

            if ($frequency === 'annual') {
                if (!empty($already_paid_collections)) {
                    $this->sendResponse(400, 'error', 'Annual fee already collected in this session');
                    return;
                }
                $total_expected = $fee_amount - $discount;
                if (abs($amount_collected - $total_expected) > 0.01) {
                    $this->sendResponse(400, 'error', 'Amount must match expected for annual fee');
                    return;
                }
                $remaining_balance = 0;
            } elseif ($frequency === 'other') {
                $max_collections = floor(12 / $custom_frequency);
                $paid_count = count($already_paid_collections);
                $pending_count = max(0, $max_collections - $paid_count);
                $collections_to_pay = min($collections_count, $pending_count);
                if ($collections_to_pay <= 0) {
                    $this->sendResponse(400, 'error', 'No pending collections');
                    return;
                }
                $total_expected = ($fee_amount * $collections_to_pay) - $discount;
                if (abs($amount_collected - $total_expected) > 0.01) {
                    $this->sendResponse(400, 'error', 'Amount must match expected for other frequency');
                    return;
                }
                $remaining_balance = max(0, ($pending_count - $collections_to_pay) * $fee_amount);
                $payment_month = array_fill(0, $collections_to_pay, $payment_month[0] ?? 1);
            } else { // monthly
                $pending_months = array_diff($applicable_months_array, $already_paid_collections);
                $to_pay = array_intersect($payment_month, $pending_months);
                if (empty($to_pay)) {
                    $this->sendResponse(400, 'error', 'Selected months already paid or not applicable');
                    return;
                }
                $total_expected = ($fee_amount * count($to_pay)) - $discount;
                if (abs($amount_collected - $total_expected) > 0.01) {
                    $this->sendResponse(400, 'error', 'Amount must match expected for monthly fee');
                    return;
                }
                $remaining_balance = max(0, (count($pending_months) - count($to_pay)) * $fee_amount);
                $payment_month = $to_pay;
            }

            $this->pdo->beginTransaction();
            $stmt = $this->pdo->prepare("
                INSERT INTO fee_collections (
                    student_id, fee_structure_id, amount_collected, discount, remarks, 
                    remaining_balance, payment_month, payment_date, payment_method, status, 
                    created_on, session
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed', NOW(), ?)
            ");
            $stmt->execute([
                $student_id, $fee_structure_id, $amount_collected, $discount, $remarks,
                $remaining_balance, implode(',', $payment_month), $payment_date, $payment_method, $session
            ]);

            $payment_id = $this->pdo->lastInsertId();

            // Notification queue
            $receipt_link = "/receipts/fee_receipt_{$payment_id}.pdf";
            $month_names = implode(', ', array_map(fn($m) => $this->months[$m], $payment_month));
            $particular_desc = $is_transport_fee ? 'Transport Fee' : ($fee_structure['particular'] ?? 'Fee');
            $description = "Payment of ₹{$amount_collected} for {$particular_desc} (Months: {$month_names}, Session: {$session}) on {$payment_date}.";
            if ($discount > 0) $description .= " Discount: ₹{$discount}.";

            $stmt = $this->pdo->prepare("
                INSERT INTO notification_queue (
                    uid, title, description, doc_link, notification_type, is_sticky, created_at, sent_at, status
                )
                VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW(), ?)
            ");
            $stmt->execute([$student_uid, 'Fee Payment Receipt', $description, $receipt_link, 'normal', 0, 'pending']);

            $this->pdo->commit();
            $this->sendResponse(200, 'success', 'Fee collected successfully for session ' . $session);
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            error_log("Failed to collect fee: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to collect fee: ' . $e->getMessage());
        }
    }

    private function handleDelete() {
        $payment_id = filter_var($_GET['payment_id'] ?? 0, FILTER_VALIDATE_INT);
        if ($payment_id <= 0) {
            $this->sendResponse(400, 'error', 'Invalid or missing payment ID');
            return;
        }

        try {
            $this->pdo->beginTransaction();
            $stmt = $this->pdo->prepare("DELETE FROM fee_collections WHERE id = ?");
            $stmt->execute([$payment_id]);
            if ($stmt->rowCount() === 0) {
                $this->pdo->rollBack();
                $this->sendResponse(404, 'error', 'Payment record not found');
                return;
            }
            $this->pdo->commit();
            $this->sendResponse(200, 'success', 'Payment record deleted successfully');
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            error_log("Failed to delete payment record: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to delete payment record');
        }
    }

    private function getStudentsByClass($class_id) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT id, full_name, father_name
                FROM students
                WHERE class = ? AND status = 'active'
                ORDER BY full_name
            ");
            $stmt->execute([$class_id]);
            $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $this->sendResponse(200, 'success', 'Students fetched successfully', $students);
        } catch (PDOException $e) {
            error_log("Failed to fetch students: " . $e->getMessage());
            $this->sendResponse(500, 'error', 'Failed to fetch students');
        }
    }

    private function sendResponse($statusCode, $status, $message, $data = null) {
        http_response_code($statusCode);
        $response = ['status' => $status, 'message' => $message];
        if ($data !== null) {
            $response['data'] = $data;
        }
        echo json_encode($response);
        exit();
    }
}

$feeCollectionMaster = new FeeCollectionMaster();
$feeCollectionMaster->handleRequest();
?>