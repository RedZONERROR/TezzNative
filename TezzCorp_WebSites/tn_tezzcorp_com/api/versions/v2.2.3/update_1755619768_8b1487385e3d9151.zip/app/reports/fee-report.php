<?php
session_start();
if(!isset($_SESSION['uid'])){
    header("location: ../../login");
    die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">

<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- Select2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" />
    <!-- Select2 Bootstrap 5 Theme -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">

    <title>Fee Reports - AI-ERP 2.0</title>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }

        .filter-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .filter-card .form-label {
            color: white;
            font-weight: 500;
        }

        .filter-card .form-control,
        .filter-card .form-select {
            background-color: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
        }

        .filter-card .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        .filter-card .form-control:focus,
        .filter-card .form-select:focus {
            background-color: rgba(255, 255, 255, 0.2);
            border-color: rgba(255, 255, 255, 0.5);
            box-shadow: 0 0 0 0.2rem rgba(255, 255, 255, 0.25);
            color: white;
        }

        .stats-card {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
        }

        .stats-value {
            font-size: 2rem;
            font-weight: bold;
        }

        .table-responsive {
            border-radius: 0.5rem;
            overflow: hidden;
        }

        .table th {
            background-color: #f8f9fa;
            border-top: none;
            font-weight: 600;
            color: #495057;
        }

        .badge-status {
            font-size: 0.75rem;
            padding: 0.375rem 0.75rem;
        }

        .loading-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        /* Fixed Select2 styling and clear button alignment */
        .select2-container--bootstrap-5 .select2-selection {
            background-color: rgba(255, 255, 255, 0.1) !important;
            border: 1px solid rgba(255, 255, 255, 0.3) !important;
            color: white !important;
            min-height: 38px !important;
        }

        .select2-container--bootstrap-5 .select2-selection__rendered {
            color: white !important;
            line-height: 36px !important;
        }

        .select2-container--bootstrap-5 .select2-selection__placeholder {
            color: rgba(255, 255, 255, 0.7) !important;
        }

        .select2-container--bootstrap-5 .select2-selection__clear {
            color: white !important;
            font-size: 18px !important;
            line-height: 36px !important;
            margin-right: 10px !important;
            position: absolute !important;
            right: 20px !important;
            top: 50% !important;
            transform: translateY(-50%) !important;
        }

        .select2-container--bootstrap-5 .select2-selection__clear:hover {
            color: #ff6b6b !important;
        }

        .select2-container--bootstrap-5 .select2-selection__arrow {
            right: 10px !important;
            top: 50% !important;
            transform: translateY(-50%) !important;
        }

        .select2-container--bootstrap-5 .select2-selection__arrow b {
            border-color: white transparent transparent transparent !important;
        }

        .select2-dropdown {
            background-color: white !important;
            border: 1px solid rgba(255, 255, 255, 0.3) !important;
        }

        .select2-container--bootstrap-5 .select2-results__option {
            color: #333 !important;
        }

        .select2-container--bootstrap-5 .select2-results__option--highlighted {
            background-color: #667eea !important;
            color: white !important;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <!-- Page Header -->
                    <div class="card mb-3">
                        <div class="card-body py-3">
                            <div class="d-flex align-items-center justify-content-between flex-wrap">
                                <h4 class="card-title mb-0">Fee Reports</h4>
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb mb-0">
                                        <li class="breadcrumb-item d-flex align-items-center">
                                            <a class="text-muted text-decoration-none d-flex" href="/app" aria-label="Home">
                                                <iconify-icon icon="solar:home-2-line-duotone" class="fs-5"></iconify-icon>
                                            </a>
                                        </li>
                                        <li class="breadcrumb-item">
                                            <span class="badge bg-primary-subtle text-primary fw-medium">Fee Reports</span>
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>

                    <!-- Filter Section -->
                    <div class="card filter-card mb-4">
                        <div class="card-header">
                            <h5 class="card-title mb-0 text-white">
                                <i class="fas fa-filter me-2"></i>Report Filters
                            </h5>
                        </div>
                        <div class="card-body">
                            <form id="filterForm" class="row g-3">
                                <div class="col-md-3">
                                    <label for="filter_class" class="form-label">Class</label>
                                    <select class="form-select" id="filter_class" name="filter_class">
                                        <option value="">All Classes</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="filter_student" class="form-label">Student</label>
                                    <select class="form-select" id="filter_student" name="filter_student">
                                        <option value="">All Students</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="filter_particular" class="form-label">Fee Type</label>
                                    <select class="form-select" id="filter_particular" name="filter_particular">
                                        <option value="">All Fee Types</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="filter_session" class="form-label">Session</label>
                                    <select class="form-select" id="filter_session" name="filter_session">
                                        <option value="">All Sessions</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="filter_payment_method" class="form-label">Payment Method</label>
                                    <select class="form-select" id="filter_payment_method" name="filter_payment_method">
                                        <option value="">All Methods</option>
                                        <option value="cash">Cash</option>
                                        <option value="card">Card</option>
                                        <option value="online">Online</option>
                                        <option value="cheque">Cheque</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="filter_status" class="form-label">Status</label>
                                    <select class="form-select" id="filter_status" name="filter_status">
                                        <option value="">All Status</option>
                                        <option value="completed">Completed</option>
                                        <option value="failed">Failed</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="filter_date_from" class="form-label">Date From</label>
                                    <input type="date" class="form-control" id="filter_date_from" name="filter_date_from">
                                </div>
                                <div class="col-md-3">
                                    <label for="filter_date_to" class="form-label">Date To</label>
                                    <input type="date" class="form-control" id="filter_date_to" name="filter_date_to">
                                </div>
                                <div class="col-12">
                                    <div class="d-flex gap-2">
                                        <button type="button" id="applyFilters" class="btn btn-light">
                                            <i class="fas fa-search me-2"></i>Apply Filters
                                        </button>
                                        <button type="button" id="clearFilters" class="btn btn-outline-light">
                                            <i class="fas fa-times me-2"></i>Clear Filters
                                        </button>
                                        <button type="button" id="exportReport" class="btn btn-success ms-auto">
                                            <i class="fas fa-download me-2"></i>Export Report
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Statistics Cards -->
                    <div class="row mb-4" id="statsCards">
                        <div class="col-md-3">
                            <div class="card stats-card">
                                <div class="card-body text-center">
                                    <div class="stats-value" id="totalCollections">0</div>
                                    <div class="small">Total Collections</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card stats-card">
                                <div class="card-body text-center">
                                    <div class="stats-value" id="totalAmount">₹0</div>
                                    <div class="small">Total Amount</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card stats-card">
                                <div class="card-body text-center">
                                    <div class="stats-value" id="totalDiscount">₹0</div>
                                    <div class="small">Total Discount</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card stats-card">
                                <div class="card-body text-center">
                                    <div class="stats-value" id="pendingAmount">₹0</div>
                                    <div class="small">Pending Amount</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Report Table -->
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">Fee Collection Report</h5>
                            <div id="tableExportButtons" class="btn-group btn-group-sm">
                                <!-- Export buttons will be added dynamically -->
                            </div>
                        </div>
                        <div class="card-body position-relative">
                            <div id="loadingOverlay" class="loading-overlay" style="display: none;">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover" id="feeReportTable">
                                    <thead>
                                        <tr>
                                            <th>Receipt ID</th>
                                            <th>Student Name</th>
                                            <th>Class</th>
                                            <th>Fee Type</th>
                                            <th>Amount Collected</th>
                                            <th>Discount</th>
                                            <th>Remaining Balance</th>
                                            <th>Payment Month</th>
                                            <th>Payment Date</th>
                                            <th>Payment Method</th>
                                            <th>Session</th>
                                            <th>Status</th>
                                            <th>Remarks</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="reportTableBody">
                                        <!-- Data will be loaded dynamically -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script src="../assets/js/index.global.min.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>

    <script>
        $(document).ready(function() {
            // Initialize Select2
            $('#filter_class, #filter_student, #filter_particular, #filter_session, #filter_payment_method, #filter_status').select2({
                theme: 'bootstrap-5',
                width: '100%',
                allowClear: true,
                dropdownParent: $('.filter-card'),
                placeholder: function() {
                    return $(this).data('placeholder') || 'Select an option';
                }
            });

            let reportTable;
            const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

            // Load initial data
            loadFilterOptions();
            loadReportData();

            // Event handlers
            $('#applyFilters').on('click', function() {
                loadReportData();
            });

            $('#clearFilters').on('click', function() {
                $('#filterForm')[0].reset();
                $('#filter_class, #filter_student, #filter_particular, #filter_session, #filter_payment_method, #filter_status').val(null).trigger('change');
                loadReportData();
            });

            $('#exportReport').on('click', function() {
                exportFullReport();
            });

            // Class change handler
            $('#filter_class').on('change', function() {
                const classId = $(this).val();
                if (classId) {
                    loadStudentsByClass(classId);
                } else {
                    $('#filter_student').empty().append('<option value="">All Students</option>').trigger('change');
                }
            });

            // Load filter options
            function loadFilterOptions() {
                // Load classes
                $.ajax({
                    url: 'api/class_master.php',
                    method: 'GET',
                    data: { perPage: 100, status: 'active' },
                    success: function(response) {
                        if (response.data) {
                            $('#filter_class').empty().append('<option value="">All Classes</option>');
                            response.data.forEach(function(item) {
                                $('#filter_class').append(`<option value="${item.id}">${item.class_name}</option>`);
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error loading classes:', error);
                    }
                });

                // Load particulars
                $.ajax({
                    url: 'api/fee_report_master.php',
                    method: 'GET',
                    data: { action: 'get_particulars' },
                    success: function(response) {
                        if (response.status === 'success' && response.data) {
                            $('#filter_particular').empty().append('<option value="">All Fee Types</option>');
                            response.data.forEach(function(item) {
                                $('#filter_particular').append(`<option value="${item.id}">${item.particular}</option>`);
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error loading particulars:', error);
                    }
                });

                // Load sessions
                $.ajax({
                    url: 'api/fee_report_master.php',
                    method: 'GET',
                    data: { action: 'get_sessions' },
                    success: function(response) {
                        if (response.status === 'success' && response.data) {
                            $('#filter_session').empty().append('<option value="">All Sessions</option>');
                            response.data.forEach(function(session) {
                                $('#filter_session').append(`<option value="${session}">${session}</option>`);
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error loading sessions:', error);
                    }
                });
            }

            // Load students by class
            function loadStudentsByClass(classId) {
                $.ajax({
                    url: 'api/fee_report_master.php',
                    method: 'GET',
                    data: { action: 'get_students_by_class', class_id: classId },
                    success: function(response) {
                        if (response.status === 'success' && response.data) {
                            $('#filter_student').empty().append('<option value="">All Students</option>');
                            response.data.forEach(function(student) {
                                $('#filter_student').append(`<option value="${student.id}">${student.full_name} - ${student.father_name}</option>`);
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error loading students:', error);
                    }
                });
            }

            // Load report data
            function loadReportData() {
                $('#loadingOverlay').show();
                
                const filters = {
                    action: 'get_report',
                    class_id: $('#filter_class').val(),
                    student_id: $('#filter_student').val(),
                    particular_id: $('#filter_particular').val(),
                    session: $('#filter_session').val(),
                    payment_method: $('#filter_payment_method').val(),
                    status: $('#filter_status').val(),
                    date_from: $('#filter_date_from').val(),
                    date_to: $('#filter_date_to').val()
                };

                $.ajax({
                    url: 'api/fee_report_master.php',
                    method: 'GET',
                    data: filters,
                    success: function(response) {
                        if (response.status === 'success') {
                            updateStatistics(response.statistics);
                            updateReportTable(response.data);
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: response.message || 'Failed to load report data'
                            });
                        }
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load report data'
                        });
                    },
                    complete: function() {
                        $('#loadingOverlay').hide();
                    }
                });
            }

            // Update statistics
            function updateStatistics(stats) {
                $('#totalCollections').text(stats.total_collections || 0);
                $('#totalAmount').text('₹' + (parseFloat(stats.total_amount || 0).toLocaleString('en-IN', {minimumFractionDigits: 2})));
                $('#totalDiscount').text('₹' + (parseFloat(stats.total_discount || 0).toLocaleString('en-IN', {minimumFractionDigits: 2})));
                $('#pendingAmount').text('₹' + (parseFloat(stats.pending_amount || 0).toLocaleString('en-IN', {minimumFractionDigits: 2})));
            }

            // Update report table
            function updateReportTable(data) {
                // Destroy existing DataTable
                if (reportTable) {
                    reportTable.destroy();
                }

                // Prepare data for DataTable
                const tableData = data.map(record => [
                    record.id,
                    record.student_name,
                    record.class_name,
                    record.particular,
                    '₹' + parseFloat(record.amount_collected || 0).toLocaleString('en-IN', {minimumFractionDigits: 2}),
                    '₹' + parseFloat(record.discount || 0).toLocaleString('en-IN', {minimumFractionDigits: 2}),
                    '₹' + parseFloat(record.remaining_balance || 0).toLocaleString('en-IN', {minimumFractionDigits: 2}),
                    record.payment_month_name || '-',
                    record.payment_date ? new Date(record.payment_date).toLocaleDateString('en-IN') : '-',
                    record.payment_method ? record.payment_method.charAt(0).toUpperCase() + record.payment_method.slice(1) : '-',
                    record.session || '-',
                    record.status === 'completed' 
                        ? '<span class="badge bg-success-subtle text-success badge-status">Completed</span>' 
                        : '<span class="badge bg-danger-subtle text-danger badge-status">Failed</span>',
                    record.remarks || '-',
                    `<button class="btn btn-sm btn-outline-info print-receipt" data-id="${record.id}">
                        <i class="fas fa-print"></i> Print
                    </button>`
                ]);

                const currentStats = {
                    totalCollections: $('#totalCollections').text(),
                    totalAmount: $('#totalAmount').text(),
                    totalDiscount: $('#totalDiscount').text(),
                    pendingAmount: $('#pendingAmount').text()
                };

                // Initialize DataTable
                reportTable = $('#feeReportTable').DataTable({
                    data: tableData,
                    columns: [
                        { title: "Receipt ID" },
                        { title: "Student Name" },
                        { title: "Class" },
                        { title: "Fee Type" },
                        { title: "Amount Collected" },
                        { title: "Discount" },
                        { title: "Remaining Balance" },
                        { title: "Payment Month" },
                        { title: "Payment Date" },
                        { title: "Payment Method" },
                        { title: "Session" },
                        { title: "Status" },
                        { title: "Remarks" },
                        { title: "Action" }
                    ],
                    dom: 'Bfrtip',
                    buttons: [
                        {
                            extend: 'print',
                            text: '<i class="fas fa-print"></i> Print',
                            className: 'btn btn-primary btn-sm me-1',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
                            }
                        },
                        {
                            extend: 'excelHtml5',
                            text: '<i class="fas fa-file-excel"></i> Excel',
                            className: 'btn btn-success btn-sm me-1',
                            title: 'Fee Collection Report',
                            messageTop: function() {
                                return 'Fee Collection Report Summary:\n' +
                                       'Total Collections: ' + currentStats.totalCollections + '\n' +
                                       'Total Amount: ' + currentStats.totalAmount + '\n' +
                                       'Total Discount: ' + currentStats.totalDiscount + '\n' +
                                       'Pending Amount: ' + currentStats.pendingAmount + '\n\n';
                            },
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
                            }
                        },
                        {
                            extend: 'pdfHtml5',
                            text: '<i class="fas fa-file-pdf"></i> PDF',
                            className: 'btn btn-danger btn-sm',
                            title: 'Fee Collection Report',
                            orientation: 'landscape',
                            pageSize: 'A4',
                            messageTop: function() {
                                return 'Summary - Collections: ' + currentStats.totalCollections + 
                                       ', Amount: ' + currentStats.totalAmount + 
                                       ', Discount: ' + currentStats.totalDiscount + 
                                       ', Pending: ' + currentStats.pendingAmount;
                            },
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
                            },
                            customize: function(doc) {
                                doc.pageMargins = [20, 20, 20, 20];
                                doc.defaultStyle.fontSize = 8;
                                doc.styles.tableHeader.fontSize = 9;
                                doc.styles.title.fontSize = 14;
                            }
                        }
                    ],
                    pageLength: 25,
                    responsive: true,
                    order: [[0, 'desc']],
                    initComplete: function() {
                        $('#tableExportButtons').empty().append($('.dt-buttons'));
                    }
                });

                $('#feeReportTable').off('click', '.print-receipt').on('click', '.print-receipt', function(e) {
                    e.preventDefault();
                    const receiptId = $(this).data('id');
                    if (receiptId) {
                        window.open(`/receipts/fee_receipt_${receiptId}.pdf`, '_blank');
                    } else {
                        console.error('Receipt ID not found');
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Receipt ID not found'
                        });
                    }
                });
            }

            // Export full report
            function exportFullReport() {
                const filters = {
                    action: 'export_report',
                    class_id: $('#filter_class').val(),
                    student_id: $('#filter_student').val(),
                    particular_id: $('#filter_particular').val(),
                    session: $('#filter_session').val(),
                    payment_method: $('#filter_payment_method').val(),
                    status: $('#filter_status').val(),
                    date_from: $('#filter_date_from').val(),
                    date_to: $('#filter_date_to').val()
                };

                // Create form and submit for download
                const form = $('<form>', {
                    method: 'POST',
                    action: 'api/fee_report_master.php'
                });

                Object.keys(filters).forEach(key => {
                    if (filters[key]) {
                        form.append($('<input>', {
                            type: 'hidden',
                            name: key,
                            value: filters[key]
                        }));
                    }
                });

                $('body').append(form);
                form.submit();
                form.remove();
            }
        });
    </script>
</body>

</html>