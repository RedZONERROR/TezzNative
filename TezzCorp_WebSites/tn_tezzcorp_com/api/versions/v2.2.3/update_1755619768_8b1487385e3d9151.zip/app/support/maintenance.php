<?php
session_start();
if(!isset($_SESSION['uid'])){
	header("location: ../../login");
	die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];

function fetchPaymentsFromAPI($userEmail) {
    $apiUrl = 'https://www.bthdevelopers.com/api/payments.php';
    
    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200 && $response) {
        $data = json_decode($response, true);
        
        if ($data && isset($data['success']) && $data['success'] && isset($data['data'])) {
            // Filter payments by user email
            $userPayments = array_filter($data['data'], function($payment) use ($userEmail) {
                return isset($payment['client_email']) && $payment['client_email'] === $userEmail;
            });
            
            return array_values($userPayments); // Re-index array
        }
    }
    
    return [];
}

$paymentsData = fetchPaymentsFromAPI($email);
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">

<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
    <script src="../assets/js/jquery.steps.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>

    <title>Maintenance - AI-ERP 2.0</title>

    <style>
        .payment-card {
            transition: all 0.3s ease;
            border: 1px solid #e9ecef;
        }
        .payment-card:hover {
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }
        .status-badge {
            font-size: 0.75rem;
            padding: 0.375rem 0.75rem;
        }
        .amount-display {
            font-size: 1.25rem;
            font-weight: 600;
        }
        .pay-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            transition: all 0.3s ease;
        }
        .pay-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        .loading-spinner {
            display: none;
        }
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: #6c757d;
        }
        .filter-section {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar -->
        <?php include 'util/sidebar.php'; ?>
        <div class="page-wrapper">
            <!-- Header -->
            <?php include 'util/topbar.php'; ?>

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Maintenance Payments</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Maintenance
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Filter Section -->
                    <div class="filter-section">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <div class="d-flex align-items-center">
                                    <iconify-icon icon="solar:user-circle-line-duotone" class="fs-4 me-2 text-primary"></iconify-icon>
                                    <div>
                                        <h6 class="mb-0">Logged in as:</h6>
                                        <span class="text-muted"><?php echo htmlspecialchars($email); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 text-md-end mt-3 mt-md-0">
                                <button class="btn btn-outline-primary" onclick="location.reload()">
                                    <iconify-icon icon="solar:refresh-line-duotone" class="me-1"></iconify-icon>
                                    Refresh
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Payments Container -->
                    <div id="paymentsContainer">
                        <?php if (empty($paymentsData)): ?>
                            <!-- Empty State -->
                            <div class="empty-state">
                                <iconify-icon icon="solar:bill-list-line-duotone" class="fs-1 mb-3"></iconify-icon>
                                <h5>No Payments Found</h5>
                                <p>No maintenance payments found for your email address.</p>
                            </div>
                        <?php else: ?>
                            <!-- Display payments using server-side data -->
                            <div class="row">
                                <?php foreach ($paymentsData as $payment): ?>
                                    <?php
                                    $amount = $payment['collect_today_amount'] > 0 ? $payment['collect_today_amount'] : $payment['maintenance_charge'];
                                    $isPaid = $payment['status'] === 'paid';
                                    $statusClass = $isPaid ? 'bg-success' : 'bg-warning';
                                    $statusText = $isPaid ? 'Paid' : 'Pending';
                                    $dueDate = date('d/m/Y', strtotime($payment['due_date']));
                                    $paymentDate = $payment['payment_date'] ? date('d/m/Y', strtotime($payment['payment_date'])) : null;
                                    ?>
                                    <div class="col-lg-6 col-xl-4 mb-4">
                                        <div class="card payment-card h-100">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-start mb-3">
                                                    <div>
                                                        <h6 class="card-title mb-1"><?php echo htmlspecialchars($payment['invoice_number']); ?></h6>
                                                        <small class="text-muted"><?php echo htmlspecialchars($payment['contact_person']); ?></small>
                                                    </div>
                                                    <span class="badge <?php echo $statusClass; ?> status-badge"><?php echo $statusText; ?></span>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <div class="amount-display text-primary">₹<?php echo number_format($amount, 2); ?></div>
                                                    <small class="text-muted">
                                                        <?php echo $payment['collect_today_amount'] > 0 ? 'Amount Due' : 'Maintenance Charge'; ?>
                                                    </small>
                                                </div>
                                                
                                                <div class="row text-sm mb-3">
                                                    <div class="col-6">
                                                        <small class="text-muted d-block">Due Date</small>
                                                        <small class="fw-medium"><?php echo $dueDate; ?></small>
                                                    </div>
                                                    <?php if ($paymentDate): ?>
                                                        <div class="col-6">
                                                            <small class="text-muted d-block">Paid Date</small>
                                                            <small class="fw-medium"><?php echo $paymentDate; ?></small>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                
                                                <?php if (!empty($payment['notes'])): ?>
                                                    <div class="mb-3">
                                                        <small class="text-muted d-block">Notes</small>
                                                        <small><?php echo htmlspecialchars($payment['notes']); ?></small>
                                                    </div>
                                                <?php endif; ?>
                                                
                                                <div class="d-grid">
                                                    <?php if ($isPaid): ?>
                                                        <button class="btn btn-success" disabled>
                                                            <iconify-icon icon="solar:check-circle-line-duotone" class="me-1"></iconify-icon>
                                                            Payment Completed
                                                        </button>
                                                    <?php else: ?>
                                                        <button class="btn btn-primary pay-btn" onclick="initiatePayment(<?php echo $payment['id']; ?>, '<?php echo htmlspecialchars($payment['payment_token']); ?>')">
                                                            <iconify-icon icon="solar:card-line-duotone" class="me-1"></iconify-icon>
                                                            Pay Now
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>

    <script>
        function initiatePayment(paymentId, paymentToken) {
            if (!paymentId || !paymentToken) {
                alert('Invalid payment information. Please refresh and try again.');
                return;
            }
            
            // Redirect to checkout page with payment ID and token
            const checkoutUrl = `https://www.bthdevelopers.com/checkout.php?paymentId=${paymentId}&token=${paymentToken}`;
            window.open(checkoutUrl, '_blank');
        }
    </script>
</body>

</html>