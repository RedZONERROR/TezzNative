<?php
/**
 * AI-ERP 2.0 Update Master API
 * Handles update-related operations for the system.
 */

try {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

    // Redirect if user is not authenticated
    if (!isset($_SESSION['uid'])) {
        header('Content-Type: application/json; charset=UTF-8');
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
        exit;
    }

    // Initialize database connection
    $db = getDBConnection();

    // Define constants
    define('SYSTEM_VERSION', VERSION);
    define('UPDATE_SERVER', UPDATE_URL);
    define('UPDATE_CHANNEL', 'stable');
    define('TEMP_DIRECTORY', $_SERVER['DOCUMENT_ROOT'] . '/temp/');
    define('LOGS_DIRECTORY', $_SERVER['DOCUMENT_ROOT'] . '/logs/');

    define('EXCLUDED_DIRECTORIES', [
        'uploads',
        'includes', 
        'logs',
        '.well-known',
        'temp',
        'app/updates' // Protect only the updater directory, not entire app
    ]);
    define('EXCLUDED_FILES', [
        'robots.txt',
        '.htaccess'
    ]);

    // Set headers for JSON API
    header('Content-Type: application/json; charset=UTF-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST');
    header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token');

    // Validate admin user
    $email = filter_var($_SESSION['email'] ?? '', FILTER_VALIDATE_EMAIL);
    if (empty($email)) {
        throw new Exception('Invalid or missing email in session');
    }
    $stmt = $db->prepare("SELECT id, name FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();
    if (!$admin) {
        session_destroy();
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Invalid user']);
        exit;
    }

    class UpdateMasterController {
        private $db;
        private $logger;

        public function __construct($db) {
            $this->db = $db;

            // Ensure logs directory exists and is writable
            if (!file_exists(LOGS_DIRECTORY)) {
                if (!mkdir(LOGS_DIRECTORY, 0755, true)) {
                    throw new Exception('Failed to create logs directory: ' . LOGS_DIRECTORY);
                }
            }
            if (!is_writable(LOGS_DIRECTORY)) {
                throw new Exception('Logs directory is not writable: ' . LOGS_DIRECTORY);
            }

            $this->logger = function ($message) {
                $log_file = LOGS_DIRECTORY . 'update_errors.log';
                $timestamp = date('Y-m-d H:i:s');
                file_put_contents($log_file, "[{$timestamp}] {$message}\n", FILE_APPEND);
            };
        }

        private function sendError(int $code, string $message): void {
            http_response_code($code);
            echo json_encode(['status' => 'error', 'message' => $message]);
            exit;
        }

        private function sendSuccess(int $code, array $data): void {
            http_response_code($code);
            echo json_encode(array_merge(['status' => 'success'], $data));
            exit;
        }

        private function logError(string $message): void {
            ($this->logger)('ERROR: ' . $message);
        }

        private function getSetting(string $key, string $default = ''): string {
            try {
                $stmt = $this->db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
                $stmt->execute([$key]);
                $row = $stmt->fetch();
                $value = $row ? $row['setting_value'] : $default;
                $this->logError("Retrieved setting: key=$key, value=$value");
                return $value;
            } catch (Exception $e) {
                $this->logError('Failed to get setting: ' . $e->getMessage());
                return $default;
            }
        }

        private function updateSetting(string $key, string $value): bool {
            try {
                $stmt = $this->db->prepare(
                    "INSERT INTO system_settings (setting_key, setting_value, created_at, updated_at) VALUES (?, ?, NOW(), NOW()) 
                     ON DUPLICATE KEY UPDATE setting_value = ?, updated_at = NOW()"
                );
                $stmt->execute([$key, $value, $value]);
                $this->logError("Updated setting: key=$key, value=$value");
                return true;
            } catch (Exception $e) {
                $this->logError('Failed to update setting: ' . $e->getMessage());
                return false;
            }
        }

        private function getLicenseInfo() {
            try {
                $license_key = $this->getSetting('license_key', '');
                if (empty($license_key)) {
                    $this->logError('License key not found in system_settings');
                    return false;
                }
                if (!defined('LICENSE_DOMAIN')) {
                    $this->logError('LICENSE_DOMAIN not defined in config.php');
                    return false;
                }
                $license_info = [
                    'key' => $license_key,
                    'domain' => LICENSE_DOMAIN
                ];
                $this->logError('License info: key=' . $license_key . ', domain=' . LICENSE_DOMAIN);
                return $license_info;
            } catch (Exception $e) {
                $this->logError('Exception in getLicenseInfo: ' . $e->getMessage());
                return false;
            }
        }

        private function sendAdminNotification(string $subject, string $message, string $type = 'info'): bool {
            global $admin;
            try {
                $stmt = $this->db->prepare("INSERT INTO notifications (user_id, subject, message, type) VALUES (?, ?, ?, ?)");
                $stmt->execute([$admin['id'], $subject, $message, $type]);
                $this->logError('Sent admin notification: ' . $subject);
                return true;
            } catch (Exception $e) {
                $this->logError('Failed to send notification: ' . $e->getMessage());
                return false;
            }
        }

        private function checkForUpdates(): array {
            try {
                $current_version = $this->getSetting('system_version', SYSTEM_VERSION);
                $update_channel = $this->getSetting('update_channel', UPDATE_CHANNEL);

                $license_info = $this->getLicenseInfo();
                if (!$license_info) {
                    $this->logError('No valid license found');
                    return ['status' => 'error', 'message' => 'No valid license found'];
                }

                // Generate server-to-server CSRF token
                $csrf_data = generateServerCsrfToken($license_info['key'], $license_info['domain']);
                $server_csrf_token = $csrf_data['token'];

                $data = [
                    'action' => 'check_update',
                    'version' => $current_version,
                    'channel' => $update_channel,
                    'license' => $license_info['key'],
                    'domain' => $license_info['domain']
                ];

                $query_string = http_build_query($data);
                $url = UPDATE_SERVER . 'updates.php?' . $query_string;
                $this->logError('Sending GET request to: ' . $url);
                $this->logError('CSRF token: ' . $server_csrf_token);

                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 30);
                curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    'X-CSRF-Token: ' . $server_csrf_token
                ]);

                $response = curl_exec($ch);
                if (curl_errno($ch)) {
                    $error = curl_error($ch);
                    $this->logError('cURL error when checking for updates: ' . $error);
                    curl_close($ch);
                    return ['status' => 'error', 'message' => 'Failed to connect to update server: ' . $error];
                }
                $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $this->logError('Update server response: HTTP ' . $http_code . ' - ' . $response);
                curl_close($ch);

                if ($http_code !== 200) {
                    $this->logError('Non-200 response from update server: HTTP ' . $http_code);
                    return ['status' => 'error', 'message' => 'Update server error (HTTP ' . $http_code . ')'];
                }

                $result = json_decode($response, true);
                if (!$result || !isset($result['status'])) {
                    $this->logError('Invalid response from update server: ' . $response);
                    return ['status' => 'error', 'message' => 'Invalid response from update server'];
                }

                if ($result['status'] === 'success' && !$result['update_available']) {
                    $result['message'] = 'System is already updated to the latest version';
                    $this->logError('No update available: System is at the latest version (' . $current_version . ')');
                }

                $this->logError('Parsed response: ' . json_encode($result));
                $this->updateSetting('last_update_check', date('Y-m-d H:i:s'));
                return $result;
            } catch (Exception $e) {
                $this->logError('Exception in checkForUpdates: ' . $e->getMessage());
                return ['status' => 'error', 'message' => 'Internal server error: ' . $e->getMessage()];
            }
        }

        private function downloadUpdate(array $update_info) {
            try {
                $license_info = $this->getLicenseInfo();
                if (!$license_info) {
                    $this->logError('No valid license for download');
                    return ['success' => false, 'message' => 'No valid license found'];
                }

                if (!file_exists(TEMP_DIRECTORY)) {
                    if (!mkdir(TEMP_DIRECTORY, 0755, true)) {
                        $this->logError('Failed to create temp directory: ' . TEMP_DIRECTORY);
                        return ['success' => false, 'message' => 'Failed to create temp directory'];
                    }
                }
                if (!is_writable(TEMP_DIRECTORY)) {
                    $this->logError('Temp directory is not writable: ' . TEMP_DIRECTORY);
                    return ['success' => false, 'message' => 'Temp directory is not writable'];
                }

                // Generate server-to-server CSRF token
                $csrf_data = generateServerCsrfToken($license_info['key'], $license_info['domain']);
                $server_csrf_token = $csrf_data['token'];

                $data = [
                    'version' => $update_info['version'],
                    'license' => $license_info['key'],
                    'domain' => $license_info['domain']
                ];

                $this->logError('Sending download cURL request with data: ' . json_encode($data));
                $this->logError('CSRF token: ' . $server_csrf_token);

                $update_package = TEMP_DIRECTORY . 'update_' . $update_info['version'] . '_' . time() . '.zip';
                $ch = curl_init(UPDATE_SERVER . 'updates.php?action=download_update');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 3600);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    'X-CSRF-Token: ' . $server_csrf_token,
                    'Accept: application/zip'
                ]);

                $response = curl_exec($ch);
                $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $content_type = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
                $curl_error = curl_error($ch);
                curl_close($ch);

                $this->logError("Download update response: HTTP $http_code, Content-Type: $content_type");

                if ($curl_error) {
                    $this->logError("cURL error: $curl_error");
                    return ['success' => false, 'message' => 'cURL error: ' . $curl_error];
                }

                if ($http_code !== 200) {
                    $this->logError("Non-200 response: HTTP $http_code, Response: $response");
                    return ['success' => false, 'message' => 'Update server error (HTTP ' . $http_code . '): ' . $response];
                }

                if (strpos($content_type, 'application/zip') !== 0) {
                    $this->logError("Invalid Content-Type: $content_type, Response: $response");
                    return ['success' => false, 'message' => 'Invalid response type, expected application/zip'];
                }

                if (file_put_contents($update_package, $response) === false) {
                    $this->logError('Failed to save update package: ' . $update_package);
                    return ['success' => false, 'message' => 'Failed to save update package'];
                }

                $this->logError('Update package saved: ' . $update_package);
                return ['success' => true, 'file_path' => $update_package];
            } catch (Exception $e) {
                $this->logError('Exception in downloadUpdate: ' . $e->getMessage());
                return ['success' => false, 'message' => 'Internal server error: ' . $e->getMessage()];
            }
        }

        private function deleteDirectory($dir) {
            if (!file_exists($dir)) {
                return true;
            }
            if (!is_dir($dir)) {
                return unlink($dir);
            }
            foreach (scandir($dir) as $item) {
                if ($item == '.' || $item == '..') {
                    continue;
                }
                if (!$this->deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
                    return false;
                }
            }
            return rmdir($dir);
        }

        private function isExcluded(string $relativePath): bool {
            $pathParts = explode('/', trim($relativePath, '/'));
            $topLevelDir = $pathParts[0] ?? '';
            $fileName = basename($relativePath);
            
            foreach (EXCLUDED_DIRECTORIES as $excludedDir) {
                if (strpos($excludedDir, '/') !== false) {
                    // Handle nested paths like 'app/updates'
                    if (strpos($relativePath, $excludedDir) === 0) {
                        return true;
                    }
                } else {
                    // Handle top-level directories
                    if ($topLevelDir === $excludedDir) {
                        return true;
                    }
                }
            }
            
            // Check if file is excluded
            if (in_array($fileName, EXCLUDED_FILES)) {
                return true;
            }
            
            return false;
        }

        private function deleteAllExceptProtected(): bool {
            try {
                $root_dir = $_SERVER['DOCUMENT_ROOT'];
                $items = scandir($root_dir);
                $deleted_count = 0;
                $skipped_count = 0;

                foreach ($items as $item) {
                    if ($item === '.' || $item === '..') {
                        continue;
                    }

                    $item_path = $root_dir . '/' . $item;
                    
                    $should_skip = false;
                    
                    // Check if this is a top-level excluded item
                    if (in_array($item, EXCLUDED_FILES)) {
                        $should_skip = true;
                    }
                    
                    // Check excluded directories (including nested ones)
                    foreach (EXCLUDED_DIRECTORIES as $excludedDir) {
                        if (strpos($excludedDir, '/') !== false) {
                            // For nested paths like 'app/updates', only exclude if it matches exactly
                            $parts = explode('/', $excludedDir);
                            if ($parts[0] === $item && $item === 'app') {
                                // Special handling for app directory - we need to delete selectively
                                $should_skip = false; // Don't skip the entire app directory
                                break;
                            }
                        } else {
                            // For top-level exclusions
                            if ($item === $excludedDir) {
                                $should_skip = true;
                                break;
                            }
                        }
                    }

                    if ($should_skip) {
                        $this->logError('Skipping protected item: ' . $item);
                        $skipped_count++;
                        continue;
                    }

                    if ($item === 'app' && is_dir($item_path)) {
                        if ($this->deleteAppDirectorySelectively($item_path)) {
                            $this->logError('Selectively cleaned app directory');
                            $deleted_count++;
                        } else {
                            $this->logError('Failed to selectively clean app directory');
                            return false;
                        }
                        continue;
                    }

                    // Delete the item
                    if (is_dir($item_path)) {
                        if ($this->deleteDirectory($item_path)) {
                            $this->logError('Deleted directory: ' . $item);
                            $deleted_count++;
                        } else {
                            $this->logError('Failed to delete directory: ' . $item);
                            return false;
                        }
                    } else {
                        if (unlink($item_path)) {
                            $this->logError('Deleted file: ' . $item);
                            $deleted_count++;
                        } else {
                            $this->logError('Failed to delete file: ' . $item);
                            return false;
                        }
                    }
                }

                $this->logError("Cleanup completed: $deleted_count items deleted, $skipped_count items protected");
                return true;
            } catch (Exception $e) {
                $this->logError('Exception in deleteAllExceptProtected: ' . $e->getMessage());
                return false;
            }
        }

        private function deleteAppDirectorySelectively(string $app_dir): bool {
            try {
                $items = scandir($app_dir);
                $deleted_count = 0;
                $skipped_count = 0;

                foreach ($items as $item) {
                    if ($item === '.' || $item === '..') {
                        continue;
                    }

                    $item_path = $app_dir . '/' . $item;
                    
                    // Skip the updates directory
                    if ($item === 'updates') {
                        $this->logError('Skipping protected app/updates directory');
                        $skipped_count++;
                        continue;
                    }

                    // Delete everything else in app directory
                    if (is_dir($item_path)) {
                        if ($this->deleteDirectory($item_path)) {
                            $this->logError('Deleted app subdirectory: ' . $item);
                            $deleted_count++;
                        } else {
                            $this->logError('Failed to delete app subdirectory: ' . $item);
                            return false;
                        }
                    } else {
                        if (unlink($item_path)) {
                            $this->logError('Deleted app file: ' . $item);
                            $deleted_count++;
                        } else {
                            $this->logError('Failed to delete app file: ' . $item);
                            return false;
                        }
                    }
                }

                $this->logError("App directory cleanup: $deleted_count items deleted, $skipped_count items protected");
                return true;
            } catch (Exception $e) {
                $this->logError('Exception in deleteAppDirectorySelectively: ' . $e->getMessage());
                return false;
            }
        }

        private function installUpdate(string $update_package, array $update_info): bool {
            global $admin;

            try {
                if (!file_exists($update_package) || !is_readable($update_package)) {
                    $this->logError('Update package not found: ' . $update_package);
                    return false;
                }

                $root_dir = $_SERVER['DOCUMENT_ROOT'];
                
                // Step 1: Delete everything except protected items
                $this->logError('Deleting all files except protected items...');
                if (!$this->deleteAllExceptProtected()) {
                    $this->logError('Failed to delete existing files');
                    return false;
                }

                // Step 2: Extract zip to temp directory
                $extract_dir = TEMP_DIRECTORY . 'extract_' . time() . '/';
                $zip = new ZipArchive;
                if ($zip->open($update_package) !== true) {
                    $this->logError('Failed to open zip: ' . $update_package);
                    return false;
                }

                if (!$zip->extractTo($extract_dir)) {
                    $zip->close();
                    $this->logError('Failed to extract zip');
                    return false;
                }
                $zip->close();
                $this->logError('Extracted to: ' . $extract_dir);

                // Step 3: Copy everything from extracted directory to root
                $this->logError('Copying files to root directory...');
                $installed_count = $this->copyExtractedFiles($extract_dir, $root_dir);
                
                if ($installed_count === false) {
                    $this->logError('Failed to copy extracted files');
                    return false;
                }

                $this->logError("Installation completed: $installed_count files installed");

                // Update system version
                $this->updateSetting('system_version', $update_info['version']);

                // Log update history
                $stmt = $this->db->prepare("INSERT INTO update_history (version, description, applied_by, update_date) VALUES (?, ?, ?, NOW())");
                $stmt->execute([$update_info['version'], "System updated to version " . $update_info['version'], $admin['name']]);

                // Clean up
                unlink($update_package);
                $this->deleteDirectory($extract_dir);

                // Send notification
                $this->sendAdminNotification(
                    'System Updated to v' . $update_info['version'],
                    'System successfully updated to version ' . $update_info['version'] . '. ' . $installed_count . ' files installed.',
                    'info'
                );

                return true;
            } catch (Exception $e) {
                $this->logError('Exception in installUpdate: ' . $e->getMessage());
                return false;
            }
        }

        private function copyExtractedFiles(string $source_dir, string $target_dir): int|false {
            try {
                $installed_count = 0;
                $items = scandir($source_dir);
                
                foreach ($items as $item) {
                    if ($item === '.' || $item === '..') {
                        continue;
                    }

                    $source_path = $source_dir . $item;
                    $target_path = $target_dir . '/' . $item;

                    $should_skip = false;
                    
                    // Check if this item should be skipped
                    if (in_array($item, EXCLUDED_FILES)) {
                        $should_skip = true;
                    }
                    
                    // Check excluded directories
                    foreach (EXCLUDED_DIRECTORIES as $excludedDir) {
                        if (strpos($excludedDir, '/') !== false) {
                            // For nested paths, check if this is the start of the path
                            $parts = explode('/', $excludedDir);
                            if ($parts[0] === $item) {
                                // This is a parent directory of an excluded path
                                if ($item === 'app') {
                                    $should_skip = false;
                                    break;
                                }
                            }
                        } else {
                            if ($item === $excludedDir) {
                                $should_skip = true;
                                break;
                            }
                        }
                    }

                    if ($should_skip) {
                        $this->logError('Skipping protected item during copy: ' . $item);
                        continue;
                    }

                    if (is_dir($source_path)) {
                        if ($item === 'app') {
                            if ($this->copyAppDirectorySelectively($source_path, $target_path)) {
                                $this->logError('Selectively copied app directory');
                                $installed_count++;
                            } else {
                                $this->logError('Failed to selectively copy app directory');
                                return false;
                            }
                        } else {
                            // Copy directory recursively
                            if ($this->copyDirectorySimple($source_path, $target_path)) {
                                $this->logError('Copied directory: ' . $item);
                                $installed_count++;
                            } else {
                                $this->logError('Failed to copy directory: ' . $item);
                                return false;
                            }
                        }
                    } else {
                        // Copy file
                        if (copy($source_path, $target_path)) {
                            chmod($target_path, 0644);
                            $this->logError('Copied file: ' . $item);
                            $installed_count++;
                        } else {
                            $this->logError('Failed to copy file: ' . $source_path);
                            return false;
                        }
                    }
                }

                return $installed_count;
            } catch (Exception $e) {
                $this->logError('Exception in copyExtractedFiles: ' . $e->getMessage());
                return false;
            }
        }

        private function copyAppDirectorySelectively(string $source, string $destination): bool {
            try {
                if (!is_dir($source)) {
                    return false;
                }

                if (!file_exists($destination)) {
                    if (!mkdir($destination, 0755, true)) {
                        $this->logError('Failed to create app directory: ' . $destination);
                        return false;
                    }
                }

                $items = scandir($source);
                foreach ($items as $item) {
                    if ($item === '.' || $item === '..') {
                        continue;
                    }

                    // Skip the updates directory
                    if ($item === 'updates') {
                        $this->logError('Skipping app/updates directory during copy');
                        continue;
                    }

                    $source_path = $source . '/' . $item;
                    $dest_path = $destination . '/' . $item;

                    if (is_dir($source_path)) {
                        if (!$this->copyDirectorySimple($source_path, $dest_path)) {
                            return false;
                        }
                    } else {
                        if (!copy($source_path, $dest_path)) {
                            $this->logError('Failed to copy app file: ' . $source_path);
                            return false;
                        }
                        chmod($dest_path, 0644);
                    }
                }

                return true;
            } catch (Exception $e) {
                $this->logError('Exception in copyAppDirectorySelectively: ' . $e->getMessage());
                return false;
            }
        }

        private function copyDirectorySimple(string $source, string $destination): bool {
            try {
                if (!is_dir($source)) {
                    return false;
                }

                if (!file_exists($destination)) {
                    if (!mkdir($destination, 0755, true)) {
                        $this->logError('Failed to create directory: ' . $destination);
                        return false;
                    }
                }

                $items = scandir($source);
                foreach ($items as $item) {
                    if ($item === '.' || $item === '..') {
                        continue;
                    }

                    $source_path = $source . '/' . $item;
                    $dest_path = $destination . '/' . $item;

                    if (is_dir($source_path)) {
                        if (!$this->copyDirectorySimple($source_path, $dest_path)) {
                            return false;
                        }
                    } else {
                        if (!copy($source_path, $dest_path)) {
                            $this->logError('Failed to copy file: ' . $source_path);
                            return false;
                        }
                        chmod($dest_path, 0644);
                    }
                }

                return true;
            } catch (Exception $e) {
                $this->logError('Exception in copyDirectorySimple: ' . $e->getMessage());
                return false;
            }
        }

        public function handleRequest() {
            try {
                $action = $_GET['action'] ?? '';

                switch ($action) {
                    case 'check':
                        $result = $this->checkForUpdates();
                        $this->logError('HandleRequest result: ' . json_encode($result));
                        if ($result['status'] === 'success' && $result['update_available']) {
                            $_SESSION['update_info'] = [
                                'version' => $result['version'],
                                'release_date' => $result['release_date'],
                                'notes' => $result['notes'],
                                'size' => $result['size']
                            ];
                            $this->logError('Session update_info set: ' . json_encode($_SESSION['update_info']));
                        } elseif ($result['status'] === 'success') {
                            unset($_SESSION['update_info']);
                            $this->logError('Session update_info unset');
                        }
                        $this->sendSuccess(200, $result);
                        break;

                    case 'install':
                        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                            $this->sendError(405, 'Method not allowed');
                        }
                        if (!isset($_SESSION['update_info'])) {
                            $this->logError('No update information available in session');
                            $this->sendError(400, 'No update information available');
                        }
                        $update_info = $_SESSION['update_info'];
                        $current_version = $this->getSetting('system_version', SYSTEM_VERSION);
                        if ($current_version === $update_info['version']) {
                            $this->logError('System is already updated to version: ' . $current_version);
                            unset($_SESSION['update_info']);
                            $this->sendSuccess(200, ['message' => 'System is already updated to the latest version']);
                        }
                        $download_result = $this->downloadUpdate($update_info);
                        if (!$download_result['success']) {
                            $this->logError('Download update failed: ' . $download_result['message']);
                            $this->sendError(500, $download_result['message']);
                        }
                        $installed = $this->installUpdate($download_result['file_path'], $update_info);
                        if (!$installed) {
                            $this->logError('Install update failed');
                            $this->sendError(500, 'Failed to install system update');
                        }
                        unset($_SESSION['update_info']);
                        $this->sendSuccess(200, ['message' => 'System update installed successfully']);
                        break;

                    case 'history':
                        $stmt = $this->db->prepare("SELECT * FROM update_history ORDER BY update_date DESC LIMIT 10");
                        $stmt->execute();
                        $history = $stmt->fetchAll();
                        $this->sendSuccess(200, ['data' => $history]);
                        break;

                    case 'settings':
                        $settings = [
                            'current_version' => $this->getSetting('system_version', SYSTEM_VERSION),
                            'last_update_check' => $this->getSetting('last_update_check', 'Never'),
                            'update_channel' => $this->getSetting('update_channel', UPDATE_CHANNEL),
                            'license_status' => $this->getLicenseInfo() ? 'Active' : 'Invalid'
                        ];
                        $this->sendSuccess(200, ['data' => $settings]);
                        break;

                    default:
                        $this->sendError(400, 'Invalid action');
                }
            } catch (Exception $e) {
                $this->logError('Exception in handleRequest: ' . $e->getMessage());
                $this->sendError(500, 'Internal server error: ' . $e->getMessage());
            }
        }
    }

    $controller = new UpdateMasterController($db);
    $controller->handleRequest();
} catch (Exception $e) {
    error_log("Exception in controller initialization: " . $e->getMessage(), 3, $_SERVER['DOCUMENT_ROOT'] . '/logs/update_errors.log');
    header('Content-Type: application/json; charset=UTF-8');
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Internal server error']);
    exit;
}
?>