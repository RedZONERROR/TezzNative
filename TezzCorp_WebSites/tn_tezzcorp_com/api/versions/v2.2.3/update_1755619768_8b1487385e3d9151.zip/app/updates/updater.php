<?php
session_start();

// Redirect to login if user is not authenticated
if (!isset($_SESSION['uid'])) {
    header("Location: ../../login");
    exit();
}

// Validate session variables
$role = $_SESSION['role'] ?? '';
$name = $_SESSION['name'] ?? 'Unknown';
$photo = $_SESSION['photo'] ?? '';
$email = filter_var($_SESSION['email'] ?? '', FILTER_SANITIZE_EMAIL);

// Generate CSRF token for AJAX requests
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="<?php echo htmlspecialchars($csrf_token); ?>" />

    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
    <script src="../assets/js/jquery.steps.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>

    <title>Updater - AI-ERP 2.0</title>
</head>
<body>
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <?php include 'util/sidebar.php'; ?>
        <div class="page-wrapper">
            <?php include 'util/topbar.php'; ?>
            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">System Updater</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">System Updater</span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="alert-container"></div>

                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title fw-semibold mb-4">System Information</h5>
                            <div class="p-4 rounded-3 bg-light-subtle" id="system-info">
                                <p class="mb-2"><strong>Current Version:</strong> <span id="current-version">Loading...</span></p>
                                <p class="mb-2"><strong>Last Update Check:</strong> <span id="last-update-check">Loading...</span></p>
                                <p class="mb-2"><strong>Update Channel:</strong> <span id="update-channel">Loading...</span></p>
                                <p class="mb-0"><strong>License Status:</strong> <span id="license-status">Loading...</span></p>
                            </div>
                            <button id="check-updates-btn" class="btn btn-primary mt-4">
                                <i class="ti ti-refresh me-2"></i> Check for Updates
                            </button>
                        </div>
                    </div>

                    <div class="card" id="update-available-card" style="display: none;">
                        <div class="card-body">
                            <h5 class="card-title fw-semibold mb-4">Update Available</h5>
                            <div class="p-4 rounded-3 bg-light-subtle" id="update-info">
                                <p class="mb-2"><strong>New Version:</strong> <span id="new-version"></span></p>
                                <p class="mb-2"><strong>Release Date:</strong> <span id="release-date"></span></p>
                                <p class="mb-0"><strong>Package Size:</strong> <span id="package-size"></span></p>
                            </div>
                            <div class="p-4 rounded-3 bg-light-subtle mt-4" id="release-notes">
                                <h6 class="mb-3">Release Notes:</h6>
                                <div style="max-height: 200px; overflow-y: auto;" id="release-notes-content"></div>
                            </div>
                            <div class="mt-4">
                                <button id="install-update-btn" class="btn btn-success">
                                    <i class="ti ti-download me-2"></i> Install Update
                                </button>
                            </div>
                            <div class="progress mt-4" id="update-progress" style="display: none;">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%;" id="progress-bar">0%</div>
                            </div>
                            <div class="alert alert-warning mt-4" role="alert">
                                <i class="ti ti-alert-triangle me-2"></i>
                                <strong>Important:</strong> This update will delete all existing files and folders in the root directory except for protected items, then install the new system files.
                            </div>
                            
                            <!-- Updated excluded directories information to reflect comprehensive update -->
                            <div class="alert alert-info mt-3" role="alert">
                                <i class="ti ti-info-circle me-2"></i>
                                <strong>Protected Items (Will NOT be deleted):</strong>
                                <ul class="mb-0 mt-2">
                                    <li>/uploads - User uploaded files</li>
                                    <li>/includes - Configuration files</li>
                                    <li>/logs - System logs</li>
                                    <li>/.well-known - SSL/Domain verification</li>
                                    <li>/temp - Temporary files</li>
                                    <li>/api - API directory</li>
                                    <li>robots.txt - SEO configuration</li>
                                    <li>.htaccess - Server configuration</li>
                                    <li>updater.php - This updater file</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title fw-semibold mb-4">Update History</h5>
                            <div class="table-responsive">
                                <table class="table table-hover" id="update-history-table">
                                    <thead>
                                        <tr>
                                            <th>Version</th>
                                            <th>Date</th>
                                            <th>Description</th>
                                            <th>Applied By</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>

    <script>
        $(document).ready(function() {
            const csrfToken = $('meta[name="csrf-token"]').attr('content');

            // Function to show alerts
            function showAlert(message, type) {
                const alertHtml = `
                    <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                        <i class="ti ti-${type === 'success' ? 'check' : 'alert-circle'} me-2"></i> ${message}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>`;
                $('#alert-container').html(alertHtml);
                setTimeout(() => $('.alert').alert('close'), 8000); // Increased timeout for longer messages
            }

            // Fetch system settings
            function fetchSystemSettings() {
                $.ajax({
                    url: 'api/update_master.php?action=settings',
                    method: 'GET',
                    headers: { 'X-CSRF-Token': csrfToken },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            const settings = response.data;
                            $('#current-version').text('v' + settings.current_version);
                            $('#last-update-check').text(settings.last_update_check);
                            $('#update-channel').text(settings.update_channel);
                            $('#license-status').html(`<span class="badge bg-${settings.license_status === 'Active' ? 'success' : 'danger'}">${settings.license_status}</span>`);
                        } else {
                            showAlert('Failed to fetch system settings: ' + response.message, 'danger');
                        }
                    },
                    error: function(xhr) {
                        showAlert('Error fetching system settings: ' + (xhr.responseJSON?.message || 'Server error'), 'danger');
                    }
                });
            }

            // Fetch update history
            function fetchUpdateHistory() {
                $.ajax({
                    url: 'api/update_master.php?action=history',
                    method: 'GET',
                    headers: { 'X-CSRF-Token': csrfToken },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            const history = response.data;
                            const tbody = $('#update-history-table tbody');
                            tbody.empty();
                            if (history.length === 0) {
                                tbody.append('<tr><td colspan="4" class="text-center">No update history available.</td></tr>');
                            } else {
                                history.forEach(item => {
                                    tbody.append(`
                                        <tr>
                                            <td>v${item.version}</td>
                                            <td>${new Date(item.update_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</td>
                                            <td>${item.description}</td>
                                            <td>${item.applied_by}</td>
                                        </tr>
                                    `);
                                });
                            }
                        } else {
                            showAlert('Failed to fetch update history: ' + response.message, 'danger');
                        }
                    },
                    error: function(xhr) {
                        showAlert('Error fetching update history: ' + (xhr.responseJSON?.message || 'Server error'), 'danger');
                    }
                });
            }

            // Check for updates
            $('#check-updates-btn').click(function() {
                $(this).prop('disabled', true).html('<i class="ti ti-refresh me-2"></i> Checking...');
                $.ajax({
                    url: 'api/update_master.php?action=check',
                    method: 'GET',
                    headers: { 'X-CSRF-Token': csrfToken },
                    dataType: 'json',
                    success: function(response) {
                        $('#check-updates-btn').prop('disabled', false).html('<i class="ti ti-refresh me-2"></i> Check for Updates');
                        if (response.status === 'success') {
                            fetchSystemSettings();
                            if (response.update_available) {
                                $('#update-available-card').show();
                                $('#new-version').text('v' + response.version);
                                $('#release-date').text(response.release_date);
                                $('#package-size').text(response.size);
                                $('#release-notes-content').text(response.notes);
                                showAlert('Update available: v' + response.version + ' - This will update the entire system while preserving your data and configuration.', 'success');
                            } else {
                                $('#update-available-card').hide();
                                showAlert('Your system is up to date.', 'success');
                            }
                        } else {
                            showAlert('Failed to check for updates: ' + response.message, 'danger');
                        }
                    },
                    error: function(xhr) {
                        $('#check-updates-btn').prop('disabled', false).html('<i class="ti ti-refresh me-2"></i> Check for Updates');
                        showAlert('Error checking for updates: ' + (xhr.responseJSON?.message || 'Server error'), 'danger');
                    }
                });
            });

            $('#install-update-btn').click(function() {
                if (!confirm('This will DELETE ALL files and folders except protected items, then install new files. Are you sure?')) {
                    return;
                }
                
                $(this).prop('disabled', true).html('<i class="ti ti-download me-2"></i> Installing...');
                $('#update-progress').show();
                let progress = 0;
                const progressInterval = setInterval(() => {
                    progress += 5;
                    $('#progress-bar').css('width', progress + '%').text(progress + '%');
                    if (progress >= 90) clearInterval(progressInterval);
                }, 2000);

                $.ajax({
                    url: 'api/update_master.php?action=install',
                    method: 'POST',
                    headers: { 'X-CSRF-Token': csrfToken },
                    dataType: 'json',
                    timeout: 300000, // 5 minutes
                    success: function(response) {
                        clearInterval(progressInterval);
                        $('#progress-bar').css('width', '100%').text('100%');
                        $('#install-update-btn').prop('disabled', false).html('<i class="ti ti-download me-2"></i> Install Update');
                        $('#update-progress').hide();
                        if (response.status === 'success') {
                            $('#update-available-card').hide();
                            fetchSystemSettings();
                            fetchUpdateHistory();
                            showAlert('System update completed successfully!', 'success');
                        } else {
                            showAlert('Failed to install update: ' + response.message, 'danger');
                        }
                    },
                    error: function(xhr) {
                        clearInterval(progressInterval);
                        $('#progress-bar').css('width', '0%').text('0%');
                        $('#install-update-btn').prop('disabled', false).html('<i class="ti ti-download me-2"></i> Install Update');
                        $('#update-progress').hide();
                        showAlert('Error installing update: ' + (xhr.responseJSON?.message || 'Server error'), 'danger');
                    }
                });
            });

            // Initial load
            fetchSystemSettings();
            fetchUpdateHistory();
        });
    </script>
</body>
</html>