<?php
session_start();
if(!isset($_SESSION['uid'])){
	header("location: ../../login");
	die();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Site Settings - AI-ERP 2.0</title>
    <style>
        .btn-loading .spinner-border {
            display: inline-block;
        }
        .spinner-border {
            display: none;
            width: 1rem;
            height: 1rem;
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!--  Sidebar End -->
        <div class="page-wrapper">
            <!--  Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!--  Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Site Settings</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Site Settings
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Settings Form -->
                    <div class="card card-body">
                        <form id="siteSettingsForm">
                            <input type="hidden" id="settings_id">
                            <input type="hidden" name="_method" value="PUT">
                            <!-- General Settings -->
                            <h5 class="mb-3">General Settings</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="school_name" class="form-label">School Name</label>
                                    <input type="text" id="school_name" name="school_name" class="form-control" placeholder="Enter school name" required />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label">School Email</label>
                                    <input type="email" id="email" name="email" class="form-control" placeholder="Enter school email" required />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="address" class="form-label">Address</label>
                                    <input type="text" id="address" name="address" class="form-control" placeholder="Address" required />
                                    <div class="validation-text text-danger"></div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="phone" class="form-label">Phone Number</label>
                                    <input type="tel" id="phone" name="phone" class="form-control" placeholder="Enter phone number" required pattern="\+?\d{10,15}" maxlength="15" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="tagline" class="form-label">Tagline</label>
                                    <input type="text" id="tagline" name="tagline" class="form-control" placeholder="Enter school tagline" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="footer_text" class="form-label">Footer Text</label>
                                    <input type="text" id="footer_text" name="footer_text" class="form-control" placeholder="Enter footer text" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                            </div>

                            <!-- Branding -->
                            <h5 class="mt-4 mb-3">Branding</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="logo" class="form-label">School Logo</label>
                                    <input type="file" id="logo" name="logo" class="form-control" accept="image/*" />
                                    <img id="logo_preview" src="" alt="Logo Preview" class="img-fluid mt-2" style="max-height: 100px; display: none;" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="favicon" class="form-label">Favicon</label>
                                    <input type="file" id="favicon" name="favicon" class="form-control" accept="image/*" />
                                    <img id="favicon_preview" src="" alt="Favicon Preview" class="img-fluid mt-2" style="max-height: 50px; display: none;" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="primary_color" class="form-label">Primary Color</label>
                                    <input type="color" id="primary_color" name="primary_color" class="form-control form-control-color" value="#007bff" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="secondary_color" class="form-label">Secondary Color</label>
                                    <input type="color" id="secondary_color" name="secondary_color" class="form-control form-control-color" value="#006cc" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="background_color" class="form-label">Background Color</label>
                                    <input type="color" id="background_color" name="background_color" class="form-control form-control-color" value="#000000" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                            </div>

                            <!-- Support Contacts -->
                            <h5 class="mt-4 mb-3">Support Contacts</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="transport_head_mobile" class="form-label">Transport Head Mobile</label>
                                    <input type="tel" id="transport_head_mobile" name="transport_head_mobile" class="form-control" placeholder="Enter transport head mobile" pattern="\+?\d{10,15}" maxlength="15" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="fees_collection_mobile" class="form-label">Fees Collection Mobile</label>
                                    <input type="tel" id="fees_collection_mobile" name="fees_collection_mobile" class="form-control" placeholder="Enter mobile number" pattern="\+?\d{10,15}" maxlength="15" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="whatsapp_number" class="form-label">WhatsApp Number</label>
                                    <input type="tel" id="whatsapp_number" name="whatsapp_number" class="form-control" placeholder="Enter WhatsApp number" pattern="\+?\d{10,15}" maxlength="15" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="calling_number" class="form-label">Calling Number</label>
                                    <input type="tel" id="calling_number" name="calling_number" class="form-control" placeholder="Enter Calling number" pattern="\+?\d{10,15}" maxlength="15" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                            </div>

                            <!-- Email Settings -->
                            <h5 class="mt-4 mb-3">Email Settings</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="phpmailer_host" class="form-label">PHPMailer Host</label>
                                    <input type="text" id="phpmailer_host" name="phpmailer_host" class="form-control" placeholder="e.g., smtp.gmail.com" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="phpmailer_username" class="form-label">PHPMailer Username</label>
                                    <input type="text" id="phpmailer_username" name="phpmailer_username" class="form-control" placeholder="e.g., your-email@gmail.com" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="phpmailer_password" class="form-label">PHPMailer Password</label>
                                    <input type="password" id="phpmailer_password" name="phpmailer_password" class="form-control" placeholder="Enter password" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="phpmailer_port" class="form-label">PHPMailer Port</label>
                                    <input type="number" id="phpmailer_port" name="phpmailer_port" class="form-control" placeholder="e.g., 587" min="1" max="65535" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                            </div>

                            <!-- Social Media -->
                            <h5 class="mt-4 mb-3">Social Media</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="facebook_url" class="form-label">Facebook URL</label>
                                    <input type="url" id="facebook_url" name="facebook_url" class="form-control" placeholder="https://facebook.com/" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="twitter_url" class="form-label">Twitter URL</label>
                                    <input type="url" id="twitter_url" name="twitter_url" class="form-control" placeholder="https://twitter.com/" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="instagram_url" class="form-label">Instagram URL</label>
                                    <input type="url" id="instagram_url" name="instagram_url" class="form-control" placeholder="https://instagram.com/" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="linkedin_url" class="form-label">LinkedIn URL</label>
                                    <input type="url" id="linkedin_url" name="linkedin_url" class="form-control" placeholder="https://linkedin.com/" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="youtube_url" class="form-label">YouTube URL</label>
                                    <input type="url" id="youtube_url" name="youtube_url" class="form-control" placeholder="https://youtube.com/" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                            </div>

                            <!-- Analytics & Maintenance -->
                            <h5 class="mt-4 mb-3">Analytics & Maintenance</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="google_analytics_id" class="form-label">Google Analytics ID</label>
                                    <input type="text" id="google_analytics_id" name="google_analytics_id" class="form-control" placeholder="e.g., UA-XXXXX-Y" pattern="UA-[0-9]+-[0-9]+" />
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="maintenance_mode" class="form-label">Maintenance Mode</label>
                                    <select id="maintenance_mode" name="maintenance_mode" class="form-control">
                                        <option value="disabled">Disabled</option>
                                        <option value="enabled">Enabled</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select id="status" name="status" class="form-control" required>
                                        <option value="">Select Status</option>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                            </div>

                            <div class="text-end mt-4">
                                <button type="submit" class="btn btn-success" id="save-settings-btn">Save Settings
                                    <div class="spinner-border text-light btn-loading" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        $(document).ready(function() {
            // Load existing settings
            function loadSettings() {
                $.ajax({
                    url: 'api/site_settings_master.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        console.log('API Response:', response); // Debug: Log the API response
                        const settings = response.data && response.data.length > 0 ? response.data[0] : {};
                        if (settings) {
                            $('#settings_id').val(settings.id || '');
                            $('#school_name').val(settings.school_name || '');
                            $('#email').val(settings.email || '');
                            $('#address').val(settings.address || '');
                            $('#phone').val(settings.phone || '');
                            $('#tagline').val(settings.tagline || '');
                            $('#footer_text').val(settings.footer_text || '');
                            if (settings.logo) {
                                $('#logo_preview').attr('src', settings.logo).show();
                            }
                            if (settings.favicon) {
                                $('#favicon_preview').attr('src', settings.favicon).show();
                            }
                            $('#primary_color').val(settings.primary_color || '#007bff');
                            $('#secondary_color').val(settings.secondary_color || '#006cc');
                            $('#background_color').val(settings.background_color || '#000000');
                            $('#transport_head_mobile').val(settings.transport_head_mobile || '');
                            $('#fees_collection_mobile').val(settings.fees_collection_mobile || '');
                            $('#whatsapp_number').val(settings.whatsapp_number || '');
                            $('#calling_number').val(settings.calling_number || '');
                            $('#phpmailer_host').val(settings.phpmailer_host || '');
                            $('#phpmailer_username').val(settings.phpmailer_username || '');
                            $('#phpmailer_password').val(settings.phpmailer_password || '');
                            $('#phpmailer_port').val(settings.phpmailer_port || '');
                            $('#facebook_url').val(settings.facebook_url || '');
                            $('#twitter_url').val(settings.twitter_url || '');
                            $('#instagram_url').val(settings.instagram_url || '');
                            $('#linkedin_url').val(settings.linkedin_url || '');
                            $('#youtube_url').val(settings.youtube_url || '');
                            $('#google_analytics_id').val(settings.google_analytics_id || '');
                            $('#maintenance_mode').val(settings.maintenance_mode || 'disabled');
                            $('#status').val(settings.status || 'active');
                        } else {
                            console.warn('No settings data found in response');
                            Swal.fire({
                                icon: 'warning',
                                title: 'No Data',
                                text: 'No site settings found. Please save settings to create a record.'
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error loading settings:', xhr.responseText); // Debug: Log the error
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load site settings: ' + (xhr.responseJSON?.error || error)
                        });
                    }
                });
            }

            // Preview image before upload
            $('#logo').on('change', function(event) {
                const file = event.target.files[0];
                if (file) {
                    $('#logo_preview').attr('src', URL.createObjectURL(file)).show();
                }
            });

            $('#favicon').on('change', function(event) {
                const file = event.target.files[0];
                if (file) {
                    $('#favicon_preview').attr('src', URL.createObjectURL(file)).show();
                }
            });

            // Handle form submission
            $('#siteSettingsForm').on('submit', function(e) {
                e.preventDefault();

                if (!this.checkValidity()) {
                    this.reportValidity();
                    return;
                }

                const formData = new FormData(this); // Use the form directly to populate FormData
                formData.append('id', $('#settings_id').val());

                // Debug: Log FormData contents
                for (let [key, value] of formData.entries()) {
                    console.log(key, value);
                }

                $('#save-settings-btn').addClass('btn-loading');

                $.ajax({
                    url: 'api/site_settings_master.php',
                    type: 'POST', // Changed from PUT to POST
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Site settings updated successfully'
                        });
                        loadSettings(); // Reload settings to reflect changes
                    },
                    error: function(xhr, status, error) {
                        console.error('Error saving settings:', xhr.responseText); // Debug: Log the error
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to update site settings: ' + (xhr.responseJSON?.error || error)
                        });
                    },
                    complete: function() {
                        $('#save-settings-btn').removeClass('btn-loading');
                    }
                });
            });

            // Initial load
            loadSettings();
        });
    </script>
</body>
</html>