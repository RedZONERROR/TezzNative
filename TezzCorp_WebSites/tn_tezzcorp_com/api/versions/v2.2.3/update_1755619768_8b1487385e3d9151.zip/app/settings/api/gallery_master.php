<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class GalleryController {
    private $pdo;
    private $logger;
    private $uploadDir;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            file_put_contents(__DIR__ . '/logs/gallery_api.log', $logMessage, FILE_APPEND);
        };

        // Set upload directory
        $this->uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/uploads/gallery/';
        if (!file_exists($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
    }

    // Validate input data
    private function validateInput(array $data, bool $isUpdate = false): array {
        $this->logError('Validating input: ' . json_encode($data));
        $errors = [];
        $validData = [];

        // Define validation rules
        $fields = [
            'category' => ['type' => 'string', 'enum' => ['Photos', 'Events', 'Facilities', 'Achievements'], 'required' => !$isUpdate],
            'image' => ['type' => 'string', 'max_length' => 255, 'required' => false],
            'videos' => ['type' => 'string', 'max_length' => 255, 'required' => false],
        ];

        // Validate id separately for updates
        if ($isUpdate) {
            if (!isset($data['id']) || !filter_var($data['id'], FILTER_VALIDATE_INT) || $data['id'] <= 0) {
                $errors[] = "id must be a valid integer";
            } else {
                $validData['id'] = (int)$data['id'];
            }
        }

        // Validate other fields
        foreach ($fields as $field => $rules) {
            if (array_key_exists($field, $data)) {
                $value = $data[$field];

                // Handle NULL or empty strings for optional fields
                if ($value === '' && !$rules['required']) {
                    $value = null;
                }

                // Type checking
                if ($value !== null) {
                    switch ($rules['type']) {
                        case 'string':
                            if (!is_string($value)) {
                                $errors[] = "$field must be a string";
                            } elseif (isset($rules['max_length']) && strlen($value) > $rules['max_length']) {
                                $errors[] = "$field must not exceed {$rules['max_length']} characters";
                            }
                            break;
                    }

                    // Enum validation
                    if (isset($rules['enum']) && !in_array($value, $rules['enum'], true)) {
                        $errors[] = "$field must be one of: " . implode(', ', $rules['enum']);
                    }
                }

                $validData[$field] = $value;
            } elseif ($rules['required']) {
                $errors[] = "$field is required";
            }
        }

        if (!$isUpdate) {
            $hasImageFile = isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE;
            $hasVideoFile = isset($_FILES['videos']) && $_FILES['videos']['error'] !== UPLOAD_ERR_NO_FILE;
            $hasImageData = !empty($validData['image']);
            $hasVideoData = !empty($validData['videos']);
            
            if (!$hasImageFile && !$hasVideoFile && !$hasImageData && !$hasVideoData) {
                $errors[] = "At least one media file (image or video) is required";
            }
        }

        if ($errors) {
            $this->sendError(400, 'Validation failed: ' . implode('; ', $errors));
        }

        $this->logError('Validated data: ' . json_encode($validData));
        return $validData;
    }

    // Handle file upload
    private function handleFileUpload($fileKey, $existingPath = null) {
        if (!isset($_FILES[$fileKey]) || $_FILES[$fileKey]['error'] === UPLOAD_ERR_NO_FILE) {
            return $existingPath; // No new file uploaded, return existing path
        }

        $file = $_FILES[$fileKey];
        
        // Define allowed types based on file key
        if ($fileKey === 'image') {
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/svg+xml', 'image/webp'];
            $maxSize = 5 * 1024 * 1024; // 5MB for images
        } else if ($fileKey === 'videos') {
            $allowedTypes = ['video/mp4', 'video/avi', 'video/mov', 'video/wmv', 'video/webm'];
            $maxSize = 50 * 1024 * 1024; // 50MB for videos
        } else {
            $this->sendError(400, "Invalid file key: $fileKey");
        }

        if (!in_array($file['type'], $allowedTypes)) {
            $this->sendError(400, "Invalid file type for $fileKey. Allowed types: " . implode(', ', $allowedTypes));
        }
        if ($file['size'] > $maxSize) {
            $maxSizeMB = $maxSize / (1024 * 1024);
            $this->sendError(400, "File size for $fileKey exceeds {$maxSizeMB}MB");
        }

        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '_' . time() . '.' . $extension;
        $destination = $this->uploadDir . $filename;

        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            $this->logError("Failed to upload file for $fileKey");
            $this->sendError(500, "Failed to upload file for $fileKey");
        }

        // Delete old file if it exists
        if ($existingPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $existingPath)) {
            unlink($_SERVER['DOCUMENT_ROOT'] . $existingPath);
        }

        return '/uploads/gallery/' . $filename;
    }

    // Send JSON error response
    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['error' => $message]);
        exit;
    }

    // Send JSON success response
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    // Log error message
    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // Handle GET request
    public function get($request) {
        if (isset($request['id'])) {
            $id = filter_var($request['id'], FILTER_VALIDATE_INT);
            if (!$id) {
                $this->sendError(400, 'Invalid ID');
            }

            $stmt = $this->pdo->prepare("SELECT * FROM gallery WHERE id = ?");
            $stmt->execute([$id]);
            $entry = $stmt->fetch();

            if ($entry) {
                $this->sendSuccess(200, ['data' => [$entry]]);
            } else {
                $this->sendError(404, 'Gallery item not found');
            }
        } else {
            // Build query with optional category filter
            $sql = "SELECT * FROM gallery";
            $params = [];
            
            if (isset($request['category']) && !empty($request['category'])) {
                $sql .= " WHERE category = ?";
                $params[] = $request['category'];
            }
            
            $sql .= " ORDER BY id DESC";

            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            $entries = $stmt->fetchAll();

            $this->sendSuccess(200, ['data' => $entries]);
        }
    }

    // Handle POST request (create new gallery item)
    public function post() {
        // Check for _method field to determine actual method
        $method = isset($_POST['_method']) ? strtoupper($_POST['_method']) : 'POST';
        
        if ($method === 'PUT') {
            $this->put();
            return;
        } else if ($method === 'DELETE') {
            $this->delete();
            return;
        }

        // Parse FormData
        $data = $_POST;

        // Validate input
        $validData = $this->validateInput($data, false);

        // Handle file uploads
        $validData['image'] = $this->handleFileUpload('image');
        $validData['videos'] = $this->handleFileUpload('videos');

        // Prepare fields for insert
        $fields = array_keys($validData);
        $placeholders = array_fill(0, count($fields), '?');
        $values = array_values($validData);

        $sql = "INSERT INTO gallery (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $placeholders) . ")";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($values);
            $newId = $this->pdo->lastInsertId();
            $this->sendSuccess(201, ['message' => 'Gallery item created', 'id' => $newId]);
        } catch (PDOException $e) {
            $this->logError('Insert failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to create gallery item: ' . $e->getMessage());
        }
    }

    // Handle PUT request (update gallery item)
    public function put() {
        // Parse FormData
        $data = $_POST;

        if (!isset($data['id'])) {
            $this->sendError(400, 'ID is required for update');
        }

        // Get existing record
        $stmt = $this->pdo->prepare("SELECT * FROM gallery WHERE id = ?");
        $stmt->execute([$data['id']]);
        $existing = $stmt->fetch();

        if (!$existing) {
            $this->sendError(404, 'Gallery item not found');
        }

        // Validate input
        $validData = $this->validateInput($data, true);

        // Handle file uploads
        $validData['image'] = $this->handleFileUpload('image', $existing['image']);
        $validData['videos'] = $this->handleFileUpload('videos', $existing['videos']);

        // Prepare fields for update
        $fields = array_keys($validData);
        $updateFields = [];
        $values = [];
        foreach ($fields as $field) {
            if ($field !== 'id') {
                $updateFields[] = "$field = ?";
                $values[] = $validData[$field];
            }
        }
        $values[] = $validData['id'];

        $sql = "UPDATE gallery SET " . implode(', ', $updateFields) . " WHERE id = ?";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($values);
            $this->sendSuccess(200, ['message' => 'Gallery item updated']);
        } catch (PDOException $e) {
            $this->logError('Update failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to update gallery item: ' . $e->getMessage());
        }
    }

    // Handle DELETE request
    public function delete() {
        $id = isset($_POST['id']) ? $_POST['id'] : null;
        
        if (!$id || !filter_var($id, FILTER_VALIDATE_INT)) {
            $this->sendError(400, 'Valid ID is required');
        }

        // Get existing record to delete files
        $stmt = $this->pdo->prepare("SELECT * FROM gallery WHERE id = ?");
        $stmt->execute([$id]);
        $existing = $stmt->fetch();

        if (!$existing) {
            $this->sendError(404, 'Gallery item not found');
        }

        try {
            // Delete the record
            $stmt = $this->pdo->prepare("DELETE FROM gallery WHERE id = ?");
            $stmt->execute([$id]);

            // Delete associated files
            if ($existing['image'] && file_exists($_SERVER['DOCUMENT_ROOT'] . $existing['image'])) {
                unlink($_SERVER['DOCUMENT_ROOT'] . $existing['image']);
            }
            if ($existing['videos'] && file_exists($_SERVER['DOCUMENT_ROOT'] . $existing['videos'])) {
                unlink($_SERVER['DOCUMENT_ROOT'] . $existing['videos']);
            }

            $this->sendSuccess(200, ['message' => 'Gallery item deleted']);
        } catch (PDOException $e) {
            $this->logError('Delete failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to delete gallery item: ' . $e->getMessage());
        }
    }

    // Route requests
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];

        switch ($method) {
            case 'GET':
                $this->get($_GET);
                break;
            case 'POST':
                $this->post();
                break;
            default:
                $this->sendError(405, 'Method not allowed');
        }
    }
}

// Ensure logs directory exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Instantiate and handle request
$controller = new GalleryController();
$controller->handleRequest();
?>