<?php
// API to add a notification to the queue
header("Content-Type: application/json");
require_once 'db_config.php';

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Get JSON data from request body
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($data['uid']) || !isset($data['title']) || !isset($data['description'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing required fields"]);
    exit;
}

// Connect to database
$conn = getConnection();

// Prepare and bind parameters to prevent SQL injection
$stmt = $conn->prepare("INSERT INTO notification_queue (uid, title, description, doc_link, notification_type, is_sticky) 
                        VALUES (?, ?, ?, ?, ?, ?)");

// Set default values for optional parameters
$doc_link = isset($data['doc_link']) ? $data['doc_link'] : NULL;
$notification_type = isset($data['notification_type']) ? $data['notification_type'] : 'normal';
$is_sticky = isset($data['is_sticky']) ? ($data['is_sticky'] ? 1 : 0) : 0;

$stmt->bind_param("sssssi", 
    $data['uid'], 
    $data['title'], 
    $data['description'], 
    $doc_link,
    $notification_type,
    $is_sticky
);

// Execute the statement
if ($stmt->execute()) {
    $notification_id = $conn->insert_id;
    echo json_encode([
        "success" => true,
        "message" => "Notification added to queue",
        "notification_id" => $notification_id
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "error" => "Failed to add notification",
        "details" => $stmt->error
    ]);
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
