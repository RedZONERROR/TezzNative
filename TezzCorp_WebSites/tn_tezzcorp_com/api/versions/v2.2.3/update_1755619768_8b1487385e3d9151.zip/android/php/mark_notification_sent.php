<?php
// API to mark notifications as sent
header("Content-Type: application/json");
require_once 'db_config.php';

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Get JSON data from request body
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($data['notification_ids']) || !is_array($data['notification_ids']) || empty($data['notification_ids'])) {
    http_response_code(400);
    echo json_encode(["error" => "notification_ids array is required"]);
    exit;
}

// Connect to database
$conn = getConnection();

// Create placeholders for SQL IN clause
$placeholders = str_repeat('?,', count($data['notification_ids']) - 1) . '?';

// Prepare statement
$stmt = $conn->prepare("UPDATE notification_queue 
                        SET status = 'sent', sent_at = CURRENT_TIMESTAMP 
                        WHERE id IN ($placeholders) AND status = 'pending'");

// Bind parameters - need to bind each ID individually
$types = str_repeat('i', count($data['notification_ids']));
$stmt->bind_param($types, ...$data['notification_ids']);

// Execute the statement
if ($stmt->execute()) {
    $affected_rows = $stmt->affected_rows;
    echo json_encode([
        "success" => true,
        "message" => "Notifications marked as sent",
        "affected_count" => $affected_rows
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "error" => "Failed to update notification status",
        "details" => $stmt->error
    ]);
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
