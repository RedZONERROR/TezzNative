<?php
// Include database configuration
require_once 'db_config.php';

// Get database connection
$conn = getConnection();

// SQL to create notification_queue table
$sql = "CREATE TABLE IF NOT EXISTS notification_queue (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    uid VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    doc_link VARCHAR(255) DEFAULT NULL,
    notification_type ENUM('normal', 'silent', 'emergency') NOT NULL DEFAULT 'normal',
    is_sticky TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    sent_at TIMESTAMP NULL DEFAULT NULL,
    status ENUM('pending', 'sent', 'failed') NOT NULL DEFAULT 'pending',
    INDEX (uid),
    INDEX (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

// Execute query
if ($conn->query($sql) === TRUE) {
    echo "Table notification_queue created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

// Close connection
$conn->close();
?>
