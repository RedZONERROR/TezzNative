<?php
require_once 'db_config.php';

// Connect to database
$conn = getConnection();

// Form for adding test notifications
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Add Test Notification</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
            }
            h1 {
                color: #333;
            }
            label {
                display: block;
                margin-top: 10px;
                font-weight: bold;
            }
            input[type="text"], textarea, select {
                width: 100%;
                padding: 8px;
                margin-top: 5px;
                box-sizing: border-box;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
            input[type="checkbox"] {
                margin-top: 10px;
            }
            button {
                background-color: #4CAF50;
                color: white;
                padding: 10px 15px;
                margin-top: 20px;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }
            button:hover {
                background-color: #45a049;
            }
            .success {
                color: green;
                font-weight: bold;
                margin: 20px 0;
            }
            .error {
                color: red;
                font-weight: bold;
                margin: 20px 0;
            }
        </style>
    </head>
    <body>
        <h1>Add Test Notification</h1>
        
        <form method="post" action="">
            <label for="uid">User ID:</label>
            <input type="text" id="uid" name="uid" required>
            
            <label for="title">Notification Title:</label>
            <input type="text" id="title" name="title" required>
            
            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="4" required></textarea>
            
            <label for="doc_link">Document Link (optional):</label>
            <input type="text" id="doc_link" name="doc_link">
            
            <label for="notification_type">Notification Type:</label>
            <select id="notification_type" name="notification_type">
                <option value="normal">Normal</option>
                <option value="silent">Silent</option>
                <option value="emergency">Emergency</option>
            </select>
            
            <label>
                <input type="checkbox" id="is_sticky" name="is_sticky" value="1">
                Make notification sticky
            </label>
            
            <button type="submit">Add Notification</button>
        </form>
        
        <?php
        // Display list of existing notifications
        $stmt = $conn->prepare("SELECT * FROM notification_queue ORDER BY created_at DESC LIMIT 10");
        $stmt->execute();
        $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($notifications) > 0) {
            echo "<h2>Recent Notifications</h2>";
            echo "<table border='1' style='width:100%; border-collapse: collapse; margin-top: 20px;'>";
            echo "<tr><th>ID</th><th>User ID</th><th>Title</th><th>Type</th><th>Status</th><th>Created</th></tr>";
            
            foreach ($notifications as $note) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($note['id']) . "</td>";
                echo "<td>" . htmlspecialchars($note['uid']) . "</td>";
                echo "<td>" . htmlspecialchars($note['title']) . "</td>";
                echo "<td>" . htmlspecialchars($note['notification_type']) . "</td>";
                echo "<td>" . htmlspecialchars($note['status']) . "</td>";
                echo "<td>" . htmlspecialchars($note['created_at']) . "</td>";
                echo "</tr>";
            }
            
            echo "</table>";
        }
        ?>
    </body>
    </html>
    <?php
    exit;
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate inputs
        $uid = isset($_POST['uid']) ? trim($_POST['uid']) : '';
        $title = isset($_POST['title']) ? trim($_POST['title']) : '';
        $description = isset($_POST['description']) ? trim($_POST['description']) : '';
        $doc_link = isset($_POST['doc_link']) ? trim($_POST['doc_link']) : '';
        $notification_type = isset($_POST['notification_type']) ? trim($_POST['notification_type']) : 'normal';
        $is_sticky = isset($_POST['is_sticky']) ? 1 : 0;
        
        if (empty($uid) || empty($title) || empty($description)) {
            throw new Exception("User ID, title and description are required.");
        }
        
        // Validate notification type
        if (!in_array($notification_type, ['normal', 'silent', 'emergency'])) {
            $notification_type = 'normal'; // Default to normal if invalid
        }
        
        // Insert notification
        $stmt = $conn->prepare("INSERT INTO notification_queue 
                                (uid, title, description, doc_link, notification_type, is_sticky, created_at, status) 
                                VALUES (?, ?, ?, ?, ?, ?, NOW(), 'pending')");
        
        $stmt->execute([$uid, $title, $description, $doc_link, $notification_type, $is_sticky]);
        
        // Redirect to prevent form resubmission
        header("Location: test_add_notification.php?success=1");
        exit;
    } catch (Exception $e) {
        echo '<!DOCTYPE html>
        <html>
        <head>
            <title>Error</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
                body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
                .error { color: red; font-weight: bold; margin: 20px 0; }
                a { display: inline-block; margin-top: 20px; color: #0066cc; text-decoration: none; }
                a:hover { text-decoration: underline; }
            </style>
        </head>
        <body>
            <div class="error">Error: ' . htmlspecialchars($e->getMessage()) . '</div>
            <a href="test_add_notification.php">← Back to form</a>
        </body>
        </html>';
    }
}
?>
