<?php
// API to get pending notifications for a specific user
header("Content-Type: application/json");
require_once 'db_config.php';

// Check if request is GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Get UID from request parameters
$uid = isset($_GET['uid']) ? $_GET['uid'] : null;

if (!$uid) {
    http_response_code(400);
    echo json_encode(["error" => "UID parameter is required"]);
    exit;
}

// Connect to database
$conn = getConnection();

// Prepare and execute query
$stmt = $conn->prepare("SELECT id, title, description, doc_link, notification_type, is_sticky, created_at 
                        FROM notification_queue 
                        WHERE uid = ? AND status = 'pending'
                        ORDER BY created_at DESC");
$stmt->bind_param("s", $uid);
$stmt->execute();

// Get result
$result = $stmt->get_result();
$notifications = [];

while ($row = $result->fetch_assoc()) {
    // Format boolean fields
    $row['is_sticky'] = (bool)$row['is_sticky'];
    $notifications[] = $row;
}

// Return response
echo json_encode([
    "success" => true,
    "count" => count($notifications),
    "notifications" => $notifications
]);

// Close statement and connection
$stmt->close();
$conn->close();
?>
