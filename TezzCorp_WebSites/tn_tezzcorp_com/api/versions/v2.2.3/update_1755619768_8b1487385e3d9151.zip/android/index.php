<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to handle session tokens
class SessionManager {
    private $pdo;
    private $logger;

    public function __construct(PDO $pdo, callable $logger) {
        $this->pdo = $pdo;
        $this->logger = $logger;
    }

    public function createSession($user_id, $user_type) {
        try {
            $session_token = bin2hex(random_bytes(32));
            $expires_at = date('Y-m-d H:i:s', strtotime('+7 days'));
            $stmt = $this->pdo->prepare(
                'INSERT INTO sessions (user_id, user_type, session_token, expires_at) 
                VALUES (:user_id, :user_type, :session_token, :expires_at)'
            );
            $stmt->execute([
                ':user_id' => $user_id,
                ':user_type' => $user_type,
                ':session_token' => $session_token,
                ':expires_at' => $expires_at
            ]);
            return $session_token;
        } catch (PDOException $e) {
            ($this->logger)('Session creation failed: ' . $e->getMessage());
            throw new Exception('Failed to create session');
        }
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            ($this->logger)('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// LoginController class to handle login logic
class LoginController {
    private $pdo;
    private $logger;
    private $sessionManager;

    public function __construct(PDO $pdo, callable $logger) {
        $this->pdo = $pdo;
        $this->logger = $logger;
        $this->sessionManager = new SessionManager($pdo, $logger);
    }

    private function logError($message) {
        ($this->logger)($message);
    }

    public function handleLogin() {
        $alert = ['message' => '', 'type' => ''];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $user_type = isset($_POST['user_type']) ? trim($_POST['user_type']) : '';
            if (empty($user_type) || !in_array($user_type, ['student', 'teacher'])) {
                return ['message' => 'Invalid user type', 'type' => 'error'];
            }

            if ($user_type === 'student') {
                return $this->handleStudentLogin();
            } else {
                return $this->handleTeacherLogin();
            }
        }

        return $alert;
    }

    private function handleStudentLogin() {
        $mobile_number = isset($_POST['registration_number']) ? trim($_POST['registration_number']) : '';
        $dob = isset($_POST['dob']) ? trim($_POST['dob']) : '';

        if (empty($mobile_number) || empty($dob)) {
            return ['message' => 'Mobile number and date of birth are required', 'type' => 'error'];
        }

        if (!preg_match('/^\d{10}$/', $mobile_number)) {
            return ['message' => 'Invalid mobile number format', 'type' => 'error'];
        }

        if (!DateTime::createFromFormat('Y-m-d', $dob)) {
            return ['message' => 'Invalid date of birth format', 'type' => 'error'];
        }

        try {
            $stmt = $this->pdo->prepare(
                'SELECT id, uid, full_name FROM students 
                WHERE mobile_number = :mobile_number 
                AND date_of_birth = :dob 
                AND status = "active"'
            );
            $stmt->execute([
                ':mobile_number' => $mobile_number,
                ':dob' => $dob
            ]);
            $student = $stmt->fetch();

            if ($student) {
                $session_token = $this->sessionManager->createSession($student['id'], 'student');
                $_SESSION['user_id'] = $student['id'];
                $_SESSION['user_type'] = 'student';
                $_SESSION['user_name'] = $student['full_name'];
                $_SESSION['session_token'] = $session_token;

                $cookie_duration = isset($_POST['remember']) ? time() + (30 * 24 * 60 * 60) : 0;
                setcookie('session_token', $session_token, $cookie_duration, '/', '', true, true);
                setcookie('android_uid', $student['uid'], $cookie_duration, '/', '', false, false);

                header("Location: student/index.php");
                exit;
            } else {
                return ['message' => 'Invalid mobile number or date of birth', 'type' => 'error'];
            }
        } catch (PDOException $e) {
            $this->logError('Student login failed: ' . $e->getMessage());
            return ['message' => 'Database error occurred', 'type' => 'error'];
        }
    }

    private function handleTeacherLogin() {
        $email = isset($_POST['email']) ? trim($_POST['email']) : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';

        if (empty($email) || empty($password)) {
            return ['message' => 'Email and password are required', 'type' => 'error'];
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['message' => 'Invalid email format', 'type' => 'error'];
        }

        try {
            $stmt = $this->pdo->prepare(
                'SELECT id, name, password 
                FROM staff 
                WHERE email = :email 
                AND role IN ("Super Admin", "Admin", "Teacher", "Principal", "Support Staff") 
                AND status = "Active"'
            );
            $stmt->execute([':email' => $email]);
            $teacher = $stmt->fetch();

            if ($teacher && password_verify($password, $teacher['password'])) {
                $session_token = $this->sessionManager->createSession($teacher['id'], 'teacher');
                $_SESSION['user_id'] = $teacher['id'];
                $_SESSION['user_type'] = 'teacher';
                $_SESSION['user_name'] = $teacher['name'];
                $_SESSION['session_token'] = $session_token;

                $cookie_duration = isset($_POST['remember']) ? time() + (30 * 24 * 60 * 60) : 0;
                setcookie('session_token', $session_token, $cookie_duration, '/', '', true, true);

                header("Location: staff/index.php");
                exit;
            } else {
                return ['message' => 'Invalid email or password', 'type' => 'error'];
            }
        } catch (PDOException $e) {
            $this->logError('Teacher login failed: ' . $e->getMessage());
            return ['message' => 'Database error occurred', 'type' => 'error'];
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    $alert = ['message' => 'Database connection failed', 'type' => 'error'];
}

// Initialize logger
$logger = function ($message) {
    $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
    file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/logs/api.log', $logMessage, FILE_APPEND);
};

// Check for existing session or cookie
$sessionManager = new SessionManager($pdo, $logger);
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        try {
            $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
            $stmt->execute([':uid' => $_COOKIE['android_uid']]);
            $user = $stmt->fetch();
            
            if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_type'] = 'student';
                $_SESSION['user_name'] = $user['full_name'];
                $_SESSION['session_token'] = $_COOKIE['session_token'];
                header("Location: student/index.php");
                exit;
            }
        } catch (PDOException $e) {
            ($logger)('Cookie session validation failed: ' . $e->getMessage());
        }
    }
} else {
    if ($sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
        header("Location: " . ($_SESSION['user_type'] === 'student' ? 'student/index.php' : 'staff/index.php'));
        exit;
    } else {
        session_destroy();
        setcookie('session_token', '', time() - 3600, '/', '', true, true);
        setcookie('android_uid', '', time() - 3600, '/', '', false, false);
    }
}

// Handle login
$alert = ['message' => '', 'type' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $loginController = new LoginController($pdo, $logger);
    $alert = $loginController->handleLogin();
}

// Fetch site settings
try {
    $stmt = $pdo->prepare('SELECT school_name, logo, tagline, facebook_url, twitter_url, instagram_url, linkedin_url FROM site_settings WHERE id = 1');
    $stmt->execute();
    $settings = $stmt->fetch();
    
    if (!$settings) {
        $settings = [
            'school_name' => 'EduConnect',
            'tagline' => 'Learn, Connect, Succeed',
            'logo' => $_SERVER['DOCUMENT_ROOT'] . '/android/favicon.svg',
            'facebook_url' => '#',
            'twitter_url' => '#',
            'instagram_url' => '#',
            'linkedin_url' => '#'
        ];
    }
} catch (PDOException $e) {
    error_log('Failed to fetch site settings: ' . $e->getMessage());
    $settings = [
        'school_name' => 'EduConnect',
        'facebook_url' => '#',
        'twitter_url' => '#',
        'instagram_url' => '#',
        'linkedin_url' => '#'
    ];
}

$school_name = htmlspecialchars($settings['school_name']);
$tagline = htmlspecialchars($settings['tagline']);
$logo = 'https://' . $_SERVER['HTTP_HOST'] . $settings['logo'];
$facebook_url = htmlspecialchars($settings['facebook_url']);
$twitter_url = htmlspecialchars($settings['twitter_url']);
$instagram_url = htmlspecialchars($settings['instagram_url']);
$linkedin_url = htmlspecialchars($settings['linkedin_url']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $school_name; ?> - Login</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .login-header {
            background-color: var(--primary-color);
            color: white;
            padding: 30px 20px;
            text-align: center;
            border-bottom-left-radius: 30px;
            border-bottom-right-radius: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        
        .app-logo {
            width: 80px;
            height: 80px;
            border-radius: 20px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        
        .app-logo i {
            font-size: 40px;
            color: var(--primary-color);
        }
        
        .app-name {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .app-slogan {
            font-size: 16px;
            opacity: 0.9;
        }
        
        .login-container {
            flex: 1;
            padding: 30px 20px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            max-width: 450px;
            margin: 0 auto;
            width: 100%;
        }
        
        .login-title {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .input-group {
            margin-bottom: 20px;
        }
        
        .input-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 15px;
        }
        
        .input-field {
            width: 100%;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 16px;
            transition: var(--transition);
            background-color: white;
        }
        
        .input-field:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(0, 85, 164, 0.2);
            outline: none;
        }
        
        .input-with-icon {
            position: relative;
        }
        
        .input-with-icon .input-field {
            padding-left: 45px;
        }
        
        .input-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--light-text);
        }
        
        .forgot-password {
            text-align: right;
            margin-bottom: 25px;
        }
        
        .forgot-password a {
            color: var(--primary-color);
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
        }
        
        .login-button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            padding: 15px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            width: 100%;
            margin-bottom: 20px;
        }
        
        .login-button:hover {
            background-color: #004a8f;
        }
        
        .login-divider {
            display: flex;
            align-items: center;
            margin: 20px 0;
        }
        
        .login-divider::before,
        .login-divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background-color: #ddd;
        }
        
        .login-divider-text {
            padding: 0 15px;
            color: var(--light-text);
            font-size: 14px;
        }
        
        .social-login {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .social-button {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid #ddd;
            background-color: white;
            color: #333;
            font-size: 20px;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .social-button:hover {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }
        
        .social-button.google {
            color: #DB4437;
        }
        
        .social-button.facebook {
            color: #4267B2;
        }
        
        .social-button.apple {
            color: #000;
        }
        
        .register-link {
            text-align: center;
            font-size: 15px;
        }
        
        .register-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
        }
        
        .user-type-toggle {
            display: flex;
            background-color: #eee;
            border-radius: 30px;
            margin-bottom: 25px;
            padding: 5px;
        }
        
        .user-type-option {
            flex: 1;
            text-align: center;
            padding: 10px;
            cursor: pointer;
            border-radius: 25px;
            font-weight: 500;
            transition: var(--transition);
        }
        
        .user-type-option.active {
            background-color: var(--primary-color);
            color: white;
        }
        
        .alert {
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            display: <?php echo $alert['message'] ? 'block' : 'none'; ?>;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        .ripple {
            position: relative;
            overflow: hidden;
        }
        
        .ripple:after {
            content: "";
            display: block;
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            pointer-events: none;
            background-image: radial-gradient(circle, rgba(255, 255, 255, 0.3) 10%, transparent 10.01%);
            background-repeat: no-repeat;
            background-position: 50%;
            transform: scale(10, 10);
            opacity: 0;
            transition: transform .5s, opacity 1s;
        }
        
        .ripple:active:after {
            transform: scale(0, 0);
            opacity: .3;
            transition: 0s;
        }
        
        @media (max-width: 480px) {
            .login-header {
                padding: 20px;
            }
            
            .app-logo {
                width: 70px;
                height: 70px;
            }
            
            .app-name {
                font-size: 24px;
            }
            
            .app-slogan {
                font-size: 14px;
            }
            
            .login-title {
                font-size: 22px;
                margin-bottom: 25px;
            }
            
            .input-field {
                padding: 12px;
                font-size: 15px;
            }
        }
        
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Logging in...</div>
    </div>

    <div class="login-header">
        <div class="app-logo">
            <img style="height: 110px;" src="<?php echo $logo; ?>" alt="<?php echo $school_name; ?>">
        </div>
        <div class="app-name"><?php echo $school_name; ?></div>
        <div class="app-slogan"><?php echo $tagline; ?></div>
    </div>
    
    <div class="login-container">
        <div class="login-title">Welcome Back!</div>
        
        <div class="user-type-toggle">
            <div class="user-type-option <?php echo (!isset($_POST['user_type']) || $_POST['user_type'] === 'student') ? 'active' : ''; ?>" data-type="student">Student/Guardian</div>
            <div class="user-type-option <?php echo (isset($_POST['user_type']) && $_POST['user_type'] === 'teacher') ? 'active' : ''; ?>" data-type="teacher">Teacher</div>
        </div>
        
        <div class="alert alert-<?php echo htmlspecialchars($alert['type']); ?>" id="alert"><?php echo htmlspecialchars($alert['message']); ?></div>
        
        <form id="loginForm" method="POST" action="index.php">
            <input type="hidden" id="userType" name="user_type" value="<?php echo isset($_POST['user_type']) ? htmlspecialchars($_POST['user_type']) : 'student'; ?>">
            
            <!-- Student login fields -->
            <div id="studentFields" style="<?php echo (isset($_POST['user_type']) && $_POST['user_type'] === 'teacher') ? 'display: none;' : 'display: block;'; ?>">
                <div class="input-group">
                    <label for="registrationNumber" class="input-label">Mobile Number</label>
                    <div class="input-with-icon">
                        <i class="fas fa-id-card input-icon"></i>
                        <input type="number" id="registrationNumber" name="registration_number" class="input-field" placeholder="Registered mobile number" value="<?php echo isset($_POST['registration_number']) ? htmlspecialchars($_POST['registration_number']) : ''; ?>">
                    </div>
                </div>
                
                <div class="input-group">
                    <label for="dob" class="input-label">Date of Birth</label>
                    <div class="input-with-icon">
                        <i class="fas fa-calendar-alt input-icon"></i>
                        <input type="date" id="dob" name="dob" class="input-field" value="<?php echo isset($_POST['dob']) ? htmlspecialchars($_POST['dob']) : ''; ?>">
                    </div>
                </div>
            </div>
            
            <!-- Teacher login fields -->
            <div id="teacherFields" style="<?php echo (isset($_POST['user_type']) && $_POST['user_type'] === 'teacher') ? 'display: block;' : 'display: none;'; ?>">
                <div class="input-group">
                    <label for="email" class="input-label">Registered Email</label>
                    <div class="input-with-icon">
                        <i class="fas fa-user input-icon"></i>
                        <input type="email" id="email" name="email" class="input-field" placeholder="Enter your email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                    </div>
                </div>
                
                <div class="input-group">
                    <label for="password" class="input-label">Password</label>
                    <div class="input-with-icon">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" id="password" name="password" class="input-field" placeholder="Enter your password">
                    </div>
                </div>
            </div>
            
            <div class="input-group">
                <label class="checkbox-container">
                    <input type="checkbox" id="remember" name="remember" <?php echo isset($_POST['remember']) ? 'checked' : ''; ?>>
                    <span class="checkmark"></span>
                    Remember me
                </label>
            </div>
            
            <div style="<?php echo (isset($_POST['user_type']) && $_POST['user_type'] === 'teacher') ? 'display: block;' : 'display: none;'; ?>" class="forgot-password" id="forgot-password">
                <a href="forgot_password.php">Forgot Password?</a>
            </div>
            
            <button type="submit" class="login-button ripple">Login</button>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loader = document.getElementById('loader');
            const alertBox = document.getElementById('alert');
            
            // Hide loader after page load
            loader.style.opacity = '0';
            setTimeout(() => {
                loader.style.display = 'none';
                loader.style.opacity = '1';
            }, 300);
            
            // Prevent zooming on double tap
            document.addEventListener('dblclick', function(e) {
                e.preventDefault();
            });
            
            // User type toggle
            const userTypeOptions = document.querySelectorAll('.user-type-option');
            const userTypeInput = document.getElementById('userType');
            const studentFields = document.getElementById('studentFields');
            const teacherFields = document.getElementById('teacherFields');
            const forgotPassword = document.getElementById('forgot-password');
            
            userTypeOptions.forEach(option => {
                option.addEventListener('click', function() {
                    userTypeOptions.forEach(opt => opt.classList.remove('active'));
                    this.classList.add('active');
                    const userType = this.getAttribute('data-type');
                    userTypeInput.value = userType;
                    if (userType === 'student') {
                        studentFields.style.display = 'block';
                        teacherFields.style.display = 'none';
                        forgotPassword.style.display = 'none';
                    } else {
                        studentFields.style.display = 'none';
                        teacherFields.style.display = 'block';
                        forgotPassword.style.display = 'block';
                    }
                });
            });
            
            // Show loader on form submit
            document.getElementById('loginForm').addEventListener('submit', function() {
                loader.style.display = 'flex';
            });
            
            // Hide alert after 5 seconds if present
            if (alertBox.textContent.trim()) {
                setTimeout(() => {
                    alertBox.style.display = 'none';
                }, 5000);
            }
        });
    </script>
</body>
</html>