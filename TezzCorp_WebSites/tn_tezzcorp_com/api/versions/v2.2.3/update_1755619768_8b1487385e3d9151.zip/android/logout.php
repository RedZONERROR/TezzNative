<?php
// Start session
session_start();

// Include database connection
include 'conn.php';

// Set header to return JSON
header('Content-Type: application/json');

// Get session data from multiple sources
$sessionToken = '';
$userId = '';
$userType = '';

// Check POST parameters first (for form submissions and AJAX)
if (isset($_POST['session_token'])) {
    $sessionToken = $_POST['session_token'];
    $userId = isset($_POST['user_id']) ? $_POST['user_id'] : '';
    $userType = isset($_POST['user_type']) ? $_POST['user_type'] : '';
}

// Check JSON POST data (for fetch API)
if (empty($sessionToken)) {
    $postData = json_decode(file_get_contents('php://input'), true);
    if (isset($postData['session_token'])) {
        $sessionToken = $postData['session_token'];
        $userId = isset($postData['user_id']) ? $postData['user_id'] : '';
        $userType = isset($postData['user_type']) ? $postData['user_type'] : '';
    }
}

// If still empty, check cookies
if (empty($sessionToken) && isset($_COOKIE['session_token'])) {
    $sessionToken = $_COOKIE['session_token'];
    $userId = isset($_COOKIE['user_id']) ? $_COOKIE['user_id'] : '';
    $userType = isset($_COOKIE['user_type']) ? $_COOKIE['user_type'] : '';
}

// If still empty, check session
if (empty($sessionToken) && isset($_SESSION['session_token'])) {
    $sessionToken = $_SESSION['session_token'];
    $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';
    $userType = isset($_SESSION['user_type']) ? $_SESSION['user_type'] : '';
}

try {
    // Delete session from database if we have the necessary data
    if (!empty($sessionToken) && !empty($userId)) {
        $query = "DELETE FROM user_sessions WHERE user_id = ? AND session_token = ?";
        $stmt = $con->prepare($query);
        
        // If userType is provided, include it in the query
        if (!empty($userType)) {
            $query = "DELETE FROM user_sessions WHERE user_id = ? AND user_type = ? AND session_token = ?";
            $stmt = $con->prepare($query);
            $stmt->bind_param("iss", $userId, $userType, $sessionToken);
        } else {
            $stmt->bind_param("is", $userId, $sessionToken);
        }
        
        $stmt->execute();
        $stmt->close();
    }
    
    // Clear all PHP session data
    $_SESSION = array();
    
    // Destroy the session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // Destroy the session
    session_destroy();
    
    // Clear all cookies with various path options to ensure they're removed
    $paths = ['/', '/app', ''];
    foreach ($paths as $path) {
        setcookie('session_token', '', time() - 3600, $path);
        setcookie('user_id', '', time() - 3600, $path);
        setcookie('user_type', '', time() - 3600, $path);
        setcookie('user_name', '', time() - 3600, $path);
    }
    
    // Return success response with client-side script to clear localStorage and sessionStorage
    echo json_encode([
        'success' => true,
        'message' => 'Logged out successfully',
        'clearScript' => "
            // Clear sessionStorage
            sessionStorage.removeItem('user_id');
            sessionStorage.removeItem('user_type');
            sessionStorage.removeItem('user_name');
            sessionStorage.removeItem('session_token');
            
            // Clear localStorage
            localStorage.removeItem('user_id');
            localStorage.removeItem('user_type');
            localStorage.removeItem('user_name');
            localStorage.removeItem('session_token');
        "
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred: ' . $e->getMessage()
    ]);
}

// Close connection
$con->close();
?>