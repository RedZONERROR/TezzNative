<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    $alert_message = 'Database connection failed. Please try again later.';
    $alert_type = 'error';
}

// Initialize variables
$alert_message = '';
$alert_type = '';
$token_valid = false;
$token = isset($_GET['token']) ? trim($_GET['token']) : '';

// Validate token
if ($token) {
    try {
        $domain = $_SERVER['HTTP_HOST'];
        $stmt = $pdo->prepare(
            'SELECT user_id, expires_at 
             FROM password_reset_tokens 
             WHERE token = :token 
             AND domain = :domain 
             AND expires_at > NOW()'
        );
        $stmt->execute([
            ':token' => $token,
            ':domain' => $domain
        ]);
        $reset_data = $stmt->fetch();

        if ($reset_data) {
            $token_valid = true;
        } else {
            $alert_message = 'Invalid or expired reset link.';
            $alert_type = 'error';
        }
    } catch (PDOException $e) {
        error_log('Token validation error: ' . $e->getMessage());
        $alert_message = 'An error occurred. Please try again.';
        $alert_type = 'error';
    }
} else {
    $alert_message = 'No reset token provided.';
    $alert_type = 'error';
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $token_valid) {
    try {
        $new_password = isset($_POST['new_password']) ? trim($_POST['new_password']) : '';
        $confirm_password = isset($_POST['confirm_password']) ? trim($_POST['confirm_password']) : '';

        if (empty($new_password) || empty($confirm_password)) {
            throw new Exception('Please fill in all fields.');
        }

        if ($new_password !== $confirm_password) {
            throw new Exception('Passwords do not match.');
        }

        if (strlen($new_password) < 8) {
            throw new Exception('Password must be at least 8 characters long.');
        }

        // Get user data from password_reset_tokens
        $stmt = $pdo->prepare(
            'SELECT user_id 
             FROM password_reset_tokens 
             WHERE token = :token 
             AND domain = :domain 
             AND expires_at > NOW()'
        );
        $stmt->execute([
            ':token' => $token,
            ':domain' => $_SERVER['HTTP_HOST']
        ]);
        $reset_data = $stmt->fetch();

        if (!$reset_data) {
            throw new Exception('Invalid or expired reset link.');
        }

        // Update password in staff table
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare(
            'UPDATE staff 
             SET password = :password 
             WHERE id = :user_id'
        );
        $stmt->execute([
            ':password' => $hashed_password,
            ':user_id' => $reset_data['user_id']
        ]);

        // Delete used token
        $stmt = $pdo->prepare(
            'DELETE FROM password_reset_tokens 
             WHERE token = :token 
             AND domain = :domain'
        );
        $stmt->execute([
            ':token' => $token,
            ':domain' => $_SERVER['HTTP_HOST']
        ]);

        $alert_message = 'Password reset successfully! You can now login with your new password.';
        $alert_type = 'success';
    } catch (Exception $e) {
        error_log('Password reset error: ' . $e->getMessage());
        $alert_message = $e->getMessage();
        $alert_type = 'error';
    }
}

// Fetch site settings
try {
    $stmt = $pdo->prepare('SELECT school_name, logo, tagline, facebook_url, twitter_url, instagram_url, linkedin_url FROM site_settings WHERE id = 1');
    $stmt->execute();
    $settings = $stmt->fetch();
    
    if (!$settings) {
        $settings = [
            'school_name' => 'EduConnect',
            'tagline' => 'Learn, Connect, Succeed',
            'logo' => $_SERVER['DOCUMENT_ROOT'] . '/android/favicon.svg',
            'facebook_url' => '#',
            'twitter_url' => '#',
            'instagram_url' => '#',
            'linkedin_url' => '#'
        ];
    }
} catch (PDOException $e) {
    error_log('Failed to fetch site settings: ' . $e->getMessage());
    $settings = [
        'school_name' => 'EduConnect',
        'facebook_url' => '#',
        'twitter_url' => '#',
        'instagram_url' => '#',
        'linkedin_url' => '#'
    ];
}

$school_name = htmlspecialchars($settings['school_name']);
$tagline = htmlspecialchars($settings['tagline']);
$logo = 'https://' . $_SERVER['HTTP_HOST'] . $settings['logo'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>EduConnect - Reset Password</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .login-header {
            background-color: var(--primary-color);
            color: white;
            padding: 30px 20px;
            text-align: center;
            border-bottom-left-radius: 30px;
            border-bottom-right-radius: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .app-logo {
            width: 80px;
            height: 80px;
            background-color: white;
            border-radius: 20px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .app-logo i {
            font-size: 40px;
            color: var(--primary-color);
        }

        .app-name {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .app-slogan {
            font-size: 16px;
            opacity: 0.9;
        }

        .login-container {
            flex: 1;
            padding: 30px 20px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            max-width: 450px;
            margin: 0 auto;
            width: 100%;
        }

        .login-title {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 30px;
            text-align: center;
        }

        .input-group {
            margin-bottom: 20px;
        }

        .input-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 15px;
        }

        .input-field {
            width: 100%;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 16px;
            transition: var(--transition);
            background-color: white;
        }

        .input-field:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(0, 85, 164, 0.2);
            outline: none;
        }

        .input-with-icon {
            position: relative;
        }

        .input-with-icon .input-field {
            padding-left: 45px;
        }

        .input-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--light-text);
        }

        .login-button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            padding: 15px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            width: 100%;
            margin-bottom: 20px;
        }

        .login-button:hover {
            background-color: #004a8f;
        }

        .register-link {
            text-align: center;
            font-size: 15px;
        }

        .register-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
        }

        .alert {
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            display: none;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
            display: none;
        }

        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }

        @media (max-width: 480px) {
            .login-title {
                font-size: 22px;
            }
            
            .input-field {
                padding: 12px;
                font-size: 15px;
            }
            
            .login-button {
                padding: 12px;
                font-size: 15px;
            }
            
            .register-link {
                font-size: 14px;
            }
        }

        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="login-header">
        <div class="app-logo">
            <img style="height: 110px;" src="<?php echo $logo; ?>" alt="<?php echo $school_name; ?>">
        </div>
        <div class="app-name"><?php echo $school_name; ?></div>
        <div class="app-slogan"><?php echo $tagline; ?></div>
    </div>

    <div style="margin-top: -150px;" class="login-container">
        <div class="login-title">Reset Your Password</div>

        <?php if ($alert_message): ?>
            <div class="alert alert-<?php echo $alert_type; ?>" style="display: block;">
                <?php echo htmlspecialchars($alert_message); ?>
            </div>
        <?php else: ?>
            <div class="alert" id="alert" style="display: none;"></div>
        <?php endif; ?>

        <?php if ($token_valid): ?>
        <form method="POST" id="resetPasswordForm">
            <div class="input-group">
                <label for="newPassword" class="input-label">New Password</label>
                <div class="input-with-icon">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" id="newPassword" name="new_password" class="input-field" placeholder="Enter your new password" required>
                </div>
            </div>

            <div class="input-group">
                <label for="confirmPassword" class="input-label">Confirm Password</label>
                <div class="input-with-icon">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" id="confirmPassword" name="confirm_password" class="input-field" placeholder="Confirm your new password" required>
                </div>
            </div>

            <button type="submit" class="login-button">Reset Password</button>
            <div class="register-link">
                <a href="login.php">Back to Login</a>
            </div>
        </form>
        <?php else: ?>
        <div class="register-link">
            <a href="forgot_password.php">Request a new reset link</a>
        </div>
        <?php endif; ?>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loader = document.getElementById('loader');
            const alertBox = document.getElementById('alert');

            document.addEventListener('dblclick', function(e) {
                e.preventDefault();
            });

            if (alertBox && alertBox.style.display === 'block') {
                setTimeout(() => {
                    alertBox.style.display = 'none';
                }, 5000);
            }

            const resetPasswordForm = document.getElementById('resetPasswordForm');
            if (resetPasswordForm) {
                resetPasswordForm.addEventListener('submit', function(e) {
                    const newPassword = document.getElementById('newPassword').value;
                    const confirmPassword = document.getElementById('confirmPassword').value;

                    if (newPassword !== confirmPassword) {
                        e.preventDefault();
                        showAlert('Passwords do not match', 'error');
                    } else if (newPassword.length < 8) {
                        e.preventDefault();
                        showAlert('Password must be at least 8 characters long', 'error');
                    } else {
                        loader.style.display = 'flex';
                    }
                });
            }

            function showAlert(message, type) {
                alertBox.textContent = message;
                alertBox.className = 'alert alert-' + type;
                alertBox.style.display = 'block';

                setTimeout(() => {
                    alertBox.style.display = 'none';
                }, 5000);
            }
        });
    </script>
</body>
</html>