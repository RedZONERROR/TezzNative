<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch site settings
try {
    $stmt = $pdo->prepare('SELECT school_name, facebook_url, twitter_url, instagram_url, linkedin_url FROM site_settings WHERE id = 1');
    $stmt->execute();
    $settings = $stmt->fetch();
    
    if (!$settings) {
        $settings = [
            'school_name' => 'EduConnect',
            'facebook_url' => '#',
            'twitter_url' => '#',
            'instagram_url' => '#',
            'linkedin_url' => '#'
        ];
    }
} catch (PDOException $e) {
    error_log('Failed to fetch site settings: ' . $e->getMessage());
    $settings = [
        'school_name' => 'EduConnect',
        'facebook_url' => '#',
        'twitter_url' => '#',
        'instagram_url' => '#',
        'linkedin_url' => '#'
    ];
}

$school_name = htmlspecialchars($settings['school_name']);
$facebook_url = htmlspecialchars($settings['facebook_url']);
$twitter_url = htmlspecialchars($settings['twitter_url']);
$instagram_url = htmlspecialchars($settings['instagram_url']);
$linkedin_url = htmlspecialchars($settings['linkedin_url']);

// Handle news filter
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$valid_filters = ['all', 'academic', 'sports', 'events', 'announcements'];
if (!in_array($filter, $valid_filters)) {
    $filter = 'all';
}

// Fetch news
$news_items = [];
try {
    $query = 'SELECT id, title, excerpt, image, category, published_date, author 
              FROM news 
              WHERE status = "published"';
    $params = [];
    
    if ($filter !== 'all') {
        $query .= ' AND category = :category';
        $params[':category'] = $filter;
    }
    
    $query .= ' ORDER BY published_date DESC';
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $news_items = $stmt->fetchAll();
    
    // Format the date
    foreach ($news_items as &$news) {
        $news['published_date'] = date('F d, Y', strtotime($news['published_date']));
    }
} catch (PDOException $e) {
    error_log('Failed to fetch news: ' . $e->getMessage());
    $news_items = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $school_name; ?> - News</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }
        
        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .news-filter {
            display: flex;
            overflow-x: auto;
            gap: 10px;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        
        .filter-button {
            background-color: var(--secondary-color);
            border: none;
            border-radius: 20px;
            padding: 8px 15px;
            font-size: 14px;
            font-weight: 500;
            color: var(--text-color);
            cursor: pointer;
            white-space: nowrap;
            transition: var(--transition);
        }
        
        .filter-button.active {
            background-color: var(--primary-color);
            color: white;
        }
        
        .news-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .news-item {
            background-color: white;
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: var(--transition);
            cursor: pointer;
        }
        
        .news-item:hover {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }
        
        .news-image {
            width: 100%;
            height: 180px;
            object-fit: cover;
        }
        
        .news-content {
            padding: 15px;
        }
        
        .news-category {
            display: inline-block;
            font-size: 12px;
            font-weight: 500;
            color: white;
            background-color: var(--primary-color);
            padding: 4px 8px;
            border-radius: 12px;
            margin-bottom: 10px;
        }
        
        .news-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 10px;
            line-height: 1.3;
        }
        
        .news-excerpt {
            font-size: 14px;
            color: var(--light-text);
            margin-bottom: 15px;
            line-height: 1.5;
        }
        
        .news-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 13px;
            color: var(--light-text);
        }
        
        .news-date {
            display: flex;
            align-items: center;
        }
        
        .news-date i {
            margin-right: 5px;
        }
        
        .news-author {
            display: flex;
            align-items: center;
        }
        
        .news-author i {
            margin-right: 5px;
        }
        
        .read-more {
            display: inline-block;
            color: var(--primary-color);
            font-weight: 500;
            font-size: 14px;
            margin-top: 10px;
            text-decoration: none;
        }
        
        .read-more i {
            margin-left: 5px;
            transition: var(--transition);
        }
        
        .read-more:hover i {
            transform: translateX(3px);
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        .social-links {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }
        
        .social-link {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--secondary-color);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: var(--transition);
        }
        
        .social-link:hover {
            background-color: var(--primary-color);
            color: white;
            transform: translateY(-3px);
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Empty state */
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
            text-align: center;
        }
        
        .empty-icon {
            font-size: 50px;
            color: #ccc;
            margin-bottom: 15px;
        }
        
        .empty-text {
            font-size: 16px;
            color: var(--light-text);
            margin-bottom: 20px;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }
            
            .news-title {
                font-size: 16px;
            }
            
            .news-image {
                height: 150px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" id="back-button"></i>
        News
    </div>
    
    <div class="section">
        <div class="news-filter">
            <a href="?filter=all" class="filter-button <?php echo $filter === 'all' ? 'active' : ''; ?>">All News</a>
            <a href="?filter=academic" class="filter-button <?php echo $filter === 'academic' ? 'active' : ''; ?>">Academic</a>
            <a href="?filter=sports" class="filter-button <?php echo $filter === 'sports' ? 'active' : ''; ?>">Sports</a>
            <a href="?filter=events" class="filter-button <?php echo $filter === 'events' ? 'active' : ''; ?>">Events</a>
            <a href="?filter=announcements" class="filter-button <?php echo $filter === 'announcements' ? 'active' : ''; ?>">Announcements</a>
        </div>
        
        <div class="news-list" id="news-list">
            <?php if (empty($news_items)): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-newspaper"></i>
                    </div>
                    <div class="empty-text">No news found for this category.</div>
                </div>
            <?php else: ?>
                <?php foreach ($news_items as $news): ?>
                    <div class="news-item" data-id="<?php echo $news['id']; ?>">
                        <img src="<?php echo htmlspecialchars($news['image'] ?: '/placeholder.svg?height=180&width=400'); ?>" alt="<?php echo htmlspecialchars($news['title']); ?>" class="news-image">
                        <div class="news-content">
                            <span class="news-category"><?php echo htmlspecialchars(ucfirst($news['category'])); ?></span>
                            <h3 class="news-title"><?php echo htmlspecialchars($news['title']); ?></h3>
                            <p class="news-excerpt"><?php echo htmlspecialchars($news['excerpt']); ?></p>
                            <div class="news-meta">
                                <div class="news-date">
                                    <i class="far fa-calendar-alt"></i> <?php echo htmlspecialchars($news['published_date']); ?>
                                </div>
                                <div class="news-author">
                                    <i class="far fa-user"></i> <?php echo htmlspecialchars($news['author']); ?>
                                </div>
                            </div>
                            <a href="#" class="read-more">Read more <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="modules.php" class="footer-item ripple active">
            <i class="fas fa-th footer-icon"></i>
            <span class="footer-text">Modules</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>
    
    <!-- Social Links -->
    <div class="social-links">
        <a href="<?php echo $facebook_url; ?>" class="social-link">
            <i class="fab fa-facebook-f"></i>
        </a>
        <a href="<?php echo $twitter_url; ?>" class="social-link">
            <i class="fab fa-twitter"></i>
        </a>
        <a href="<?php echo $instagram_url; ?>" class="social-link">
            <i class="fab fa-instagram"></i>
        </a>
        <a href="<?php echo $linkedin_url; ?>" class="social-link">
            <i class="fab fa-linkedin-in"></i>
        </a>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            // Back button functionality
            document.getElementById('back-button').addEventListener('click', function() {
                showLoader();
                window.location.href = 'modules.php';
            });
            
            // Add click event to news items
            document.querySelectorAll('.news-item').forEach(item => {
                item.addEventListener('click', function(e) {
                    // Prevent navigation if clicking on "Read more" link
                    if (e.target.closest('.read-more')) {
                        return;
                    }
                    
                    const newsId = this.getAttribute('data-id');
                    alert(`Viewing news details for ID: ${newsId}`);
                });
            });
            
            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }
            
            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>