<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND (expires_at > NOW() OR expires_at IS NULL)'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            $session = $stmt->fetch();

            if ($session) {
                $new_expiry = date('Y-m-d H:i:s', strtotime('+1 day'));
                $update_stmt = $this->pdo->prepare(
                    'UPDATE sessions 
                    SET expires_at = :expires_at 
                    WHERE session_token = :session_token'
                );
                $update_stmt->execute([
                    ':expires_at' => $new_expiry,
                    ':session_token' => $session_token
                ]);
                return true;
            }
            return false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// FeeManager class to handle fee operations
class FeeManager {
    private $pdo;
    private $user_id;
    private $current_date;

    public function __construct(PDO $pdo, $user_id, $current_date) {
        $this->pdo = $pdo;
        $this->user_id = $user_id;
        $this->current_date = $current_date;
    }

    public function getFeeDetails($fee_structure_id) {
        try {
            // Step 1: Fetch the fee structure and related particulars
            $stmt = $this->pdo->prepare(
                'SELECT fs.id, fs.particular_id, fs.class_id, fs.amount, fs.applicable_months, fs.frequency, fs.custom_frequency, p.particular 
                FROM fee_structure fs 
                JOIN particulars p ON fs.particular_id = p.id 
                WHERE fs.id = :id 
                AND fs.status = "active" 
                AND p.status = "active"'
            );
            $stmt->execute([':id' => $fee_structure_id]);
            $fee = $stmt->fetch();

            if (!$fee) {
                return null;
            }

            // Step 2: Determine the session based on current date (April to March)
            $current_month = (int)(new DateTime($this->current_date))->format('n'); // 6 for June
            $current_year = (int)(new DateTime($this->current_date))->format('Y'); // 2025
            $session_start_year = $current_month >= 4 ? $current_year : $current_year - 1;
            $current_session = "$session_start_year-" . ($session_start_year + 1); // e.g., "2025-2026"

            // Define session months (April to March)
            $session_months = [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3];
            $month_names = [
                1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
                5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
                9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
            ];

            // Step 3: Fetch all fee structures for the same particular_id and class_id to handle duplicates
            $stmt = $this->pdo->prepare(
                'SELECT id, amount, frequency 
                FROM fee_structure 
                WHERE particular_id = :particular_id 
                AND class_id = :class_id 
                AND status = "active"'
            );
            $stmt->execute([
                ':particular_id' => $fee['particular_id'],
                ':class_id' => $fee['class_id']
            ]);
            $fee_structures = $stmt->fetchAll();

            // Use the first fee structure's amount to avoid aggregating duplicates
            $amount = (float)$fee['amount'];

            // Step 4: Calculate total session fee based on frequency
            if ($fee['frequency'] === 'monthly') {
                $session_fee = $amount * count($session_months); // ₹400 * 12 = ₹4800
            } elseif ($fee['frequency'] === 'annual') {
                $session_fee = $amount; // ₹300 for Registration Fee
            } elseif ($fee['frequency'] === 'other') {
                $collections_per_year = floor(12 / $fee['custom_frequency']);
                $session_fee = $amount * $collections_per_year; // ₹200 * 3 = ₹600 for Examination Fee
            } else {
                $session_fee = $amount; // Default to one-time fee
            }

            // Step 5: Fetch payment history for all fee_structure_ids related to this particular
            $fee_structure_ids = array_column($fee_structures, 'id');
            $placeholders = implode(',', array_fill(0, count($fee_structure_ids), '?'));
            $stmt = $this->pdo->prepare(
                "SELECT amount_collected, discount, remaining_balance, payment_date, payment_method, payment_month 
                FROM fee_collections 
                WHERE student_id = ? 
                AND fee_structure_id IN ($placeholders) 
                AND session = ? 
                AND status = 'completed'"
            );
            $params = array_merge([$this->user_id], $fee_structure_ids, [$current_session]);
            $stmt->execute($params);
            $payments = $stmt->fetchAll();

            // Step 6: Process payments
            $total_paid = 0;
            $payment_months = [];
            foreach ($payments as &$payment) {
                $total_paid += (float)$payment['amount_collected'];
                if ($fee['frequency'] === 'monthly' && !empty($payment['payment_month'])) {
                    $months = array_map('intval', explode(',', $payment['payment_month']));
                    $payment['months_paid'] = array_map(fn($m) => $month_names[$m], $months);
                    $payment_months = array_unique(array_merge($payment_months, $months));
                }
                $payment['payment_date'] = date('F j, Y', strtotime($payment['payment_date']));
            }
            unset($payment); // Break the reference after the loop

            // Step 7: Calculate remaining balance
            $remaining_balance = max(0, $session_fee - $total_paid);

            // Step 8: Calculate due date
            $due_date = $this->calculateDueDate($fee['frequency'], $fee['applicable_months'], $current_month, $session_start_year);

            return [
                'id' => $fee['id'],
                'title' => $fee['particular'],
                'amount' => $amount,
                'session_fee' => $session_fee,
                'due_date' => $due_date,
                'total_paid' => $total_paid,
                'remaining_balance' => $remaining_balance,
                'status' => $remaining_balance == 0 ? 'paid' : 'due',
                'payments' => $payments,
                'frequency' => $fee['frequency']
            ];
        } catch (PDOException $e) {
            error_log('Fee details fetch failed: ' . $e->getMessage());
            return null;
        }
    }

    private function calculateDueDate($frequency, $applicable_months, $current_month, $session_start_year) {
        $month_names = [
            1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
            5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
            9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
        ];

        // Default due date: 10th of the month
        $due_day = 10;
        $due_year = $session_start_year;
        $due_month = 4; // Default to April (session start)

        if ($frequency === 'monthly') {
            if (strtolower($applicable_months) === 'all') {
                $due_month = $current_month;
            } else {
                $months = array_map('intval', array_filter(explode(',', $applicable_months)));
                $due_month = in_array($current_month, $months) ? $current_month : $months[0] ?? 4;
            }
        } elseif ($frequency === 'annual') {
            $due_month = 4; // Annual fees due in April
        } elseif ($frequency === 'other') {
            $due_month = 4; // Default to April for first collection
            if (strtolower($applicable_months) !== 'all') {
                $months = array_map('intval', array_filter(explode(',', $applicable_months)));
                $due_month = $months[0] ?? 4;
            }
        }

        // Adjust year for months January to March
        if ($due_month < 4) {
            $due_year = $session_start_year + 1;
        }

        try {
            $due_date_str = sprintf('%d-%02d-%02d', $due_year, $due_month, $due_day);
            $due_date = (new DateTime($due_date_str))->format('F j, Y');
        } catch (Exception $e) {
            error_log('Failed to parse due date: ' . $due_date_str . ' - ' . $e->getMessage());
            $due_date = $month_names[$due_month] . ' ' . $due_day . ', ' . $due_year;
        }

        return $due_date;
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            setcookie('session_token', '', time() - 3600, '/', '', true, true);
            setcookie('android_uid', '', time() - 3600, '/', '', true, true);
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    setcookie('android_uid', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Get fee_structure_id from URL
$fee_structure_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($fee_structure_id <= 0) {
    header("Location: fee_dues.php");
    exit;
}

// Initialize FeeManager with current date
$current_date = '2025-06-06 15:01:00'; // 03:01 PM IST on June 06, 2025
$feeManager = new FeeManager($pdo, $_SESSION['user_id'], $current_date);

// Fetch fee details
$fee = $feeManager->getFeeDetails($fee_structure_id);
if (!$fee) {
    header("Location: fee_dues.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Educational App - Fee Details</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }
        
        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .fee-details {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .fee-card {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .fee-label {
            font-size: 16px;
            font-weight: 500;
        }
        
        .fee-value {
            font-size: 18px;
            font-weight: 600;
        }
        
        .fee-value.paid {
            color: var(--success-color);
        }
        
        .fee-value.due {
            color: var(--danger-color);
        }
        
        .payment-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .payment-item {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            border-left: 4px solid var(--success-color);
        }
        
        .payment-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 10px;
        }
        
        .payment-date {
            font-size: 16px;
            font-weight: 600;
        }
        
        .payment-method {
            font-size: 12px;
            color: var(--light-text);
            background-color: var(--secondary-color);
            padding: 4px 8px;
            border-radius: 12px;
        }
        
        .payment-meta {
            display: flex;
            justify-content: space-between;
            font-size: 13px;
            color: var(--light-text);
            margin-bottom: 5px;
        }
        
        .payment-amount {
            font-weight: 500;
        }
        
        .action-button {
            background-color: var(--primary-color);
            border: none;
            border-radius: var(--border-radius);
            padding: 10px 20px;
            font-size: 16px;
            font-weight: 500;
            color: white;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            margin: 0 auto;
        }
        
        .action-button:hover {
            opacity: 0.9;
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Empty state */
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
            text-align: center;
        }
        
        .empty-icon {
            font-size: 50px;
            color: #ccc;
            margin-bottom: 15px;
        }
        
        .empty-text {
            font-size: 16px;
            color: var(--light-text);
            margin-bottom: 20px;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }
            
            .fee-value {
                font-size: 16px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" id="back-button"></i>
        Fee Details
    </div>
    
    <div class="section">
        <div class="section-title"><?php echo htmlspecialchars($fee['title']); ?></div>
        <div class="fee-details">
            <div class="fee-card">
                <div class="fee-label">Total Session Fee</div>
                <div class="fee-value">₹<?php echo number_format($fee['session_fee'], 2); ?></div>
            </div>
            <div class="fee-card">
                <div class="fee-label">Paid Amount</div>
                <div class="fee-value paid">₹<?php echo number_format($fee['total_paid'], 2); ?></div>
            </div>
            <div class="fee-card">
                <div class="fee-label">Due Amount</div>
                <div class="fee-value due">₹<?php echo number_format($fee['remaining_balance'], 2); ?></div>
            </div>
            <div class="fee-card">
                <div class="fee-label">Due Date</div>
                <div class="fee-value"><?php echo htmlspecialchars($fee['due_date']); ?></div>
            </div>
        </div>
        <?php if ($fee['status'] === 'due'): ?>
            <button class="action-button" onclick="payFee(<?php echo $fee['id']; ?>)">
                <i class="fas fa-credit-card"></i> Pay Now
            </button>
        <?php endif; ?>
    </div>
    
    <div class="section">
        <div class="section-title">Payment History</div>
        <div class="payment-list">
            <?php if (empty($fee['payments'])): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-history"></i>
                    </div>
                    <div class="empty-text">No payments made yet.</div>
                </div>
            <?php else: ?>
                <?php foreach ($fee['payments'] as $payment): ?>
                    <div class="payment-item">
                        <div class="payment-header">
                            <div class="payment-date"><?php echo htmlspecialchars($payment['payment_date']); ?></div>
                            <div class="payment-method"><?php echo htmlspecialchars($payment['payment_method'] ?? 'N/A'); ?></div>
                        </div>
                        <div class="payment-meta">
                            <div class="fee-label">Amount Paid:</div>
                            <div class="payment-amount">₹<?php echo number_format($payment['amount_collected'], 2); ?></div>
                        </div>
                        <div class="payment-meta">
                            <div class="fee-label">Discount:</div>
                            <div class="payment-amount">₹<?php echo number_format($payment['discount'], 2); ?></div>
                        </div>
                        <?php if ($fee['frequency'] === 'monthly' && !empty($payment['months_paid'])): ?>
                            <div class="payment-meta">
                                <div class="fee-label">Months Paid:</div>
                                <div class="payment-amount"><?php echo htmlspecialchars(implode(', ', $payment['months_paid'])); ?></div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            // Back button functionality
            document.getElementById('back-button').addEventListener('click', function() {
                showLoader();
                window.location.href = 'fee_dues.php';
            });
            
            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }

            // Make functions available globally
            window.payFee = function(feeId) {
                showLoader();
                window.location.href = `pay_fee.php?id=${feeId}`;
            };
            
            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>