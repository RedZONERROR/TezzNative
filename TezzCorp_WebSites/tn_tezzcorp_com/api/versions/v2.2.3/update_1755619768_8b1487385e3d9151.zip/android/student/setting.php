<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Settings class to handle operations
class Settings {
    private $pdo;
    private $user_id;

    public function __construct(PDO $pdo, $user_id) {
        $this->pdo = $pdo;
        $this->user_id = $user_id;
    }

    public function getSettings() {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT notifications, dark_mode, language 
                FROM user_settings 
                WHERE sid = :sid'
            );
            $stmt->execute([':sid' => $this->user_id]);
            $settings = $stmt->fetch();

            if (!$settings) {
                // Insert default settings if none exist
                $stmt = $this->pdo->prepare(
                    'INSERT INTO user_settings (sid, notifications, dark_mode, language) 
                    VALUES (:sid, 1, 0, "English")'
                );
                $stmt->execute([':sid' => $this->user_id]);

                return [
                    'notifications' => 1,
                    'dark_mode' => 0,
                    'language' => 'English'
                ];
            }

            return $settings;
        } catch (PDOException $e) {
            error_log('Settings fetch failed: ' . $e->getMessage());
            return [
                'notifications' => 1,
                'dark_mode' => 0,
                'language' => 'English'
            ];
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Initialize Settings manager
$settingsManager = new Settings($pdo, $_SESSION['user_id']);

// Fetch settings
$settings = $settingsManager->getSettings();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Educational App - Settings</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px; /* Space for fixed footer */
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        body.dark-mode {
            background-color: #1a1a1a;
            color: #e0e0e0;
        }
        
        body.dark-mode .header {
            background-color: #003a73;
        }
        
        body.dark-mode .section {
            background-color: #2a2a2a;
        }
        
        body.dark-mode .setting-item {
            background-color: #3a3a3a;
        }
        
        body.dark-mode .footer {
            background-color: #2a2a2a;
        }
        
        body.dark-mode .version-info {
            color: #a0a0a0;
        }
        
        body.dark-mode .setting-text,
        body.dark-mode .section-title {
            color: #e0e0e0;
        }
        
        body.dark-mode .setting-icon {
            background-color: rgba(0, 85, 164, 0.2);
        }
        
        body.dark-mode .footer-item {
            color: #a0a0a0;
        }
        
        body.dark-mode .footer-item.active {
            color: #4a90e2;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .setting-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .setting-item {
            display: flex;
            align-items: center;
            padding: 15px;
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: var(--transition);
            cursor: pointer;
        }
        
        .setting-item:hover, .setting-item:active {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }
        
        .setting-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(0, 85, 164, 0.1);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-right: 15px;
        }
        
        .setting-text {
            flex: 1;
            font-size: 16px;
            font-weight: 500;
        }
        
        .setting-action {
            display: flex;
            align-items: center;
        }
        
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
        }
        
        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }
        
        .toggle-slider:before {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        
        input:checked + .toggle-slider {
            background-color: var(--primary-color);
        }
        
        input:checked + .toggle-slider:before {
            transform: translateX(26px);
        }
        
        .setting-arrow {
            color: var(--light-text);
        }
        
        .setting-value {
            font-size: 14px;
            color: var(--light-text);
            margin-right: 10px;
        }
        
        .version-info {
            text-align: center;
            padding: 20px;
            color: var(--light-text);
            font-size: 14px;
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }
            
            .setting-text {
                font-size: 15px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select <?php echo $settings['dark_mode'] ? 'dark-mode' : ''; ?>">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <!-- Hidden form for updating settings -->
    <form id="update-setting-form" action="update_setting.php" method="POST" style="display: none;">
        <input type="hidden" name="setting" id="setting-name">
        <input type="hidden" name="value" id="setting-value">
    </form>

    <div class="header">Settings</div>
    
    <div class="section">
        <div class="section-title">App Settings</div>
        <div class="setting-list">
            <div class="setting-item" id="notification-setting">
                <div class="setting-icon">
                    <i class="fas fa-bell"></i>
                </div>
                <div class="setting-text">Push Notifications</div>
                <div class="setting-action">
                    <label class="toggle-switch">
                        <input type="checkbox" id="notification-toggle" <?php echo $settings['notifications'] ? 'checked' : ''; ?>>
                        <span class="toggle-slider"></span>
                    </label>
                </div>
            </div>
            <div class="setting-item" id="dark-mode-setting">
                <div class="setting-icon">
                    <i class="fas fa-moon"></i>
                </div>
                <div class="setting-text">Dark Mode</div>
                <div class="setting-action">
                    <label class="toggle-switch">
                        <input type="checkbox" id="dark-mode-toggle" <?php echo $settings['dark_mode'] ? 'checked' : ''; ?>>
                        <span class="toggle-slider"></span>
                    </label>
                </div>
            </div>
            <div class="setting-item" id="language-setting">
                <div class="setting-icon">
                    <i class="fas fa-language"></i>
                </div>
                <div class="setting-text">Language</div>
                <div class="setting-action">
                    <div class="setting-value"><?php echo htmlspecialchars($settings['language']); ?></div>
                    <div class="setting-arrow">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="section">
        <div class="section-title">Support</div>
        <div class="setting-list">
            <div class="setting-item" id="help-center">
                <div class="setting-icon">
                    <i class="fas fa-question-circle"></i>
                </div>
                <div class="setting-text">Help Center</div>
                <div class="setting-action">
                    <div class="setting-arrow">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </div>
            </div>
            <div class="setting-item" id="contact-support">
                <div class="setting-icon">
                    <i class="fas fa-headset"></i>
                </div>
                <div class="setting-text">Contact Support</div>
                <div class="setting-action">
                    <div class="setting-arrow">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </div>
            </div>
            <div class="setting-item" id="feedback">
                <div class="setting-icon">
                    <i class="fas fa-comment-alt"></i>
                </div>
                <div class="setting-text">Send Feedback</div>
                <div class="setting-action">
                    <div class="setting-arrow">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="section">
        <div class="section-title">About</div>
        <div class="setting-list">
            <div class="setting-item" id="about-app">
                <div class="setting-icon">
                    <i class="fas fa-info-circle"></i>
                </div>
                <div class="setting-text">About App</div>
                <div class="setting-action">
                    <div class="setting-arrow">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </div>
            </div>
            <div class="setting-item" id="privacy-policy">
                <div class="setting-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div class="setting-text">Privacy Policy</div>
                <div class="setting-action">
                    <div class="setting-arrow">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </div>
            </div>
            <div class="setting-item" id="terms-conditions">
                <div class="setting-icon">
                    <i class="fas fa-file-alt"></i>
                </div>
                <div class="setting-text">Terms & Conditions</div>
                <div class="setting-action">
                    <div class="setting-arrow">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="version-info">
        Version 1.0.0
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="modules.php" class="footer-item ripple">
            <i class="fas fa-th footer-icon"></i>
            <span class="footer-text">Modules</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item active ripple">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }

            // Function to update setting
            function updateSetting(setting, value) {
                showLoader();
                const form = document.getElementById('update-setting-form');
                document.getElementById('setting-name').value = setting;
                document.getElementById('setting-value').value = value ? '1' : '0';
                form.submit();
            }
            
            // Add event listeners to toggles
            document.getElementById('notification-toggle').addEventListener('change', function() {
                updateSetting('notifications', this.checked);
            });
            
            document.getElementById('dark-mode-toggle').addEventListener('change', function() {
                updateSetting('dark_mode', this.checked);
                
                // Toggle dark mode class locally (will be refreshed on form submission)
                if (this.checked) {
                    document.body.classList.add('dark-mode');
                } else {
                    document.body.classList.remove('dark-mode');
                }
            });
            
            // Add event listeners to setting items
            document.getElementById('language-setting').addEventListener('click', function() {
                alert('Language settings will be implemented soon.');
            });
            
            document.getElementById('help-center').addEventListener('click', function() {
                showLoader();
                window.location.href = 'help_center.php';
            });
            
            document.getElementById('contact-support').addEventListener('click', function() {
                showLoader();
                window.location.href = 'contact_support.php';
            });
            
            document.getElementById('feedback').addEventListener('click', function() {
                showLoader();
                window.location.href = 'feedback.php';
            });
            
            document.getElementById('about-app').addEventListener('click', function() {
                showLoader();
                window.location.href = 'about.php';
            });
            
            document.getElementById('privacy-policy').addEventListener('click', function() {
                showLoader();
                window.location.href = 'privacy_policy.php';
            });
            
            document.getElementById('terms-conditions').addEventListener('click', function() {
                showLoader();
                window.location.href = 'terms_conditions.php';
            });

            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>