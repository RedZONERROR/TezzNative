<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to handle session tokens
class SessionManager {
    private $pdo;
    private $logger;

    public function __construct(PDO $pdo, callable $logger) {
        $this->pdo = $pdo;
        $this->logger = $logger;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            ($this->logger)('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: login.php");
    exit;
}

// Initialize logger
$logger = function ($message) {
    $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
    file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/logs/api.log', $logMessage, FILE_APPEND);
};

// Initialize SessionManager
$sessionManager = new SessionManager($pdo, $logger);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        try {
            $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
            $stmt->execute([':uid' => $_COOKIE['android_uid']]);
            $user = $stmt->fetch();
            
            if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_type'] = 'student';
                $_SESSION['user_name'] = $user['full_name'];
                $_SESSION['session_token'] = $_COOKIE['session_token'];
            } else {
                header("Location: login.php");
                exit;
            }
        } catch (PDOException $e) {
            ($logger)('Cookie session validation failed: ' . $e->getMessage());
            header("Location: login.php");
            exit;
        }
    } else {
        header("Location: login.php");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Educational App - Modules</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .search-container {
            padding: 15px;
            background-color: #f0f2f5;
        }
        
        .search-bar {
            display: flex;
            align-items: center;
            background-color: white;
            border-radius: 30px;
            padding: 12px 20px;
            box-shadow: var(--box-shadow);
            transition: var(--transition);
        }
        
        .search-bar:focus-within {
            box-shadow: var(--hover-shadow);
        }
        
        .search-bar i {
            color: var(--light-text);
            margin-right: 12px;
            font-size: 18px;
        }
        
        .search-bar input {
            border: none;
            outline: none;
            width: 100%;
            font-size: 16px;
            color: var(--text-color);
            background: transparent;
        }
        
        .search-bar input::placeholder {
            color: #adb5bd;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
        }
        
        .module {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 15px 10px;
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: var(--transition);
            cursor: pointer;
            height: 100%;
        }
        
        .module:hover, .module:active {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }
        
        .module-icon {
            width: 50px;
            height: 50px;
            margin-bottom: 12px;
            color: var(--primary-color);
            font-size: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(0, 85, 164, 0.1);
            border-radius: 50%;
            padding: 12px;
        }
        
        .module-name {
            font-size: 13px;
            font-weight: 500;
            color: var(--text-color);
            line-height: 1.3;
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        .ripple {
            position: relative;
            overflow: hidden;
        }
        
        .ripple:after {
            content: "";
            display: block;
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            pointer-events: none;
            background-image: radial-gradient(circle, #fff 10%, transparent 10.01%);
            background-repeat: no-repeat;
            background-position: 50%;
            transform: scale(10, 10);
            opacity: 0;
            transition: transform .5s, opacity 1s;
        }
        
        .ripple:active:after {
            transform: scale(0, 0);
            opacity: .3;
            transition: 0s;
        }
        
        .search-results {
            display: none;
            background-color: white;
            border-radius: var(--border-radius);
            margin: 0 15px;
            padding: 15px;
            box-shadow: var(--box-shadow);
            max-height: 300px;
            overflow-y: auto;
        }
        
        .search-result-item {
            display: flex;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid #eee;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .search-result-item:last-child {
            border-bottom: none;
        }
        
        .search-result-item:hover {
            background-color: #f8f9fa;
        }
        
        .search-result-icon {
            width: 40px;
            height: 40px;
            margin-right: 15px;
            color: var(--primary-color);
            font-size: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(0, 85, 164, 0.1);
            border-radius: 50%;
        }
        
        .search-result-text {
            font-size: 14px;
            font-weight: 500;
        }
        
        .search-result-category {
            font-size: 12px;
            color: var(--light-text);
            margin-left: auto;
        }
        
        .hidden {
            display: none !important;
        }
        
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        @media (max-width: 480px) {
            .grid {
                grid-template-columns: repeat(4, 1fr);
                gap: 10px;
            }
            
            .module {
                padding: 10px 5px;
            }
            
            .module-icon {
                width: 40px;
                height: 40px;
                font-size: 20px;
                margin-bottom: 8px;
            }
            
            .module-name {
                font-size: 11px;
            }
            
            .section-title {
                font-size: 20px;
            }
        }
        
        @media (max-width: 360px) {
            .grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>
    
    <div class="header">Modules</div>
    
    <div class="search-container">
        <div class="search-bar">
            <i class="fas fa-search"></i>
            <input type="text" placeholder="Search Here..." id="searchInput">
        </div>
    </div>
    
    <div id="searchResults" class="search-results"></div>
    
    <div id="mainContent">
        <div class="section">
            <div class="section-title">Academic</div>
            <div class="grid">
                <div class="module ripple" data-module="homework">
                    <div class="module-icon">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <div class="module-name">Homework</div>
                </div>
                <div class="module ripple" data-module="attendance">
                    <div class="module-icon">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="module-name">Attendance</div>
                </div>
                <div class="module ripple" data-module="teachers">
                    <div class="module-icon">
                        <i class="fas fa-chalkboard-teacher"></i>
                    </div>
                    <div class="module-name">My Teachers</div>
                </div>
                <div class="module ripple" data-module="timetable">
                    <div class="module-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="module-name">Time Table</div>
                </div>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title">Fees & Dues</div>
            <div class="grid">
                <div class="module ripple" data-module="feedues">
                    <div class="module-icon">
                        <i class="fas fa-file-invoice-dollar"></i>
                    </div>
                    <div class="module-name">Fee Dues</div>
                </div>
                <div class="module ripple" data-module="payfee">
                    <div class="module-icon">
                        <i class="fas fa-credit-card"></i>
                    </div>
                    <div class="module-name">Pay Fee</div>
                </div>
                <div class="module ripple" data-module="feereceipts">
                    <div class="module-icon">
                        <i class="fas fa-receipt"></i>
                    </div>
                    <div class="module-name">Fee Receipts</div>
                </div>
                <div class="module ripple" data-module="feesupport">
                    <div class="module-icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <div class="module-name">Fee Support</div>
                </div>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title">Communication</div>
            <div class="grid">
                <div class="module ripple" data-module="notifications">
                    <div class="module-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <div class="module-name">Notifications</div>
                </div>
                <div class="module ripple" data-module="news">
                    <div class="module-icon">
                        <i class="fas fa-newspaper"></i>
                    </div>
                    <div class="module-name">News</div>
                </div>
                <div class="module ripple" data-module="notice">
                    <div class="module-icon">
                        <i class="fas fa-bullhorn"></i>
                    </div>
                    <div class="module-name">Notice</div>
                </div>
                <div class="module ripple" data-module="holidays">
                    <div class="module-icon">
                        <i class="fas fa-calendar-day"></i>
                    </div>
                    <div class="module-name">Holidays</div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="modules.php" class="footer-item active ripple">
            <i class="fas fa-th footer-icon"></i>
            <span class="footer-text">Modules</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loader = document.getElementById('loader');
            const searchInput = document.getElementById('searchInput');
            const searchResults = document.getElementById('searchResults');
            const mainContent = document.getElementById('mainContent');

            // Hide loader after page load
            loader.style.opacity = '0';
            setTimeout(() => {
                loader.style.display = 'none';
                loader.style.opacity = '1';
            }, 300);
            
            // Prevent zooming on double tap
            document.addEventListener('dblclick', function(e) {
                e.preventDefault();
            });
            
            // Add touch feedback for modules
            const modules = document.querySelectorAll('.module');
            modules.forEach(module => {
                module.addEventListener('touchstart', function() {
                    this.style.backgroundColor = 'rgba(0, 85, 164, 0.05)';
                });
                
                module.addEventListener('touchend', function() {
                    this.style.backgroundColor = 'white';
                });
                
                module.addEventListener('click', function() {
                    const moduleType = this.getAttribute('data-module');
                    navigateToModule(moduleType);
                });
            });

            // Module navigation with loader
            function navigateToModule(moduleType) {
                loader.style.display = 'flex';
                const modulePages = {
                    'homework': 'homework.php',
                    'attendance': 'attendance.php',
                    'teachers': 'teachers.php',
                    'timetable': 'timetable.php',
                    'feedues': 'fee_dues.php',
                    'payfee': 'pay_fee.php',
                    'feereceipts': 'fee_receipts.php',
                    'feesupport': 'fee_support.php',
                    'notifications': 'notifications.php',
                    'news': 'news.php',
                    'notice': 'notice.php',
                    'holidays': 'holidays.php'
                };
                
                if (modulePages[moduleType]) {
                    window.location.href = modulePages[moduleType];
                } else {
                    loader.style.display = 'none';
                    alert('This module is not available yet.');
                }
            }

            // Search functionality
            const allModules = [
                { name: 'Homework', category: 'Academic', icon: 'fa-book-open', module: 'homework' },
                { name: 'Discipline', category: 'Academic', icon: 'fa-tasks', module: 'discipline' },
                { name: 'My Teachers', category: 'Academic', icon: 'fa-chalkboard-teacher', module: 'teachers' },
                { name: 'Time Table', category: 'Academic', icon: 'fa-calendar-alt', module: 'timetable' },
                { name: 'Fee Dues', category: 'Fees & Dues', icon: 'fa-file-invoice-dollar', module: 'feedues' },
                { name: 'Pay Fee', category: 'Fees & Dues', icon: 'fa-credit-card', module: 'payfee' },
                { name: 'Fee Receipts', category: 'Fees & Dues', icon: 'fa-receipt', module: 'feereceipts' },
                { name: 'Fee Support', category: 'Fees & Dues', icon: 'fa-headset', module: 'feesupport' },
                { name: 'Notifications', category: 'Communication', icon: 'fa-bell', module: 'notifications' },
                { name: 'News', category: 'Communication', icon: 'fa-newspaper', module: 'news' },
                { name: 'Notice', category: 'Communication', icon: 'fa-bullhorn', module: 'notice' },
                { name: 'Holidays', category: 'Communication', icon: 'fa-calendar-day', module: 'holidays' }
            ];

            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase().trim();
                
                if (searchTerm.length > 0) {
                    const filteredModules = allModules.filter(module => 
                        module.name.toLowerCase().includes(searchTerm) || 
                        module.category.toLowerCase().includes(searchTerm)
                    );
                    displaySearchResults(filteredModules);
                    searchResults.style.display = 'block';
                    mainContent.style.display = 'none';
                } else {
                    searchResults.style.display = 'none';
                    mainContent.style.display = 'block';
                }
            });

            function displaySearchResults(results) {
                searchResults.innerHTML = '';
                
                if (results.length === 0) {
                    searchResults.innerHTML = '<div class="search-result-item">No results found</div>';
                    return;
                }
                
                results.forEach(result => {
                    const resultItem = document.createElement('div');
                    resultItem.className = 'search-result-item ripple';
                    resultItem.setAttribute('data-module', result.module);
                    
                    // Escape HTML to prevent XSS
                    const escapedName = result.name.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
                    const escapedCategory = result.category.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
                    
                    resultItem.innerHTML = `
                        <div class="search-result-icon">
                            <i class="fas ${result.icon}"></i>
                        </div>
                        <div class="search-result-text">${escapedName}</div>
                        <div class="search-result-category">${escapedCategory}</div>
                    `;
                    
                    resultItem.addEventListener('click', function() {
                        const moduleType = this.getAttribute('data-module');
                        navigateToModule(moduleType);
                    });
                    
                    searchResults.appendChild(resultItem);
                });
            }

            // Clear search when clicking outside
            document.addEventListener('click', function(e) {
                if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
                    searchInput.value = '';
                    searchResults.style.display = 'none';
                    mainContent.style.display = 'block';
                }
            });
        });
    </script>
</body>
</html>