<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Timetable class to handle operations
class Timetable {
    private $pdo;
    private $user_id;

    public function __construct(PDO $pdo, $user_id) {
        $this->pdo = $pdo;
        $this->user_id = $user_id;
    }

    public function getStudentClass() {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT class FROM students 
                WHERE id = :id AND status = "active"'
            );
            $stmt->execute([':id' => $this->user_id]);
            $student = $stmt->fetch();
            return $student ? $student['class'] : null;
        } catch (PDOException $e) {
            error_log('Student class fetch failed: ' . $e->getMessage());
            return null;
        }
    }

    public function getTimetable($day) {
        try {
            $student_class = $this->getStudentClass();
            if (!$student_class) {
                return [];
            }

            $stmt = $this->pdo->prepare(
                'SELECT t.*, te.full_name as teacher_name
                FROM timetable t
                LEFT JOIN teachers te ON t.tid = te.id
                WHERE t.class = :class AND t.day = :day
                ORDER BY t.period_number ASC'
            );
            $stmt->execute([
                ':class' => $student_class,
                ':day' => $day
            ]);
            return $stmt->fetchAll() ?: [];
        } catch (PDOException $e) {
            error_log('Timetable fetch failed: ' . $e->getMessage());
            return [];
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Initialize Timetable manager
$timetableManager = new Timetable($pdo, $_SESSION['user_id']);

// Define days of the week
$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

// Get current day index (0 = Sunday, 1 = Monday, etc.)
$currentDayIndex = date('w'); // Today is June 1, 2025, which is a Sunday (0)

// Convert to our array index (0 = Monday, 1 = Tuesday, etc.)
$defaultDayIndex = $currentDayIndex - 1;
if ($defaultDayIndex < 0 || $defaultDayIndex > 5) {
    $defaultDayIndex = 0; // Default to Monday if it's Sunday
}
$defaultDay = $days[$defaultDayIndex];

// Get selected day from query parameter, default to current day
$selectedDay = isset($_GET['day']) && in_array($_GET['day'], $days) ? htmlspecialchars($_GET['day']) : $defaultDay;

// Fetch timetable for the selected day
$timetable = $timetableManager->getTimetable($selectedDay);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Educational App - Time Table</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px; /* Space for fixed footer */
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }
        
        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .day-tabs {
            display: flex;
            overflow-x: auto;
            gap: 10px;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        
        .day-tab {
            background-color: var(--secondary-color);
            border: none;
            border-radius: 20px;
            padding: 8px 15px;
            font-size: 14px;
            font-weight: 500;
            color: var(--text-color);
            cursor: pointer;
            white-space: nowrap;
            transition: var(--transition);
        }
        
        .day-tab.active {
            background-color: var(--primary-color);
            color: white;
        }
        
        .timetable-container {
            margin-top: 20px;
        }
        
        .period {
            display: flex;
            margin-bottom: 15px;
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        
        .period-time {
            width: 80px;
            background-color: var(--primary-color);
            color: white;
            padding: 15px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            font-weight: 500;
        }
        
        .period-details {
            flex: 1;
            padding: 15px;
            background-color: white;
            border-left: 4px solid var(--primary-color);
        }
        
        .period-subject {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 5px;
            color: var(--primary-color);
        }
        
        .period-teacher {
            font-size: 14px;
            color: var(--text-color);
            margin-bottom: 5px;
        }
        
        .period-room {
            font-size: 13px;
            color: var(--light-text);
            display: flex;
            align-items: center;
        }
        
        .period-room i {
            margin-right: 5px;
        }
        
        .break-period {
            background-color: #f8f9fa;
        }
        
        .break-period .period-details {
            border-left-color: #6c757d;
        }
        
        .break-period .period-subject {
            color: #6c757d;
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Empty state */
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
            text-align: center;
        }
        
        .empty-icon {
            font-size: 50px;
            color: #ccc;
            margin-bottom: 15px;
        }
        
        .empty-text {
            font-size: 16px;
            color: var(--light-text);
            margin-bottom: 20px;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .period-time {
                width: 70px;
                font-size: 13px;
            }
            
            .period-subject {
                font-size: 15px;
            }
            
            .period-teacher {
                font-size: 13px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" id="back-button"></i>
        Time Table
    </div>
    
    <div class="section">
        <div class="day-tabs" id="day-tabs">
            <?php foreach ($days as $day): ?>
                <a href="timetable.php?day=<?php echo urlencode($day); ?>" class="day-tab <?php echo $day === $selectedDay ? 'active' : ''; ?>">
                    <?php echo htmlspecialchars($day); ?>
                </a>
            <?php endforeach; ?>
        </div>
        
        <div class="timetable-container" id="timetable-container">
            <?php if (empty($timetable)): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-calendar-times"></i>
                    </div>
                    <div class="empty-text">No classes scheduled for this day.</div>
                </div>
            <?php else: ?>
                <?php foreach ($timetable as $period): ?>
                    <div class="period <?php echo $period['is_break'] ? 'break-period' : ''; ?>">
                        <div class="period-time">
                            <div><?php echo htmlspecialchars($period['start_time']); ?></div>
                            <div>to</div>
                            <div><?php echo htmlspecialchars($period['end_time']); ?></div>
                        </div>
                        <div class="period-details">
                            <div class="period-subject"><?php echo htmlspecialchars($period['subject']); ?></div>
                            <?php if (!$period['is_break']): ?>
                                <div class="period-teacher"><?php echo htmlspecialchars($period['teacher_name'] ?: 'Unknown Teacher'); ?></div>
                                <div class="period-room">
                                    <i class="fas fa-map-marker-alt"></i> N/A
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="modules.php" class="footer-item ripple">
            <i class="fas fa-th footer-icon"></i>
            <span class="footer-text">Modules</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            // Back button functionality
            document.getElementById('back-button').addEventListener('click', function() {
                showLoader();
                window.location.href = 'modules.php';
            });
            
            // Day tabs functionality - add loader on click
            const dayTabs = document.querySelectorAll('.day-tab');
            dayTabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    showLoader();
                });
            });

            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }

            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>