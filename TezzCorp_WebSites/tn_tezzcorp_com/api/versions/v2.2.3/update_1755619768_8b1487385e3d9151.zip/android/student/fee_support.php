<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Handle form submission
$alert_message = '';
$alert_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = isset($_POST['subject']) ? trim($_POST['subject']) : '';
    $message = isset($_POST['message']) ? trim($_POST['message']) : '';
    $department = 'finance';

    if (empty($subject) || empty($message)) {
        $alert_message = 'Please fill in all fields';
        $alert_type = 'error';
    } else {
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO support_requests (user_id, user_type, subject, message, department, status, created_at) 
                VALUES (:user_id, :user_type, :subject, :message, :department, "open", NOW())'
            );
            $stmt->execute([
                ':user_id' => $_SESSION['user_id'],
                ':user_type' => $_SESSION['user_type'],
                ':subject' => $subject,
                ':message' => $message,
                ':department' => $department
            ]);
            $alert_message = 'Your request has been submitted successfully. We will get back to you soon.';
            $alert_type = 'success';
        } catch (PDOException $e) {
            error_log('Support request submission failed: ' . $e->getMessage());
            $alert_message = 'Failed to submit request. Please try again.';
            $alert_type = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Educational App - Fee Support</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }
        
        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .support-options {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .support-option {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            transition: var(--transition);
            cursor: pointer;
        }
        
        .support-option:hover {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }
        
        .support-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: rgba(0, 85, 164, 0.1);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-right: 15px;
            flex-shrink: 0;
        }
        
        .support-details {
            flex: 1;
        }
        
        .support-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .support-description {
            font-size: 14px;
            color: var(--light-text);
        }
        
        .support-arrow {
            color: var(--light-text);
            margin-left: 10px;
        }
        
        .faq-section {
            margin-top: 30px;
        }
        
        .faq-item {
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 15px;
        }
        
        .faq-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        
        .faq-question {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
        }
        
        .faq-question i {
            transition: var(--transition);
        }
        
        .faq-question.active i {
            transform: rotate(180deg);
        }
        
        .faq-answer {
            font-size: 14px;
            color: var(--light-text);
            display: none;
            padding: 10px 0;
        }
        
        .faq-answer.active {
            display: block;
        }
        
        .contact-form {
            margin-top: 20px;
        }
        
        .input-group {
            margin-bottom: 15px;
        }
        
        .input-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 15px;
        }
        
        .input-field {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 15px;
            transition: var(--transition);
        }
        
        .input-field:focus {
            border-color: var(--primary-color);
            outline: none;
        }
        
        textarea.input-field {
            min-height: 120px;
            resize: vertical;
        }
        
        .submit-button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            padding: 12px 20px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
        }
        
        .submit-button:hover {
            background-color: #004a8f;
        }
        
        /* Alert message */
        .alert {
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            display: none;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }
            
            .support-title {
                font-size: 15px;
            }
            
            .support-description {
                font-size: 13px;
            }
            
            .faq-question {
                font-size: 15px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" id="back-button"></i>
        Fee Support
    </div>
    
    <div class="section">
        <div class="section-title">How Can We Help?</div>
        <div class="support-options">
            <div class="support-option" id="payment-issues">
                <div class="support-icon">
                    <i class="fas fa-credit-card"></i>
                </div>
                <div class="support-details">
                    <div class="support-title">Payment Issues</div>
                    <div class="support-description">Help with payment failures or refunds</div>
                </div>
                <div class="support-arrow">
                    <i class="fas fa-chevron-right"></i>
                </div>
            </div>
            
            <div class="support-option" id="fee-structure">
                <div class="support-icon">
                    <i class="fas fa-file-invoice-dollar"></i>
                </div>
                <div class="support-details">
                    <div class="support-title">Fee Structure</div>
                    <div class="support-description">Information about fee breakdown</div>
                </div>
                <div class="support-arrow">
                    <i class="fas fa-chevron-right"></i>
                </div>
            </div>
            
            <div class="support-option" id="scholarships">
                <div class="support-icon">
                    <i class="fas fa-award"></i>
                </div>
                <div class="support-details">
                    <div class="support-title">Scholarships & Financial Aid</div>
                    <div class="support-description">Learn about available financial assistance</div>
                </div>
                <div class="support-arrow">
                    <i class="fas fa-chevron-right"></i>
                </div>
            </div>
            
            <div class="support-option" id="contact-finance">
                <div class="support-icon">
                    <i class="fas fa-headset"></i>
                </div>
                <div class="support-details">
                    <div class="support-title">Contact Finance Department</div>
                    <div class="support-description">Speak directly with our finance team</div>
                </div>
                <div class="support-arrow">
                    <i class="fas fa-chevron-right"></i>
                </div>
            </div>
        </div>
    </div>
    
    <div class="section faq-section">
        <div class="section-title">Frequently Asked Questions</div>
        <div class="faq-list">
            <div class="faq-item">
                <div class="faq-question">
                    When is the fee payment deadline?
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    Fee payment deadlines are typically set at the beginning of each semester. For the current semester, the deadline is the 10th of the first applicable month (e.g., January 10, 2025 for January fees). Late payments may incur additional charges.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    Can I pay my fees in installments?
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    Yes, we offer installment plans for fee payments. Please contact the finance department to set up an installment plan based on your specific needs and circumstances.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    How can I apply for a scholarship?
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    Scholarship applications are accepted at the beginning of each academic year. You can apply through the scholarship portal on our website or visit the finance office for assistance with the application process.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    What payment methods are accepted?
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    We accept various payment methods including credit/debit cards, bank transfers, and digital wallets. Cash payments can be made directly at the finance office during working hours.
                </div>
            </div>
        </div>
    </div>
    
    <div class="section" id="contact-form-section" style="display: none;">
        <div class="section-title">Contact Finance Department</div>
        <?php if ($alert_message): ?>
            <div class="alert alert-<?php echo htmlspecialchars($alert_type); ?>" id="alert">
                <?php echo htmlspecialchars($alert_message); ?>
            </div>
        <?php else: ?>
            <div class="alert" id="alert" style="display: none;"></div>
        <?php endif; ?>
        <form id="support-form" class="contact-form" method="POST" action="fee_support.php">
            <div class="input-group">
                <label for="subject" class="input-label">Subject</label>
                <input type="text" id="subject" name="subject" class="input-field" placeholder="Enter subject" value="<?php echo isset($_POST['subject']) ? htmlspecialchars($_POST['subject']) : ''; ?>">
            </div>
            
            <div class="input-group">
                <label for="message" class="input-label">Message</label>
                <textarea id="message" name="message" class="input-field" placeholder="Describe your issue or question"><?php echo isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''; ?></textarea>
            </div>
            
            <button type="submit" class="submit-button">
                <i class="fas fa-paper-plane"></i> Submit Request
            </button>
        </form>
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="modules.php" class="footer-item ripple">
            <i class="fas fa-th footer-icon"></i>
            <span class="footer-text">Modules</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple active">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            // Back button functionality
            document.getElementById('back-button').addEventListener('click', function() {
                showLoader();
                window.location.href = 'setting.php';
            });
            
            // FAQ toggle functionality
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', function() {
                    // Toggle active class on question
                    this.classList.toggle('active');
                    
                    // Toggle active class on answer
                    const answer = this.nextElementSibling;
                    answer.classList.toggle('active');
                });
            });
            
            // Support option click handlers
            document.getElementById('payment-issues').addEventListener('click', function() {
                showContactForm('Payment Issue');
            });
            
            document.getElementById('fee-structure').addEventListener('click', function() {
                showContactForm('Fee Structure Inquiry');
            });
            
            document.getElementById('scholarships').addEventListener('click', function() {
                showContactForm('Scholarship & Financial Aid');
            });
            
            document.getElementById('contact-finance').addEventListener('click', function() {
                showContactForm('General Finance Inquiry');
            });
            
            // Form submission handling
            document.getElementById('support-form').addEventListener('submit', function(e) {
                const subject = document.getElementById('subject').value;
                const message = document.getElementById('message').value;
                
                if (!subject || !message) {
                    e.preventDefault();
                    showAlert('Please fill in all fields', 'error');
                    return;
                }
                
                showLoader();
            });
            
            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }
            
            // Function to show contact form
            function showContactForm(subject) {
                document.getElementById('subject').value = subject;
                document.getElementById('contact-form-section').style.display = 'block';
                
                // Scroll to form
                document.getElementById('contact-form-section').scrollIntoView({ behavior: 'smooth' });
            }
            
            // Function to show alert
            function showAlert(message, type) {
                const alertBox = document.getElementById('alert');
                alertBox.textContent = message;
                alertBox.className = 'alert alert-' + type;
                alertBox.style.display = 'block';
                
                // Hide alert after 5 seconds
                setTimeout(() => {
                    alertBox.style.display = 'none';
                }, 5000);
            }
            
            // Hide loader after page load
            hideLoader();

            // Show alert if present
            <?php if ($alert_message): ?>
                showAlert('<?php echo addslashes($alert_message); ?>', '<?php echo $alert_type; ?>');
                <?php if ($alert_type === 'success'): ?>
                    setTimeout(() => {
                        document.getElementById('contact-form-section').style.display = 'none';
                    }, 3000);
                <?php endif; ?>
            <?php endif; ?>
        });
    </script>
</body>
</html>