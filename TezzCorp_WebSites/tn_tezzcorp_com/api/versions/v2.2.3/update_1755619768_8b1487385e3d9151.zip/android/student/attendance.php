<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch site settings
try {
    $stmt = $pdo->prepare('SELECT school_name, facebook_url, twitter_url, instagram_url, linkedin_url FROM site_settings WHERE id = 1');
    $stmt->execute();
    $settings = $stmt->fetch();
    
    if (!$settings) {
        $settings = [
            'school_name' => 'EduConnect',
            'facebook_url' => '#',
            'twitter_url' => '#',
            'instagram_url' => '#',
            'linkedin_url' => '#'
        ];
    }
} catch (PDOException $e) {
    error_log('Failed to fetch site settings: ' . $e->getMessage());
    $settings = [
        'school_name' => 'EduConnect',
        'facebook_url' => '#',
        'twitter_url' => '#',
        'instagram_url' => '#',
        'linkedin_url' => '#'
    ];
}

$school_name = htmlspecialchars($settings['school_name']);
$facebook_url = htmlspecialchars($settings['facebook_url']);
$twitter_url = htmlspecialchars($settings['twitter_url']);
$instagram_url = htmlspecialchars($settings['instagram_url']);
$linkedin_url = htmlspecialchars($settings['linkedin_url']);

// Handle month and year selection
$currentDate = new DateTime('2025-06-01 13:31:00', new DateTimeZone('Asia/Kolkata')); // Current date: June 01, 2025, 01:31 PM IST
$currentMonth = (int)$currentDate->format('n') - 1; // 0-based month (June = 5)
$currentYear = (int)$currentDate->format('Y'); // 2025

// Get month and year from query parameters, default to current month/year
$selectedMonth = isset($_GET['month']) ? (int)$_GET['month'] : $currentMonth;
$selectedYear = isset($_GET['year']) ? (int)$_GET['year'] : $currentYear;

// Validate month and year
if ($selectedMonth < 0 || $selectedMonth > 11) {
    $selectedMonth = $currentMonth;
}
if ($selectedYear < 2000 || $selectedYear > 2100) {
    $selectedYear = $currentYear;
}

// Calculate previous and next month/year for navigation
$prevMonth = $selectedMonth - 1;
$prevYear = $selectedYear;
if ($prevMonth < 0) {
    $prevMonth = 11;
    $prevYear--;
}

$nextMonth = $selectedMonth + 1;
$nextYear = $selectedYear;
if ($nextMonth > 11) {
    $nextMonth = 0;
    $nextYear++;
}

// Format the current month and year for display
$monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
$currentMonthDisplay = $monthNames[$selectedMonth] . ' ' . $selectedYear;

// Fetch attendance records for the selected month
$attendanceRecords = [];
try {
    $startDate = sprintf('%d-%02d-01', $selectedYear, $selectedMonth + 1);
    $endDate = (new DateTime($startDate))->modify('last day of this month')->format('Y-m-d');
    
    $query = 'SELECT date, time, status 
              FROM student_attendance 
              WHERE student_id = :student_id 
              AND date BETWEEN :start_date AND :end_date 
              ORDER BY date ASC';
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':student_id' => $_SESSION['user_id'],
        ':start_date' => $startDate,
        ':end_date' => $endDate
    ]);
    $attendanceRecords = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('Failed to fetch attendance records: ' . $e->getMessage());
    $attendanceRecords = [];
}

// Fetch holidays for the selected month
$holidays = [];
try {
    $query = 'SELECT holiday_date, name 
              FROM holidays 
              WHERE holiday_date BETWEEN :start_date AND :end_date 
              AND status = "published" 
              ORDER BY holiday_date ASC';
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':start_date' => $startDate,
        ':end_date' => $endDate
    ]);
    $holidays = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('Failed to fetch holidays: ' . $e->getMessage());
    $holidays = [];
}

// Process attendance data for the calendar and summary
$daysInMonth = (new DateTime($startDate))->format('t');
$attendanceData = [];
$presentCount = 0;
$absentCount = 0;
$leaveCount = 0;
$holidayCount = 0;

for ($day = 1; $day <= $daysInMonth; $day++) {
    $dateStr = sprintf('%d-%02d-%02d', $selectedYear, $selectedMonth + 1, $day);
    $dateObj = new DateTime($dateStr);
    $dayOfWeek = (int)$dateObj->format('w'); // 0 (Sunday) to 6 (Saturday)
    
    // Check if it's a holiday
    $holiday = array_filter($holidays, fn($h) => $h['holiday_date'] === $dateStr);
    $holiday = reset($holiday);
    
    if ($holiday) {
        $attendanceData[$day] = [
            'date' => $dateStr,
            'status' => 'holiday',
            'label' => $holiday['name']
        ];
        $holidayCount++;
        continue;
    }
    
    // Check if it's a weekend (Saturday or Sunday)
    if ($dayOfWeek === 0 || $dayOfWeek === 6) {
        $attendanceData[$day] = [
            'date' => $dateStr,
            'status' => 'holiday',
            'label' => 'Weekend'
        ];
        $holidayCount++;
        continue;
    }
    
    // Check attendance record
    $record = array_filter($attendanceRecords, fn($r) => $r['date'] === $dateStr);
    $record = reset($record);
    
    if ($record) {
        if ($record['status'] == 1) {
            $attendanceData[$day] = [
                'date' => $dateStr,
                'status' => 'present',
                'label' => 'Present',
                'time' => date('h:i A', strtotime($record['time']))
            ];
            $presentCount++;
        } else {
            $attendanceData[$day] = [
                'date' => $dateStr,
                'status' => 'absent',
                'label' => 'Absent',
                'time' => date('h:i A', strtotime($record['time']))
            ];
            $absentCount++;
        }
    } else {
        // No record and not a holiday/weekend, assume Leave
        $attendanceData[$day] = [
            'date' => $dateStr,
            'status' => 'leave',
            'label' => 'Leave'
        ];
        $leaveCount++;
    }
}

// Calculate attendance percentage (excluding holidays)
$totalWorkingDays = $presentCount + $absentCount + $leaveCount;
$attendancePercentage = $totalWorkingDays > 0 ? round(($presentCount / $totalWorkingDays) * 100) : 0;

// Generate calendar data
$firstDay = (new DateTime($startDate))->format('w'); // Day of week for the 1st (0 = Sunday)
$calendarRows = [];
$date = 1;
for ($i = 0; $i < 6; $i++) {
    $row = [];
    for ($j = 0; $j < 7; $j++) {
        if ($i === 0 && $j < $firstDay) {
            $row[] = null; // Empty cell before the first day
        } elseif ($date > $daysInMonth) {
            $row[] = null; // Empty cell after the last day
        } else {
            $row[] = $attendanceData[$date];
            $date++;
        }
    }
    $calendarRows[] = $row;
    if ($date > $daysInMonth) break;
}

// Fetch attendance percentages for the last 6 months for the chart
$monthlyPercentages = [];
for ($i = 5; $i >= 0; $i--) {
    $month = $selectedMonth - $i;
    $year = $selectedYear;
    if ($month < 0) {
        $month += 12;
        $year--;
    }
    
    $monthStart = sprintf('%d-%02d-01', $year, $month + 1);
    $monthEnd = (new DateTime($monthStart))->modify('last day of this month')->format('Y-m-d');
    
    // Fetch attendance records for the month
    $monthRecords = [];
    try {
        $stmt = $pdo->prepare(
            'SELECT date, status 
             FROM student_attendance 
             WHERE student_id = :student_id 
             AND date BETWEEN :start_date AND :end_date'
        );
        $stmt->execute([
            ':student_id' => $_SESSION['user_id'],
            ':start_date' => $monthStart,
            ':end_date' => $monthEnd
        ]);
        $monthRecords = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log('Failed to fetch monthly attendance: ' . $e->getMessage());
    }
    
    // Fetch holidays for the month
    $monthHolidays = [];
    try {
        $stmt = $pdo->prepare(
            'SELECT holiday_date 
             FROM holidays 
             WHERE holiday_date BETWEEN :start_date AND :end_date 
             AND status = "published"'
        );
        $stmt->execute([
            ':start_date' => $monthStart,
            ':end_date' => $monthEnd
        ]);
        $monthHolidays = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log('Failed to fetch monthly holidays: ' . $e->getMessage());
    }
    
    // Calculate working days and percentage
    $monthDays = (new DateTime($monthStart))->format('t');
    $monthPresent = 0;
    $monthAbsent = 0;
    $monthLeave = 0;
    $monthHoliday = 0;
    
    for ($day = 1; $day <= $monthDays; $day++) {
        $dateStr = sprintf('%d-%02d-%02d', $year, $month + 1, $day);
        $dateObj = new DateTime($dateStr);
        $dayOfWeek = (int)$dateObj->format('w');
        
        // Check if it's a holiday or weekend
        $isHoliday = array_filter($monthHolidays, fn($h) => $h['holiday_date'] === $dateStr);
        if (!empty($isHoliday) || $dayOfWeek === 0 || $dayOfWeek === 6) {
            $monthHoliday++;
            continue;
        }
        
        // Check attendance
        $record = array_filter($monthRecords, fn($r) => $r['date'] === $dateStr);
        $record = reset($record);
        
        if ($record) {
            if ($record['status'] == 1) {
                $monthPresent++;
            } else {
                $monthAbsent++;
            }
        } else {
            $monthLeave++;
        }
    }
    
    $monthTotal = $monthPresent + $monthAbsent + $monthLeave;
    $percentage = $monthTotal > 0 ? round(($monthPresent / $monthTotal) * 100) : 0;
    
    $monthlyPercentages[] = [
        'month' => $monthNames[$month],
        'percentage' => $percentage
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $school_name; ?> - Attendance</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
            --present-color: #28a745;
            --absent-color: #dc3545;
            --leave-color: #fd7e14;
            --holiday-color: #6c757d;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }
        
        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .attendance-summary {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        
        .summary-card {
            flex: 1;
            padding: 15px;
            border-radius: var(--border-radius);
            text-align: center;
            margin: 0 5px;
            background-color: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        
        .summary-card:first-child {
            margin-left: 0;
        }
        
        .summary-card:last-child {
            margin-right: 0;
        }
        
        .summary-value {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .summary-label {
            font-size: 12px;
            color: var(--light-text);
        }
        
        .present-card .summary-value {
            color: var(--present-color);
        }
        
        .absent-card .summary-value {
            color: var(--absent-color);
        }
        
        .leave-card .summary-value {
            color: var(--leave-color);
        }
        
        .percentage-card .summary-value {
            color: var(--primary-color);
        }
        
        .month-selector {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .month-name {
            font-size: 18px;
            font-weight: 600;
        }
        
        .month-nav {
            display: flex;
            gap: 15px;
        }
        
        .month-nav-button {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background-color: var(--secondary-color);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            text-decoration: none;
        }
        
        .month-nav-button:hover {
            background-color: var(--primary-color);
            color: white;
        }
        
        .calendar {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        .calendar th {
            padding: 10px;
            text-align: center;
            font-weight: 500;
            color: var(--light-text);
            font-size: 14px;
        }
        
        .calendar td {
            padding: 0;
            text-align: center;
            position: relative;
        }
        
        .calendar-day {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 3px auto;
            border-radius: 50%;
            position: relative;
            cursor: pointer;
        }
        
        .calendar-day.present {
            background-color: rgba(40, 167, 69, 0.2);
        }
        
        .calendar-day.absent {
            background-color: rgba(220, 53, 69, 0.2);
        }
        
        .calendar-day.leave {
            background-color: rgba(253, 126, 20, 0.2);
        }
        
        .calendar-day.holiday {
            background-color: rgba(108, 117, 125, 0.2);
        }
        
        .calendar-day.today {
            border: 2px solid var(--primary-color);
        }
        
        .calendar-day.inactive {
            background-color: transparent;
            color: #ccc;
        }
        
        .calendar-day-number {
            font-size: 14px;
            font-weight: 500;
            line-height: 1;
            color: inherit;
        }
        
        .legend {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 10px;
        }
        
        .legend-item {
            display: flex;
            align-items: center;
            font-size: 13px;
            color: var(--light-text);
        }
        
        .legend-color {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 5px;
        }
        
        .legend-color.present {
            background-color: var(--present-color);
        }
        
        .legend-color.absent {
            background-color: var(--absent-color);
        }
        
        .legend-color.leave {
            background-color: var(--leave-color);
        }
        
        .legend-color.holiday {
            background-color: var(--holiday-color);
        }
        
        .attendance-chart {
            height: 200px;
            margin-top: 20px;
            position: relative;
        }
        
        .chart-bars {
            display: flex;
            height: 150px;
            align-items: flex-end;
            gap: 15px;
            margin-bottom: 10px;
        }
        
        .chart-bar {
            flex: 1;
            background-color: var(--primary-color);
            border-radius: 5px 5px 0 0;
            position: relative;
            min-width: 30px;
        }
        
        .chart-bar-label {
            position: absolute;
            bottom: -25px;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 12px;
            color: var(--light-text);
        }
        
        .chart-bar-value {
            position: absolute;
            top: -25px;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 12px;
            font-weight: 500;
            color: var(--primary-color);
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        .social-links {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }
        
        .social-link {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--secondary-color);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: var(--transition);
        }
        
        .social-link:hover {
            background-color: var(--primary-color);
            color: white;
            transform: translateY(-3px);
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }
            
            .summary-value {
                font-size: 20px;
            }
            
            .month-name {
                font-size: 16px;
            }
            
            .calendar-day {
                width: 35px;
                height: 35px;
            }
            
            .calendar-day-number {
                font-size: 12px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" id="back-button"></i>
        Attendance
    </div>
    
    <div class="section">
        <div class="section-title">Attendance Summary</div>
        <div class="attendance-summary">
            <div class="summary-card present-card">
                <div class="summary-value"><?php echo $presentCount; ?></div>
                <div class="summary-label">Present</div>
            </div>
            <div class="summary-card absent-card">
                <div class="summary-value"><?php echo $absentCount; ?></div>
                <div class="summary-label">Absent</div>
            </div>
            <div class="summary-card leave-card">
                <div class="summary-value"><?php echo $leaveCount; ?></div>
                <div class="summary-label">Leave</div>
            </div>
            <div class="summary-card percentage-card">
                <div class="summary-value"><?php echo $attendancePercentage; ?>%</div>
                <div class="summary-label">Attendance</div>
            </div>
        </div>
    </div>
    
    <div class="section">
        <div class="month-selector">
            <div class="month-name"><?php echo $currentMonthDisplay; ?></div>
            <div class="month-nav">
                <a href="?month=<?php echo $prevMonth; ?>&year=<?php echo $prevYear; ?>" class="month-nav-button" onclick="showLoader()">
                    <i class="fas fa-chevron-left"></i>
                </a>
                <a href="?month=<?php echo $nextMonth; ?>&year=<?php echo $nextYear; ?>" class="month-nav-button" onclick="showLoader()">
                    <i class="fas fa-chevron-right"></i>
                </a>
            </div>
        </div>
        
        <table class="calendar" id="attendance-calendar">
            <thead>
                <tr>
                    <th>Sun</th>
                    <th>Mon</th>
                    <th>Tue</th>
                    <th>Wed</th>
                    <th>Thu</th>
                    <th>Fri</th>
                    <th>Sat</th>
                </tr>
            </thead>
            <tbody id="calendar-body">
                <?php foreach ($calendarRows as $row): ?>
                    <tr>
                        <?php foreach ($row as $day): ?>
                            <td>
                                <?php if ($day): ?>
                                    <div class="calendar-day <?php echo htmlspecialchars($day['status']); ?> <?php echo $day['date'] === $currentDate->format('Y-m-d') ? 'today' : ''; ?>"
                                         data-date="<?php echo htmlspecialchars($day['date']); ?>"
                                         onclick="showDetails('<?php echo htmlspecialchars($day['date']); ?>', '<?php echo htmlspecialchars($day['status']); ?>', '<?php echo htmlspecialchars($day['label']); ?>', '<?php echo isset($day['time']) ? htmlspecialchars($day['time']) : ''; ?>')">
                                        <div class="calendar-day-number"><?php echo (int)(new DateTime($day['date']))->format('d'); ?></div>
                                    </div>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div class="legend">
            <div class="legend-item">
                <div class="legend-color present"></div>
                <span>Present</span>
            </div>
            <div class="legend-item">
                <div class="legend-color absent"></div>
                <span>Absent</span>
            </div>
            <div class="legend-item">
                <div class="legend-color leave"></div>
                <span>Leave</span>
            </div>
            <div class="legend-item">
                <div class="legend-color holiday"></div>
                <span>Holiday</span>
            </div>
        </div>
    </div>
    
    <div class="section">
        <div class="section-title">Monthly Attendance</div>
        <div class="attendance-chart">
            <div class="chart-bars" id="attendance-chart">
                <?php foreach ($monthlyPercentages as $monthData): ?>
                    <div style="flex: 1; display: flex; flex-direction: column; align-items: center; position: relative;">
                        <div class="chart-bar" style="height: <?php echo $monthData['percentage']; ?>%; width: 100%;"></div>
                        <div class="chart-bar-label"><?php echo htmlspecialchars($monthData['month']); ?></div>
                        <div class="chart-bar-value"><?php echo $monthData['percentage']; ?>%</div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="modules.php" class="footer-item ripple active">
            <i class="fas fa-th footer-icon"></i>
            <span class="footer-text">Modules</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>
    
    <!-- Social Links -->
    <div class="social-links">
        <a href="<?php echo $facebook_url; ?>" class="social-link">
            <i class="fab fa-facebook-f"></i>
        </a>
        <a href="<?php echo $twitter_url; ?>" class="social-link">
            <i class="fab fa-twitter"></i>
        </a>
        <a href="<?php echo $instagram_url; ?>" class="social-link">
            <i class="fab fa-instagram"></i>
        </a>
        <a href="<?php echo $linkedin_url; ?>" class="social-link">
            <i class="fab fa-linkedin-in"></i>
        </a>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            // Back button functionality
            document.getElementById('back-button').addEventListener('click', function() {
                showLoader();
                window.location.href = 'modules.php';
            });
            
            // Function to show loader
            window.showLoader = function() {
                loader.style.display = 'flex';
            };
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }
            
            // Function to show attendance details
            window.showDetails = function(date, status, label, time) {
                let message = `Date: ${date}\nStatus: ${label}`;
                if (time) {
                    message += `\nTime: ${time}`;
                }
                alert(message);
            };
            
            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>