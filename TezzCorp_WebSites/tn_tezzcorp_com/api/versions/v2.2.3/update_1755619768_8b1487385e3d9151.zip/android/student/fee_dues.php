<?php
// Enable error logging
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', $_SERVER['DOCUMENT_ROOT'] . '/logs/php_errors.log');
error_reporting(E_ALL);

// Log script start
error_log('Starting fee_dues.php execution at ' . date('Y-m-d H:i:s'));

// Set session cookie parameters before starting session
session_set_cookie_params(86400, '/', '', true, true);
session_start();

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
error_log('Config file loaded');

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        error_log('SessionManager initialized');
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            error_log('Validating session for user_id ' . $user_id);
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND (expires_at > NOW() OR expires_at IS NULL)'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            $session = $stmt->fetch();

            if ($session) {
                $new_expiry = date('Y-m-d H:i:s', strtotime('+1 day'));
                $update_stmt = $this->pdo->prepare(
                    'UPDATE sessions 
                    SET expires_at = :expires_at 
                    WHERE session_token = :session_token'
                );
                $update_stmt->execute([
                    ':expires_at' => $new_expiry,
                    ':session_token' => $session_token
                ]);
                error_log('Session validated successfully for user_id ' . $user_id);
                return true;
            }
            error_log('Session validation failed: No matching session found for token ' . $session_token);
            return false;
        } catch (PDOException $e) {
            error_log('Session validation failed due to database error: ' . $e->getMessage());
            return true; // Fallback: Assume session is valid if database error occurs
        }
    }
}

// FeeManager class to handle fee operations
class FeeManager {
    private $pdo;
    private $user_id;
    private $current_date;

    public function __construct(PDO $pdo, $user_id, $current_date) {
        $this->pdo = $pdo;
        $this->user_id = $user_id;
        $this->current_date = $current_date;
        error_log('FeeManager initialized for user_id ' . $this->user_id);
    }

    public function getFeeData() {
        try {
            // Step 1: Fetch student details
            error_log('Fetching student details for student_id ' . $this->user_id);
            $stmt = $this->pdo->prepare(
                'SELECT class, status FROM students WHERE id = :student_id'
            );
            $stmt->execute([':student_id' => $this->user_id]);
            $student = $stmt->fetch();

            if (!$student) {
                error_log('Student not found for student_id ' . $this->user_id);
                return [
                    'class' => null,
                    'current_session' => null,
                    'total_session_fee' => 0,
                    'paid_amount' => 0,
                    'remaining_fee' => 0,
                    'fee_details' => [],
                    'session_summary' => [],
                    'error' => 'Student not found.'
                ];
            }

            $class = $student['class'];
            $student_status = $student['status'];
            error_log('Student details for student_id ' . $this->user_id . ': class = ' . $class . ', status = ' . $student_status);

            if ($student_status !== 'active') {
                error_log('Student status is not active for student_id ' . $this->user_id);
                return [
                    'class' => $class,
                    'current_session' => null,
                    'total_session_fee' => 0,
                    'paid_amount' => 0,
                    'remaining_fee' => 0,
                    'fee_details' => [],
                    'session_summary' => [],
                    'error' => 'Student account is not active.'
                ];
            }

            // Step 2: Determine current session (April to March)
            $current_month = (int)(new DateTime($this->current_date))->format('n'); // 6 for June
            $current_year = (int)(new DateTime($this->current_date))->format('Y'); // 2025
            $session_start_year = $current_month >= 4 ? $current_year : $current_year - 1;
            $current_session = "$session_start_year-" . ($session_start_year + 1); // e.g., "2025-2026"
            error_log("Determined current session: $current_session");

            // Define session months (April to March)
            $session_months = [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3];
            $month_names = [
                1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
                5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
                9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
            ];

            // Step 3: Fetch fee structures for the student's class
            error_log('Fetching fee structures for class ' . $class);
            $stmt = $this->pdo->prepare(
                'SELECT 
                    fs.id AS fee_structure_id,
                    fs.particular_id,
                    fs.amount AS fee_amount,
                    fs.applicable_months,
                    fs.frequency,
                    fs.custom_frequency,
                    p.particular
                 FROM fee_structure fs
                 LEFT JOIN particulars p ON fs.particular_id = p.id
                 WHERE fs.class_id = :class_id 
                     AND fs.status = "active"
                     AND (p.status = "active" OR p.status IS NULL)'
            );
            $stmt->execute([':class_id' => $class]);
            $fee_structures = $stmt->fetchAll();

            error_log('Raw fee structures for class_id ' . $class . ': ' . json_encode($fee_structures));

            if (empty($fee_structures)) {
                error_log('No fee structures found for class_id ' . $class);
                return [
                    'class' => $class,
                    'current_session' => $current_session,
                    'total_session_fee' => 0,
                    'paid_amount' => 0,
                    'remaining_fee' => 0,
                    'fee_details' => [],
                    'session_summary' => [],
                    'error' => 'No fee structures found for your class.'
                ];
            }

            // Step 4: Fetch payment history for the student in the current session
            $fee_structure_ids = array_column($fee_structures, 'fee_structure_id');
            $payments = [];
            if (!empty($fee_structure_ids)) {
                $placeholders = implode(',', array_fill(0, count($fee_structure_ids), '?'));
                $stmt = $this->pdo->prepare(
                    "SELECT 
                        fee_structure_id, 
                        amount_collected, 
                        discount, 
                        payment_month, 
                        remaining_balance,
                        status
                    FROM fee_collections 
                    WHERE student_id = ? 
                        AND fee_structure_id IN ($placeholders) 
                        AND session = ? 
                        AND status = 'completed'"
                );
                $params = array_merge([$this->user_id], $fee_structure_ids, [$current_session]);
                $stmt->execute($params);
                $payments = $stmt->fetchAll();
                error_log('Payments for student_id ' . $this->user_id . ' in session ' . $current_session . ': ' . json_encode($payments));
            } else {
                error_log('No fee structure IDs to fetch payments for');
            }

            // Step 5: Process fee structures and calculate dues
            $total_session_fee = 0;
            $total_paid_amount = 0;
            $total_remaining_fee = 0;
            $fee_details = [];
            $session_summary = [];
            $fee_structures_by_particular = [];

            // Group fee structures by particular_id and collect all fee_structure_ids
            foreach ($fee_structures as $row) {
                $particular_id = $row['particular_id'];
                if (!isset($fee_structures_by_particular[$particular_id])) {
                    $fee_structures_by_particular[$particular_id] = [
                        'fee_structure_ids' => [$row['fee_structure_id']],
                        'particular' => $row['particular'] ?? 'Unknown Particular',
                        'amount' => (float)$row['fee_amount'],
                        'frequency' => $row['frequency'],
                        'custom_frequency' => (int)$row['custom_frequency'],
                        'applicable_months' => $row['applicable_months']
                    ];
                } else {
                    // Add additional fee_structure_id
                    $fee_structures_by_particular[$particular_id]['fee_structure_ids'][] = $row['fee_structure_id'];
                    // Do not aggregate amounts for any frequency; use the first amount
                    continue;
                }
            }

            // Step 6: Calculate total session fee and pending amounts
            foreach ($fee_structures_by_particular as $particular_id => $data) {
                $fee_structure_ids = $data['fee_structure_ids'];
                $amount = $data['amount'];
                $frequency = $data['frequency'];
                $custom_frequency = $data['custom_frequency'];
                $applicable_months = $data['applicable_months'];

                // Calculate total fee for the session based on frequency
                if ($frequency === 'monthly') {
                    // Monthly fee applies to all 12 months in the session
                    $session_fee = $amount * count($session_months);
                    $per_collection = $amount;
                } elseif ($frequency === 'annual') {
                    // Annual fee applies once per session
                    $session_fee = $amount;
                    $per_collection = $amount;
                } elseif ($frequency === 'other') {
                    // 'other' frequency: Calculate number of collections in the session
                    $collections_per_year = floor(12 / $custom_frequency);
                    $session_fee = $amount * $collections_per_year;
                    $per_collection = $amount; // Amount per collection
                } else {
                    // Default to one-time fee
                    $session_fee = $amount;
                    $per_collection = $amount;
                }

                $total_session_fee += $session_fee;

                // Fetch payments for all fee_structure_ids of this particular
                $fee_payments = array_filter($payments, fn($p) => in_array($p['fee_structure_id'], $fee_structure_ids));
                $collected_amount = 0;
                $remaining_balance = $session_fee; // Default to session fee
                $payment_months = [];
                $pending_months = [];
                $pending_collections = 0;

                foreach ($fee_payments as $payment) {
                    $collected_amount += (float)$payment['amount_collected'];
                    $remaining_balance = (float)$payment['remaining_balance']; // Use latest remaining_balance
                    $payment_months = array_unique(array_merge(
                        $payment_months,
                        array_map('intval', array_filter(explode(',', $payment['payment_month'])))
                    ));
                }

                $total_paid_amount += $collected_amount;

                // Use the first fee_structure_id for linking in the UI
                $fee_structure_id = $fee_structure_ids[0];

                // Calculate pending months/collections and status
                if ($frequency === 'monthly') {
                    // Determine applicable months
                    if (strtolower($applicable_months) === 'all') {
                        $applicable = $session_months;
                    } else {
                        $applicable = array_map('intval', array_filter(explode(',', $applicable_months)));
                        $applicable = array_intersect($applicable, $session_months);
                    }

                    // Find pending months
                    $pending_months = array_diff($applicable, $payment_months);
                    $pending_amount = max(0, $session_fee - $collected_amount);
                    $remaining_balance = max(0, $session_fee - $collected_amount);

                    // Determine status based on whether the fee is fully paid
                    $status = ($collected_amount >= $session_fee) ? 'paid' : 'unpaid';
                } elseif ($frequency === 'other') {
                    // Calculate total expected collections
                    $total_collections = floor(12 / $custom_frequency);
                    $session_fee = $per_collection * $total_collections; // Recalculate to ensure accuracy
                    $remaining_balance = max(0, $session_fee - $collected_amount); // Adjust remaining balance

                    // If fully paid, set status to paid and pending to 0
                    if ($collected_amount >= $session_fee) {
                        $status = 'paid';
                        $pending_amount = 0;
                        $remaining_balance = 0;
                    } else {
                        // Determine collection months (e.g., for custom_frequency = 4, collections in April, August, December)
                        $collection_months = [];
                        $start_month = 4; // April (session start)
                        for ($i = 0; $i < $total_collections; $i++) {
                            $month = ($start_month + ($i * $custom_frequency) - 1) % 12 + 1;
                            $collection_months[] = $month;
                        }

                        // Count paid collections by checking payment_months against collection_months
                        $collections_paid = 0;
                        foreach ($collection_months as $due_month) {
                            if (in_array($due_month, $payment_months)) {
                                $collections_paid++;
                            }
                        }

                        $pending_collections = max(0, $total_collections - $collections_paid);
                        $pending_amount = max(0, $session_fee - $collected_amount);

                        // Determine status: Check if a collection is due on or before the current month and unpaid
                        $is_current_due = false;
                        foreach ($collection_months as $due_month) {
                            if ($due_month <= $current_month && !in_array($due_month, $payment_months)) {
                                $is_current_due = true;
                                break;
                            }
                        }
                        $status = $is_current_due ? 'unpaid' : 'paid';
                    }
                } elseif ($frequency === 'annual') {
                    // Annual fee: Paid if any payment exists in the session
                    $is_paid = $collected_amount >= $session_fee;
                    $pending_amount = $is_paid ? 0 : $session_fee - $collected_amount;
                    $remaining_balance = max(0, $session_fee - $collected_amount);
                    $status = $is_paid ? 'paid' : 'unpaid';
                } else {
                    // Default one-time fee
                    $is_paid = $collected_amount >= $session_fee;
                    $pending_amount = $is_paid ? 0 : $session_fee - $collected_amount;
                    $remaining_balance = max(0, $session_fee - $collected_amount);
                    $status = $is_paid ? 'paid' : 'unpaid';
                }

                // Calculate due date
                $due_date = $this->calculateDueDate($frequency, $applicable_months, $current_month, $session_start_year);

                // Add to fee details (current month focus)
                if ($status === 'unpaid' || $collected_amount > 0) {
                    $fee_details[] = [
                        'id' => $fee_structure_id,
                        'title' => $data['particular'],
                        'amount' => $per_collection,
                        'collected_amount' => $collected_amount,
                        'remaining_balance' => $remaining_balance,
                        'payment_months' => array_map(fn($m) => $month_names[$m], $payment_months),
                        'due_date' => $due_date,
                        'status' => $status
                    ];
                }

                // Add to session summary
                $session_summary[] = [
                    'title' => $data['particular'],
                    'session_fee' => $session_fee,
                    'paid_amount' => $collected_amount,
                    'pending_amount' => $pending_amount
                ];
            }

            $total_remaining_fee = $total_session_fee - $total_paid_amount;

            // Step 7: Log final data
            error_log('Final fee data: ' . json_encode([
                'class' => $class,
                'current_session' => $current_session,
                'total_session_fee' => $total_session_fee,
                'paid_amount' => $total_paid_amount,
                'remaining_fee' => $total_remaining_fee,
                'fee_details' => $fee_details,
                'session_summary' => $session_summary
            ]));

            return [
                'class' => $class,
                'current_session' => $current_session,
                'total_session_fee' => $total_session_fee,
                'paid_amount' => $total_paid_amount,
                'remaining_fee' => $total_remaining_fee,
                'fee_details' => $fee_details,
                'session_summary' => $session_summary
            ];
        } catch (PDOException $e) {
            error_log('Fee data fetch failed: ' . $e->getMessage());
            return [
                'class' => null,
                'current_session' => null,
                'total_session_fee' => 0,
                'paid_amount' => 0,
                'remaining_fee' => 0,
                'fee_details' => [],
                'session_summary' => [],
                'error' => 'Database error occurred while fetching fee data.'
            ];
        }
    }

    private function calculateDueDate($frequency, $applicable_months, $current_month, $session_start_year) {
        $month_names = [
            1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
            5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
            9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
        ];

        // Default due date: 10th of the month
        $due_day = 10;
        $due_year = $session_start_year;
        $due_month = 4; // Default to April (session start)

        if ($frequency === 'monthly') {
            if (strtolower($applicable_months) === 'all') {
                $due_month = $current_month;
            } else {
                $months = array_map('intval', array_filter(explode(',', $applicable_months)));
                $due_month = in_array($current_month, $months) ? $current_month : $months[0] ?? 4;
            }
        } elseif ($frequency === 'annual') {
            $due_month = 4; // Annual fees due in April
        } elseif ($frequency === 'other') {
            $due_month = 4; // Default to April for first collection
            if (strtolower($applicable_months) !== 'all') {
                $months = array_map('intval', array_filter(explode(',', $applicable_months)));
                $due_month = $months[0] ?? 4;
            }
        }

        // Adjust year for months January to March
        if ($due_month < 4) {
            $due_year = $session_start_year + 1;
        }

        try {
            $due_date_str = sprintf('%d-%02d-%02d', $due_year, $due_month, $due_day);
            $due_date = (new DateTime($due_date_str))->format('F j, Y');
        } catch (Exception $e) {
            error_log('Failed to parse due date: ' . $due_date_str . ' - ' . $e->getMessage());
            $due_date = $month_names[$due_month] . ' ' . $due_day . ', ' . $due_year;
        }

        return $due_date;
    }
}

// Initialize PDO
try {
    error_log('Attempting database connection');
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
    error_log('Database connection successful');
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session and attempt recovery via cookie
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    error_log('Session variables missing, attempting cookie recovery');
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
            error_log('Session recovered via cookie for user_id ' . $user['id']);
        } else {
            error_log('Cookie-based session recovery failed for android_uid ' . $_COOKIE['android_uid']);
            setcookie('session_token', '', time() - 3600, '/', '', true, true);
            setcookie('android_uid', '', time() - 3600, '/', '', true, true);
            header("Location: /android/");
            exit;
        }
    } else {
        error_log('No session or cookie data available, redirecting to login');
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    error_log('Session validation failed for user_id ' . $_SESSION['user_id']);
    header("Location: /android/?session_expired=true");
    exit;
}

// Initialize FeeManager with current date
$current_date = '2025-06-06 14:57:00'; // Updated to 02:57 PM IST on June 06, 2025
$feeManager = new FeeManager($pdo, $_SESSION['user_id'], $current_date);

// Fetch fee data
$fee_data = $feeManager->getFeeData();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>EduConnect - Fee Dues</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --unpaid-color: #ff4500;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }
        
        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .fee-summary {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .fee-card {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .fee-label {
            font-size: 16px;
            font-weight: 500;
        }
        
        .fee-value {
            font-size: 18px;
            font-weight: 600;
        }
        
        .fee-value.paid {
            color: var(--success-color);
        }
        
        .fee-value.unpaid {
            color: var(--unpaid-color);
        }
        
        .fee-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .fee-item {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        .fee-item.paid {
            border-left-color: var(--success-color);
        }
        
        .fee-item.unpaid {
            border-left-color: var(--unpaid-color);
        }
        
        .fee-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 10px;
        }
        
        .fee-title {
            font-size: 16px;
            font-weight: 600;
        }
        
        .fee-status {
            font-size: 12px;
            padding: 4px 8px;
            border-radius: 12px;
            font-weight: 500;
        }
        
        .status-paid {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-unpaid {
            background-color: #ffe5e5;
            color: var(--unpaid-color);
        }
        
        .fee-meta {
            display: flex;
            justify-content: space-between;
            font-size: 13px;
            color: var(--light-text);
            flex-wrap: wrap;
            gap: 5px;
        }
        
        .fee-date {
            display: flex;
            align-items: center;
        }
        
        .fee-date i {
            margin-right: 5px;
        }
        
        .fee-amount {
            display: flex;
            align-items: center;
        }
        
        .fee-amount i {
            margin-right: 5px;
        }
        
        .fee-collected {
            display: flex;
            align-items: center;
        }
        
        .fee-collected i {
            margin-right: 5px;
        }
        
        .fee-remaining {
            display: flex;
            align-items: center;
        }
        
        .fee-remaining i {
            margin-right: 5px;
        }
        
        .fee-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 10px;
        }
        
        .action-button {
            background-color: var(--secondary-color);
            border: none;
            border-radius: var(--border-radius);
            padding: 8px 15px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .action-button.primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .action-button:hover {
            opacity: 0.9;
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Empty state */
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
            text-align: center;
        }
        
        .empty-icon {
            font-size: 50px;
            color: #ccc;
            margin-bottom: 15px;
        }
        
        .empty-text {
            font-size: 16px;
            color: var(--light-text);
            margin-bottom: 20px;
        }
        
        /* Error message */
        .error-message {
            color: var(--danger-color);
            font-size: 14px;
            margin-top: 10px;
            text-align: center;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }
            
            .fee-title {
                font-size: 15px;
            }
            
            .fee-value {
                font-size: 16px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" onclick="navigateTo('modules.php')"></i>
        Fee Dues
    </div>
    
    <div class="section">
        <div class="section-title">Session Summary (<?php echo htmlspecialchars($fee_data['current_session']); ?>)</div>
        <div class="fee-summary">
            <div class="fee-card">
                <div class="fee-label">Total Fee for Session</div>
                <div class="fee-value">₹<?php echo number_format($fee_data['total_session_fee'], 2); ?></div>
            </div>
            <div class="fee-card">
                <div class="fee-label">Total Collected</div>
                <div class="fee-value paid">₹<?php echo number_format($fee_data['paid_amount'], 2); ?></div>
            </div>
            <div class="fee-card">
                <div class="fee-label">Remaining Fee</div>
                <div class="fee-value unpaid">₹<?php echo number_format($fee_data['remaining_fee'], 2); ?></div>
            </div>
        </div>
        <div class="section-title">Breakdown by Fee Type</div>
        <div class="fee-list">
            <?php foreach ($fee_data['session_summary'] as $summary): ?>
                <div class="fee-item">
                    <div class="fee-header">
                        <div class="fee-title"><?php echo htmlspecialchars($summary['title']); ?></div>
                    </div>
                    <div class="fee-meta">
                        <div class="fee-amount"><i class="fas fa-coins"></i> Total for Session: ₹<?php echo number_format($summary['session_fee'], 2); ?></div>
                        <div class="fee-collected"><i class="fas fa-money-bill-wave"></i> Collected: ₹<?php echo number_format($summary['paid_amount'], 2); ?></div>
                        <div class="fee-remaining"><i class="fas fa-exclamation-circle"></i> Pending: ₹<?php echo number_format($summary['pending_amount'], 2); ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="section">
        <div class="section-title">Current Fee Details</div>
        <div class="fee-list" id="fee-list">
            <?php if (empty($fee_data['fee_details'])): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-file-invoice-dollar"></i>
                    </div>
                    <div class="empty-text">
                        <?php echo isset($fee_data['error']) ? htmlspecialchars($fee_data['error']) : 'No fee dues found.'; ?>
                    </div>
                    <?php if (isset($fee_data['error'])): ?>
                        <div class="error-message">
                            Please contact support if this issue persists.
                        </div>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <?php foreach ($fee_data['fee_details'] as $fee): ?>
                    <div class="fee-item <?php echo htmlspecialchars($fee['status']); ?>">
                        <div class="fee-header">
                            <div class="fee-title"><?php echo htmlspecialchars($fee['title']); ?></div>
                            <div class="fee-status status-<?php echo htmlspecialchars($fee['status']); ?>">
                                <?php echo ucfirst(htmlspecialchars($fee['status'])); ?>
                            </div>
                        </div>
                        <div class="fee-meta">
                            <div class="fee-date">
                                <i class="far fa-calendar-alt"></i> Due: <?php echo htmlspecialchars($fee['due_date']); ?>
                            </div>
                            <div class="fee-amount">
                                <i class="fas fa-coins"></i> Amount: ₹<?php echo number_format($fee['amount'], 2); ?>
                            </div>
                            <?php if ($fee['collected_amount'] > 0): ?>
                                <div class="fee-collected">
                                    <i class="fas fa-money-bill-wave"></i> Collected: ₹<?php echo number_format($fee['collected_amount'], 2); ?>
                                </div>
                            <?php endif; ?>
                            <div class="fee-remaining">
                                <i class="fas fa-exclamation-circle"></i> Remaining: ₹<?php echo number_format($fee['remaining_balance'], 2); ?>
                            </div>
                        </div>
                        <?php if ($fee['status'] === 'unpaid'): ?>
                            <div class="fee-actions">
                                <button class="action-button" onclick="navigateTo('fee_details.php?id=<?php echo $fee['id']; ?>')">
                                    <i class="far fa-eye"></i> View Details
                                </button>
                                <button class="action-button primary" onclick="navigateTo('pay_fee.php?id=<?php echo $fee['id']; ?>')">
                                    <i class="fas fa-credit-card"></i> Pay Now
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="modules.php" class="footer-item active ripple">
            <i class="fas fa-th footer-icon"></i>
            <span class="footer-text">Modules</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loader = document.getElementById('loader');

            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }

            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }

            // Navigate with loader
            window.navigateTo = function(url) {
                showLoader();
                setTimeout(() => {
                    window.location.href = url;
                }, 300);
            };

            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>