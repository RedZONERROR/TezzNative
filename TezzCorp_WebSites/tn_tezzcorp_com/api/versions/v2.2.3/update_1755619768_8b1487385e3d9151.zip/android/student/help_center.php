<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch site settings
try {
    $stmt = $pdo->prepare('SELECT school_name, facebook_url, twitter_url, instagram_url, linkedin_url FROM site_settings WHERE id = 1');
    $stmt->execute();
    $settings = $stmt->fetch();
    
    if (!$settings) {
        $settings = [
            'school_name' => 'EduConnect',
            'facebook_url' => '#',
            'twitter_url' => '#',
            'instagram_url' => '#',
            'linkedin_url' => '#'
        ];
    }
} catch (PDOException $e) {
    error_log('Failed to fetch site settings: ' . $e->getMessage());
    $settings = [
        'school_name' => 'EduConnect',
        'facebook_url' => '#',
        'twitter_url' => '#',
        'instagram_url' => '#',
        'linkedin_url' => '#'
    ];
}

$school_name = htmlspecialchars($settings['school_name']);
$facebook_url = htmlspecialchars($settings['facebook_url']);
$twitter_url = htmlspecialchars($settings['twitter_url']);
$instagram_url = htmlspecialchars($settings['instagram_url']);
$linkedin_url = htmlspecialchars($settings['linkedin_url']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $school_name; ?> - Help Center</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }
        
        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .help-categories {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .help-category {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            transition: var(--transition);
            cursor: pointer;
        }
        
        .help-category:hover {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }
        
        .category-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: rgba(0, 85, 164, 0.1);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-right: 15px;
            flex-shrink: 0;
        }
        
        .category-details {
            flex: 1;
        }
        
        .category-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .category-description {
            font-size: 14px;
            color: var(--light-text);
        }
        
        .category-arrow {
            color: var(--light-text);
            margin-left: 10px;
        }
        
        .faq-section {
            margin-top: 20px;
        }
        
        .faq-item {
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 15px;
        }
        
        .faq-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        
        .faq-question {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
        }
        
        .faq-question i {
            transition: var(--transition);
        }
        
        .faq-question.active i {
            transform: rotate(180deg);
        }
        
        .faq-answer {
            font-size: 14px;
            color: var(--light-text);
            display: none;
            padding: 10px 0;
        }
        
        .faq-answer.active {
            display: block;
        }
        
        .search-container {
            margin-bottom: 20px;
        }
        
        .search-bar {
            display: flex;
            align-items: center;
            background-color: white;
            border-radius: 30px;
            padding: 12px 20px;
            box-shadow: var(--box-shadow);
            transition: var(--transition);
        }
        
        .search-bar:focus-within {
            box-shadow: var(--hover-shadow);
        }
        
        .search-bar i {
            color: var(--light-text);
            margin-right: 12px;
            font-size: 18px;
        }
        
        .search-bar input {
            border: none;
            outline: none;
            width: 100%;
            font-size: 16px;
            color: var(--text-color);
            background: transparent;
        }
        
        .search-bar input::placeholder {
            color: #adb5bd;
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        .social-links {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }
        
        .social-link {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--secondary-color);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: var(--transition);
        }
        
        .social-link:hover {
            background-color: var(--primary-color);
            color: white;
            transform: translateY(-3px);
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }
            
            .category-title {
                font-size: 15px;
            }
            
            .category-description {
                font-size: 13px;
            }
            
            .faq-question {
                font-size: 15px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" id="back-button"></i>
        Help Center
    </div>
    
    <div class="section">
        <div class="search-container">
            <div class="search-bar">
                <i class="fas fa-search"></i>
                <input type="text" placeholder="Search for help..." id="search-input">
            </div>
        </div>
        
        <div class="help-categories">
            <div class="help-category" id="getting-started">
                <div class="category-icon">
                    <i class="fas fa-rocket"></i>
                </div>
                <div class="category-details">
                    <div class="category-title">Getting Started</div>
                    <div class="category-description">Learn the basics of using the app</div>
                </div>
                <div class="category-arrow">
                    <i class="fas fa-chevron-right"></i>
                </div>
            </div>
            
            <div class="help-category" id="account-management">
                <div class="category-icon">
                    <i class="fas fa-user-cog"></i>
                </div>
                <div class="category-details">
                    <div class="category-title">Account Management</div>
                    <div class="category-description">Manage your account settings</div>
                </div>
                <div class="category-arrow">
                    <i class="fas fa-chevron-right"></i>
                </div>
            </div>
            
            <div class="help-category" id="fees-payments">
                <div class="category-icon">
                    <i class="fas fa-credit-card"></i>
                </div>
                <div class="category-details">
                    <div class="category-title">Fees & Payments</div>
                    <div class="category-description">Help with fee payments and receipts</div>
                </div>
                <div class="category-arrow">
                    <i class="fas fa-chevron-right"></i>
                </div>
            </div>
            
            <div class="help-category" id="academic-support">
                <div class="category-icon">
                    <i class="fas fa-book"></i>
                </div>
                <div class="category-details">
                    <div class="category-title">Academic Support</div>
                    <div class="category-description">Help with homework and assignments</div>
                </div>
                <div class="category-arrow">
                    <i class="fas fa-chevron-right"></i>
                </div>
            </div>
            
            <div class="help-category" id="technical-issues">
                <div class="category-icon">
                    <i class="fas fa-tools"></i>
                </div>
                <div class="category-details">
                    <div class="category-title">Technical Issues</div>
                    <div class="category-description">Troubleshoot common problems</div>
                </div>
                <div class="category-arrow">
                    <i class="fas fa-chevron-right"></i>
                </div>
            </div>
        </div>
    </div>
    
    <div class="section faq-section">
        <div class="section-title">Frequently Asked Questions</div>
        <div class="faq-list">
            <div class="faq-item">
                <div class="faq-question">
                    How do I reset my password?
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    To reset your password, go to the login screen and click on "Forgot Password". Enter your registered email or phone number, and follow the instructions sent to you to create a new password.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    How can I view my homework assignments?
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    You can view your homework assignments by navigating to the "Homework" module from either the Dashboard or the Modules page. Here you'll find all your pending, completed, and overdue assignments.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    How do I pay my school fees online?
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    To pay fees online, go to the "Fees & Dues" section in the Modules page, then select "Pay Fee". You can choose from various payment methods including credit/debit cards, bank transfers, or digital wallets.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    How can I contact my teachers?
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    You can contact your teachers through the "My Teachers" section in the Modules page. Select the teacher you wish to contact, and you'll find options to call, email, or send a message directly through the app.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    How do I view my attendance record?
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    Your attendance summary is displayed on your Account page. For a detailed attendance record, navigate to the Modules page and select the "Attendance" module where you can view daily, weekly, and monthly attendance reports.
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="modules.php" class="footer-item ripple">
            <i class="fas fa-th footer-icon"></i>
            <span class="footer-text">Modules</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple active">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>
    
    <!-- Social Links -->
    <div class="social-links">
        <a href="<?php echo $facebook_url; ?>" class="social-link">
            <i class="fab fa-facebook-f"></i>
        </a>
        <a href="<?php echo $twitter_url; ?>" class="social-link">
            <i class="fab fa-twitter"></i>
        </a>
        <a href="<?php echo $instagram_url; ?>" class="social-link">
            <i class="fab fa-instagram"></i>
        </a>
        <a href="<?php echo $linkedin_url; ?>" class="social-link">
            <i class="fab fa-linkedin-in"></i>
        </a>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            // Back button functionality
            document.getElementById('back-button').addEventListener('click', function() {
                showLoader();
                window.location.href = 'setting.php';
            });
            
            // FAQ toggle functionality
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', function() {
                    // Toggle active class on question
                    this.classList.toggle('active');
                    
                    // Toggle active class on answer
                    const answer = this.nextElementSibling;
                    answer.classList.toggle('active');
                });
            });
            
            // Help category click handlers
            document.getElementById('getting-started').addEventListener('click', function() {
                // For demo purposes, just show an alert
                alert('Getting Started guide will be available soon.');
            });
            
            document.getElementById('account-management').addEventListener('click', function() {
                alert('Account Management guide will be available soon.');
            });
            
            document.getElementById('fees-payments').addEventListener('click', function() {
                alert('Fees & Payments guide will be available soon.');
            });
            
            document.getElementById('academic-support').addEventListener('click', function() {
                alert('Academic Support guide will be available soon.');
            });
            
            document.getElementById('technical-issues').addEventListener('click', function() {
                alert('Technical Issues guide will be available soon.');
            });
            
            // Search functionality
            const searchInput = document.getElementById('search-input');
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                
                // For demo purposes, just log the search term
                console.log('Searching for:', searchTerm);
                
                // In a real implementation, you would filter FAQs and categories based on the search term
            });
            
            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }
            
            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>