<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch site settings
try {
    $stmt = $pdo->prepare('SELECT school_name, email, address, phone, facebook_url, twitter_url, instagram_url, linkedin_url FROM site_settings WHERE id = 1');
    $stmt->execute();
    $settings = $stmt->fetch();
    
    if (!$settings) {
        $settings = [
            'school_name' => 'EduConnect',
            'email' => 'legal@educonnect.com',
            'address' => '123 Education Street, Learning City, LC 12345',
            'phone' => '+1 (555) 123-4567',
            'facebook_url' => '#',
            'twitter_url' => '#',
            'instagram_url' => '#',
            'linkedin_url' => '#'
        ];
    }
} catch (PDOException $e) {
    error_log('Failed to fetch site settings: ' . $e->getMessage());
    $settings = [
        'school_name' => 'EduConnect',
        'email' => 'legal@educonnect.com',
        'address' => '123 Education Street, Learning City, LC 12345',
        'phone' => '+1 (555) 123-4567',
        'facebook_url' => '#',
        'twitter_url' => '#',
        'instagram_url' => '#',
        'linkedin_url' => '#'
    ];
}

$school_name = htmlspecialchars($settings['school_name']);
$email = htmlspecialchars($settings['email']);
$address = htmlspecialchars($settings['address']);
$phone = htmlspecialchars($settings['phone']);
$facebook_url = htmlspecialchars($settings['facebook_url']);
$twitter_url = htmlspecialchars($settings['twitter_url']);
$instagram_url = htmlspecialchars($settings['instagram_url']);
$linkedin_url = htmlspecialchars($settings['linkedin_url']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Educational App - Terms & Conditions</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }
        
        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .terms-content {
            font-size: 15px;
            line-height: 1.6;
            color: var(--text-color);
        }
        
        .terms-content p {
            margin-bottom: 15px;
        }
        
        .terms-content h3 {
            font-size: 18px;
            font-weight: 600;
            margin: 25px 0 15px;
            color: var(--primary-color);
        }
        
        .terms-content ul {
            margin-bottom: 15px;
            padding-left: 20px;
        }
        
        .terms-content li {
            margin-bottom: 8px;
        }
        
        .terms-date {
            font-style: italic;
            color: var(--light-text);
            margin-top: 30px;
            font-size: 14px;
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        .social-links {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }
        
        .social-link {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--secondary-color);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: var(--transition);
        }
        
        .social-link:hover {
            background-color: var(--primary-color);
            color: white;
            transform: translateY(-3px);
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }
            
            .terms-content {
                font-size: 14px;
            }
            
            .terms-content h3 {
                font-size: 16px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" id="back-button"></i>
        Terms & Conditions
    </div>
    
    <div class="section">
        <div class="terms-content">
            <p>Please read these Terms and Conditions ("Terms", "Terms and Conditions") carefully before using the <?php echo $school_name; ?> mobile application (the "App") operated by <?php echo $school_name; ?> ("us", "we", or "our").</p>
            
            <p>Your access to and use of the App is conditioned on your acceptance of and compliance with these Terms. These Terms apply to all visitors, users, and others who access or use the App.</p>
            
            <p>By accessing or using the App, you agree to be bound by these Terms. If you disagree with any part of the terms, then you may not access the App.</p>
            
            <h3>1. User Accounts</h3>
            <p>When you create an account with us, you must provide accurate, complete, and current information at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account on our App.</p>
            
            <p>You are responsible for safeguarding the password that you use to access the App and for any activities or actions under your password. You agree not to disclose your password to any third party. You must notify us immediately upon becoming aware of any breach of security or unauthorized use of your account.</p>
            
            <h3>2. Acceptable Use</h3>
            <p>You agree to use the App only for lawful purposes and in a way that does not infringe the rights of, restrict, or inhibit anyone else's use and enjoyment of the App. Prohibited behavior includes:</p>
            <ul>
                <li>Conducting any fraudulent, abusive, or illegal activity</li>
                <li>Posting or transmitting harmful or malicious code</li>
                <li>Attempting to gain unauthorized access to our systems or user accounts</li>
                <li>Harassing, bullying, or intimidating other users</li>
                <li>Posting content that is defamatory, obscene, or otherwise objectionable</li>
                <li>Using the App to distribute unsolicited promotional or commercial content</li>
                <li>Impersonating another person or misrepresenting your affiliation with a person or entity</li>
            </ul>
            
            <h3>3. Educational Content and Services</h3>
            <p>The App provides access to educational content, tools, and services. While we strive to ensure the accuracy and quality of the content, we make no guarantees regarding its completeness or reliability.</p>
            
            <p>Educational content provided through the App is for informational purposes only and should not be considered a substitute for professional educational advice or formal educational programs.</p>
            
            <h3>4. Payments and Fees</h3>
            <p>Certain features of the App may require payment of fees. You agree to pay all fees and charges incurred in connection with your use of the App at the rates in effect when the charges were incurred.</p>
            
            <p>All fees are non-refundable unless otherwise specified. We reserve the right to change our fees at any time, upon notice through the App or by email.</p>
            
            <h3>5. Intellectual Property</h3>
            <p>The App and its original content, features, and functionality are and will remain the exclusive property of <?php echo $school_name; ?> and its licensors. The App is protected by copyright, trademark, and other laws of both the United States and foreign countries.</p>
            
            <p>Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of <?php echo $school_name; ?>.</p>
            
            <h3>6. User Content</h3>
            <p>Our App may allow you to post, link, store, share and otherwise make available certain information, text, graphics, videos, or other material. You are responsible for the content that you post to the App, including its legality, reliability, and appropriateness.</p>
            
            <p>By posting content to the App, you grant us the right to use, modify, publicly perform, publicly display, reproduce, and distribute such content on and through the App. You retain any and all of your rights to any content you submit, post or display on or through the App and you are responsible for protecting those rights.</p>
            
            <h3>7. Termination</h3>
            <p>We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.</p>
            
            <p>Upon termination, your right to use the App will immediately cease. If you wish to terminate your account, you may simply discontinue using the App or contact us to request account deletion.</p>
            
            <h3>8. Limitation of Liability</h3>
            <p>In no event shall <?php echo $school_name; ?>, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from:</p>
            <ul>
                <li>Your access to or use of or inability to access or use the App</li>
                <li>Any conduct or content of any third party on the App</li>
                <li>Any content obtained from the App</li>
                <li>Unauthorized access, use or alteration of your transmissions or content</li>
            </ul>
            
            <h3>9. Governing Law</h3>
            <p>These Terms shall be governed and construed in accordance with the laws of the United States, without regard to its conflict of law provisions.</p>
            
            <p>Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights. If any provision of these Terms is held to be invalid or unenforceable by a court, the remaining provisions of these Terms will remain in effect.</p>
            
            <h3>10. Changes to Terms</h3>
            <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will provide notice of any changes by posting the new Terms on this page and updating the "Last Updated" date.</p>
            
            <p>Your continued use of the App after any such changes constitutes your acceptance of the new Terms. Please review these Terms periodically for changes.</p>
            
            <h3>11. Contact Us</h3>
            <p>If you have any questions about these Terms, please contact us at:</p>
            <p>Email: <?php echo $email; ?><br>
            Phone: <?php echo $phone; ?><br>
            Address: <?php echo $address; ?></p>
            
            <div class="terms-date">Last Updated: June 1, 2025</div>
        </div>
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="modules.php" class="footer-item ripple">
            <i class="fas fa-th footer-icon"></i>
            <span class="footer-text">Modules</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple active">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>
    
    <!-- Social Links -->
    <div class="social-links">
        <a href="<?php echo $facebook_url; ?>" class="social-link">
            <i class="fab fa-facebook-f"></i>
        </a>
        <a href="<?php echo $twitter_url; ?>" class="social-link">
            <i class="fab fa-twitter"></i>
        </a>
        <a href="<?php echo $instagram_url; ?>" class="social-link">
            <i class="fab fa-instagram"></i>
        </a>
        <a href="<?php echo $linkedin_url; ?>" class="social-link">
            <i class="fab fa-linkedin-in"></i>
        </a>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            // Back button functionality
            document.getElementById('back-button').addEventListener('click', function() {
                showLoader();
                window.location.href = 'setting.php';
            });
            
            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }
            
            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>