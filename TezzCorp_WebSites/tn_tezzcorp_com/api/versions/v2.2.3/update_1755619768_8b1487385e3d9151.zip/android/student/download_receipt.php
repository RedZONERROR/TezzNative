<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// FeeManager class to handle fee operations
class FeeManager {
    private $pdo;
    private $user_id;

    public function __construct(PDO $pdo, $user_id) {
        $this->pdo = $pdo;
        $this->user_id = $user_id;
    }

    public function getReceiptDetails($fee_collection_id) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT fc.id, fc.student_id, fc.amount_collected, fc.discount, fc.payment_date, fc.payment_month, 
                        fc.payment_method, fs.particular_id, p.particular 
                FROM fee_collections fc 
                JOIN fee_structure fs ON fc.fee_structure_id = fs.id 
                JOIN particulars p ON fs.particular_id = p.id 
                WHERE fc.id = :id 
                AND fc.student_id = :student_id 
                AND fc.status = "paid" 
                AND fs.status = "active" 
                AND p.status = "active"'
            );
            $stmt->execute([
                ':id' => $fee_collection_id,
                ':student_id' => $this->user_id
            ]);
            $receipt = $stmt->fetch();

            if ($receipt) {
                return [
                    'id' => $receipt['id'],
                    'fee_title' => $receipt['particular'],
                    'fee_description' => "Payment for {$receipt['payment_month']}",
                    'payment_reference' => "FEE-{$receipt['id']}",
                    'payment_date' => date('F j, Y', strtotime($receipt['payment_date'])),
                    'amount' => $receipt['amount_collected'],
                    'discount' => $receipt['discount'],
                    'payment_method' => $receipt['payment_method']
                ];
            }
            return null;
        } catch (PDOException $e) {
            error_log('Receipt details fetch failed: ' . $e->getMessage());
            return null;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Get fee_collection_id from URL
$fee_collection_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($fee_collection_id <= 0) {
    header("Location: fee_receipts.php");
    exit;
}

// Initialize FeeManager
$feeManager = new FeeManager($pdo, $_SESSION['user_id']);

// Fetch receipt details
$receipt = $feeManager->getReceiptDetails($fee_collection_id);
if (!$receipt) {
    header("Location: fee_receipts.php");
    exit;
}

// Generate receipt content
$receipt_content = "===== Fee Receipt =====\n\n";
$receipt_content .= "Payment Reference: {$receipt['payment_reference']}\n";
$receipt_content .= "Fee Type: {$receipt['fee_title']}\n";
$receipt_content .= "Description: {$receipt['fee_description']}\n";
$receipt_content .= "Payment Date: {$receipt['payment_date']}\n";
$receipt_content .= "Amount Paid: ₹" . number_format($receipt['amount'], 2) . "\n";
$receipt_content .= "Discount: ₹" . number_format($receipt['discount'], 2) . "\n";
$receipt_content .= "Payment Method: {$receipt['payment_method']}\n";
$receipt_content .= "\n===== End of Receipt =====";

// Set headers for download
header('Content-Type: text/plain');
header('Content-Disposition: attachment; filename="receipt_' . $receipt['payment_reference'] . '.txt"');
header('Content-Length: ' . strlen($receipt_content));

// Output the receipt content
echo $receipt_content;
exit;