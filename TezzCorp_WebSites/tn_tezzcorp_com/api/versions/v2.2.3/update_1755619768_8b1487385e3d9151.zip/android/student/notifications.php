<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch site settings
try {
    $stmt = $pdo->prepare('SELECT school_name, facebook_url, twitter_url, instagram_url, linkedin_url FROM site_settings WHERE id = 1');
    $stmt->execute();
    $settings = $stmt->fetch();
    
    if (!$settings) {
        $settings = [
            'school_name' => 'EduConnect',
            'facebook_url' => '#',
            'twitter_url' => '#',
            'instagram_url' => '#',
            'linkedin_url' => '#'
        ];
    }
} catch (PDOException $e) {
    error_log('Failed to fetch site settings: ' . $e->getMessage());
    $settings = [
        'school_name' => 'EduConnect',
        'facebook_url' => '#',
        'twitter_url' => '#',
        'instagram_url' => '#',
        'linkedin_url' => '#'
    ];
}

$school_name = htmlspecialchars($settings['school_name']);
$facebook_url = htmlspecialchars($settings['facebook_url']);
$twitter_url = htmlspecialchars($settings['twitter_url']);
$instagram_url = htmlspecialchars($settings['instagram_url']);
$linkedin_url = htmlspecialchars($settings['linkedin_url']);

// Handle notification actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $notification_id = isset($_POST['notification_id']) ? (int)$_POST['notification_id'] : 0;
    
    try {
        if ($action === 'read' && $notification_id > 0) {
            $stmt = $pdo->prepare(
                'UPDATE notifications 
                SET is_read = 1 
                WHERE id = :notification_id 
                AND user_id = :user_id 
                AND user_type = :user_type'
            );
            $stmt->execute([
                ':notification_id' => $notification_id,
                ':user_id' => $_SESSION['user_id'],
                ':user_type' => $_SESSION['user_type']
            ]);
        } elseif ($action === 'delete' && $notification_id > 0) {
            $stmt = $pdo->prepare(
                'DELETE FROM notifications 
                WHERE id = :notification_id 
                AND user_id = :user_id 
                AND user_type = :user_type'
            );
            $stmt->execute([
                ':notification_id' => $notification_id,
                ':user_id' => $_SESSION['user_id'],
                ':user_type' => $_SESSION['user_type']
            ]);
        } elseif ($action === 'read_all') {
            $stmt = $pdo->prepare(
                'UPDATE notifications 
                SET is_read = 1 
                WHERE user_id = :user_id 
                AND user_type = :user_type'
            );
            $stmt->execute([
                ':user_id' => $_SESSION['user_id'],
                ':user_type' => $_SESSION['user_type']
            ]);
        } elseif ($action === 'delete_all') {
            $stmt = $pdo->prepare(
                'DELETE FROM notifications 
                WHERE user_id = :user_id 
                AND user_type = :user_type'
            );
            $stmt->execute([
                ':user_id' => $_SESSION['user_id'],
                ':user_type' => $_SESSION['user_type']
            ]);
        }
    } catch (PDOException $e) {
        error_log('Notification action failed: ' . $e->getMessage());
    }
    
    // Redirect to refresh the page
    header("Location: notifications.php");
    exit;
}

// Fetch notifications
$notifications = [];
try {
    $stmt = $pdo->prepare(
        'SELECT id, title, message, category, type, is_read, created_at, 
                TIMESTAMPDIFF(MINUTE, created_at, NOW()) AS minutes_ago 
        FROM notifications 
        WHERE user_id = :user_id 
        AND user_type = :user_type 
        ORDER BY created_at DESC'
    );
    $stmt->execute([
        ':user_id' => $_SESSION['user_id'],
        ':user_type' => $_SESSION['user_type']
    ]);
    $notifications = $stmt->fetchAll();
    
    // Format time ago
    foreach ($notifications as &$notification) {
        $minutes = $notification['minutes_ago'];
        if ($minutes < 60) {
            $notification['time_ago'] = $minutes . ' minute' . ($minutes !== 1 ? 's' : '') . ' ago';
        } elseif ($minutes < 1440) {
            $hours = floor($minutes / 60);
            $notification['time_ago'] = $hours . ' hour' . ($hours !== 1 ? 's' : '') . ' ago';
        } else {
            $days = floor($minutes / 1440);
            $notification['time_ago'] = $days . ' day' . ($days !== 1 ? 's' : '') . ' ago';
        }
    }
} catch (PDOException $e) {
    error_log('Failed to fetch notifications: ' . $e->getMessage());
    $notifications = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $school_name; ?> - Notifications</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --info-color: #17a2b8;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }
        
        .header-actions {
            display: flex;
            gap: 15px;
        }
        
        .header-icon {
            font-size: 20px;
            cursor: pointer;
        }
        
        .notification-list {
            padding: 15px;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .notification-item {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: var(--box-shadow);
            display: flex;
            gap: 15px;
            transition: var(--transition);
            cursor: pointer;
            position: relative;
        }
        
        .notification-item:hover {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }
        
        .notification-item.unread {
            border-left: 4px solid var(--primary-color);
        }
        
        .notification-item.unread::after {
            content: '';
            position: absolute;
            top: 15px;
            right: 15px;
            width: 10px;
            height: 10px;
            background-color: var(--primary-color);
            border-radius: 50%;
        }
        
        .notification-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            flex-shrink: 0;
        }
        
        .notification-icon.primary {
            background-color: rgba(0, 85, 164, 0.1);
            color: var(--primary-color);
        }
        
        .notification-icon.success {
            background-color: rgba(40, 167, 69, 0.1);
            color: var(--success-color);
        }
        
        .notification-icon.warning {
            background-color: rgba(255, 193, 7, 0.1);
            color: var(--warning-color);
        }
        
        .notification-icon.danger {
            background-color: rgba(220, 53, 69, 0.1);
            color: var(--danger-color);
        }
        
        .notification-icon.info {
            background-color: rgba(23, 162, 184, 0.1);
            color: var(--info-color);
        }
        
        .notification-content {
            flex: 1;
        }
        
        .notification-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .notification-message {
            font-size: 14px;
            color: var(--light-text);
            margin-bottom: 10px;
        }
        
        .notification-meta {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: var(--light-text);
        }
        
        .notification-time {
            display: flex;
            align-items: center;
        }
        
        .notification-time i {
            margin-right: 5px;
        }
        
        .notification-category {
            font-weight: 500;
        }
        
        .notification-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 10px;
        }
        
        .action-button {
            background-color: var(--secondary-color);
            border: none;
            border-radius: var(--border-radius);
            padding: 6px 12px;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .action-button.primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .action-button:hover {
            opacity: 0.9;
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        .social-links {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }
        
        .social-link {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--secondary-color);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: var(--transition);
        }
        
        .social-link:hover {
            background-color: var(--primary-color);
            color: white;
            transform: translateY(-3px);
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Empty state */
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 50px 30px;
            text-align: center;
        }
        
        .empty-icon {
            font-size: 50px;
            color: #ccc;
            margin-bottom: 15px;
        }
        
        .empty-text {
            font-size: 16px;
            color: var(--light-text);
            margin-bottom: 20px;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .notification-title {
                font-size: 15px;
            }
            
            .notification-message {
                font-size: 13px;
            }
            
            .notification-icon {
                width: 45px;
                height: 45px;
                font-size: 18px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <div>
            <i class="fas fa-arrow-left back-button" id="back-button"></i>
            Notifications
        </div>
        <div class="header-actions">
            <form method="POST" style="display: inline;">
                <input type="hidden" name="action" value="read_all">
                <button type="submit" class="header-icon" style="background: none; border: none; color: inherit;">
                    <i class="fas fa-check-double"></i>
                </button>
            </form>
            <form method="POST" style="display: inline;">
                <input type="hidden" name="action" value="delete_all">
                <button type="submit" class="header-icon" style="background: none; border: none; color: inherit;">
                    <i class="fas fa-trash"></i>
                </button>
            </form>
        </div>
    </div>
    
    <div class="notification-list" id="notification-list">
        <?php if (empty($notifications)): ?>
            <div class="empty-state">
                <div class="empty-icon">
                    <i class="fas fa-bell-slash"></i>
                </div>
                <div class="empty-text">No notifications found.</div>
            </div>
        <?php else: ?>
            <?php foreach ($notifications as $notification): ?>
                <?php
                // Determine icon class based on type
                $iconClass = 'primary';
                $iconName = 'fa-bell';
                switch ($notification['type']) {
                    case 'success':
                        $iconClass = 'success';
                        $iconName = 'fa-check-circle';
                        break;
                    case 'warning':
                        $iconClass = 'warning';
                        $iconName = 'fa-exclamation-triangle';
                        break;
                    case 'danger':
                        $iconClass = 'danger';
                        $iconName = 'fa-times-circle';
                        break;
                    case 'info':
                        $iconClass = 'info';
                        $iconName = 'fa-info-circle';
                        break;
                }
                ?>
                <div class="notification-item <?php echo $notification['is_read'] ? '' : 'unread'; ?>" data-id="<?php echo $notification['id']; ?>">
                    <div class="notification-icon <?php echo $iconClass; ?>">
                        <i class="fas <?php echo $iconName; ?>"></i>
                    </div>
                    <div class="notification-content">
                        <div class="notification-title"><?php echo htmlspecialchars($notification['title']); ?></div>
                        <div class="notification-message"><?php echo htmlspecialchars($notification['message']); ?></div>
                        <div class="notification-meta">
                            <div class="notification-time">
                                <i class="far fa-clock"></i> <?php echo htmlspecialchars($notification['time_ago']); ?>
                            </div>
                            <div class="notification-category"><?php echo htmlspecialchars($notification['category']); ?></div>
                        </div>
                        <div class="notification-actions">
                            <?php if (!$notification['is_read']): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="read">
                                    <input type="hidden" name="notification_id" value="<?php echo $notification['id']; ?>">
                                    <button type="submit" class="action-button mark-read">
                                        <i class="fas fa-check"></i> Mark as Read
                                    </button>
                                </form>
                            <?php endif; ?>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="notification_id" value="<?php echo $notification['id']; ?>">
                                <button type="submit" class="action-button delete-notification">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="modules.php" class="footer-item ripple active">
            <i class="fas fa-th footer-icon"></i>
            <span class="footer-text">Modules</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>
    
    <!-- Social Links -->
    <div class="social-links">
        <a href="<?php echo $facebook_url; ?>" class="social-link">
            <i class="fab fa-facebook-f"></i>
        </a>
        <a href="<?php echo $twitter_url; ?>" class="social-link">
            <i class="fab fa-twitter"></i>
        </a>
        <a href="<?php echo $instagram_url; ?>" class="social-link">
            <i class="fab fa-instagram"></i>
        </a>
        <a href="<?php echo $linkedin_url; ?>" class="social-link">
            <i class="fab fa-linkedin-in"></i>
        </a>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            // Back button functionality
            document.getElementById('back-button').addEventListener('click', function() {
                showLoader();
                window.location.href = 'modules.php';
            });
            
            // Add click event to notification items to mark as read
            document.querySelectorAll('.notification-item.unread').forEach(item => {
                item.addEventListener('click', function(e) {
                    // Don't mark as read if clicking on action buttons
                    if (e.target.closest('.notification-actions')) {
                        return;
                    }
                    
                    const form = item.querySelector('form[action*="action=read"]');
                    if (form) {
                        form.submit();
                    }
                });
            });
            
            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }
            
            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>