<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Check for database configuration constants
if (!defined('DB_HOST') || !defined('DB_NAME') || !defined('DB_USER') || !defined('DB_PASS')) {
    error_log('Database configuration constants are missing.');
    http_response_code(500);
    die('Server configuration error.');
}

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        error_log('SessionManager initialized');
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            error_log('Validating session for user_id ' . $user_id);
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND (expires_at > NOW() OR expires_at IS NULL)'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            $session = $stmt->fetch();

            if ($session) {
                $new_expiry = date('Y-m-d H:i:s', strtotime('+1 day'));
                $update_stmt = $this->pdo->prepare(
                    'UPDATE sessions 
                    SET expires_at = :expires_at 
                    WHERE session_token = :session_token'
                );
                $update_stmt->execute([
                    ':expires_at' => $new_expiry,
                    ':session_token' => $session_token
                ]);
                error_log('Session validated successfully for user_id ' . $user_id);
                return true;
            }
            error_log('Session validation failed: No matching session found for token ' . $session_token);
            return false;
        } catch (PDOException $e) {
            error_log('Session validation failed due to database error: ' . $e->getMessage());
            return true; // Fallback: Assume session is valid if database error occurs
        }
    }
}

// FeeManager class to handle fee operations
class FeeManager {
    private $pdo;
    private $user_id;
    private $current_date;

    public function __construct(PDO $pdo, $user_id, $current_date) {
        $this->pdo = $pdo;
        $this->user_id = $user_id;
        $this->current_date = $current_date;
    }

    public function getReceiptDetails($fee_collection_id) {
        try {
            // Step 1: Fetch student details
            $stmt = $this->pdo->prepare(
                'SELECT full_name, class FROM students WHERE id = :student_id AND status = "active"'
            );
            $stmt->execute([':student_id' => $this->user_id]);
            $student = $stmt->fetch();

            if (!$student) {
                return null;
            }

            // Step 2: Determine the session based on current date (April to March)
            $current_month = (int)(new DateTime($this->current_date))->format('n');
            $current_year = (int)(new DateTime($this->current_date))->format('Y');
            $session_start_year = $current_month >= 4 ? $current_year : $current_year - 1;
            $current_session = "$session_start_year-" . ($session_start_year + 1);

            // Step 3: Fetch receipt details
            $stmt = $this->pdo->prepare(
                'SELECT fc.id, fc.student_id, fc.amount_collected, fc.discount, fc.payment_date, fc.payment_month, 
                        fc.payment_method, fc.session, fs.particular_id, p.particular 
                FROM fee_collections fc 
                JOIN fee_structure fs ON fc.fee_structure_id = fs.id 
                JOIN particulars p ON fs.particular_id = p.id 
                WHERE fc.id = :id 
                AND fc.student_id = :student_id 
                AND fc.status = "completed" 
                AND fs.status = "active" 
                AND p.status = "active"'
            );
            $stmt->execute([
                ':id' => $fee_collection_id,
                ':student_id' => $this->user_id
            ]);
            $receipt = $stmt->fetch();

            if (!$receipt) {
                return null;
            }

            // Step 4: Format payment months
            $month_names = [
                1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
                5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
                9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
            ];
            $description = "Payment for ";
            if ($receipt['payment_month'] !== null && !empty($receipt['payment_month'])) {
                $months = array_map('intval', explode(',', $receipt['payment_month']));
                $month_names_array = array_map(fn($m) => $month_names[$m], $months);
                $description .= implode(', ', $month_names_array);
            } else {
                $description .= "Session {$receipt['session']}";
            }

            return [
                'id' => $receipt['id'],
                'student_name' => $student['full_name'],
                'class' => $student['class'],
                'session' => $receipt['session'],
                'fee_title' => $receipt['particular'],
                'fee_description' => $description,
                'payment_reference' => "FEE-{$receipt['id']}",
                'payment_date' => date('F j, Y', strtotime($receipt['payment_date'])),
                'amount' => $receipt['amount_collected'],
                'discount' => $receipt['discount'],
                'payment_method' => $receipt['payment_method'] ?? 'N/A'
            ];
        } catch (PDOException $e) {
            error_log('Receipt details fetch failed: ' . $e->getMessage());
            return null;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Prevent redirection loop by checking if already redirected
if (isset($_GET['redirected']) && $_GET['redirected'] === '1') {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    setcookie('android_uid', '', time() - 3600, '/', '', true, true);
    http_response_code(403);
    die('Session validation failed. Please log in again.');
}

// Check session and validate
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token']) || !$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            session_destroy();
            setcookie('session_token', '', time() - 3600, '/', '', true, true);
            setcookie('android_uid', '', time() - 3600, '/', '', true, true);
            header("Location: /android/?redirected=1");
            exit;
        }
    } else {
        session_destroy();
        setcookie('session_token', '', time() - 3600, '/', '', true, true);
        setcookie('android_uid', '', time() - 3600, '/', '', true, true);
        header("Location: /android/?redirected=1");
        exit;
    }
}

// Get fee_collection_id from URL
$fee_collection_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
// if ($fee_collection_id === false || $fee_collection_id <= 0) {
//     header("Location: fee_receipts.php");
//     exit;
// }

// Initialize FeeManager with current date
$current_date = date('Y-m-d H:i:s');
$feeManager = new FeeManager($pdo, $_SESSION['user_id'], $current_date);

// Fetch receipt details
$receipt = $feeManager->getReceiptDetails($fee_collection_id);
// if (!$receipt) {
//     header("Location: fee_receipts.php");
//     exit;
// }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Educational App - Fee Receipt</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
            --success-color: #28a745;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }
        
        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .student-details {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 20px;
            font-size: 16px;
        }
        
        .student-info {
            display: flex;
            justify-content: space-between;
        }
        
        .receipt-details {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .receipt-card {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .receipt-label {
            font-size: 16px;
            font-weight: 500;
        }
        
        .receipt-value {
            font-size: 18px;
            font-weight: 600;
        }
        
        .receipt-value.success {
            color: var(--success-color);
        }
        
        .action-button {
            background-color: var(--primary-color);
            border: none;
            border-radius: var(--border-radius);
            padding: 10px 20px;
            font-size: 16px;
            font-weight: 500;
            color: white;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            margin: 0 auto;
        }
        
        .action-button:hover {
            opacity: 0.9;
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }
            
            .receipt-value {
                font-size: 16px;
            }
            
            .student-info {
                flex-direction: column;
                gap: 5px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" id="back-button"></i>
        Fee Receipt
    </div>
    
    <div class="section">
        <div class="section-title"><?php echo htmlspecialchars($receipt['fee_title']); ?> Receipt</div>
        <div class="student-details">
            <div class="student-info">
                <div><strong>Student Name:</strong> <?php echo htmlspecialchars($receipt['student_name']); ?></div>
                <div><strong>Class:</strong> <?php echo htmlspecialchars($receipt['class']); ?></div>
            </div>
            <div class="student-info">
                <div><strong>Session:</strong> <?php echo htmlspecialchars($receipt['session']); ?></div>
            </div>
        </div>
        <div class="receipt-details">
            <div class="receipt-card">
                <div class="receipt-label">Payment Reference</div>
                <div class="receipt-value"><?php echo htmlspecialchars($receipt['payment_reference']); ?></div>
            </div>
            <div class="receipt-card">
                <div class="receipt-label">Description</div>
                <div class="receipt-value"><?php echo htmlspecialchars($receipt['fee_description']); ?></div>
            </div>
            <div class="receipt-card">
                <div class="receipt-label">Payment Date</div>
                <div class="receipt-value"><?php echo htmlspecialchars($receipt['payment_date']); ?></div>
            </div>
            <div class="receipt-card">
                <div class="receipt-label">Amount Paid</div>
                <div class="receipt-value success">₹<?php echo number_format($receipt['amount'], 2); ?></div>
            </div>
            <div class="receipt-card">
                <div class="receipt-label">Discount</div>
                <div class="receipt-value">₹<?php echo number_format($receipt['discount'], 2); ?></div>
            </div>
            <div class="receipt-card">
                <div class="receipt-label">Payment Method</div>
                <div class="receipt-value"><?php echo htmlspecialchars($receipt['payment_method']); ?></div>
            </div>
        </div>
        <button class="action-button" onclick="downloadReceipt(<?php echo $receipt['id']; ?>)">
            <i class="fas fa-download"></i> Download Receipt
        </button>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            // Back button functionality
            document.getElementById('back-button').addEventListener('click', function() {
                showLoader();
                window.location.href = 'modules.php';
            });
            
            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }

            // Make functions available globally
            window.downloadReceipt = function(receiptId) {
                showLoader();
                window.location.href = `download_receipt.php?id=${receiptId}`;
            };
            
            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>