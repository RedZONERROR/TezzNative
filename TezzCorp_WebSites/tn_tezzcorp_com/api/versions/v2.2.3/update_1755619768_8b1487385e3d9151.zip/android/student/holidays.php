<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch site settings
try {
    $stmt = $pdo->prepare('SELECT school_name, facebook_url, twitter_url, instagram_url, linkedin_url FROM site_settings WHERE id = 1');
    $stmt->execute();
    $settings = $stmt->fetch();
    
    if (!$settings) {
        $settings = [
            'school_name' => 'EduConnect',
            'facebook_url' => '#',
            'twitter_url' => '#',
            'instagram_url' => '#',
            'linkedin_url' => '#'
        ];
    }
} catch (PDOException $e) {
    error_log('Failed to fetch site settings: ' . $e->getMessage());
    $settings = [
        'school_name' => 'EduConnect',
        'facebook_url' => '#',
        'twitter_url' => '#',
        'instagram_url' => '#',
        'linkedin_url' => '#'
    ];
}

$school_name = htmlspecialchars($settings['school_name']);
$facebook_url = htmlspecialchars($settings['facebook_url']);
$twitter_url = htmlspecialchars($settings['twitter_url']);
$instagram_url = htmlspecialchars($settings['instagram_url']);
$linkedin_url = htmlspecialchars($settings['linkedin_url']);

// Handle month and year selection
$currentDate = new DateTime();
$currentMonth = (int)$currentDate->format('n') - 1; // 0-based month for consistency with JavaScript Date
$currentYear = (int)$currentDate->format('Y');

// Get month and year from query parameters, default to current month/year
$selectedMonth = isset($_GET['month']) ? (int)$_GET['month'] : $currentMonth;
$selectedYear = isset($_GET['year']) ? (int)$_GET['year'] : $currentYear;

// Validate month and year
if ($selectedMonth < 0 || $selectedMonth > 11) {
    $selectedMonth = $currentMonth;
}
if ($selectedYear < 2000 || $selectedYear > 2100) {
    $selectedYear = $currentYear;
}

// Calculate previous and next month/year for navigation
$prevMonth = $selectedMonth - 1;
$prevYear = $selectedYear;
if ($prevMonth < 0) {
    $prevMonth = 11;
    $prevYear--;
}

$nextMonth = $selectedMonth + 1;
$nextYear = $selectedYear;
if ($nextMonth > 11) {
    $nextMonth = 0;
    $nextYear++;
}

// Format the current month and year for display
$monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
$currentMonthDisplay = $monthNames[$selectedMonth] . ' ' . $selectedYear;

// Fetch holidays for the selected month and year
$holidays = [];
try {
    // Adjust month for SQL (1-based) and format the date range
    $startDate = sprintf('%d-%02d-01', $selectedYear, $selectedMonth + 1);
    $endDate = (new DateTime($startDate))->modify('last day of this month')->format('Y-m-d');
    
    $query = 'SELECT holiday_date, name, description, type, duration 
              FROM holidays 
              WHERE holiday_date BETWEEN :start_date AND :end_date 
              AND status = "published" 
              ORDER BY holiday_date ASC';
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':start_date' => $startDate,
        ':end_date' => $endDate
    ]);
    $holidays = $stmt->fetchAll();
    
    // Format the date for display
    foreach ($holidays as &$holiday) {
        $date = new DateTime($holiday['holiday_date']);
        $holiday['day'] = $date->format('j');
        $holiday['month'] = $date->format('M');
    }
} catch (PDOException $e) {
    error_log('Failed to fetch holidays: ' . $e->getMessage());
    $holidays = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $school_name; ?> - Holidays</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
            --national-color: #dc3545;
            --religious-color: #6f42c1;
            --school-color: #0055a4;
            --vacation-color: #28a745;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }
        
        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .month-selector {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .month-name {
            font-size: 18px;
            font-weight: 600;
        }
        
        .month-nav {
            display: flex;
            gap: 15px;
        }
        
        .month-nav-button {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background-color: var(--secondary-color);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            text-decoration: none;
        }
        
        .month-nav-button:hover {
            background-color: var(--primary-color);
            color: white;
        }
        
        .holiday-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .holiday-item {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            gap: 15px;
            transition: var(--transition);
        }
        
        .holiday-item:hover {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }
        
        .holiday-date {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        
        .holiday-date.national {
            background-color: var(--national-color);
        }
        
        .holiday-date.religious {
            background-color: var(--religious-color);
        }
        
        .holiday-date.school {
            background-color: var(--school-color);
        }
        
        .holiday-date.vacation {
            background-color: var(--vacation-color);
        }
        
        .holiday-day {
            font-size: 24px;
            font-weight: 600;
            line-height: 1;
        }
        
        .holiday-month {
            font-size: 12px;
            text-transform: uppercase;
        }
        
        .holiday-details {
            flex: 1;
        }
        
        .holiday-name {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .holiday-description {
            font-size: 14px;
            color: var(--light-text);
        }
        
        .holiday-type {
            font-size: 12px;
            font-weight: 500;
            color: white;
            padding: 4px 8px;
            border-radius: 12px;
            display: inline-block;
            margin-top: 8px;
        }
        
        .holiday-type.national {
            background-color: var(--national-color);
        }
        
        .holiday-type.religious {
            background-color: var(--religious-color);
        }
        
        .holiday-type.school {
            background-color: var(--school-color);
        }
        
        .holiday-type.vacation {
            background-color: var(--vacation-color);
        }
        
        .holiday-duration {
            display: flex;
            align-items: center;
            font-size: 13px;
            color: var(--light-text);
            margin-top: 5px;
        }
        
        .holiday-duration i {
            margin-right: 5px;
        }
        
        .legend {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        
        .legend-item {
            display: flex;
            align-items: center;
            font-size: 13px;
            color: var(--light-text);
        }
        
        .legend-color {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 5px;
        }
        
        .legend-color.national {
            background-color: var(--national-color);
        }
        
        .legend-color.religious {
            background-color: var(--religious-color);
        }
        
        .legend-color.school {
            background-color: var(--school-color);
        }
        
        .legend-color.vacation {
            background-color: var(--vacation-color);
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        .social-links {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }
        
        .social-link {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--secondary-color);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: var(--transition);
        }
        
        .social-link:hover {
            background-color: var(--primary-color);
            color: white;
            transform: translateY(-3px);
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Empty state */
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
            text-align: center;
        }
        
        .empty-icon {
            font-size: 50px;
            color: #ccc;
            margin-bottom: 15px;
        }
        
        .empty-text {
            font-size: 16px;
            color: var(--light-text);
            margin-bottom: 20px;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }
            
            .month-name {
                font-size: 16px;
            }
            
            .holiday-name {
                font-size: 15px;
            }
            
            .holiday-date {
                width: 50px;
                height: 50px;
            }
            
            .holiday-day {
                font-size: 20px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" id="back-button"></i>
        Holidays
    </div>
    
    <div class="section">
        <div class="month-selector">
            <div class="month-name"><?php echo $currentMonthDisplay; ?></div>
            <div class="month-nav">
                <a href="?month=<?php echo $prevMonth; ?>&year=<?php echo $prevYear; ?>" class="month-nav-button" onclick="showLoader()">
                    <i class="fas fa-chevron-left"></i>
                </a>
                <a href="?month=<?php echo $nextMonth; ?>&year=<?php echo $nextYear; ?>" class="month-nav-button" onclick="showLoader()">
                    <i class="fas fa-chevron-right"></i>
                </a>
            </div>
        </div>
        
        <div class="holiday-list" id="holiday-list">
            <?php if (empty($holidays)): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-calendar-day"></i>
                    </div>
                    <div class="empty-text">No holidays in this month.</div>
                </div>
            <?php else: ?>
                <?php foreach ($holidays as $holiday): ?>
                    <div class="holiday-item">
                        <div class="holiday-date <?php echo htmlspecialchars($holiday['type']); ?>">
                            <div class="holiday-day"><?php echo htmlspecialchars($holiday['day']); ?></div>
                            <div class="holiday-month"><?php echo htmlspecialchars($holiday['month']); ?></div>
                        </div>
                        <div class="holiday-details">
                            <div class="holiday-name"><?php echo htmlspecialchars($holiday['name']); ?></div>
                            <div class="holiday-description"><?php echo htmlspecialchars($holiday['description']); ?></div>
                            <div class="holiday-type <?php echo htmlspecialchars($holiday['type']); ?>"><?php echo htmlspecialchars(ucfirst($holiday['type'])); ?></div>
                            <div class="holiday-duration">
                                <i class="far fa-clock"></i> <?php echo htmlspecialchars($holiday['duration']); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <div class="legend">
            <div class="legend-item">
                <div class="legend-color national"></div>
                <span>National</span>
            </div>
            <div class="legend-item">
                <div class="legend-color religious"></div>
                <span>Religious</span>
            </div>
            <div class="legend-item">
                <div class="legend-color school"></div>
                <span>School</span>
            </div>
            <div class="legend-item">
                <div class="legend-color vacation"></div>
                <span>Vacation</span>
            </div>
        </div>
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="modules.php" class="footer-item ripple active">
            <i class="fas fa-th footer-icon"></i>
            <span class="footer-text">Modules</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>
    
    <!-- Social Links -->
    <div class="social-links">
        <a href="<?php echo $facebook_url; ?>" class="social-link">
            <i class="fab fa-facebook-f"></i>
        </a>
        <a href="<?php echo $twitter_url; ?>" class="social-link">
            <i class="fab fa-twitter"></i>
        </a>
        <a href="<?php echo $instagram_url; ?>" class="social-link">
            <i class="fab fa-instagram"></i>
        </a>
        <a href="<?php echo $linkedin_url; ?>" class="social-link">
            <i class="fab fa-linkedin-in"></i>
        </a>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            // Back button functionality
            document.getElementById('back-button').addEventListener('click', function() {
                showLoader();
                window.location.href = 'modules.php';
            });
            
            // Function to show loader
            window.showLoader = function() {
                loader.style.display = 'flex';
            };
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }
            
            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>