<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM students WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'student')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'student';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch site settings
try {
    $stmt = $pdo->prepare('SELECT school_name, email, address, phone, facebook_url, twitter_url, instagram_url, linkedin_url FROM site_settings WHERE id = 1');
    $stmt->execute();
    $settings = $stmt->fetch();
    
    if (!$settings) {
        $settings = [
            'school_name' => 'EduConnect',
            'email' => 'privacy@educonnect.com',
            'address' => '123 Education Street, Learning City, LC 12345',
            'phone' => '+1 (555) 123-4567',
            'facebook_url' => '#',
            'twitter_url' => '#',
            'instagram_url' => '#',
            'linkedin_url' => '#'
        ];
    }
} catch (PDOException $e) {
    error_log('Failed to fetch site settings: ' . $e->getMessage());
    $settings = [
        'school_name' => 'EduConnect',
        'email' => 'privacy@educonnect.com',
        'address' => '123 Education Street, Learning City, LC 12345',
        'phone' => '+1 (555) 123-4567',
        'facebook_url' => '#',
        'twitter_url' => '#',
        'instagram_url' => '#',
        'linkedin_url' => '#'
    ];
}

$school_name = htmlspecialchars($settings['school_name']);
$email = htmlspecialchars($settings['email']);
$address = htmlspecialchars($settings['address']);
$phone = htmlspecialchars($settings['phone']);
$facebook_url = htmlspecialchars($settings['facebook_url']);
$twitter_url = htmlspecialchars($settings['twitter_url']);
$instagram_url = htmlspecialchars($settings['instagram_url']);
$linkedin_url = htmlspecialchars($settings['linkedin_url']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Educational App - Privacy Policy</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }
        
        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .policy-content {
            font-size: 15px;
            line-height: 1.6;
            color: var(--text-color);
        }
        
        .policy-content p {
            margin-bottom: 15px;
        }
        
        .policy-content h3 {
            font-size: 18px;
            font-weight: 600;
            margin: 25px 0 15px;
            color: var(--primary-color);
        }
        
        .policy-content ul {
            margin-bottom: 15px;
            padding-left: 20px;
        }
        
        .policy-content li {
            margin-bottom: 8px;
        }
        
        .policy-date {
            font-style: italic;
            color: var(--light-text);
            margin-top: 30px;
            font-size: 14px;
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        .social-links {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }
        
        .social-link {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--secondary-color);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: var(--transition);
        }
        
        .social-link:hover {
            background-color: var(--primary-color);
            color: white;
            transform: translateY(-3px);
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }
            
            .policy-content {
                font-size: 14px;
            }
            
            .policy-content h3 {
                font-size: 16px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" id="back-button"></i>
        Privacy Policy
    </div>
    
    <div class="section">
        <div class="policy-content">
            <p>This Privacy Policy describes how <?php echo $school_name; ?> ("we", "our", or "us") collects, uses, and shares your personal information when you use our mobile application ("App").</p>
            
            <h3>Information We Collect</h3>
            <p>We collect several types of information from and about users of our App, including:</p>
            <ul>
                <li><strong>Personal Information:</strong> This includes your name, email address, phone number, date of birth, profile picture, and other identifiers that you provide when registering or using our App.</li>
                <li><strong>Educational Information:</strong> This includes your student ID, class/grade information, attendance records, academic performance data, homework submissions, and other educational records.</li>
                <li><strong>Payment Information:</strong> When you make payments through our App, we collect payment details, transaction history, and billing information.</li>
                <li><strong>Device Information:</strong> We collect information about your device, including IP address, device type, operating system, browser type, and mobile network information.</li>
                <li><strong>Usage Information:</strong> We collect information about how you use our App, including pages visited, features used, time spent on the App, and other usage patterns.</li>
            </ul>
            
            <h3>How We Use Your Information</h3>
            <p>We use the information we collect to:</p>
            <ul>
                <li>Provide, maintain, and improve our App and services</li>
                <li>Process and manage your account, including verifying your identity</li>
                <li>Facilitate communication between students, parents, and teachers</li>
                <li>Process payments and manage fee-related activities</li>
                <li>Track and analyze academic performance</li>
                <li>Send notifications about important updates, events, and deadlines</li>
                <li>Respond to your inquiries and provide customer support</li>
                <li>Ensure the security and integrity of our App</li>
                <li>Comply with legal obligations and enforce our terms of service</li>
            </ul>
            
            <h3>How We Share Your Information</h3>
            <p>We may share your personal information with:</p>
            <ul>
                <li><strong>School Administrators and Teachers:</strong> To facilitate educational services and communication</li>
                <li><strong>Service Providers:</strong> Third-party vendors who provide services on our behalf, such as hosting, payment processing, and analytics</li>
                <li><strong>Legal Authorities:</strong> When required by law or to protect our rights and safety</li>
            </ul>
            <p>We do not sell your personal information to third parties.</p>
            
            <h3>Data Security</h3>
            <p>We implement appropriate technical and organizational measures to protect your personal information from unauthorized access, disclosure, alteration, and destruction. However, no method of transmission over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute security.</p>
            
            <h3>Children's Privacy</h3>
            <p>Our App is designed for use by students, parents, and educational institutions. We collect information from students under the age of 13 only with verifiable parental consent or through educational institutions as permitted by law. If you are a parent or guardian and believe we have collected information from your child without proper consent, please contact us.</p>
            
            <h3>Your Rights</h3>
            <p>Depending on your location, you may have certain rights regarding your personal information, including:</p>
            <ul>
                <li>The right to access and receive a copy of your personal information</li>
                <li>The right to correct or update your personal information</li>
                <li>The right to delete your personal information</li>
                <li>The right to restrict or object to processing of your personal information</li>
                <li>The right to data portability</li>
            </ul>
            <p>To exercise these rights, please contact us using the information provided below.</p>
            
            <h3>Changes to This Privacy Policy</h3>
            <p>We may update this Privacy Policy from time to time to reflect changes in our practices or for other operational, legal, or regulatory reasons. We will notify you of any material changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.</p>
            
            <h3>Contact Us</h3>
            <p>If you have any questions or concerns about this Privacy Policy or our data practices, please contact us at:</p>
            <p>Email: <?php echo $email; ?><br>
            Phone: <?php echo $phone; ?><br>
            Address: <?php echo $address; ?></p>
            
            <div class="policy-date">Last Updated: June 1, 2025</div>
        </div>
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="modules.php" class="footer-item ripple">
            <i class="fas fa-th footer-icon"></i>
            <span class="footer-text">Modules</span>
        </a>
        <a href="account.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Account</span>
        </a>
        <a href="setting.php" class="footer-item ripple active">
            <i class="fas fa-cog footer-icon"></i>
            <span class="footer-text">Setting</span>
        </a>
    </div>
    
    <!-- Social Links -->
    <div class="social-links">
        <a href="<?php echo $facebook_url; ?>" class="social-link">
            <i class="fab fa-facebook-f"></i>
        </a>
        <a href="<?php echo $twitter_url; ?>" class="social-link">
            <i class="fab fa-twitter"></i>
        </a>
        <a href="<?php echo $instagram_url; ?>" class="social-link">
            <i class="fab fa-instagram"></i>
        </a>
        <a href="<?php echo $linkedin_url; ?>" class="social-link">
            <i class="fab fa-linkedin-in"></i>
        </a>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader initially
            const loader = document.getElementById('loader');
            
            // Back button functionality
            document.getElementById('back-button').addEventListener('click', function() {
                showLoader();
                window.location.href = 'setting.php';
            });
            
            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }
            
            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>