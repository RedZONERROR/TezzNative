<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM staff WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'staff')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'staff';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch teacher profile data
$teacher = [];
try {
    $stmt = $pdo->prepare(
        'SELECT name, email, mobile, role, photo 
         FROM staff 
         WHERE id = :id AND status = "active"'
    );
    $stmt->execute([':id' => $_SESSION['user_id']]);
    $teacher = $stmt->fetch();
    
    if (!$teacher) {
        header("Location: /android/");
        exit;
    }
    
    // Sanitize data for display
    $teacher['name'] = htmlspecialchars($teacher['name']);
    $teacher['email'] = htmlspecialchars($teacher['email']);
    $teacher['mobile'] = htmlspecialchars($teacher['mobile']);
    $teacher['role'] = htmlspecialchars($teacher['role']);
    $teacher['photo'] = !empty($teacher['photo']) ? htmlspecialchars($teacher['photo']) : '';
    
    // Get initials for avatar fallback
    $teacher['initials'] = '';
    if ($teacher['name']) {
        $name_parts = explode(' ', $teacher['name']);
        $teacher['initials'] = strtoupper(substr($name_parts[0], 0, 1));
        if (count($name_parts) > 1) {
            $teacher['initials'] .= strtoupper(substr($name_parts[count($name_parts) - 1], 0, 1));
        }
    }
} catch (PDOException $e) {
    error_log('Failed to fetch teacher profile: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Handle profile update
$alert_message = '';
$alert_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $name = isset($_POST['name']) ? trim($_POST['name']) : '';
        $email = isset($_POST['email']) ? trim($_POST['email']) : '';
        $phone = isset($_POST['mobile']) ? trim($_POST['mobile']) : '';

        if (empty($name) || empty($email) || empty($phone)) {
            $alert_message = 'All fields are required.';
            $alert_type = 'error';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $alert_message = 'Invalid email format.';
            $alert_type = 'error';
        } elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
            $alert_message = 'Phone number must be 10 digits.';
            $alert_type = 'error';
        } else {
            $stmt = $pdo->prepare(
                'UPDATE staff 
                 SET name = :name, email = :email, mobile = :mobile, updated_at = NOW() 
                 WHERE id = :id AND status = "active"'
            );
            $stmt->execute([
                ':name' => $name,
                ':email' => $email,
                ':mobile' => $phone,
                ':id' => $_SESSION['user_id']
            ]);

            if ($stmt->rowCount() > 0) {
                $alert_message = 'Profile updated successfully!';
                $alert_type = 'success';
                // Update session and teacher data
                $_SESSION['user_name'] = $name;
                $teacher['name'] = htmlspecialchars($name);
                $teacher['email'] = htmlspecialchars($email);
                $teacher['mobile'] = htmlspecialchars($phone);
                // Update initials
                $teacher['initials'] = '';
                $name_parts = explode(' ', $name);
                $teacher['initials'] = strtoupper(substr($name_parts[0], 0, 1));
                if (count($name_parts) > 1) {
                    $teacher['initials'] .= strtoupper(substr($name_parts[count($name_parts) - 1], 0, 1));
                }
            } else {
                $alert_message = 'No changes made or failed to update profile.';
                $alert_type = 'error';
            }
        }
    } catch (PDOException $e) {
        error_log('Failed to update profile: ' . $e->getMessage());
        $alert_message = 'Failed to update profile. Please try again.';
        $alert_type = 'error';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>EduConnect - Teacher Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }

        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }

        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }

        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }

        .profile-section {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }

        .profile-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            font-weight: 600;
            margin-bottom: 15px;
        }

        .profile-avatar img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }

        .profile-name {
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .profile-subject {
            font-size: 16px;
            color: var(--light-text);
            margin-bottom: 15px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 15px;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 16px;
            color: var(--text-color);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .btn {
            display: inline-block;
            font-weight: 500;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            user-select: none;
            border: 1px solid transparent;
            padding: 12px 20px;
            font-size: 16px;
            line-height: 1.5;
            border-radius: var(--border-radius);
            transition: var(--transition);
            cursor: pointer;
        }

        .btn-primary {
            color: #fff;
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: #004a8f;
            border-color: #004a8f;
        }

        .btn-block {
            display: block;
            width: 100%;
        }

        /* Alert message */
        .alert {
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            display: none;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }

        .footer-item.active {
            color: var(--primary-color);
        }

        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }

        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }

        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }

        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }

        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }

            .profile-name {
                font-size: 20px;
            }
        }

        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" onclick="window.location.href='index.php';"></i>
        Profile
    </div>

    <div class="section">
        <div class="profile-section">
            <div class="profile-avatar">
                <?php if ($teacher['photo']): ?>
                    <img src="/<?php echo $teacher['photo']; ?>" alt="Profile Image" />
                <?php else: ?>
                    <?php echo $teacher['initials']; ?>
                <?php endif; ?>
            </div>
            <div class="profile-name"><?php echo $teacher['name']; ?></div>
            <div class="profile-subject"><?php echo $teacher['role']; ?></div>
        </div>
    </div>

    <div class="section">
        <?php if ($alert_message): ?>
            <div class="alert alert-<?php echo $alert_type; ?>" style="display: block;">
                <?php echo htmlspecialchars($alert_message); ?>
            </div>
        <?php else: ?>
            <div class="alert" id="alert" style="display: none;"></div>
        <?php endif; ?>

        <div class="section-title">Edit Profile</div>
        <form method="POST" action="teacher_profile.php">
            <div class="form-group">
                <label for="name" class="form-label">Name</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo $teacher['name']; ?>" required>
            </div>
            <div class="form-group">
                <label for="email" class="form-label">Email</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo $teacher['email']; ?>" required>
            </div>
            <div class="form-group">
                <label for="mobile" class="form-label">Phone</label>
                <input type="tel" id="mobile" name="mobile" class="form-control" value="<?php echo $teacher['mobile']; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">
                <i class="fas fa-save"></i> Save Changes
            </button>
        </form>
    </div>

    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="classes.php" class="footer-item">
            <i class="fas fa-chalkboard footer-icon"></i>
            <span class="footer-text">Classes</span>
        </a>
        <a href="marks.php" class="footer-item ripple">
            <i class="fa fa-pencil-square footer-icon"></i>
            <span class="footer-text">Marks</span>
        </a>
        <a href="profile.php" class="footer-item active">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Profile</span>
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader
            const loader = document.getElementById('loader');
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }
            
            // Hide loader after page load
            hideLoader();

            // Auto-hide alert after 5 seconds
            const alertBox = document.getElementById('alert');
            if (alertBox && alertBox.style.display === 'block') {
                setTimeout(() => {
                    alertBox.style.display = 'none';
                }, 5000);
            }
        });
    </script>
</body>
</html>