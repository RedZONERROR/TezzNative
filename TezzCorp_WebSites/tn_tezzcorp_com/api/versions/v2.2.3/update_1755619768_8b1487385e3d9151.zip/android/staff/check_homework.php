<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM staff WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'staff')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'staff';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch classes assigned to the teacher (from class_teacher)
$classes = [];
try {
    $stmt = $pdo->prepare(
        'SELECT c.id, c.class_name 
         FROM class_teacher ct
         JOIN class c ON ct.class = c.id
         WHERE ct.tid = :tid AND ct.status = "active" AND c.status = "active"'
    );
    $stmt->execute([':tid' => $_SESSION['user_id']]);
    $classes = $stmt->fetchAll();
    
    foreach ($classes as &$class) {
        $class['class_name'] = htmlspecialchars($class['class_name']);
    }
} catch (PDOException $e) {
    error_log('Failed to fetch classes: ' . $e->getMessage());
    $classes = [];
}

// Handle form submission to update homework status
$alert_message = '';
$alert_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $homework_submissions = isset($_POST['homework_status']) ? $_POST['homework_status'] : [];
        if (empty($homework_submissions)) {
            throw new Exception('No homework submissions to update.');
        }

        foreach ($homework_submissions as $submission_id => $status) {
            $stmt = $pdo->prepare(
                'UPDATE homework_submissions 
                 SET status = :status, date = :date 
                 WHERE id = :id AND hid IN (
                     SELECT id FROM homework WHERE class IN (
                         SELECT class_name FROM class_teacher ct 
                         JOIN class c ON ct.class = c.id 
                         WHERE ct.tid = :tid AND ct.status = "active"
                     )
                 )'
            );
            $stmt->execute([
                ':status' => $status,
                ':date' => '2025-06-01',
                ':id' => $submission_id,
                ':tid' => $_SESSION['user_id']
            ]);
        }

        $alert_message = 'Homework statuses updated successfully!';
        $alert_type = 'success';
    } catch (Exception $e) {
        error_log('Failed to update homework statuses: ' . $e->getMessage());
        $alert_message = 'Failed to update homework statuses: ' . $e->getMessage();
        $alert_type = 'error';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
   <title>EduConnect - Check Homework</title>
   <!-- Font Awesome for icons -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   <!-- Google Fonts -->
   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
   <style>
       :root {
           --primary-color: #0055a4;
           --secondary-color: #f8f9fa;
           --text-color: #333;
           --light-text: #6c757d;
           --border-radius: 12px;
           --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
           --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
           --transition: all 0.3s ease;
           --success-color: #28a745;
           --danger-color: #dc3545;
       }
       
       * {
           margin: 0;
           padding: 0;
           box-sizing: border-box;
           font-family: 'Poppins', sans-serif;
           -webkit-tap-highlight-color: transparent;
       }
       
       body {
           background-color: #f0f2f5;
           color: var(--text-color);
           padding-bottom: 70px;
           overflow-x: hidden;
           -webkit-font-smoothing: antialiased;
           -moz-osx-font-smoothing: grayscale;
       }
       
       .header {
           background-color: var(--primary-color);
           color: white;
           padding: 20px;
           font-size: 28px;
           font-weight: 600;
           box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
           position: sticky;
           top: 0;
           z-index: 100;
           display: flex;
           align-items: center;
       }
       
       .back-button {
           margin-right: 15px;
           cursor: pointer;
       }
       
       .section {
           background-color: white;
           border-radius: var(--border-radius);
           margin: 15px;
           padding: 20px;
           box-shadow: var(--box-shadow);
       }
       
       .section-title {
           color: var(--primary-color);
           font-size: 22px;
           font-weight: 600;
           margin-bottom: 20px;
           position: relative;
           padding-bottom: 8px;
       }
       
       .section-title::after {
           content: '';
           position: absolute;
           bottom: 0;
           left: 0;
           width: 40px;
           height: 3px;
           background-color: var(--primary-color);
           border-radius: 10px;
       }
       
       .class-selector {
           margin-bottom: 20px;
       }
       
       .select-wrapper {
           position: relative;
           margin-bottom: 15px;
       }
       
       .select-wrapper::after {
           content: '\f107';
           font-family: 'Font Awesome 5 Free';
           font-weight: 900;
           position: absolute;
           right: 15px;
           top: 50%;
           transform: translateY(-50%);
           color: var(--light-text);
           pointer-events: none;
       }
       
       .select-field {
           width: 100%;
           padding: 12px 15px;
           border: 1px solid #ddd;
           border-radius: var(--border-radius);
           appearance: none;
           font-size: 16px;
           color: var(--text-color);
           background-color: white;
       }
       
       .select-field:focus {
           outline: none;
           border-color: var(--primary-color);
       }
       
       .date-selector {
           display: flex;
           align-items: center;
           gap: 10px;
       }
       
       .date-field {
           flex: 1;
           padding: 12px 15px;
           border: 1px solid #ddd;
           border-radius: var(--border-radius);
           font-size: 16px;
           color: var(--text-color);
       }
       
       .date-field:focus {
           outline: none;
           border-color: var(--primary-color);
       }
       
       .homework-list {
           margin-top: 20px;
       }
       
       .student-item {
           display: flex;
           align-items: center;
           padding: 15px;
           border-bottom: 1px solid #eee;
       }
       
       .student-item:last-child {
           border-bottom: none;
       }
       
       .student-avatar {
           width: 40px;
           height: 40px;
           border-radius: 50%;
           background-color: var(--primary-color);
           color: white;
           display: flex;
           align-items: center;
           justify-content: center;
           font-size: 16px;
           font-weight: 600;
           margin-right: 15px;
       }
       
       .student-info {
           flex: 1;
       }
       
       .student-name {
           font-size: 16px;
           font-weight: 500;
       }
       
       .student-roll {
           font-size: 13px;
           color: var(--light-text);
       }
       
       .homework-toggle {
           display: flex;
           gap: 10px;
       }
       
       .homework-button {
           width: 40px;
           height: 40px;
           border-radius: 50%;
           display: flex;
           align-items: center;
           justify-content: center;
           border: 2px solid #ddd;
           background-color: white;
           color: var(--light-text);
           cursor: pointer;
           transition: var(--transition);
       }
       
       .homework-button.completed {
           border-color: var(--success-color);
           color: var(--success-color);
       }
       
       .homework-button.completed.active {
           background-color: var(--success-color);
           color: white;
       }
       
       .homework-button.pending {
           border-color: var(--danger-color);
           color: var(--danger-color);
       }
       
       .homework-button.pending.active {
           background-color: var(--danger-color);
           color: white;
       }
       
       .submit-container {
           margin-top: 20px;
           display: flex;
           justify-content: space-between;
       }
       
       .submit-button {
           background-color: var(--primary-color);
           color: white;
           border: none;
           border-radius: var(--border-radius);
           padding: 12px 20px;
           font-size: 16px;
           font-weight: 600;
           cursor: pointer;
           transition: var(--transition);
           display: flex;
           align-items: center;
           gap: 10px;
       }
       
       .submit-button:hover {
           background-color: #004a8f;
       }
       
       .reset-button {
           background-color: var(--light-text);
           color: white;
           border: none;
           border-radius: var(--border-radius);
           padding: 12px 20px;
           font-size: 16px;
           font-weight: 600;
           cursor: pointer;
           transition: var(--transition);
           display: flex;
           align-items: center;
           gap: 10px;
       }
       
       .reset-button:hover {
           background-color: #5a6268;
       }
       
       .homework-summary {
           display: flex;
           justify-content: space-between;
           margin-top: 20px;
           padding-top: 15px;
           border-top: 1px solid #eee;
       }
       
       .summary-item {
           text-align: center;
       }
       
       .summary-value {
           font-size: 24px;
           font-weight: 600;
       }
       
       .summary-label {
           font-size: 14px;
           color: var(--light-text);
       }
       
       .completed-summary .summary-value {
           color: var(--success-color);
       }
       
       .pending-summary .summary-value {
           color: var(--danger-color);
       }
       
       /* Alert message */
       .alert {
           padding: 15px;
           border-radius: var(--border-radius);
           margin-bottom: 20px;
           display: none;
       }
       
       .alert-error {
           background-color: #f8d7da;
           color: #721c24;
           border: 1px solid #f5c6cb;
       }
       
       .alert-success {
           background-color: #d4edda;
           color: #155724;
           border: 1px solid #c3e6cb;
       }
       
       .footer {
           position: fixed;
           bottom: 0;
           width: 100%;
           background-color: white;
           display: flex;
           justify-content: space-around;
           padding: 10px 0;
           box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
           z-index: 1000;
       }
       
       .footer-item {
           display: flex;
           flex-direction: column;
           align-items: center;
           text-decoration: none;
           color: var(--light-text);
           transition: var(--transition);
           padding: 5px 0;
           width: 25%;
       }
       
       .footer-item.active {
           color: var(--primary-color);
       }
       
       .footer-icon {
           font-size: 22px;
           margin-bottom: 4px;
       }
       
       .footer-text {
           font-size: 12px;
           font-weight: 500;
       }
       
       /* Loading Animation */
       .loader-container {
           position: fixed;
           top: 0;
           left: 0;
           width: 100%;
           height: 100%;
           background-color: rgba(255, 255, 255, 0.9);
           display: flex;
           justify-content: center;
           align-items: center;
           z-index: 9999;
           transition: opacity 0.3s ease;
       }
       
       .loader {
           width: 50px;
           height: 50px;
           border: 5px solid rgba(0, 85, 164, 0.2);
           border-radius: 50%;
           border-top-color: var(--primary-color);
           animation: spin 1s ease-in-out infinite;
       }
       
       @keyframes spin {
           to {
               transform: rotate(360deg);
           }
       }
       
       .loader-text {
           position: absolute;
           margin-top: 80px;
           color: var(--primary-color);
           font-weight: 500;
       }
       
       /* Media Queries for better responsiveness */
       @media (max-width: 480px) {
           .section-title {
               font-size: 20px;
           }
           
           .student-name {
               font-size: 15px;
           }
           
           .homework-button {
               width: 35px;
               height: 35px;
           }
           
           .summary-value {
               font-size: 20px;
           }
           
           .summary-label {
               font-size: 12px;
           }
       }
       
       /* Prevent text selection for better mobile experience */
       .no-select {
           -webkit-touch-callout: none;
           -webkit-user-select: none;
           -khtml-user-select: none;
           -moz-user-select: none;
           -ms-user-select: none;
           user-select: none;
       }
   </style>
</head>
<body class="no-select">
   <!-- Loading Animation -->
   <div class="loader-container" id="loader">
       <div class="loader"></div>
       <div class="loader-text">Loading...</div>
   </div>

   <div class="header">
       <i class="fas fa-arrow-left back-button" onclick="window.location.href='index.php';"></i>
       Check Homework
   </div>
   
   <div class="section">
       <?php if ($alert_message): ?>
           <div class="alert alert-<?php echo $alert_type; ?>" style="display: block;">
               <?php echo htmlspecialchars($alert_message); ?>
           </div>
       <?php else: ?>
           <div class="alert" id="alert" style="display: none;"></div>
       <?php endif; ?>
       
       <div class="class-selector">
           <div class="section-title">Select Class</div>
           <div class="select-wrapper">
               <select id="class-select" class="select-field">
                   <option value="">Select a class</option>
                   <?php foreach ($classes as $class): ?>
                       <option value="<?php echo $class['class_name']; ?>">
                           <?php echo $class['class_name']; ?>
                       </option>
                   <?php endforeach; ?>
               </select>
           </div>
           
           <div class="date-selector">
               <input type="date" id="homework-date" class="date-field" value="2025-06-01">
           </div>
       </div>
       
       <div id="homework-container" style="display: none;">
           <div class="section-title">Check Homework</div>
           <form method="POST" id="homework-form">
               <div class="homework-list" id="student-list">
                   <!-- Students and submissions will be loaded dynamically -->
               </div>
               
               <div class="homework-summary">
                   <div class="summary-item completed-summary">
                       <div class="summary-value" id="completed-count">0</div>
                       <div class="summary-label">Completed</div>
                   </div>
                   <div class="summary-item pending-summary">
                       <div class="summary-value" id="pending-count">0</div>
                       <div class="summary-label">Pending</div>
                   </div>
               </div>
               
               <div class="submit-container">
                   <button type="button" id="reset-button" class="reset-button">
                       <i class="fas fa-redo"></i> Reset
                   </button>
                   <button type="submit" id="submit-button" class="submit-button">
                       <i class="fas fa-save"></i> Save Changes
                   </button>
               </div>
           </form>
       </div>
   </div>
   
   <!-- Footer Navigation -->
   <div class="footer">
       <a href="index.php" class="footer-item">
           <i class="fas fa-home footer-icon"></i>
           <span class="footer-text">Dashboard</span>
       </a>
       <a href="classes.php" class="footer-item">
           <i class="fas fa-chalkboard footer-icon"></i>
           <span class="footer-text">Classes</span>
       </a>
       <a href="marks.php" class="footer-item ripple">
            <i class="fa fa-pencil-square footer-icon"></i>
            <span class="footer-text">Marks</span>
        </a>
       <a href="profile.php" class="footer-item">
           <i class="fas fa-user footer-icon"></i>
           <span class="footer-text">Profile</span>
       </a>
   </div>
   
   <script>
       document.addEventListener('DOMContentLoaded', function() {
           const loader = document.getElementById('loader');
           
           // Function to show loader
           function showLoader() {
               loader.style.display = 'flex';
           }
           
           // Function to hide loader
           function hideLoader() {
               loader.style.opacity = '0';
               setTimeout(() => {
                   loader.style.display = 'none';
                   loader.style.opacity = '1';
               }, 300);
           }
           
           // Auto-hide alert after 5 seconds
           const alertBox = document.getElementById('alert');
           if (alertBox && alertBox.style.display === 'block') {
               setTimeout(() => {
                   alertBox.style.display = 'none';
               }, 5000);
           }
           
           // Class select change event
           document.getElementById('class-select').addEventListener('change', function() {
               const className = this.value;
               if (className) {
                   fetchSubmissions(className);
               } else {
                   document.getElementById('homework-container').style.display = 'none';
               }
           });
           
           // Date change event
           document.getElementById('homework-date').addEventListener('change', function() {
               const className = document.getElementById('class-select').value;
               if (className) {
                   fetchSubmissions(className);
               }
           });
           
           // Reset button click event
           document.getElementById('reset-button').addEventListener('click', function() {
               resetStatuses();
           });
           
           // Function to fetch homework submissions
           function fetchSubmissions(className) {
               showLoader();
               const date = document.getElementById('homework-date').value;
               
               fetch('fetch_homework_submissions.php', {
                   method: 'POST',
                   headers: {
                       'Content-Type': 'application/json',
                   },
                   body: JSON.stringify({
                       class: className,
                       date: date
                   })
               })
               .then(response => {
                   if (!response.ok) {
                       throw new Error('Network response was not ok');
                   }
                   return response.json();
               })
               .then(data => {
                   renderSubmissionList(data.submissions);
                   document.getElementById('homework-container').style.display = 'block';
                   hideLoader();
               })
               .catch(error => {
                   console.error('Error fetching submissions:', error);
                   showAlert('Failed to load submissions. Please try again.', 'error');
                   hideLoader();
               });
           }
           
           // Function to render submission list
           function renderSubmissionList(submissions) {
               const studentList = document.getElementById('student-list');
               studentList.innerHTML = '';
               
               if (!submissions || submissions.length === 0) {
                   studentList.innerHTML = '<p>No submissions found for this class and date.</p>';
                   return;
               }
               
               submissions.forEach(submission => {
                   const studentItem = document.createElement('div');
                   studentItem.className = 'student-item';
                   studentItem.setAttribute('data-submission-id', submission.submission_id);
                   
                   studentItem.innerHTML = `
                       <div class="student-avatar">
                           ${submission.photo ? `<img style="width: 40px; height: 40px; border-radius: 50%;" src="${submission.photo}" alt="Student Photo">` : submission.initials}
                       </div>
                       <div class="student-info">
                           <div class="student-name">${submission.name}</div>
                           <div class="student-roll">Roll No: ${submission.roll_no}</div>
                           <div class="student-roll">
                               <a href="${submission.work}" target="_blank">View Submission</a>
                           </div>
                       </div>
                       <div class="homework-toggle">
                           <button type="button" class="homework-button completed" data-status="completed">
                               <i class="fas fa-check"></i>
                           </button>
                           <button type="button" class="homework-button pending" data-status="pending">
                               <i class="fas fa-times"></i>
                           </button>
                           <input type="hidden" name="homework_status[${submission.submission_id}]" class="status-input" value="${submission.status}">
                       </div>
                   `;
                   
                   studentList.appendChild(studentItem);
                   
                   // Set current status
                   const status = submission.status || 'pending';
                   const completedButton = studentItem.querySelector('.homework-button.completed');
                   const pendingButton = studentItem.querySelector('.homework-button.pending');
                   if (status === 'completed') {
                       completedButton.classList.add('active');
                   } else {
                       pendingButton.classList.add('active');
                   }
               });
               
               // Add click event to homework buttons
               const homeworkButtons = document.querySelectorAll('.homework-button');
               homeworkButtons.forEach(button => {
                   button.addEventListener('click', function() {
                       const studentItem = this.closest('.student-item');
                       const buttons = studentItem.querySelectorAll('.homework-button');
                       const statusInput = studentItem.querySelector('.status-input');
                       
                       buttons.forEach(btn => btn.classList.remove('active'));
                       this.classList.add('active');
                       
                       const status = this.getAttribute('data-status');
                       statusInput.value = status;
                       
                       updateSummary();
                   });
               });
               
               updateSummary();
           }
           
           // Function to update homework summary
           function updateSummary() {
               const completedCount = document.querySelectorAll('.homework-button.completed.active').length;
               const pendingCount = document.querySelectorAll('.homework-button.pending.active').length;
               
               document.getElementById('completed-count').textContent = completedCount;
               document.getElementById('pending-count').textContent = pendingCount;
           }
           
           // Function to reset statuses
           function resetStatuses() {
               const studentItems = document.querySelectorAll('.student-item');
               
               studentItems.forEach(item => {
                   const buttons = item.querySelectorAll('.homework-button');
                   const statusInput = item.querySelector('.status-input');
                   
                   buttons.forEach(btn => btn.classList.remove('active'));
                   item.querySelector('.homework-button.pending').classList.add('active');
                   statusInput.value = 'pending';
               });
               
               updateSummary();
           }
           
           // Function to show alert
           function showAlert(message, type) {
               const alertBox = document.getElementById('alert');
               alertBox.textContent = message;
               alertBox.className = 'alert alert-' + type;
               alertBox.style.display = 'block';
               
               setTimeout(() => {
                   alertBox.style.display = 'none';
               }, 5000);
           }
           
           // Hide loader after page load
           hideLoader();
       });
   </script>
</body>
</html>