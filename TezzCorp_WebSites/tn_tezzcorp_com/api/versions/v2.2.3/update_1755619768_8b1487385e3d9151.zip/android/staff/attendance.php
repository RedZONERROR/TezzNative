<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM staff WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'staff')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'staff';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch classes assigned to the teacher (from class_teacher)
$classes = [];
try {
    $stmt = $pdo->prepare(
        'SELECT c.id, c.class_name 
         FROM class_teacher ct
         JOIN class c ON ct.class = c.id
         WHERE ct.tid = :tid AND ct.status = "active" AND c.status = "active"'
    );
    $stmt->execute([':tid' => $_SESSION['user_id']]);
    $classes = $stmt->fetchAll();
    
    // Sanitize class data
    foreach ($classes as &$class) {
        $class['class_name'] = htmlspecialchars($class['class_name']);
    }
} catch (PDOException $e) {
    error_log('Failed to fetch classes: ' . $e->getMessage());
    $classes = [];
}

// Handle class selection and date
$selected_class_id = isset($_POST['class_id']) ? (int)$_POST['class_id'] : (count($classes) > 0 ? $classes[0]['id'] : 0);
$selected_date = isset($_POST['attendance_date']) ? $_POST['attendance_date'] : date('Y-m-d', strtotime('2025-06-01 16:00:00'));

// Validate date (cannot be in the future)
$current_date = new DateTime('2025-06-01 16:00:00', new DateTimeZone('Asia/Kolkata'));
$selected_date_obj = new DateTime($selected_date);
if ($selected_date_obj > $current_date) {
    $selected_date = $current_date->format('Y-m-d');
    $selected_date_obj = $current_date;
}

// Fetch students for the selected class, joining with documents table to get student_photo
$students = [];
$existing_attendance = [];
$attendance_exists = false;
if ($selected_class_id) {
    try {
        $stmt = $pdo->prepare(
            'SELECT s.id, s.full_name, s.roll_no, s.uid, d.student_photo 
             FROM students s
             LEFT JOIN documents d ON s.uid = d.uid
             WHERE s.class = :class_id AND s.status = "active" 
             ORDER BY s.roll_no ASC'
        );
        $stmt->execute([':class_id' => $selected_class_id]);
        $students = $stmt->fetchAll();
        
        // Sanitize student data and add initials for avatar fallback
        foreach ($students as &$student) {
            $student['full_name'] = htmlspecialchars($student['full_name']);
            $student['roll_no'] = htmlspecialchars($student['roll_no']);
            $student['student_photo'] = !empty($student['student_photo']) ? htmlspecialchars($student['student_photo']) : '';
            
            // Get initials for avatar fallback
            $student['initials'] = '';
            if ($student['full_name']) {
                $name_parts = explode(' ', $student['full_name']);
                $student['initials'] = strtoupper(substr($name_parts[0], 0, 1));
                if (count($name_parts) > 1) {
                    $student['initials'] .= strtoupper(substr($name_parts[count($name_parts) - 1], 0, 1));
                }
            }
        }
        
        // Fetch existing attendance for the selected date
        $stmt = $pdo->prepare(
            'SELECT student_id, status 
             FROM student_attendance 
             WHERE date = :date AND student_id IN (
                 SELECT id FROM students WHERE class = :class_id
             )'
        );
        $stmt->execute([
            ':date' => $selected_date,
            ':class_id' => $selected_class_id
        ]);
        $attendance_records = $stmt->fetchAll();
        
        // Check if attendance has already been submitted
        if (!empty($attendance_records)) {
            $attendance_exists = true;
        }
        
        foreach ($attendance_records as $record) {
            $existing_attendance[$record['student_id']] = $record['status'];
        }
    } catch (PDOException $e) {
        error_log('Failed to fetch students: ' . $e->getMessage());
        $students = [];
    }
}

// Handle attendance submission or update
$alert_message = '';
$alert_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_attendance'])) {
    try {
        // Debug: Log the submitted attendance data
        $attendance_data = isset($_POST['attendance']) ? $_POST['attendance'] : [];
        error_log('Attendance data submitted: ' . print_r($attendance_data, true));
        
        if (empty($attendance_data)) {
            $alert_message = 'No attendance data submitted. Please mark attendance for at least one student.';
            $alert_type = 'error';
        } else {
            $pdo->beginTransaction();
            
            $current_time = $current_date->format('H:i:s'); // 04:00 PM as 16:00:00
            
            // Get class name for notifications
            $class_name = '';
            foreach ($classes as $class) {
                if ($class['id'] == $selected_class_id) {
                    $class_name = $class['class_name'];
                    break;
                }
            }
            
            // Prepare notification insert statement
            $notification_stmt = $pdo->prepare(
                'INSERT INTO notification_queue (uid, title, description, notification_type, is_sticky, status, created_at) 
                 VALUES (:uid, :title, :description, :notification_type, :is_sticky, :status, NOW())'
            );
            
            if ($attendance_exists) {
                // Update existing records
                $stmt = $pdo->prepare(
                    'UPDATE student_attendance 
                     SET status = :status, time = :time, updated_at = NOW() 
                     WHERE student_id = :student_id AND date = :date'
                );
                
                foreach ($attendance_data as $student_id => $status) {
                    // Map UI status to database status: 'present' -> '1', 'absent'/'leave' -> '0'
                    $db_status = ($status === 'present') ? '1' : '0';
                    $stmt->execute([
                        ':student_id' => (int)$student_id,
                        ':date' => $selected_date,
                        ':time' => $current_time,
                        ':status' => $db_status
                    ]);
                    
                    // Find student UID
                    $student_uid = '';
                    foreach ($students as $student) {
                        if ($student['id'] == $student_id) {
                            $student_uid = $student['uid'];
                            break;
                        }
                    }
                    
                    // Insert notification
                    if ($student_uid) {
                        $notification_status = ($status === 'present') ? 'Present' : ($status === 'absent' ? 'Absent' : 'On Leave');
                        $notification_stmt->execute([
                            ':uid' => $student_uid,
                            ':title' => 'Attendance Marked',
                            ':description' => "Your attendance for class {$class_name} on {$selected_date} has been marked as {$notification_status}.",
                            ':notification_type' => 'normal',
                            ':is_sticky' => 0,
                            ':status' => 'pending'
                        ]);
                    }
                }
                
                $alert_message = 'Attendance updated successfully!';
            } else {
                // Insert new records
                $stmt = $pdo->prepare(
                    'INSERT INTO student_attendance (student_id, date, time, status, created_at, updated_at) 
                     VALUES (:student_id, :date, :time, :status, NOW(), NOW())'
                );
                
                foreach ($attendance_data as $student_id => $status) {
                    // Map UI status to database status: 'present' -> '1', 'absent'/'leave' -> '0'
                    $db_status = ($status === 'present') ? '1' : '0';
                    $stmt->execute([
                        ':student_id' => (int)$student_id,
                        ':date' => $selected_date,
                        ':time' => $current_time,
                        ':status' => $db_status
                    ]);
                    
                    // Find student UID
                    $student_uid = '';
                    foreach ($students as $student) {
                        if ($student['id'] == $student_id) {
                            $student_uid = $student['uid'];
                            break;
                        }
                    }
                    
                    // Insert notification
                    if ($student_uid) {
                        $notification_status = ($status === 'present') ? 'Present' : ($status === 'absent' ? 'Absent' : 'On Leave');
                        $notification_stmt->execute([
                            ':uid' => $student_uid,
                            ':title' => 'Attendance Marked',
                            ':description' => "Your attendance for class {$class_name} on {$selected_date} has been marked as {$notification_status}.",
                            ':notification_type' => 'normal',
                            ':is_sticky' => 0,
                            ':status' => 'pending'
                        ]);
                    }
                }
                
                $alert_message = 'Attendance saved successfully!';
            }
            
            $pdo->commit();
            $alert_type = 'success';
            
            // Update existing attendance for display
            foreach ($attendance_data as $student_id => $status) {
                $existing_attendance[$student_id] = ($status === 'present') ? '1' : '0';
            }
            $attendance_exists = true;
        }
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log('Failed to save/update attendance or notifications: ' . $e->getMessage());
        $alert_message = 'Failed to save/update attendance: ' . $e->getMessage();
        $alert_type = 'error';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
   <title>EduConnect - Take Attendance</title>
   <!-- Font Awesome for icons -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   <!-- Google Fonts -->
   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
   <style>
       :root {
           --primary-color: #0055a4;
           --secondary-color: #f8f9fa;
           --text-color: #333;
           --light-text: #6c757d;
           --border-radius: 12px;
           --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
           --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
           --transition: all 0.3s ease;
           --success-color: #28a745;
           --danger-color: #dc3545;
           --warning-color: #ffc107;
       }
       
       * {
           margin: 0;
           padding: 0;
           box-sizing: border-box;
           font-family: 'Poppins', sans-serif;
           -webkit-tap-highlight-color: transparent;
       }
       
       body {
           background-color: #f0f2f5;
           color: var(--text-color);
           padding-bottom: 70px; /* Space for fixed footer */
           overflow-x: hidden;
           -webkit-font-smoothing: antialiased;
           -moz-osx-font-smoothing: grayscale;
       }
       
       .header {
           background-color: var(--primary-color);
           color: white;
           padding: 20px;
           font-size: 28px;
           font-weight: 600;
           box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
           position: sticky;
           top: 0;
           z-index: 100;
           display: flex;
           align-items: center;
       }
       
       .back-button {
           margin-right: 15px;
           cursor: pointer;
       }
       
       .section {
           background-color: white;
           border-radius: var(--border-radius);
           margin: 15px;
           padding: 20px;
           box-shadow: var(--box-shadow);
       }
       
       .section-title {
           color: var(--primary-color);
           font-size: 22px;
           font-weight: 600;
           margin-bottom: 20px;
           position: relative;
           padding-bottom: 8px;
       }
       
       .section-title::after {
           content: '';
           position: absolute;
           bottom: 0;
           left: 0;
           width: 40px;
           height: 3px;
           background-color: var(--primary-color);
           border-radius: 10px;
       }
       
       .class-selector {
           margin-bottom: 20px;
       }
       
       .select-wrapper {
           position: relative;
           margin-bottom: 15px;
       }
       
       .select-wrapper::after {
           content: '\f107';
           font-family: 'Font Awesome 5 Free';
           font-weight: 900;
           position: absolute;
           right: 15px;
           top: 50%;
           transform: translateY(-50%);
           color: var(--light-text);
           pointer-events: none;
       }
       
       .select-field {
           width: 100%;
           padding: 12px 15px;
           border: 1px solid #ddd;
           border-radius: var(--border-radius);
           appearance: none;
           font-size: 16px;
           color: var(--text-color);
           background-color: white;
       }
       
       .select-field:focus {
           outline: none;
           border-color: var(--primary-color);
       }
       
       .date-selector {
           display: flex;
           align-items: center;
           gap: 10px;
       }
       
       .date-field {
           flex: 1;
           padding: 12px 15px;
           border: 1px solid #ddd;
           border-radius: var(--border-radius);
           font-size: 16px;
           color: var(--text-color);
       }
       
       .date-field:focus {
           outline: none;
           border-color: var(--primary-color);
       }
       
       .attendance-list {
           margin-top: 20px;
       }
       
       .student-item {
           display: flex;
           align-items: center;
           padding: 15px;
           border-bottom: 1px solid #eee;
       }
       
       .student-item:last-child {
           border-bottom: none;
       }
       
       .student-avatar {
           width: 40px;
           height: 40px;
           border-radius: 50%;
           background-color: var(--primary-color);
           color: white;
           display: flex;
           align-items: center;
           justify-content: center;
           font-size: 16px;
           font-weight: 600;
           margin-right: 15px;
       }
       
       .student-avatar img {
           width: 100%;
           height: 100%;
           border-radius: 50%;
           object-fit: cover;
       }
       
       .student-info {
           flex: 1;
       }
       
       .student-name {
           font-size: 16px;
           font-weight: 500;
       }
       
       .student-roll {
           font-size: 13px;
           color: var(--light-text);
       }
       
       .attendance-toggle {
           display: flex;
           gap: 10px;
       }
       
       .attendance-button {
           width: 40px;
           height: 40px;
           border-radius: 50%;
           display: flex;
           align-items: center;
           justify-content: center;
           border: 2px solid #ddd;
           background-color: white;
           color: var(--light-text);
           cursor: pointer;
           transition: var(--transition);
       }
       
       .attendance-button.present {
           border-color: var(--success-color);
           color: var(--success-color);
       }
       
       .attendance-button.present.active {
           background-color: var(--success-color);
           color: white;
       }
       
       .attendance-button.absent {
           border-color: var(--danger-color);
           color: var(--danger-color);
       }
       
       .attendance-button.absent.active {
           background-color: var(--danger-color);
           color: white;
       }
       
       .attendance-button.leave {
           border-color: var(--warning-color);
           color: var(--warning-color);
       }
       
       .attendance-button.leave.active {
           background-color: var(--warning-color);
           color: white;
       }
       
       .submit-container {
           margin-top: 20px;
           display: flex;
           justify-content: space-between;
       }
       
       .submit-button {
           background-color: var(--primary-color);
           color: white;
           border: none;
           border-radius: var(--border-radius);
           padding: 12px 20px;
           font-size: 16px;
           font-weight: 600;
           cursor: pointer;
           transition: var(--transition);
           display: flex;
           align-items: center;
           gap: 10px;
       }
       
       .submit-button:hover {
           background-color: #004a8f;
       }
       
       .reset-button {
           background-color: var(--light-text);
           color: white;
           border: none;
           border-radius: var(--border-radius);
           padding: 12px 20px;
           font-size: 16px;
           font-weight: 600;
           cursor: pointer;
           transition: var(--transition);
           display: flex;
           align-items: center;
           gap: 10px;
       }
       
       .reset-button:hover {
           background-color: #5a6268;
       }
       
       .attendance-summary {
           display: flex;
           justify-content: space-between;
           margin-top: 20px;
           padding-top: 15px;
           border-top: 1px solid #eee;
       }
       
       .summary-item {
           text-align: center;
       }
       
       .summary-value {
           font-size: 24px;
           font-weight: 600;
       }
       
       .summary-label {
           font-size: 14px;
           color: var(--light-text);
       }
       
       .present-summary .summary-value {
           color: var(--success-color);
       }
       
       .absent-summary .summary-value {
           color: var(--danger-color);
       }
       
       .leave-summary .summary-value {
           color: var(--warning-color);
       }
       
       /* Alert message */
       .alert {
           padding: 15px;
           border-radius: var(--border-radius);
           margin-bottom: 20px;
           display: none;
       }
       
       .alert-error {
           background-color: #f8d7da;
           color: #721c24;
           border: 1px solid #f5c6cb;
       }
       
       .alert-success {
           background-color: #d4edda;
           color: #155724;
           border: 1px solid #c3e6cb;
       }
       
       .footer {
           position: fixed;
           bottom: 0;
           width: 100%;
           background-color: white;
           display: flex;
           justify-content: space-around;
           padding: 10px 0;
           box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
           z-index: 1000;
       }
       
       .footer-item {
           display: flex;
           flex-direction: column;
           align-items: center;
           text-decoration: none;
           color: var(--light-text);
           transition: var(--transition);
           padding: 5px 0;
           width: 25%;
       }
       
       .footer-item.active {
           color: var(--primary-color);
       }
       
       .footer-icon {
           font-size: 22px;
           margin-bottom: 4px;
       }
       
       .footer-text {
           font-size: 12px;
           font-weight: 500;
       }
       
       /* Loading Animation */
       .loader-container {
           position: fixed;
           top: 0;
           left: 0;
           width: 100%;
           height: 100%;
           background-color: rgba(255, 255, 255, 0.9);
           display: flex;
           justify-content: center;
           align-items: center;
           z-index: 9999;
           transition: opacity 0.3s ease;
       }
       
       .loader {
           width: 50px;
           height: 50px;
           border: 5px solid rgba(0, 85, 164, 0.2);
           border-radius: 50%;
           border-top-color: var(--primary-color);
           animation: spin 1s ease-in-out infinite;
       }
       
       @keyframes spin {
           to {
               transform: rotate(360deg);
           }
       }
       
       .loader-text {
           position: absolute;
           margin-top: 80px;
           color: var(--primary-color);
           font-weight: 500;
       }
       
       /* Media Queries for better responsiveness */
       @media (max-width: 480px) {
           .section-title {
               font-size: 20px;
           }
           
           .student-name {
               font-size: 15px;
           }
           
           .attendance-button {
               width: 35px;
               height: 35px;
           }
           
           .summary-value {
               font-size: 20px;
           }
           
           .summary-label {
               font-size: 12px;
           }
       }
       
       /* Prevent text selection for better mobile experience */
       .no-select {
           -webkit-touch-callout: none;
           -webkit-user-select: none;
           -khtml-user-select: none;
           -moz-user-select: none;
           -ms-user-select: none;
           user-select: none;
       }
   </style>
</head>
<body class="no-select">
   <!-- Loading Animation -->
   <div class="loader-container" id="loader">
       <div class="loader"></div>
       <div class="loader-text">Loading...</div>
   </div>

   <div class="header">
       <i class="fas fa-arrow-left back-button" onclick="window.location.href='index.php';"></i>
       Take Attendance
   </div>
   
   <div class="section">
       <?php if ($alert_message): ?>
           <div class="alert alert-<?php echo $alert_type; ?>" style="display: block;">
               <?php echo htmlspecialchars($alert_message); ?>
           </div>
       <?php else: ?>
           <div class="alert" id="alert" style="display: none;"></div>
       <?php endif; ?>
       
       <form method="POST" action="attendance.php">
           <div class="class-selector">
               <div class="section-title">Select Class</div>
               <div class="select-wrapper">
                   <select id="class-select" name="class_id" class="select-field" onchange="this.form.submit();">
                       <option value="">Select a class</option>
                       <?php foreach ($classes as $class): ?>
                           <option value="<?php echo $class['id']; ?>" <?php echo $selected_class_id == $class['id'] ? 'selected' : ''; ?>>
                               <?php echo $class['class_name']; ?>
                           </option>
                       <?php endforeach; ?>
                   </select>
               </div>
               
               <div class="date-selector">
                   <input type="date" id="attendance-date" name="attendance_date" class="date-field" 
                          value="<?php echo $selected_date; ?>" max="<?php echo $current_date->format('Y-m-d'); ?>" 
                          onchange="this.form.submit();" required>
               </div>
           </div>
           
           <?php if ($selected_class_id && !empty($students)): ?>
               <div id="attendance-container">
                   <div class="section-title">Mark Attendance</div>
                   <div class="attendance-list" id="student-list">
                       <?php foreach ($students as $student): ?>
                           <?php 
                           // Map database status ('0', '1') to UI status
                           $status = isset($existing_attendance[$student['id']]) ? ($existing_attendance[$student['id']] === '1' ? 'present' : 'absent') : 'present';
                           ?>
                           <div class="student-item" data-id="<?php echo $student['id']; ?>">
                               <div class="student-avatar">
                                   <?php if ($student['student_photo']): ?>
                                       <img src="/<?php echo $student['student_photo']; ?>" alt="Student Image" />
                                   <?php else: ?>
                                       <?php echo $student['initials']; ?>
                                   <?php endif; ?>
                               </div>
                               <div class="student-info">
                                   <div class="student-name"><?php echo $student['full_name']; ?></div>
                                   <div class="student-roll">Roll No: <?php echo $student['roll_no']; ?></div>
                               </div>
                               <div class="attendance-toggle">
                                   <button type="button" class="attendance-button present <?php echo $status === 'present' ? 'active' : ''; ?>" data-status="present">
                                       <i class="fas fa-check"></i>
                                   </button>
                                   <button type="button" class="attendance-button absent <?php echo $status === 'absent' ? 'active' : ''; ?>" data-status="absent">
                                       <i class="fas fa-times"></i>
                                   </button>
                                   <button type="button" class="attendance-button leave <?php echo $status === 'leave' ? 'active' : ''; ?>" data-status="leave">
                                       <i class="fas fa-calendar-minus"></i>
                                   </button>
                                   <input type="hidden" name="attendance[<?php echo $student['id']; ?>]" value="<?php echo $status; ?>">
                               </div>
                           </div>
                       <?php endforeach; ?>
                   </div>
                   
                   <div class="attendance-summary">
                       <div class="summary-item present-summary">
                           <div class="summary-value" id="present-count">0</div>
                           <div class="summary-label">Present</div>
                       </div>
                       <div class="summary-item absent-summary">
                           <div class="summary-value" id="absent-count">0</div>
                           <div class="summary-label">Absent</div>
                       </div>
                       <div class="summary-item leave-summary">
                           <div class="summary-value" id="leave-count">0</div>
                           <div class="summary-label">Leave</div>
                       </div>
                   </div>
                   
                   <div class="submit-container">
                       <button type="button" id="reset-button" class="reset-button">
                           <i class="fas fa-redo"></i> Select All
                       </button>
                       <button type="submit" name="submit_attendance" class="submit-button">
                           <i class="fas fa-save"></i> <?php echo $attendance_exists ? 'Update' : 'Save'; ?>
                       </button>
                   </div>
               </div>
           <?php elseif ($selected_class_id): ?>
               <p>No students in this class.</p>
           <?php endif; ?>
       </form>
   </div>
   
   <!-- Footer Navigation -->
   <div class="footer">
       <a href="index.php" class="footer-item">
           <i class="fas fa-home footer-icon"></i>
           <span class="footer-text">Dashboard</span>
       </a>
       <a href="classes.php" class="footer-item">
           <i class="fas fa-chalkboard footer-icon"></i>
           <span class="footer-text">Classes</span>
       </a>
       <a href="marks.php" class="footer-item ripple">
            <i class="fa fa-pencil-square footer-icon"></i>
            <span class="footer-text">Marks</span>
        </a>
       <a href="profile.php" class="footer-item">
           <i class="fas fa-user footer-icon"></i>
           <span class="footer-text">Profile</span>
       </a>
   </div>
   
   <script>
       document.addEventListener('DOMContentLoaded', function() {
           const loader = document.getElementById('loader');
           
           // Function to show loader
           function showLoader() {
               loader.style.display = 'flex';
           }
           
           // Function to hide loader
           function hideLoader() {
               loader.style.opacity = '0';
               setTimeout(() => {
                   loader.style.display = 'none';
                   loader.style.opacity = '1';
               }, 300);
           }
           
           // Add click event to attendance buttons
           const attendanceButtons = document.querySelectorAll('.attendance-button');
           attendanceButtons.forEach(button => {
               button.addEventListener('click', function() {
                   const studentItem = this.closest('.student-item');
                   const buttons = studentItem.querySelectorAll('.attendance-button');
                   const hiddenInput = studentItem.querySelector('input[type="hidden"]');
                   
                   // Remove active class from all buttons
                   buttons.forEach(btn => btn.classList.remove('active'));
                   
                   // Add active class to clicked button
                   this.classList.add('active');
                   
                   // Update hidden input value
                   hiddenInput.value = this.getAttribute('data-status');
                   
                   // Update summary
                   updateSummary();
               });
           });
           
           // Reset button click event (with null check)
           const resetButton = document.getElementById('reset-button');
           if (resetButton) {
               resetButton.addEventListener('click', function() {
                   const studentItems = document.querySelectorAll('.student-item');
                   
                   studentItems.forEach(item => {
                       const buttons = item.querySelectorAll('.attendance-button');
                       const hiddenInput = item.querySelector('input[type="hidden"]');
                       
                       // Remove active class from all buttons
                       buttons.forEach(btn => btn.classList.remove('active'));
                       
                       // Set present as default
                       const presentButton = item.querySelector('.attendance-button.present');
                       presentButton.classList.add('active');
                       hiddenInput.value = 'present';
                   });
                   
                   // Update summary
                   updateSummary();
               });
           }
           
           // Function to update attendance summary
           function updateSummary() {
               let presentCount = document.querySelectorAll('.attendance-button.present.active').length;
               let absentCount = document.querySelectorAll('.attendance-button.absent.active').length;
               let leaveCount = document.querySelectorAll('.attendance-button.leave.active').length;
               
               const presentCountElement = document.getElementById('present-count');
               const absentCountElement = document.getElementById('absent-count');
               const leaveCountElement = document.getElementById('leave-count');
               
               if (presentCountElement) presentCountElement.textContent = presentCount;
               if (absentCountElement) absentCountElement.textContent = absentCount;
               if (leaveCountElement) leaveCountElement.textContent = leaveCount;
           }
           
           // Auto-hide alert after 5 seconds
           const alertBox = document.getElementById('alert');
           if (alertBox && alertBox.style.display === 'block') {
               setTimeout(() => {
                   alertBox.style.display = 'none';
               }, 5000);
           }
           
           // Update summary on page load (if elements exist)
           updateSummary();
           
           // Hide loader after page load
           hideLoader();
       });
   </script>
</body>
</html>