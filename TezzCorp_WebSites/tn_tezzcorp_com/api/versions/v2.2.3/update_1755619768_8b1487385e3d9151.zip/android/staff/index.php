<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM staff WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'staff')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'staff';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch teacher data
try {
    $stmt = $pdo->prepare(
        'SELECT name, role, photo 
         FROM staff 
         WHERE id = :id AND status = "active"'
    );
    $stmt->execute([':id' => $_SESSION['user_id']]);
    $teacher = $stmt->fetch();
    
    if (!$teacher) {
        session_destroy();
        header("Location: /android/");
        exit;
    }
    
    $teacher_name = htmlspecialchars($teacher['name']);
    $teacher_role = htmlspecialchars($teacher['role']);
    $teacher_photo = htmlspecialchars($teacher['photo'] ?: '/android/default_avatar.png');
} catch (PDOException $e) {
    error_log('Failed to fetch teacher data: ' . $e->getMessage());
    $teacher_name = "Unknown Teacher";
    $teacher_role = "Teacher";
    $teacher_photo = "/android/default_avatar.png";
}

// Fetch classes (from class_teacher and subject_teacher, joining with class table)
$classes = [];
try {
    // Fetch classes where the teacher is a class teacher
    $stmt = $pdo->prepare(
        'SELECT c.id, c.class_name, "Class Teacher" as role 
         FROM class_teacher ct
         JOIN class c ON ct.class = c.id
         WHERE ct.tid = :tid AND ct.status = "active" AND c.status = "active"'
    );
    $stmt->execute([':tid' => $_SESSION['user_id']]);
    $class_teacher_classes = $stmt->fetchAll();
    
    // Fetch classes where the teacher is a subject teacher
    $stmt = $pdo->prepare(
        'SELECT c.id, c.class_name, st.subject, "Subject Teacher" as role 
         FROM subject_teacher st
         JOIN class c ON st.class = c.id
         WHERE st.tid = :tid AND c.status = "active"'
    );
    $stmt->execute([':tid' => $_SESSION['user_id']]);
    $subject_teacher_classes = $stmt->fetchAll();
    
    // Combine and deduplicate classes
    $class_map = [];
    foreach ($class_teacher_classes as $class) {
        $class_key = $class['id'] . '-' . $class['role'];
        $class_map[$class_key] = [
            'id' => $class['id'],
            'name' => $class['class_name'],
            'role' => $class['role'],
            'schedule' => 'N/A', // Placeholder, as schedule isn't in the schema
            'details' => 'Class Teacher'
        ];
    }
    
    foreach ($subject_teacher_classes as $class) {
        $class_key = $class['id'] . '-' . $class['role'] . '-' . $class['subject'];
        $class_map[$class_key] = [
            'id' => $class['id'],
            'name' => $class['class_name'],
            'role' => $class['role'],
            'schedule' => 'N/A', // Placeholder
            'details' => $class['subject']
        ];
    }
    
    $classes = array_values($class_map);
} catch (PDOException $e) {
    error_log('Failed to fetch classes: ' . $e->getMessage());
    $classes = [];
}

// Fetch upcoming events (holidays within the next 30 days)
$events = [];
try {
    $currentDate = new DateTime('2025-06-01 15:04:00', new DateTimeZone('Asia/Kolkata'));
    $endDate = (clone $currentDate)->modify('+30 days');
    
    $stmt = $pdo->prepare(
        'SELECT holiday_date, name 
         FROM holidays 
         WHERE holiday_date BETWEEN :start_date AND :end_date 
         AND status = "published" 
         ORDER BY holiday_date ASC'
    );
    $stmt->execute([
        ':start_date' => $currentDate->format('Y-m-d'),
        ':end_date' => $endDate->format('Y-m-d')
    ]);
    $holidays = $stmt->fetchAll();
    
    foreach ($holidays as $holiday) {
        $eventDate = new DateTime($holiday['holiday_date']);
        $events[] = [
            'date' => $holiday['holiday_date'],
            'title' => htmlspecialchars($holiday['name']),
            'time' => $eventDate->format('h:i A')
        ];
    }
} catch (PDOException $e) {
    error_log('Failed to fetch events: ' . $e->getMessage());
    $events = [];
}

// Fetch teaching stats
$stats = [
    'classes' => count($classes)
];

// Fetch site settings
try {
    $stmt = $pdo->prepare('SELECT school_name, facebook_url, twitter_url, instagram_url, linkedin_url FROM site_settings WHERE id = 1');
    $stmt->execute();
    $settings = $stmt->fetch();
    
    if (!$settings) {
        $settings = [
            'school_name' => 'EduConnect',
            'facebook_url' => '#',
            'twitter_url' => '#',
            'instagram_url' => '#',
            'linkedin_url' => '#'
        ];
    }
} catch (PDOException $e) {
    error_log('Failed to fetch site settings: ' . $e->getMessage());
    $settings = [
        'school_name' => 'EduConnect',
        'facebook_url' => '#',
        'twitter_url' => '#',
        'instagram_url' => '#',
        'linkedin_url' => '#'
    ];
}

$school_name = htmlspecialchars($settings['school_name']);
$facebook_url = htmlspecialchars($settings['facebook_url']);
$twitter_url = htmlspecialchars($settings['twitter_url']);
$instagram_url = htmlspecialchars($settings['instagram_url']);
$linkedin_url = htmlspecialchars($settings['linkedin_url']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $school_name; ?> - Dashboard</title>
    
    <!-- Favicon and Icons -->
    <link rel="icon" type="image/svg+xml" href="/android/favicon.svg">
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header-title {
            font-size: 24px;
        }
        
        .header-actions {
            display: flex;
            gap: 15px;
        }
        
        .header-icon {
            font-size: 20px;
            cursor: pointer;
        }
        
        .teacher-welcome {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .teacher-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: 600;
        }
        
        .teacher-info {
            flex: 1;
        }
        
        .teacher-name {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .teacher-role {
            font-size: 14px;
            color: var(--light-text);
        }
        
        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }
        
        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
        }
        
        .quick-action {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 15px 10px;
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: var(--transition);
            cursor: pointer;
            height: 100%;
        }
        
        .quick-action:hover, .quick-action:active {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }
        
        .quick-action-icon {
            width: 50px;
            height: 50px;
            margin-bottom: 12px;
            color: var(--primary-color);
            font-size: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(0, 85, 164, 0.1);
            border-radius: 50%;
            padding: 12px;
        }
        
        .quick-action-name {
            font-size: 13px;
            font-weight: 500;
            color: var(--text-color);
            line-height: 1.3;
        }
        
        .class-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .class-item {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: var(--transition);
            cursor: pointer;
        }
        
        .class-item:hover {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }
        
        .class-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .class-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: rgba(0, 85, 164, 0.1);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            flex-shrink: 0;
        }
        
        .class-details {
            flex: 1;
        }
        
        .class-name {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .class-meta {
            font-size: 14px;
            color: var(--light-text);
            display: flex;
            gap: 15px;
        }
        
        .class-meta-item {
            display: flex;
            align-items: center;
        }
        
        .class-meta-item i {
            margin-right: 5px;
        }
        
        .class-arrow {
            color: var(--light-text);
        }
        
        .upcoming-events {
            margin-top: 15px;
        }
        
        .event-item {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .event-item:last-child {
            border-bottom: none;
        }
        
        .event-date {
            width: 50px;
            height: 60px;
            background-color: var(--primary-color);
            color: white;
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
        }
        
        .event-day {
            font-size: 20px;
            font-weight: 600;
        }
        
        .event-month {
            font-size: 12px;
            text-transform: uppercase;
        }
        
        .event-details {
            flex: 1;
        }
        
        .event-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .event-time {
            font-size: 13px;
            color: var(--light-text);
            display: flex;
            align-items: center;
        }
        
        .event-time i {
            margin-right: 5px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        
        .stat-card {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: rgba(0, 85, 164, 0.1);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-right: 15px;
        }
        
        .stat-info {
            flex: 1;
        }
        
        .stat-value {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 14px;
            color: var(--light-text);
        }
        
        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }
        
        .footer-item.active {
            color: var(--primary-color);
        }
        
        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }
        
        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }
        
        /* Ripple effect */
        .ripple {
            position: relative;
            overflow: hidden;
        }
        
        .ripple:after {
            content: "";
            display: block;
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            pointer-events: none;
            background-image: radial-gradient(circle, #fff 10%, transparent 10.01%);
            background-repeat: no-repeat;
            background-position: 50%;
            transform: scale(10, 10);
            opacity: 0;
            transition: transform .5s, opacity 1s;
        }
        
        .ripple:active:after {
            transform: scale(0, 0);
            opacity: .3;
            transition: 0s;
        }
        
        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .quick-actions {
                grid-template-columns: repeat(4, 1fr);
                gap: 10px;
            }
            
            .quick-action {
                padding: 10px 5px;
            }
            
            .quick-action-icon {
                width: 40px;
                height: 40px;
                font-size: 20px;
                margin-bottom: 8px;
            }
            
            .quick-action-name {
                font-size: 11px;
            }
            
            .section-title {
                font-size: 20px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 360px) {
            .quick-actions {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <div class="header-title">Dashboard</div>
        <div class="header-actions">
            <i class="fas fa-bell header-icon"></i>
            <i class="fas fa-envelope header-icon"></i>
        </div>
    </div>
    
    <div class="teacher-welcome">
        <div class="teacher-avatar">
            <img style="width: 60px; height: 60px; border-radius: 50%;" src="/<?php echo $teacher_photo; ?>" alt="Teacher Avatar" />
        </div>
        <div class="teacher-info">
            <div class="teacher-name"><?php echo $teacher_name; ?></div>
            <div class="teacher-role"><?php echo $teacher_role; ?></div>
        </div>
    </div>
    
    <div class="section">
        <div class="section-title">Quick Actions</div>
        <div class="quick-actions">
            <div class="quick-action ripple" data-href="attendance.php">
                <div class="quick-action-icon">
                    <i class="fas fa-clipboard-check"></i>
                </div>
                <div class="quick-action-name">Take Attendance</div>
            </div>
            <div class="quick-action ripple" data-href="homework.php">
                <div class="quick-action-icon">
                    <i class="fas fa-book"></i>
                </div>
                <div class="quick-action-name">Assign Homework</div>
            </div>
            <div class="quick-action ripple" data-href="check_homework.php">
                <div class="quick-action-icon">
                    <i class="fas fa-tasks"></i>
                </div>
                <div class="quick-action-name">Check Homework</div>
            </div>
            <div class="quick-action ripple" data-href="notices.php">
                <div class="quick-action-icon">
                    <i class="fas fa-bullhorn"></i>
                </div>
                <div class="quick-action-name">Post Notice</div>
            </div>
        </div>
    </div>
    
    <div class="section">
        <div class="section-title">My Classes</div>
        <div class="class-list">
            <?php if (empty($classes)): ?>
                <p>No classes assigned yet.</p>
            <?php else: ?>
                <?php foreach ($classes as $class): ?>
                    <div class="class-item" data-class-id="<?php echo htmlspecialchars($class['id']); ?>">
                        <div class="class-info">
                            <div class="class-icon">
                                <i class="fas fa-chalkboard"></i>
                            </div>
                            <div class="class-details">
                                <div class="class-name"><?php echo htmlspecialchars($class['name']); ?></div>
                                <div class="class-meta">
                                    <div class="class-meta-item">
                                        <i class="fas fa-clock"></i> <?php echo htmlspecialchars($class['schedule']); ?>
                                    </div>
                                    <div class="class-meta-item">
                                        <?php echo htmlspecialchars($class['details']); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="class-arrow">
                            <i class="fas fa-chevron-right"></i>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="section">
        <div class="section-title">Upcoming Events</div>
        <div class="upcoming-events">
            <?php if (empty($events)): ?>
                <p>No upcoming events.</p>
            <?php else: ?>
                <?php foreach ($events as $event): ?>
                    <?php
                    $eventDate = new DateTime($event['date']);
                    $day = $eventDate->format('d');
                    $month = $eventDate->format('M');
                    ?>
                    <div class="event-item">
                        <div class="event-date">
                            <div class="event-day"><?php echo $day; ?></div>
                            <div class="event-month"><?php echo $month; ?></div>
                        </div>
                        <div class="event-details">
                            <div class="event-title"><?php echo $event['title']; ?></div>
                            <div class="event-time"><i class="far fa-clock"></i> <?php echo $event['time']; ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="section">
        <div class="section-title">Teaching Stats</div>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-chalkboard"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-value"><?php echo $stats['classes']; ?></div>
                    <div class="stat-label">Classes</div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item active ripple">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="classes.php" class="footer-item ripple">
            <i class="fas fa-chalkboard footer-icon"></i>
            <span class="footer-text">Classes</span>
        </a>
        <a href="marks.php" class="footer-item ripple">
            <i class="fa fa-pencil-square footer-icon"></i>
            <span class="footer-text">Marks</span>
        </a>
        <a href="profile.php" class="footer-item ripple">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Profile</span>
        </a>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loader = document.getElementById('loader');
            
            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }
            
            // Prevent zooming on double tap
            document.addEventListener('dblclick', function(e) {
                e.preventDefault();
            });
            
            // Add active state to quick actions on touch
            const quickActions = document.querySelectorAll('.quick-action');
            quickActions.forEach(action => {
                action.addEventListener('touchstart', function() {
                    this.style.backgroundColor = 'rgba(0, 85, 164, 0.05)';
                });
                
                action.addEventListener('touchend', function() {
                    this.style.backgroundColor = 'white';
                });
                
                action.addEventListener('click', function() {
                    showLoader();
                    const href = this.getAttribute('data-href');
                    if (href) {
                        window.location.href = href;
                    }
                });
            });
            
            // Add click event to class items to navigate to class_details.php
            const classItems = document.querySelectorAll('.class-item');
            classItems.forEach(item => {
                item.addEventListener('click', function() {
                    showLoader();
                    const classId = this.getAttribute('data-class-id');
                    window.location.href = `class_details.php?class_id=${classId}`;
                });
            });
            
            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>