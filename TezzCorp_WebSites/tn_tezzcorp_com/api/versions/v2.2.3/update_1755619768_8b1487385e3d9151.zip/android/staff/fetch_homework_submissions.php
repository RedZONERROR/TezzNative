<?php
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

// Get request data
$input = json_decode(file_get_contents('php://input'), true);
$class_name = isset($input['class']) ? trim($input['class']) : '';
$date = isset($input['date']) ? trim($input['date']) : '';

if (empty($class_name) || empty($date)) {
    echo json_encode(['error' => 'Class and date are required']);
    exit;
}

// Fetch homework for the given class and date
try {
    $stmt = $pdo->prepare(
        'SELECT id 
         FROM homework 
         WHERE class = :class AND date = :date'
    );
    $stmt->execute([':class' => $class_name, ':date' => $date]);
    $homework = $stmt->fetchAll();
    
    if (empty($homework)) {
        echo json_encode(['submissions' => []]);
        exit;
    }
    
    $homework_ids = array_column($homework, 'id');
    
    // Fetch submissions for the homework
    $stmt = $pdo->prepare(
        'SELECT hs.id AS submission_id, hs.sid, hs.hid, hs.date, hs.status, s.name, s.roll_no, s.photo 
         FROM homework_submissions hs
         JOIN students s ON hs.sid = s.id
         WHERE hs.hid IN (' . implode(',', array_fill(0, count($homework_ids), '?')) . ')'
    );
    $stmt->execute($homework_ids);
    $submissions = $stmt->fetchAll();
    
    // Fetch work from homework table (assuming students submit the same work as assigned)
    foreach ($submissions as &$submission) {
        $stmt = $pdo->prepare('SELECT work FROM homework WHERE id = :hid');
        $stmt->execute([':hid' => $submission['hid']]);
        $homework_data = $stmt->fetch();
        $submission['work'] = $homework_data['work'] ?? '';
        
        // Generate initials if photo is not available
        $submission['initials'] = strtoupper(substr($submission['name'], 0, 2));
    }
    
    echo json_encode(['submissions' => $submissions]);
} catch (PDOException $e) {
    error_log('Failed to fetch submissions: ' . $e->getMessage());
    echo json_encode(['error' => 'Failed to fetch submissions']);
    exit;
}
?>