<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM staff WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'staff')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'staff';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Get student ID from query parameter
$student_id = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
if ($student_id <= 0) {
    header("Location: marks.php");
    exit;
}

// Fetch student details including session
try {
    $stmt = $pdo->prepare(
        'SELECT s.id, s.uid, s.full_name, s.class, s.session, d.student_photo
         FROM students s 
         LEFT JOIN documents d ON d.uid = s.uid
         WHERE s.id = :id AND s.status = "active"'
    );
    $stmt->execute([':id' => $student_id]);
    $student = $stmt->fetch();
    
    if (!$student) {
        header("Location: marks.php");
        exit;
    }
    
    $student['full_name'] = htmlspecialchars($student['full_name']);
    $student_session = htmlspecialchars($student['session']);
} catch (PDOException $e) {
    error_log('Failed to fetch student: ' . $e->getMessage());
    header("Location: marks.php");
    exit;
}

// Fetch class details
try {
    $stmt = $pdo->prepare(
        'SELECT class_name 
         FROM class 
         WHERE id = :id AND status = "active"'
    );
    $stmt->execute([':id' => $student['class']]);
    $class = $stmt->fetch();
    
    if (!$class) {
        header("Location: marks.php");
        exit;
    }
    
    $class_name = htmlspecialchars($class['class_name']);
} catch (PDOException $e) {
    error_log('Failed to fetch class: ' . $e->getMessage());
    header("Location: marks.php");
    exit;
}

// Fetch subjects for the class
$subjects = [];
try {
    $stmt = $pdo->prepare(
        'SELECT id, subject, full_marks 
         FROM subject 
         WHERE class = :class_id AND status = "active"'
    );
    $stmt->execute([':class_id' => $student['class']]);
    $subjects = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('Failed to fetch subjects: ' . $e->getMessage());
}

// Define term options
$terms = ['1st Term', '2nd Term', '3rd Term'];

// Handle form submission
$success_message = '';
$error_message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject_id = isset($_POST['subject_id']) ? (int)$_POST['subject_id'] : 0;
    $marks_obtained = isset($_POST['marks_obtained']) ? (float)$_POST['marks_obtained'] : 0;
    $max_marks = isset($_POST['max_marks']) ? (float)$_POST['max_marks'] : 100;
    $session = $student_session; // Use session from student record
    $term = isset($_POST['term']) ? trim($_POST['term']) : '';

    // Validate subject exists and get its full_marks
    $selected_subject = null;
    foreach ($subjects as $subj) {
        if ($subj['id'] == $subject_id) {
            $selected_subject = $subj;
            break;
        }
    }

    if ($subject_id > 0 && $marks_obtained >= 0 && $max_marks > 0 && !empty($session) && in_array($term, $terms)) {
        if ($selected_subject && $marks_obtained <= $selected_subject['full_marks']) {
            try {
                // Check if marks already exist for this student, subject, session, and term
                $stmt = $pdo->prepare(
                    'SELECT id FROM results 
                     WHERE uid = :uid AND class_id = :class_id AND subject_id = :subject_id 
                     AND session = :session AND term = :term'
                );
                $stmt->execute([
                    ':uid' => $student['uid'],
                    ':class_id' => $student['class'],
                    ':subject_id' => $subject_id,
                    ':session' => $session,
                    ':term' => $term
                ]);
                
                if ($stmt->fetch()) {
                    $error_message = 'Marks already exist for this student, subject, session, and term.';
                } else {
                    // Insert marks
                    $stmt = $pdo->prepare(
                        'INSERT INTO results (uid, class_id, session, term, subject_id, marks_obtained, max_marks, created_at, updated_at)
                         VALUES (:uid, :class_id, :session, :term, :subject_id, :marks_obtained, :max_marks, NOW(), NOW())'
                    );
                    $stmt->execute([
                        ':uid' => $student['uid'],
                        ':class_id' => $student['class'],
                        ':session' => $session,
                        ':term' => $term,
                        ':subject_id' => $subject_id,
                        ':marks_obtained' => $marks_obtained,
                        ':max_marks' => $max_marks
                    ]);
                    $success_message = 'Marks added successfully!';
                }
            } catch (PDOException $e) {
                error_log('Failed to insert marks: ' . $e->getMessage());
                $error_message = 'Failed to add marks. Please try again.';
            }
        } else {
            $error_message = 'Invalid marks or subject. Marks cannot exceed full marks.';
        }
    } else {
        $error_message = 'Please fill in all required fields correctly.';
    }
}

// Fetch existing marks for the student
$existing_marks = [];
try {
    $stmt = $pdo->prepare(
        'SELECT r.session, r.term, r.marks_obtained, r.max_marks, s.subject
         FROM results r
         JOIN subject s ON r.subject_id = s.id
         WHERE r.uid = :uid AND r.class_id = :class_id
         ORDER BY r.session, r.term, s.subject'
    );
    $stmt->execute([
        ':uid' => $student['uid'],
        ':class_id' => $student['class']
    ]);
    $existing_marks = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('Failed to fetch existing marks: ' . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>EduConnect - Add Student Marks</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }

        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }

        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }

        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }

        .student-info {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .student-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: rgba(0, 85, 164, 0.1);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            flex-shrink: 0;
        }

        .student-name {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .student-meta {
            font-size: 14px;
            color: var(--light-text);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 5px;
            color: var(--text-color);
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: var(--transition);
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 5px rgba(0, 85, 164, 0.2);
        }

        .submit-button {
            background-color: var(--primary-color);
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            width: 100%;
            transition: var(--transition);
        }

        .submit-button:hover {
            background-color: #004080;
            transform: translateY(-2px);
        }

        .message {
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 14px;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
        }

        .marks-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .marks-item {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .marks-details {
            font-size: 14px;
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }

        .footer-item.active {
            color: var(--primary-color);
        }

        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }

        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }

        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }

        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }

        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
            text-align: center;
        }

        .empty-icon {
            font-size: 50px;
            color: #ccc;
            margin-bottom: 15px;
        }

        .empty-text {
            font-size: 16px;
            color: var(--light-text);
            margin-bottom: 20px;
        }

        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }

            .student-name {
                font-size: 18px;
            }
        }

        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" onclick="window.location.href='marks.php';"></i>
        Add Student Marks
    </div>

    <div class="section">
        <div class="student-info">
            <div class="student-icon">
                <img src="/<?php echo $student['student_photo']; ?>" alt="<?php echo $student['full_name']; ?>" style="width: 50px; height: 50px; border-radius: 50%;">
            </div>
            <div>
                <div class="student-name"><?php echo $student['full_name']; ?></div>
                <div class="student-meta"><?php echo $class_name; ?> | Session: <?php echo $student_session; ?></div>
            </div>
        </div>

        <div class="section-title">Add Marks</div>
        <?php if ($success_message): ?>
            <div class="message success-message"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="message error-message"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label for="subject_id">Subject</label>
                <select name="subject_id" id="subject_id" required>
                    <option value="">Select Subject</option>
                    <?php foreach ($subjects as $subject): ?>
                        <option value="<?php echo $subject['id']; ?>" data-full-marks="<?php echo $subject['full_marks']; ?>">
                            <?php echo htmlspecialchars($subject['subject']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="marks_obtained">Marks Obtained</label>
                <input type="number" name="marks_obtained" id="marks_obtained" step="0.01" min="0" required>
            </div>
            <div class="form-group">
                <label for="max_marks">Maximum Marks</label>
                <input type="number" name="max_marks" id="max_marks" step="0.01" min="1" readonly>
            </div>
            <div class="form-group">
                <label for="session">Session</label>
                <input type="text" name="session" id="session" value="<?php echo $student_session; ?>" readonly>
            </div>
            <div class="form-group">
                <label for="term">Term</label>
                <select name="term" id="term" required>
                    <option value="">Select Term</option>
                    <?php foreach ($terms as $term): ?>
                        <option value="<?php echo $term; ?>"><?php echo $term; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="submit-button">Add Marks</button>
        </form>

        <div class="section-title">Existing Marks</div>
        <div class="marks-list">
            <?php if (empty($existing_marks)): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-clipboard-list"></i>
                    </div>
                    <div class="empty-text">No marks recorded for this student.</div>
                </div>
            <?php else: ?>
                <?php foreach ($existing_marks as $mark): ?>
                    <div class="marks-item">
                        <div class="marks-details">
                            <strong>Subject:</strong> <?php echo htmlspecialchars($mark['subject']); ?><br>
                            <strong>Session:</strong> <?php echo htmlspecialchars($mark['session']); ?><br>
                            <strong>Term:</strong> <?php echo htmlspecialchars($mark['term']); ?><br>
                            <strong>Marks:</strong> <?php echo htmlspecialchars($mark['marks_obtained']); ?> / <?php echo htmlspecialchars($mark['max_marks']); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="footer">
        <a href="index.php" class="footer-item">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="classes.php" class="footer-item">
            <i class="fas fa-chalkboard footer-icon"></i>
            <span class="footer-text">Classes</span>
        </a>
        <a href="marks.php" class="footer-item active">
            <i class="fa fa-pencil-square footer-icon"></i>
            <span class="footer-text">Marks</span>
        </a>
        <a href="profile.php" class="footer-item">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Profile</span>
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loader = document.getElementById('loader');
            
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }
            
            hideLoader();

            // Update max_marks based on selected subject
            const subjectSelect = document.getElementById('subject_id');
            const maxMarksInput = document.getElementById('max_marks');
            
            subjectSelect.addEventListener('change', function() {
                const selectedOption = this.options[this.selectedIndex];
                const fullMarks = selectedOption.getAttribute('data-full-marks') || '100';
                maxMarksInput.value = fullMarks;
            });
        });
    </script>
</body>
</html>