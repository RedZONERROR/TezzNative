<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM staff WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'staff')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'staff';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch classes (from class_teacher and subject_teacher, joining with class table)
$classes = [];
try {
    // Fetch classes where the teacher is a class teacher
    $stmt = $pdo->prepare(
        'SELECT c.id as class_id, c.class_name, "Class Teacher" as role 
         FROM class_teacher ct
         JOIN class c ON ct.class = c.id
         WHERE ct.tid = :tid AND ct.status = "active" AND c.status = "active"'
    );
    $stmt->execute([':tid' => $_SESSION['user_id']]);
    $class_teacher_classes = $stmt->fetchAll();
    
    // Fetch classes where the teacher is a subject teacher
    $stmt = $pdo->prepare(
        'SELECT c.id as class_id, c.class_name, st.subject, "Subject Teacher" as role 
         FROM subject_teacher st
         JOIN class c ON st.class = c.id
         WHERE st.tid = :tid AND c.status = "active"'
    );
    $stmt->execute([':tid' => $_SESSION['user_id']]);
    $subject_teacher_classes = $stmt->fetchAll();
    
    // Combine and deduplicate classes
    $class_map = [];
    foreach ($class_teacher_classes as $class) {
        $class_key = $class['class_name'] . '-' . $class['role'];
        $class_map[$class_key] = [
            'id' => $class['class_id'],
            'name' => $class['class_name'],
            'role' => $class['role'],
            'schedule' => 'N/A', // Placeholder, as schedule isn't in the schema
            'details' => 'Class Teacher'
        ];
    }
    
    foreach ($subject_teacher_classes as $class) {
        $class_key = $class['class_name'] . '-' . $class['role'] . '-' . $class['subject'];
        $class_map[$class_key] = [
            'id' => $class['class_id'],
            'name' => $class['class_name'],
            'role' => $class['role'],
            'schedule' => 'N/A', // Placeholder
            'details' => $class['subject']
        ];
    }
    
    $classes = array_values($class_map);
} catch (PDOException $e) {
    error_log('Failed to fetch classes: ' . $e->getMessage());
    $classes = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>EduConnect - My Classes</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }

        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }

        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }

        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }

        .class-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .class-item {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: var(--transition);
            cursor: pointer;
        }

        .class-item:hover {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }

        .class-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .class-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: rgba(0, 85, 164, 0.1);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            flex-shrink: 0;
        }

        .class-details {
            flex: 1;
        }

        .class-name {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .class-meta {
            font-size: 14px;
            color: var(--light-text);
            display: flex;
            gap: 15px;
        }

        .class-meta-item {
            display: flex;
            align-items: center;
        }

        .class-meta-item i {
            margin-right: 5px;
        }

        .class-arrow {
            color: var(--light-text);
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }

        .footer-item.active {
            color: var(--primary-color);
        }

        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }

        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }

        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }

        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }

        /* Empty state */
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
            text-align: center;
        }

        .empty-icon {
            font-size: 50px;
            color: #ccc;
            margin-bottom: 15px;
        }

        .empty-text {
            font-size: 16px;
            color: var(--light-text);
            margin-bottom: 20px;
        }

        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }

            .class-name {
                font-size: 15px;
            }
        }

        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" onclick="window.location.href='index.php';"></i>
        My Classes
    </div>

    <div class="section">
        <div class="section-title">Assigned Classes</div>
        <div class="class-list">
            <?php if (empty($classes)): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-chalkboard"></i>
                    </div>
                    <div class="empty-text">No classes assigned to you.</div>
                </div>
            <?php else: ?>
                <?php foreach ($classes as $class): ?>
                    <div class="class-item" data-id="<?php echo htmlspecialchars($class['id']); ?>">
                        <div class="class-info">
                            <div class="class-icon">
                                <i class="fas fa-chalkboard"></i>
                            </div>
                            <div class="class-details">
                                <div class="class-name"><?php echo htmlspecialchars($class['name']); ?></div>
                                <div class="class-meta">
                                    <div class="class-meta-item">
                                        <i class="fas fa-clock"></i> <?php echo htmlspecialchars($class['schedule']); ?>
                                    </div>
                                    <div class="class-meta-item">
                                        <?php echo htmlspecialchars($class['details']); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="classes.php" class="footer-item active">
            <i class="fas fa-chalkboard footer-icon"></i>
            <span class="footer-text">Classes</span>
        </a>
        <a href="marks.php" class="footer-item ripple">
            <i class="fa fa-pencil-square footer-icon"></i>
            <span class="footer-text">Marks</span>
        </a>
        <a href="profile.php" class="footer-item">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Profile</span>
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show loader
            const loader = document.getElementById('loader');
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }
            
            // Hide loader after page load
            hideLoader();

            // Add click event to class items
            const classItems = document.querySelectorAll('.class-item');
            classItems.forEach(item => {
                item.addEventListener('click', function() {
                    const classId = this.getAttribute('data-id');
                    window.location.href = `class_details.php?class_id=${classId}`;
                });
            });
        });
    </script>
</body>
</html>