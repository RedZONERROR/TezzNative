<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// SessionManager class to validate session tokens
class SessionManager {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function validateSession($session_token, $user_id, $user_type) {
        try {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM sessions 
                WHERE session_token = :session_token 
                AND user_id = :user_id 
                AND user_type = :user_type 
                AND expires_at > NOW()'
            );
            $stmt->execute([
                ':session_token' => $session_token,
                ':user_id' => $user_id,
                ':user_type' => $user_type
            ]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log('Session validation failed: ' . $e->getMessage());
            return false;
        }
    }
}

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    header("Location: /android/");
    exit;
}

// Initialize managers
$sessionManager = new SessionManager($pdo);

// Check session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || !isset($_SESSION['session_token'])) {
    if (isset($_COOKIE['session_token']) && isset($_COOKIE['android_uid'])) {
        $stmt = $pdo->prepare('SELECT id, full_name FROM staff WHERE uid = :uid AND status = "active"');
        $stmt->execute([':uid' => $_COOKIE['android_uid']]);
        $user = $stmt->fetch();
        
        if ($user && $sessionManager->validateSession($_COOKIE['session_token'], $user['id'], 'staff')) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'staff';
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['session_token'] = $_COOKIE['session_token'];
        } else {
            header("Location: /android/");
            exit;
        }
    } else {
        header("Location: /android/");
        exit;
    }
}

// Verify session token
if (!$sessionManager->validateSession($_SESSION['session_token'], $_SESSION['user_id'], $_SESSION['user_type'])) {
    session_destroy();
    setcookie('session_token', '', time() - 3600, '/', '', true, true);
    header("Location: /android/");
    exit;
}

// Fetch classes assigned to the teacher (from class_teacher)
$classes = [];
try {
    $stmt = $pdo->prepare(
        'SELECT c.id, c.class_name 
         FROM class_teacher ct
         JOIN class c ON ct.class = c.id
         WHERE ct.tid = :tid AND ct.status = "active" AND c.status = "active"'
    );
    $stmt->execute([':tid' => $_SESSION['user_id']]);
    $classes = $stmt->fetchAll();
    
    foreach ($classes as &$class) {
        $class['class_name'] = htmlspecialchars($class['class_name']);
    }
} catch (PDOException $e) {
    error_log('Failed to fetch classes: ' . $e->getMessage());
    $classes = [];
}

// Fetch notices posted by the teacher
$notices = [];
try {
    $stmt = $pdo->prepare(
        'SELECT n.id, n.title, n.content, n.date, n.class 
         FROM notices n 
         WHERE n.posted_by = :tid AND n.status = "active"
         ORDER BY n.date DESC'
    );
    $stmt->execute([':tid' => $_SESSION['user_id']]);
    $notices = $stmt->fetchAll();
    
    foreach ($notices as &$notice) {
        $notice['title'] = htmlspecialchars($notice['title']);
        $notice['content'] = htmlspecialchars($notice['content']);
        $notice['class'] = htmlspecialchars($notice['class']);
        $notice['date'] = (new DateTime($notice['date']))->format('Y-m-d H:i:s');
    }
} catch (PDOException $e) {
    error_log('Failed to fetch notices: ' . $e->getMessage());
    $notices = [];
}

// Handle notice submission
$alert_message = '';
$alert_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $class = isset($_POST['class']) ? trim($_POST['class']) : '';
        $title = isset($_POST['title']) ? trim($_POST['title']) : '';
        $content = isset($_POST['content']) ? trim($_POST['content']) : '';

        if (empty($class) || empty($title) || empty($content)) {
            throw new Exception('All fields are required.');
        }

        // Validate class (must be either "All Classes" or a class the teacher is assigned to)
        $valid_classes = array_column($classes, 'class_name');
        if ($class !== 'All Classes' && !in_array($class, $valid_classes)) {
            throw new Exception('Invalid class selected.');
        }

        // Insert into notices table
        $stmt = $pdo->prepare(
            'INSERT INTO notices (title, content, date, posted_by, class, status) 
             VALUES (:title, :content, :date, :posted_by, :class, :status)'
        );

        $stmt->execute([
            ':title' => $title,
            ':content' => $content,
            ':date' => '2025-06-01 16:17:00',
            ':posted_by' => $_SESSION['user_id'],
            ':class' => $class,
            ':status' => 'active'
        ]);

        $alert_message = 'Notice posted successfully!';
        $alert_type = 'success';

        // Refresh notices
        $stmt = $pdo->prepare(
            'SELECT n.id, n.title, n.content, n.date, n.class 
             FROM notices n 
             WHERE n.posted_by = :tid AND n.status = "active"
             ORDER BY n.date DESC'
        );
        $stmt->execute([':tid' => $_SESSION['user_id']]);
        $notices = $stmt->fetchAll();
        
        foreach ($notices as &$notice) {
            $notice['title'] = htmlspecialchars($notice['title']);
            $notice['content'] = htmlspecialchars($notice['content']);
            $notice['class'] = htmlspecialchars($notice['class']);
            $notice['date'] = (new DateTime($notice['date']))->format('Y-m-d H:i:s');
        }
    } catch (Exception $e) {
        error_log('Failed to post notice: ' . $e->getMessage());
        $alert_message = 'Failed to post notice: ' . $e->getMessage();
        $alert_type = 'error';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>EduConnect - Teacher Notices</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            padding-bottom: 70px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 20px;
            font-size: 28px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
        }

        .back-button {
            margin-right: 15px;
            cursor: pointer;
        }

        .section {
            background-color: white;
            border-radius: var(--border-radius);
            margin: 15px;
            padding: 20px;
            box-shadow: var(--box-shadow);
        }

        .section-title {
            color: var(--primary-color);
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 8px;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 15px;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 16px;
            color: var(--text-color);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }

        .select-wrapper {
            position: relative;
        }

        .select-wrapper::after {
            content: '\f107';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--light-text);
            pointer-events: none;
        }

        .select-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            appearance: none;
            font-size: 16px;
            color: var(--text-color);
            background-color: white;
        }

        .select-control:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .btn {
            display: inline-block;
            font-weight: 500;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            user-select: none;
            border: 1px solid transparent;
            padding: 12px 20px;
            font-size: 16px;
            line-height: 1.5;
            border-radius: var(--border-radius);
            transition: var(--transition);
            cursor: pointer;
        }

        .btn-primary {
            color: #fff;
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: #004a8f;
            border-color: #004a8f;
        }

        .btn-block {
            display: block;
            width: 100%;
        }

        .notice-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .notice-item {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: var(--transition);
        }

        .notice-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .notice-title {
            font-size: 16px;
            font-weight: 600;
        }

        .notice-date {
            font-size: 12px;
            color: var(--light-text);
        }

        .notice-class {
            font-size: 12px;
            color: var(--primary-color);
            margin-bottom: 5px;
        }

        .notice-content {
            font-size: 14px;
            color: var(--text-color);
            line-height: 1.4;
        }

        .compose-button {
            position: fixed;
            bottom: 80px;
            right: 20px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            font-size: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: var(--box-shadow);
            cursor: pointer;
            transition: var(--transition);
            z-index: 100;
        }

        .compose-button:hover {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: white;
            border-radius: var(--border-radius);
            width: 90%;
            max-width: 500px;
            padding: 20px;
            position: relative;
            box-shadow: var(--box-shadow);
        }

        .modal-close {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 24px;
            color: var(--light-text);
            cursor: pointer;
        }

        /* Alert message */
        .alert {
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            display: none;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: white;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .footer-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: var(--light-text);
            transition: var(--transition);
            padding: 5px 0;
            width: 25%;
        }

        .footer-item.active {
            color: var(--primary-color);
        }

        .footer-icon {
            font-size: 22px;
            margin-bottom: 4px;
        }

        .footer-text {
            font-size: 12px;
            font-weight: 500;
        }

        /* Loading Animation */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }

        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(0, 85, 164, 0.2);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        .loader-text {
            position: absolute;
            margin-top: 80px;
            color: var(--primary-color);
            font-weight: 500;
        }

        /* Empty state */
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
            text-align: center;
        }

        .empty-icon {
            font-size: 50px;
            color: #ccc;
            margin-bottom: 15px;
        }

        .empty-text {
            font-size: 16px;
            color: var(--light-text);
            margin-bottom: 20px;
        }

        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .section-title {
                font-size: 20px;
            }

            .notice-title {
                font-size: 15px;
            }

            .compose-button {
                width: 50px;
                height: 50px;
                font-size: 20px;
            }

            .form-label {
                font-size: 14px;
            }

            .form-control, .select-control {
                font-size: 15px;
                padding: 10px 12px;
            }

            .btn {
                font-size: 15px;
                padding: 10px 16px;
            }
        }

        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <!-- Loading Animation -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
        <div class="loader-text">Loading...</div>
    </div>

    <div class="header">
        <i class="fas fa-arrow-left back-button" onclick="window.location.href='index.php';"></i>
        Notices
    </div>

    <div class="section">
        <?php if ($alert_message): ?>
            <div class="alert alert-<?php echo $alert_type; ?>" style="display: block;">
                <?php echo htmlspecialchars($alert_message); ?>
            </div>
        <?php else: ?>
            <div class="alert" id="alert" style="display: none;"></div>
        <?php endif; ?>
        
        <div class="section-title">My Notices</div>
        <div class="notice-list" id="notice-list">
            <?php if (empty($notices)): ?>
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-bullhorn"></i>
                    </div>
                    <div class="empty-text">No notices posted yet.</div>
                </div>
            <?php else: ?>
                <?php foreach ($notices as $notice): ?>
                    <div class="notice-item" data-id="<?php echo $notice['id']; ?>">
                        <div class="notice-header">
                            <div class="notice-title"><?php echo $notice['title']; ?></div>
                            <div class="notice-date"><?php echo $notice['date']; ?></div>
                        </div>
                        <div class="notice-class">Class: <?php echo $notice['class']; ?></div>
                        <div class="notice-content"><?php echo $notice['content']; ?></div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="compose-button" id="compose-button">
        <i class="fas fa-plus"></i>
    </div>

    <!-- Modal for composing notice -->
    <div class="modal" id="compose-modal">
        <div class="modal-content">
            <span class="modal-close" id="modal-close">&times;</span>
            <div class="section-title">Compose Notice</div>
            <form method="POST" id="notice-form">
                <div class="form-group">
                    <label for="class-select" class="form-label">Class</label>
                    <div class="select-wrapper">
                        <select id="class-select" name="class" class="select-control" required>
                            <option value="">Select a class</option>
                            <option value="All Classes">All Classes</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_name']; ?>">
                                    <?php echo $class['class_name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="notice-title" class="form-label">Title</label>
                    <input type="text" id="notice-title" name="title" class="form-control" placeholder="Enter notice title" required>
                </div>
                <div class="form-group">
                    <label for="notice-content" class="form-label">Content</label>
                    <textarea id="notice-content" name="content" class="form-control" placeholder="Enter notice content" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-paper-plane"></i> Post Notice
                </button>
            </form>
        </div>
    </div>

    <!-- Footer Navigation -->
    <div class="footer">
        <a href="index.php" class="footer-item">
            <i class="fas fa-home footer-icon"></i>
            <span class="footer-text">Dashboard</span>
        </a>
        <a href="classes.php" class="footer-item">
            <i class="fas fa-chalkboard footer-icon"></i>
            <span class="footer-text">Classes</span>
        </a>
        <a href="marks.php" class="footer-item ripple">
            <i class="fa fa-pencil-square footer-icon"></i>
            <span class="footer-text">Marks</span>
        </a>
        <a href="profile.php" class="footer-item">
            <i class="fas fa-user footer-icon"></i>
            <span class="footer-text">Profile</span>
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loader = document.getElementById('loader');
            const composeButton = document.getElementById('compose-button');
            const composeModal = document.getElementById('compose-modal');
            const modalClose = document.getElementById('modal-close');
            
            // Function to show loader
            function showLoader() {
                loader.style.display = 'flex';
            }
            
            // Function to hide loader
            function hideLoader() {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    loader.style.opacity = '1';
                }, 300);
            }
            
            // Auto-hide alert after 5 seconds
            const alertBox = document.getElementById('alert');
            if (alertBox && alertBox.style.display === 'block') {
                setTimeout(() => {
                    alertBox.style.display = 'none';
                }, 5000);
            }
            
            // Open compose modal
            composeButton.addEventListener('click', function() {
                composeModal.style.display = 'flex';
            });
            
            // Close modal
            modalClose.addEventListener('click', function() {
                composeModal.style.display = 'none';
            });
            
            // Close modal when clicking outside
            composeModal.addEventListener('click', function(e) {
                if (e.target === composeModal) {
                    composeModal.style.display = 'none';
                }
            });
            
            // Hide loader after page load
            hideLoader();
        });
    </script>
</body>
</html>