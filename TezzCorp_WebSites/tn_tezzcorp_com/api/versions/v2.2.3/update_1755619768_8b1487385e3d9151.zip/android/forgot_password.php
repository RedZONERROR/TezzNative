<?php
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'error.log');

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/vendor/autoload.php'; // Adjust path if PHPMailer is installed differently

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Initialize PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    $alert_message = 'Database connection failed. Please try again later.';
    $alert_type = 'error';
}

// Fetch site settings
try {
    $stmt = $pdo->query('SELECT school_name, email, phpmailer_host, phpmailer_username, phpmailer_password, phpmailer_port FROM site_settings LIMIT 1');
    $site_settings = $stmt->fetch();
    if (!$site_settings) {
        throw new Exception('Site settings not found.');
    }
} catch (Exception $e) {
    error_log('Site settings error: ' . $e->getMessage());
    $alert_message = 'Site configuration error. Please contact support.';
    $alert_type = 'error';
}

// Rate limiting configuration
$max_attempts = 5; // Max attempts allowed in the time window
$time_window = 3600; // 1 hour in seconds
$ip_address = $_SERVER['REMOTE_ADDR'];

// Handle form submission
$alert_message = '';
$alert_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $email = isset($_POST['email']) ? trim($_POST['email']) : '';

        if (empty($email)) {
            throw new Exception('Please enter your email.');
        }

        // Search for the user in staff table
        $stmt = $pdo->prepare(
            'SELECT id, email, name 
             FROM staff 
             WHERE email = :email 
             AND status = "active"'
        );
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if (!$user) {
            throw new Exception('No account found with that email.');
        }

        // Generate a secure reset token
        $token = bin2hex(random_bytes(32));
        $expires_at = date('Y-m-d H:i:s', time() + 3600); // 1 hour expiry
        $domain = $_SERVER['HTTP_HOST']; // Get the domain

        // Store the reset token with domain
        $stmt = $pdo->prepare(
            'INSERT INTO password_reset_tokens (user_id, token, expires_at, domain) 
             VALUES (:user_id, :token, :expires_at, :domain)'
        );
        $stmt->execute([
            ':user_id' => $user['id'],
            ':token' => $token,
            ':expires_at' => $expires_at,
            ':domain' => $domain
        ]);

        // Send email using PHPMailer
        $mail = new PHPMailer(true);
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = $site_settings['phpmailer_host'];
            $mail->SMTPAuth = true;
            $mail->Username = $site_settings['phpmailer_username'];
            $mail->Password = $site_settings['phpmailer_password'];
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port = $site_settings['phpmailer_port'];

            // Recipients
            $mail->setFrom($site_settings['email'], $site_settings['school_name']);
            $mail->addAddress($user['email'], $user['name']);

            // Content
            $reset_link = "https://$domain/android/reset_password.php?token=" . $token;
            $mail->isHTML(true);
            $mail->Subject = $site_settings['school_name'] . ' Password Reset';
            $mail->Body = "
                <h2>Password Reset Request</h2>
                <p>Dear {$user['name']},</p>
                <p>We received a request to reset your {$site_settings['school_name']} password. Click the link below to reset your password:</p>
                <p><a href='$reset_link'>Reset Password</a></p>
                <p>This link will expire in 1 hour. If you did not request a password reset, please ignore this email.</p>
                <p>Best regards,<br>{$site_settings['school_name']}</p>
            ";
            $mail->AltBody = "Dear {$user['name']},\n\nWe received a request to reset your {$site_settings['school_name']} password. Please copy and paste the following link into your browser to reset your password:\n\n$reset_link\n\nThis link will expire in 1 hour. If you did not request a password reset, please ignore this email.\n\nBest regards,\n{$site_settings['school_name']}";

            $mail->send();
            $alert_message = 'A password reset link has been sent to your email.';
            $alert_type = 'success';
        } catch (Exception $e) {
            error_log("Email could not be sent. PHPMailer Error: {$mail->ErrorInfo}");
            throw new Exception('Failed to send reset email. Please try again later.');
        }
    } catch (Exception $e) {
        error_log('Forgot password error: ' . $e->getMessage());
        $alert_message = $e->getMessage();
        $alert_type = 'error';
    }
}

// Fetch site settings
try {
    $stmt = $pdo->prepare('SELECT school_name, logo, tagline, facebook_url, twitter_url, instagram_url, linkedin_url FROM site_settings WHERE id = 1');
    $stmt->execute();
    $settings = $stmt->fetch();
    
    if (!$settings) {
        $settings = [
            'school_name' => 'EduConnect',
            'tagline' => 'Learn, Connect, Succeed',
            'logo' => $_SERVER['DOCUMENT_ROOT'] . '/android/favicon.svg',
            'facebook_url' => '#',
            'twitter_url' => '#',
            'instagram_url' => '#',
            'linkedin_url' => '#'
        ];
    }
} catch (PDOException $e) {
    error_log('Failed to fetch site settings: ' . $e->getMessage());
    $settings = [
        'school_name' => 'EduConnect',
        'facebook_url' => '#',
        'twitter_url' => '#',
        'instagram_url' => '#',
        'linkedin_url' => '#'
    ];
}

$school_name = htmlspecialchars($settings['school_name']);
$tagline = htmlspecialchars($settings['tagline']);
$logo = 'https://' . $_SERVER['HTTP_HOST'] . $settings['logo'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $school_name; ?> - Forgot Password</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #0055a4;
            --secondary-color: #f8f9fa;
            --text-color: #333;
            --light-text: #6c757d;
            --border-radius: 12px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            --hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            background-color: #f0f2f5;
            color: var(--text-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        .login-header {
            background-color: var(--primary-color);
            color: white;
            padding: 30px 20px;
            text-align: center;
            border-bottom-left-radius: 30px;
            border-bottom-right-radius: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        
        .app-logo {
            width: 80px;
            height: 80px;
            background-color: white;
            border-radius: 20px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        
        .app-logo i {
            font-size: 40px;
            color: var(--primary-color);
        }
        
        .app-name {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .app-slogan {
            font-size: 16px;
            opacity: 0.9;
        }
        
        .login-container {
            flex: 1;
            padding: 30px 20px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            max-width: 450px;
            margin: 0 auto;
            width: 100%;
        }
        
        .login-title {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .input-group {
            margin-bottom: 20px;
        }
        
        .input-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 15px;
        }
        
        .input-field {
            width: 100%;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 16px;
            transition: var(--transition);
            background-color: white;
        }
        
        .input-field:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(0, 85, 164, 0.2);
            outline: none;
        }
        
        .input-with-icon {
            position: relative;
        }
        
        .input-with-icon .input-field {
            padding-left: 45px;
        }
        
        .input-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--light-text);
        }
        
        .login-button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            padding: 15px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            width: 100%;
            margin-bottom: 20px;
        }
        
        .login-button:hover {
            background-color: #004a8f;
        }
        
        .register-link {
            text-align: center;
            font-size: 15px;
        }
        
        .register-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
        }
        
        /* Alert message */
        .alert {
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            display: none;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        /* Media Queries for better responsiveness */
        @media (max-width: 480px) {
            .login-title {
                font-size: 22px;
            }
            
            .input-field {
                padding: 12px;
                font-size: 15px;
            }
            
            .login-button {
                padding: 12px;
                font-size: 15px;
            }
            
            .register-link {
                font-size: 14px;
            }
        }
        
        /* Prevent text selection for better mobile experience */
        .no-select {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="no-select">
    <div class="login-header">
        <div class="app-logo">
            <img style="height: 110px;" src="<?php echo $logo; ?>" alt="<?php echo $school_name; ?>">
        </div>
        <div class="app-name"><?php echo $school_name; ?></div>
        <div class="app-slogan"><?php echo $tagline; ?></div>
    </div>

    <div style="margin-top: -150px !important;" class="login-container">
        <div class="login-title">Forgot Password?</div>
        <?php if ($alert_message): ?>
            <div class="alert alert-<?php echo $alert_type; ?>" style="display: block;">
                <?php echo htmlspecialchars($alert_message); ?>
            </div>
        <?php else: ?>
            <div class="alert" id="alert" style="display: none;"></div>
        <?php endif; ?>
        <form method="POST">
            <div class="input-group">
                <label for="email" class="input-label">Email</label>
                <div class="input-with-icon">
                    <i class="fas fa-envelope input-icon"></i>
                    <input type="email" id="email" name="email" class="input-field" placeholder="Enter your email" required>
                </div>
            </div>
            <button type="submit" class="login-button">Reset Password</button>
            <div class="register-link">
                <a href="/android">Back to Login</a>
            </div>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Auto-hide alert after 5 seconds
            const alertBox = document.getElementById('alert');
            if (alertBox && alertBox.style.display === 'block') {
                setTimeout(() => {
                    alertBox.style.display = 'none';
                }, 5000);
            }
        });
    </script>
</body>
</html>