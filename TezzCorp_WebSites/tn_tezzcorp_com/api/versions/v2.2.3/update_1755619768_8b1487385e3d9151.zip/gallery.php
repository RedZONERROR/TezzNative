<?php
require_once 'conn.php';

$query = mysqli_query($conn, "SELECT school_name, logo, favicon, email, address, phone, tagline, footer_text, transport_head_mobile, fees_collection_mobile, whatsapp_number, calling_number, facebook_url, twitter_url, instagram_url, linkedin_url, youtube_url FROM site_settings");
$fetch = mysqli_fetch_array($query);

$photos_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM gallery WHERE category = 'Photos'"))['total'];
$events_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM gallery WHERE category = 'Events'"))['total'];
$facilities_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM gallery WHERE category = 'Facilities'"))['total'];
$achievements_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM gallery WHERE category = 'Achievements'"))['total'];

$gallery_query = mysqli_query($conn, "SELECT * FROM gallery ORDER BY id DESC");
$gallery_items = [];
while ($row = mysqli_fetch_assoc($gallery_query)) {
    $gallery_items[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery - <?php echo $fetch['school_name']; ?></title>
    <meta name="description" content="Explore our campus life through photos and videos. See our facilities, events, and student activities at <?php echo $fetch['school_name']; ?>.">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="base.css">
    <link rel="stylesheet" href="gallery.css">
    
    <!-- Favicon -->
    <?php
    if (!empty($fetch['favicon'])) {
        $favicon = htmlspecialchars($fetch['favicon'], ENT_QUOTES, 'UTF-8');
        $ext = pathinfo($favicon, PATHINFO_EXTENSION);
        
        // Set MIME type based on extension
        $mimeType = 'image/png'; // default
        if ($ext === 'jpg' || $ext === 'jpeg') {
            $mimeType = 'image/jpeg';
        } elseif ($ext === 'ico') {
            $mimeType = 'image/x-icon';
        }
    
        echo '<link rel="icon" type="' . $mimeType . '" href="' . $favicon . '">';
    }
    ?>
</head>
<body>
    <!-- Navigation -->
    <?php include 'header.php'; ?>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <div class="page-header-content">
                <h1>Campus Gallery</h1>
                <p>Explore our vibrant campus life, facilities, and memorable moments through our photo gallery.</p>
            </div>
        </div>
    </section>

    <!-- Gallery Stats -->
    <section class="section gallery-stats">
        <div class="container">
            <div class="gallery-stats-grid">
                <div class="gallery-stat">
                    <div class="gallery-stat-icon">
                        <i class="fas fa-camera"></i>
                    </div>
                    <!-- Display dynamic photo count from database -->
                    <div class="gallery-stat-number"><?php echo $photos_count; ?></div>
                    <div class="gallery-stat-label">Photos</div>
                </div>
                <div class="gallery-stat">
                    <div class="gallery-stat-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <!-- Display dynamic events count from database -->
                    <div class="gallery-stat-number"><?php echo $events_count; ?></div>
                    <div class="gallery-stat-label">Events</div>
                </div>
                <div class="gallery-stat">
                    <div class="gallery-stat-icon">
                        <i class="fas fa-building"></i>
                    </div>
                    <!-- Display dynamic facilities count from database -->
                    <div class="gallery-stat-number"><?php echo $facilities_count; ?></div>
                    <div class="gallery-stat-label">Facilities</div>
                </div>
                <div class="gallery-stat">
                    <div class="gallery-stat-icon">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <!-- Display dynamic achievements count from database -->
                    <div class="gallery-stat-number"><?php echo $achievements_count; ?></div>
                    <div class="gallery-stat-label">Achievements</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Gallery Section -->
    <section class="section gallery-section">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">Our Gallery</div>
                <h2 class="section-title">
                    Capturing Moments of 
                    <span class="gradient-text">Excellence</span>
                </h2>
                <p class="section-description">
                    From classroom activities to special events, explore the vibrant 
                    life at <?php echo $fetch['school_name']; ?> through our comprehensive gallery.
                </p>
            </div>
            
            <!-- Updated filter buttons to match database categories -->
            <div class="gallery-filter">
                <button class="filter-btn active" data-filter="all">All Photos</button>
                <button class="filter-btn" data-filter="Photos">Photos</button>
                <button class="filter-btn" data-filter="Events">Events</button>
                <button class="filter-btn" data-filter="Facilities">Facilities</button>
                <button class="filter-btn" data-filter="Achievements">Achievements</button>
            </div>
            
            <!-- Dynamic gallery grid populated from database -->
            <div class="gallery-grid">
                <?php if (empty($gallery_items)): ?>
                    <div class="col-12 text-center py-5">
                        <p>No gallery items found.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($gallery_items as $item): ?>
                        <div class="gallery-item" data-category="<?php echo $item['category']; ?>">
                            <div class="gallery-image">
                                <?php if (!empty($item['image'])): ?>
                                    <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="Gallery Image" loading="lazy">
                                <?php elseif (!empty($item['videos'])): ?>
                                    <video controls>
                                        <source src="<?php echo htmlspecialchars($item['videos']); ?>" type="video/mp4">
                                        Your browser does not support the video tag.
                                    </video>
                                <?php else: ?>
                                    <div class="image-placeholder">
                                        <i class="fas fa-image"></i>
                                    </div>
                                <?php endif; ?>
                                <div class="gallery-overlay">
                                    <!-- Updated to use compatible lightbox function -->
                                    <button class="gallery-overlay-btn" onclick="openGalleryLightbox('<?php echo htmlspecialchars($item['image'] ?? $item['videos'] ?? ''); ?>', '<?php echo htmlspecialchars($item['category']); ?>')" 
                                            data-image="<?php echo htmlspecialchars($item['image'] ?? $item['videos'] ?? ''); ?>"
                                            data-title="<?php echo htmlspecialchars($item['category']); ?>"
                                            data-description="<?php echo htmlspecialchars($item['category']); ?> - Gallery Item">
                                        <i class="fas fa-expand"></i>
                                        View
                                    </button>
                                </div>
                            </div>
                            <div class="gallery-info">
                                <h3><?php echo htmlspecialchars($item['category']); ?> Gallery</h3>
                                <p>Explore our <?php echo strtolower($item['category']); ?> collection showcasing the best moments.</p>
                                <div class="gallery-meta">
                                    <span class="gallery-category"><?php echo htmlspecialchars($item['category']); ?></span>
                                    <span><?php echo date('F Y', strtotime($item['created_at'] ?? 'now')); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include 'footer.php'; ?>

    <!-- Lightbox Modal -->
    <div id="lightbox" class="lightbox" style="display: none;">
        <div class="lightbox-content">
            <span class="lightbox-close" onclick="closeLightbox()">&times;</span>
            <button class="lightbox-nav lightbox-prev" onclick="prevImage()">
                <i class="fas fa-chevron-left"></i>
            </button>
            <button class="lightbox-nav lightbox-next" onclick="nextImage()">
                <i class="fas fa-chevron-right"></i>
            </button>
            <img id="lightbox-image" src="/placeholder.svg" alt="Lightbox Image">
            <div class="lightbox-info">
                <h3 id="lightbox-title"></h3>
                <p id="lightbox-description"></p>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="script.js"></script>
    
    <!-- Enhanced gallery JavaScript with GSAP animations and improved functionality -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const filterButtons = document.querySelectorAll('.filter-btn');
            const galleryItems = document.querySelectorAll('.gallery-item');

            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const filter = this.getAttribute('data-filter');

                    // Update active button with GSAP animation
                    filterButtons.forEach(btn => {
                        btn.classList.remove('active');
                        if (typeof gsap !== 'undefined') {
                            gsap.to(btn, { scale: 1, duration: 0.2 });
                        }
                    });
                    this.classList.add('active');
                    if (typeof gsap !== 'undefined') {
                        gsap.to(this, { scale: 1.05, duration: 0.2, yoyo: true, repeat: 1 });
                    }

                    // Filter items with staggered animation
                    if (typeof gsap !== 'undefined') {
                        const tl = gsap.timeline();

                        galleryItems.forEach((item, index) => {
                            const category = item.getAttribute('data-category');
                            const shouldShow = filter === 'all' || category === filter;

                            if (shouldShow) {
                                item.style.display = 'block';
                                tl.fromTo(item,
                                    { scale: 0.8, opacity: 0, y: 20 },
                                    {
                                        scale: 1,
                                        opacity: 1,
                                        y: 0,
                                        duration: 0.4,
                                        ease: 'back.out(1.7)'
                                    }, index * 0.05
                                );
                            } else {
                                tl.to(item, {
                                    scale: 0.8,
                                    opacity: 0,
                                    duration: 0.3,
                                    ease: 'power2.out',
                                    onComplete: () => {
                                        item.style.display = 'none';
                                    }
                                }, 0);
                            }
                        });
                    } else {
                        // Fallback without GSAP
                        galleryItems.forEach(item => {
                            const category = item.getAttribute('data-category');
                            const shouldShow = filter === 'all' || category === filter;
                            item.style.display = shouldShow ? 'block' : 'none';
                        });
                    }

                    // Update gallery images array after filtering
                    setTimeout(updateGalleryImages, 500);
                });
            });

            // Initialize gallery images array
            updateGalleryImages();
        });

        // Enhanced lightbox functionality
        let currentImageIndex = 0;
        let galleryImages = [];

        function updateGalleryImages() {
            const visibleItems = document.querySelectorAll('.gallery-item:not([style*="display: none"]) .gallery-overlay-btn');
            galleryImages = Array.from(visibleItems).map(btn => ({
                src: btn.getAttribute('data-image'),
                title: btn.getAttribute('data-title'),
                description: btn.getAttribute('data-description')
            }));
        }

        function openGalleryLightbox(src, title) {
            const lightbox = document.getElementById('lightbox');
            const lightboxImage = document.getElementById('lightbox-image');
            const lightboxTitle = document.getElementById('lightbox-title');
            const lightboxDescription = document.getElementById('lightbox-description');

            if (!lightboxImage) {
                console.error('Lightbox image element not found');
                return;
            }

            lightboxImage.src = src;
            lightboxTitle.textContent = title;
            lightboxDescription.textContent = title + ' - Gallery Item';

            // Update current index
            currentImageIndex = galleryImages.findIndex(img => img.src === src);

            lightbox.style.display = 'flex';
            document.body.style.overflow = 'hidden';

            // Add entrance animation if GSAP is available
            if (typeof gsap !== 'undefined') {
                gsap.fromTo(lightbox, 
                    { opacity: 0 }, 
                    { opacity: 1, duration: 0.3, ease: 'power2.out' }
                );
                gsap.fromTo(lightboxImage, 
                    { scale: 0.8, opacity: 0 }, 
                    { scale: 1, opacity: 1, duration: 0.4, ease: 'back.out(1.7)' }
                );
            }
        }

        function closeLightbox() {
            const lightbox = document.getElementById('lightbox');
            
            if (typeof gsap !== 'undefined') {
                gsap.to(lightbox, {
                    opacity: 0,
                    duration: 0.2,
                    ease: 'power2.out',
                    onComplete: () => {
                        lightbox.style.display = 'none';
                        document.body.style.overflow = 'auto';
                    }
                });
            } else {
                lightbox.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        }

        function prevImage() {
            if (galleryImages.length > 0) {
                currentImageIndex = (currentImageIndex - 1 + galleryImages.length) % galleryImages.length;
                updateLightboxImage();
            }
        }

        function nextImage() {
            if (galleryImages.length > 0) {
                currentImageIndex = (currentImageIndex + 1) % galleryImages.length;
                updateLightboxImage();
            }
        }

        function updateLightboxImage() {
            const lightboxImage = document.getElementById('lightbox-image');
            const lightboxTitle = document.getElementById('lightbox-title');
            const lightboxDescription = document.getElementById('lightbox-description');

            if (galleryImages[currentImageIndex]) {
                const currentImage = galleryImages[currentImageIndex];
                
                // Add transition animation if GSAP is available
                if (typeof gsap !== 'undefined') {
                    gsap.to(lightboxImage, {
                        opacity: 0,
                        duration: 0.2,
                        onComplete: () => {
                            lightboxImage.src = currentImage.src;
                            lightboxTitle.textContent = currentImage.title;
                            lightboxDescription.textContent = currentImage.description;
                            gsap.to(lightboxImage, { opacity: 1, duration: 0.3 });
                        }
                    });
                } else {
                    lightboxImage.src = currentImage.src;
                    lightboxTitle.textContent = currentImage.title;
                    lightboxDescription.textContent = currentImage.description;
                }
            }
        }

        // Enhanced keyboard navigation
        document.addEventListener('keydown', function(e) {
            const lightbox = document.getElementById('lightbox');
            if (lightbox.style.display === 'flex') {
                switch(e.key) {
                    case 'Escape':
                        closeLightbox();
                        break;
                    case 'ArrowLeft':
                        prevImage();
                        break;
                    case 'ArrowRight':
                        nextImage();
                        break;
                }
            }
        });

        // Close lightbox on background click
        document.getElementById('lightbox').addEventListener('click', function(e) {
            if (e.target === this) {
                closeLightbox();
            }
        });

        // Touch/swipe support for mobile
        let startX = 0;
        let endX = 0;

        document.getElementById('lightbox').addEventListener('touchstart', function(e) {
            startX = e.touches[0].clientX;
        }, { passive: true });

        document.getElementById('lightbox').addEventListener('touchend', function(e) {
            endX = e.changedTouches[0].clientX;
            const threshold = 50;
            const diff = startX - endX;

            if (Math.abs(diff) > threshold) {
                if (diff > 0) {
                    nextImage();
                } else {
                    prevImage();
                }
            }
        }, { passive: true });
    </script>

    <style>
        /* Added lightbox CSS styles */
        .lightbox {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 10000;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .lightbox-content {
            position: relative;
            max-width: 90%;
            max-height: 90%;
            text-align: center;
        }

        .lightbox-close {
            position: absolute;
            top: -40px;
            right: 0;
            color: white;
            font-size: 30px;
            cursor: pointer;
            z-index: 10001;
        }

        .lightbox-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            font-size: 24px;
            padding: 15px 20px;
            cursor: pointer;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .lightbox-nav:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .lightbox-prev {
            left: -60px;
        }

        .lightbox-next {
            right: -60px;
        }

        #lightbox-image {
            max-width: 100%;
            max-height: 80vh;
            object-fit: contain;
        }

        .lightbox-info {
            color: white;
            margin-top: 20px;
        }

        .lightbox-info h3 {
            margin: 0 0 10px 0;
            font-size: 1.5rem;
        }

        .lightbox-info p {
            margin: 0;
            opacity: 0.8;
        }

        @media (max-width: 768px) {
            .lightbox-nav {
                display: none;
            }
            
            .lightbox-close {
                top: 10px;
                right: 10px;
            }
        }
    </style>
</body>
</html>