<?php
require_once 'conn.php';

$query = mysqli_query($conn, "SELECT school_name, logo, favicon, email, address, phone, tagline, footer_text, transport_head_mobile, fees_collection_mobile, whatsapp_number, calling_number, facebook_url, twitter_url, instagram_url, linkedin_url, youtube_url FROM site_settings");
$fetch = mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - <?php echo $fetch['school_name']; ?></title>
    <meta name="description" content="Learn about EduVision Academy's mission, history, achievements, and leadership team. Discover our commitment to educational excellence.">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="base.css">
    <link rel="stylesheet" href="about.css">
    
    <!-- Favicon -->
    <?php
    if (!empty($fetch['favicon'])) {
        $favicon = htmlspecialchars($fetch['favicon'], ENT_QUOTES, 'UTF-8');
        $ext = pathinfo($favicon, PATHINFO_EXTENSION);
        
        // Set MIME type based on extension
        $mimeType = 'image/png'; // default
        if ($ext === 'jpg' || $ext === 'jpeg') {
            $mimeType = 'image/jpeg';
        } elseif ($ext === 'ico') {
            $mimeType = 'image/x-icon';
        }
    
        echo '<link rel="icon" type="' . $mimeType . '" href="' . $favicon . '">';
    }
    ?>
</head>
<body>
    <!-- Navigation -->
    <?php include 'header.php'; ?>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <div class="page-header-content">
                <h1>About <?php echo $fetch['school_name']; ?></h1>
                <p>Discover our story, mission, and commitment to educational excellence</p>
            </div>
        </div>
    </section>

    <!-- Mission Section -->
    <section class="section mission">
        <div class="container">
            <div class="mission-content">
                <div class="mission-text">
                    <h2>Our Mission</h2>
                    <p>At <?php echo $fetch['school_name']; ?>, we are dedicated to providing exceptional education that empowers students to reach their full potential. Our innovative approach combines traditional academic excellence with modern teaching methodologies.</p>
                    <p>We believe in nurturing not just academic success, but also character development, critical thinking, and creativity. Our goal is to prepare students for the challenges of tomorrow while instilling values that will guide them throughout their lives.</p>
                    
                    <div class="mission-values">
                        <div class="value-item">
                            <div class="value-icon">
                                <i class="fas fa-lightbulb"></i>
                            </div>
                            <div class="value-content">
                                <h4>Innovation</h4>
                                <p>Embracing cutting-edge educational technologies and methodologies to enhance learning experiences.</p>
                            </div>
                        </div>
                        <div class="value-item">
                            <div class="value-icon">
                                <i class="fas fa-heart"></i>
                            </div>
                            <div class="value-content">
                                <h4>Compassion</h4>
                                <p>Creating a supportive and inclusive environment where every student feels valued and understood.</p>
                            </div>
                        </div>
                        <div class="value-item">
                            <div class="value-icon">
                                <i class="fas fa-trophy"></i>
                            </div>
                            <div class="value-content">
                                <h4>Excellence</h4>
                                <p>Maintaining the highest standards in education and continuously striving for improvement.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mission-image">
                    <div class="image-placeholder">
                        <i class="fas fa-graduation-cap"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- History Section -->
    <section class="section history">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">Our Journey</div>
                <h2 class="section-title">
                    A Timeline of Growth and 
                    <span class="gradient-text">Achievement</span>
                </h2>
                <p class="section-description">
                    From our humble beginnings to becoming a leading educational institution, 
                    discover the milestones that shaped our journey.
                </p>
            </div>
            <div class="timeline">
                <div class="timeline-item">
                    <div class="timeline-year">1999</div>
                    <div class="timeline-content">
                        <h3>Foundation</h3>
                        <p><?php echo $fetch['school_name']; ?> was founded with a vision to revolutionize education and provide world-class learning opportunities for students of all backgrounds.</p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-year">2005</div>
                    <div class="timeline-content">
                        <h3>Campus Expansion</h3>
                        <p>Expanded our facilities with state-of-the-art science laboratories, technology centers, and modern classrooms to accommodate growing enrollment.</p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-year">2010</div>
                    <div class="timeline-content">
                        <h3>Digital Integration</h3>
                        <p>Pioneered digital learning platforms and became one of the first schools to integrate technology in every classroom, setting new standards for modern education.</p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-year">2015</div>
                    <div class="timeline-content">
                        <h3>International Recognition</h3>
                        <p>Received international accreditation and established partnerships with leading educational institutions worldwide, opening doors for global opportunities.</p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-year">2020</div>
                    <div class="timeline-content">
                        <h3>Innovation Hub</h3>
                        <p>Launched our Innovation Hub, focusing on STEM education, robotics, artificial intelligence programs, and preparing students for the future economy.</p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-year">2024</div>
                    <div class="timeline-content">
                        <h3>Future Ready</h3>
                        <p>Continuing to evolve with cutting-edge educational technologies, sustainable campus initiatives, and comprehensive student support programs.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Achievements Section -->
    <section class="section achievements">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">Our Achievements</div>
                <h2 class="section-title">
                    Recognition and Awards for 
                    <span class="gradient-text">Excellence</span>
                </h2>
                <p class="section-description">
                    Our commitment to educational excellence has been recognized by leading 
                    organizations and institutions worldwide.
                </p>
            </div>
            <div class="achievements-grid">
                <div class="achievement-card">
                    <div class="achievement-icon">
                        <i class="fas fa-medal"></i>
                    </div>
                    <h3>Excellence in Education Award</h3>
                    <p>Recognized by the National Education Board for outstanding academic performance and innovative teaching methods that inspire student success.</p>
                </div>
                <div class="achievement-card">
                    <div class="achievement-icon">
                        <i class="fas fa-globe"></i>
                    </div>
                    <h3>International Accreditation</h3>
                    <p>Accredited by leading international education organizations, ensuring global standards in our curriculum and teaching practices.</p>
                </div>
                <div class="achievement-card">
                    <div class="achievement-icon">
                        <i class="fas fa-leaf"></i>
                    </div>
                    <h3>Green School Certification</h3>
                    <p>Certified as an environmentally sustainable institution with eco-friendly practices and comprehensive green initiatives.</p>
                </div>
                <div class="achievement-card">
                    <div class="achievement-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3>Community Impact Award</h3>
                    <p>Honored for our significant contributions to community development and social responsibility programs that make a difference.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Leadership Section -->
    <section class="section leadership">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">Our Leadership</div>
                <h2 class="section-title">
                    Meet the Visionaries Behind Our 
                    <span class="gradient-text">Success</span>
                </h2>
                <p class="section-description">
                    Our experienced leadership team brings together decades of educational 
                    expertise and a shared passion for student success.
                </p>
            </div>
            <div class="leadership-grid">
                <div class="leader-card">
                    <div class="leader-image">
                        <div class="image-placeholder">
                            <i class="fas fa-user-tie"></i>
                        </div>
                    </div>
                    <div class="leader-info">
                        <h3>Dr. Sarah Mitchell</h3>
                        <div class="leader-title">Principal & CEO</div>
                        <p>With over 20 years in education, Dr. Mitchell leads our institution with a vision for innovative learning and student success. Her expertise in educational leadership has transformed countless lives.</p>
                    </div>
                </div>
                <div class="leader-card">
                    <div class="leader-image">
                        <div class="image-placeholder">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                    </div>
                    <div class="leader-info">
                        <h3>Prof. Michael Chen</h3>
                        <div class="leader-title">Academic Director</div>
                        <p>Professor Chen oversees our curriculum development and ensures academic excellence across all programs. His innovative approach to education sets new standards in the field.</p>
                    </div>
                </div>
                <div class="leader-card">
                    <div class="leader-image">
                        <div class="image-placeholder">
                            <i class="fas fa-user-friends"></i>
                        </div>
                    </div>
                    <div class="leader-info">
                        <h3>Ms. Emily Rodriguez</h3>
                        <div class="leader-title">Student Affairs Director</div>
                        <p>Ms. Rodriguez is dedicated to student welfare and creating a supportive environment for all learners. Her commitment to student success is unmatched.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include 'footer.php'; ?>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script src="script.js"></script>
</body>
</html>