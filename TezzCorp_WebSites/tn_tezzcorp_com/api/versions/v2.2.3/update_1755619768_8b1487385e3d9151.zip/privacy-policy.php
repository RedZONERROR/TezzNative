<?php
require_once 'conn.php';

$query = mysqli_query($conn, "SELECT school_name, logo, favicon, email, address, phone, tagline, footer_text, transport_head_mobile, fees_collection_mobile, whatsapp_number, calling_number, facebook_url, twitter_url, instagram_url, linkedin_url, youtube_url FROM site_settings");
$fetch = mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Favicon -->
    <?php
    if (!empty($fetch['favicon'])) {
        $favicon = htmlspecialchars($fetch['favicon'], ENT_QUOTES, 'UTF-8');
        $ext = pathinfo($favicon, PATHINFO_EXTENSION);
        
        // Set MIME type based on extension
        $mimeType = 'image/png'; // default
        if ($ext === 'jpg' || $ext === 'jpeg') {
            $mimeType = 'image/jpeg';
        } elseif ($ext === 'ico') {
            $mimeType = 'image/x-icon';
        }
    
        echo '<link rel="icon" type="' . $mimeType . '" href="' . $favicon . '">';
    }
    ?>
    
    <title>Privacy Policy - <?php echo $fetch['school_name']; ?></title>
    <link rel="stylesheet" href="assets/css/privacy-policy.css">
</head>
<body>
    <header class="header">
        <h1><?php echo $fetch['school_name']; ?></h1>
        <p>Your Privacy is Our Priority</p>
    </header>
    <main class="policy-content">
        <section>
            <h2>Privacy Policy</h2>
            <p>At <?php echo $fetch['school_name']; ?>, we respect and protect the privacy of our students, parents, and staff. This policy outlines how we collect, use, and safeguard your personal information.</p>
        </section>
        <section>
            <h3>Information We Collect</h3>
            <ul>
                <li>Student details such as name, age, and contact information.</li>
                <li>Parental or guardian contact details.</li>
                <li>Academic records and other school-related data.</li>
            </ul>
        </section>
        <section>
            <h3>How We Use Your Information</h3>
            <p>The collected information is used for:</p>
            <ul>
                <li>Academic management and communication.</li>
                <li>Enhancing the educational experience.</li>
                <li>Compliance with legal requirements.</li>
            </ul>
        </section>
        <section>
            <h3>Data Security</h3>
            <p>We take appropriate measures to ensure the security of your data and prevent unauthorized access.</p>
        </section>
        <section>
            <h3>Contact Us</h3>
            <p>If you have questions about our Privacy Policy, please contact us:</p>
            <address>
                <?php echo $fetch['school_name']; ?>,<br>
                <?php echo $fetch['address']; ?><br>
                Phone: <?php echo $fetch['phone']; ?><br>
                Email: <?php echo $fetch['email']; ?>
            </address>
        </section>
    </main>
    <footer class="footer">
        <p><?php echo $fetch['footer_text']; ?></p>
    </footer>
</body>
</html>