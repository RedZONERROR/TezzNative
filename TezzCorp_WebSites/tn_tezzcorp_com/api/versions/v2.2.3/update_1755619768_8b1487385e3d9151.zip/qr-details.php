<?php
require 'conn.php';

function decodeId($encodedId, $key) {
    $decoded = base64_decode($encodedId) ^ $key; // Decode and XOR with the key
    return $decoded;
}

if (isset($_GET['id'])) {
    $encodedId = $_GET['id'];
    $secretKey = 987654321;
    $decodedId = decodeId($encodedId, $secretKey);
    
    $query = mysqli_query($conn, "SELECT * FROM students WHERE id = $decodedId");
    $fetch = mysqli_fetch_array($query);
    
    echo $fetch['student_name'];
} else {
    echo "No ID provided.";
}
?>