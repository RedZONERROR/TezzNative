<?php
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require '../conn.php';

// Get the JSON input
$data = json_decode(file_get_contents('php://input'), true);
if (!$data || !isset($data['username'], $data['password'])) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid input. Username and password are required."
    ]);
    exit;
}

$username = $data['username'];
$password = $data['password'];

// Prepare and execute the query
$sql = "SELECT id, uid, email, password, role, name, photo FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode([
        "success" => false,
        "message" => "Database error: " . $conn->error
    ]);
    exit;
}

$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    $role = $user['role'];

    // Verify the role and password
    if ($role === "Super Admin" || $role === "Admin") {
        if (password_verify($password, $user['password'])) {
            $_SESSION['id'] = $user['id'];
            $_SESSION['uid'] = $user['uid'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['photo'] = $user['photo'];
            $_SESSION['role'] = $user['role'];
    
            echo json_encode([
                "success" => true,
                "message" => "Admin login successful!",
                "email" => $user['email'],
                "name" => $user['name'],
                "photo" => $user['photo'],
                "role" => $user['role']
            ]);
        } else {
            echo json_encode([
                "success" => false,
                "message" => "Invalid password."
            ]);
        }
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Access denied. User is not an admin."
        ]);
    }
} else {
    echo json_encode([
        "success" => false,
        "message" => "User not found."
    ]);
}

$stmt->close();
$conn->close();
?>