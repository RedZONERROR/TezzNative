<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set the timezone
date_default_timezone_set('Asia/Kolkata');

// Function to log messages
function logMessage($message) {
    $logFile = '../app/app.log';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message" . PHP_EOL, FILE_APPEND);
}

// Database connection
$host = 'localhost'; // Your database host
$db = 'u190073748_newtechpublic'; // Your database name
$user = 'u190073748_newtechpublic'; // Your database username
$pass = 'Newtech@845450'; // Your database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(['status' => 'error', 'message' => 'Database connection failed']));
}

// Function to send email
function sendEmail($recipientEmail, $subject, $body) {
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: New Tech Public School <support@newtechpublicschool.in>\r\n";

    if (mail($recipientEmail, $subject, $body, $headers)) {
        logMessage("Email sent to $recipientEmail.");
    } else {
        logMessage("Failed to send email to $recipientEmail.");
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collecting form data
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $message = htmlspecialchars(trim($_POST['message']));

    if (empty($name) || empty($email) || empty($message)) {
        echo json_encode(['status' => 'error', 'message' => 'All fields are required']);
        exit;
    }

    // Insert data into the database
    $stmt = $pdo->prepare("INSERT INTO contact (name, email, message) VALUES (?, ?, ?)");
    if ($stmt->execute([$name, $email, $message])) {
        // Acknowledgment email to the user
        $userSubject = "Thank You for Contacting New Tech Public School";
        $userMessage = "
        <html>
        <head>
            <title>Thank You for Contacting Us</title>
        </head>
        <body>
            <p>Dear $name,</p>
            <p>Thank you for reaching out to us. We have received your message and will get back to you shortly.</p>
            <p><strong>Your Message:</strong></p>
            <blockquote>$message</blockquote>
            <p>If you have any urgent queries, feel free to contact us at <a href='mailto:support@newtechpublicschool.in'>support@newtechpublicschool.in</a>.</p>
            <p>Thank you,</p>
            <p><strong>New Tech Public School Team</strong></p>
        </body>
        </html>";
        sendEmail($email, $userSubject, $userMessage);

        // Notification email to the admin
        $adminSubject = "New Contact Us Submission";
        $adminMessage = "
        <html>
        <head>
            <title>New Contact Form Submission</title>
        </head>
        <body>
            <p><strong>New message received from the Contact Us form:</strong></p>
            <p><strong>Name:</strong> $name</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Message:</strong></p>
            <blockquote>$message</blockquote>
            <p>Thank you,</p>
            <p><strong>New Tech Public School System</strong></p>
        </body>
        </html>";
        sendEmail('info@newtechpublicschool.in', $adminSubject, $adminMessage);

        echo json_encode(['status' => 'success', 'message' => 'Your message has been sent successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to save your message']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
?>