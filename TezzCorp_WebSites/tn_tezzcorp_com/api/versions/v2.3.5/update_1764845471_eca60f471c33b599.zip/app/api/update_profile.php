<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

class UserController {
    private $pdo;
    private $logger;
    private $uploadDir;

    public function __construct() {
        // Initialize database connection
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO(
                "mysql:host=$host;dbname=$db;charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        // Initialize logger
        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            $logDir = $_SERVER['DOCUMENT_ROOT'] . '/logs/';
            if (!file_exists($logDir)) mkdir($logDir, 0755, true);
            file_put_contents($logDir . 'api.log', $logMessage, FILE_APPEND);
        };

        // Set upload directory
        $this->uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/uploads/users/';
        if (!file_exists($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
    }

    // --- HELPER FUNCTIONS ---

    private function sendError(int $code, string $message): void {
        http_response_code($code);
        echo json_encode(['status' => 'error', 'error' => $message]);
        exit;
    }

    private function sendSuccess(int $code, array $data): void {
        http_response_code($code);
        echo json_encode($data);
        exit;
    }

    private function logError(string $message): void {
        ($this->logger)('ERROR: ' . $message);
    }

    // --- CORE ACTIONS ---

    // 1. Update Profile Info (Name, Email, Photo)
    private function updateProfileInfo($data) {
        // Validations
        if (empty($data['name'])) $this->sendError(400, 'Name is required');
        if (empty($data['email']) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $this->sendError(400, 'Valid email is required');
        }

        // Fetch existing data to get old photo path
        $stmt = $this->pdo->prepare("SELECT photo FROM users WHERE uid = ?");
        $stmt->execute([$_SESSION['uid']]);
        $existing = $stmt->fetch();
        if (!$existing) $this->sendError(404, 'User not found');

        // Handle File Upload
        $photoPath = $existing['photo'];
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['photo'];
            $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            if (!in_array($file['type'], $allowed)) $this->sendError(400, 'Invalid image type');
            if ($file['size'] > 2 * 1024 * 1024) $this->sendError(400, 'Image too large (Max 2MB)');

            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = uniqid() . '.' . $ext;
            $destination = $this->uploadDir . $filename;

            if (move_uploaded_file($file['tmp_name'], $destination)) {
                $photoPath = '/uploads/users/' . $filename;
                // Optional: Delete old photo if it exists and is not default
            }
        }

        // Update DB
        try {
            $stmt = $this->pdo->prepare("UPDATE users SET name = ?, email = ?, photo = ? WHERE uid = ?");
            $stmt->execute([$data['name'], $data['email'], $photoPath, $_SESSION['uid']]);

            // Update Session
            $_SESSION['name'] = $data['name'];
            $_SESSION['email'] = $data['email'];
            $_SESSION['photo'] = $photoPath;

            $this->sendSuccess(200, [
                'status' => 'success',
                'message' => 'Profile updated successfully',
                'data' => ['name' => $data['name'], 'photo' => $photoPath]
            ]);
        } catch (PDOException $e) {
            $this->logError('Profile Update Failed: ' . $e->getMessage());
            $this->sendError(500, 'Database update failed');
        }
    }

    // 2. Update Password
    private function updatePassword($data) {
        // Validations
        if (empty($data['old_password'])) $this->sendError(400, 'Current password is required');
        if (empty($data['new_password'])) $this->sendError(400, 'New password is required');
        if (strlen($data['new_password']) < 6) $this->sendError(400, 'New password must be at least 6 characters');
        if ($data['new_password'] !== $data['confirm_password']) $this->sendError(400, 'Confirm password does not match');

        // Fetch current password hash
        $stmt = $this->pdo->prepare("SELECT password FROM users WHERE uid = ?");
        $stmt->execute([$_SESSION['uid']]);
        $user = $stmt->fetch();

        if (!$user) $this->sendError(404, 'User not found');

        // Verify Old Password
        // Note: Using password_verify handles BCRYPT hashing automatically
        if (!password_verify($data['old_password'], $user['password'])) {
            // Security: Generic message for wrong password
            $this->sendError(400, 'Incorrect current password'); 
        }

        // Hash New Password
        $newHash = password_hash($data['new_password'], PASSWORD_DEFAULT);

        // Update DB
        try {
            $stmt = $this->pdo->prepare("UPDATE users SET password = ? WHERE uid = ?");
            $stmt->execute([$newHash, $_SESSION['uid']]);

            $this->sendSuccess(200, [
                'status' => 'success',
                'message' => 'Password changed successfully'
            ]);
        } catch (PDOException $e) {
            $this->logError('Password Update Failed: ' . $e->getMessage());
            $this->sendError(500, 'Failed to update password');
        }
    }

    // Main Handler
    public function handleRequest() {
        // Auth Check
        if (!isset($_SESSION['uid'])) {
            $this->sendError(401, 'Unauthorized access');
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendError(405, 'Method not allowed');
        }

        // Determine Action
        $action = $_POST['action'] ?? 'update_info'; // Default to info update for backward compatibility

        if ($action === 'update_password') {
            $this->updatePassword($_POST);
        } else {
            $this->updateProfileInfo($_POST);
        }
    }
}

// Instantiate and handle request
$controller = new UserController();
$controller->handleRequest();
?>