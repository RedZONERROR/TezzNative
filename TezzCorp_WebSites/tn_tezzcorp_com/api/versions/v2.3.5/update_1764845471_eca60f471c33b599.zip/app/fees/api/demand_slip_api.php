<?php
header('Content-Type: application/json');
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Helper to get month name
function getMonthName($m) {
    if ($m == 0) return "Pending Dues (Prev. Session)";
    return date("F", mktime(0, 0, 0, $m, 10));
}

$action = $_GET['action'] ?? 'fetch';

if ($action === 'fetch' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo = getDBConnection();
        $class_id = $_POST['class_id'] ?? null;
        $current_month_input = $_POST['month'] ?? null; 
        
        if (!$class_id) {
            throw new Exception("Class ID is required");
        }
        if (!$current_month_input) {
            throw new Exception("Current Month must be selected");
        }

        $current_month_input = intval($current_month_input);

        // 1. Determine Session
        $current_year = date('Y');
        $current_month_real = date('n');
        $session_start = ($current_month_real < 4) ? ($current_year - 1) : $current_year;
        $session = $session_start . '-' . ($session_start + 1);

        // 2. Fetch School Settings
        $settings = $pdo->query("SELECT school_name, address, phone FROM site_settings LIMIT 1")->fetch(PDO::FETCH_ASSOC);
        if (!$settings) {
            $settings = ['school_name' => 'School Name', 'address' => 'Address', 'phone' => 'Phone'];
        }

        // 3. Fetch Students
        $stmt = $pdo->prepare("SELECT id, full_name, father_name, roll_no, transport_id, uid, class FROM students WHERE class = ? AND status = 'active' ORDER BY roll_no ASC");
        $stmt->execute([$class_id]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 4. Class Info
        $stmt = $pdo->prepare("SELECT class_name FROM class WHERE id = ?");
        $stmt->execute([$class_id]);
        $class_info = $stmt->fetch(PDO::FETCH_ASSOC);
        $class_name = $class_info['class_name'] ?? '';

        // 5. Pre-fetch Standard Fee Structure
        $stmt = $pdo->prepare("
            SELECT particular_id, amount, frequency, custom_frequency, applicable_months, 
            (SELECT particular FROM particulars WHERE id = fee_structure.particular_id) as particular_name 
            FROM fee_structure 
            WHERE class_id = ? AND session = ? AND status = 'active'
        ");
        $stmt->execute([$class_id, $session]);
        $class_fee_structure = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $demand_slips = [];
        
        // Standard Academic Year Order (April to March)
        // Index: 0=Apr, 1=May, 2=Jun, 3=Jul, 4=Aug, 5=Sep, 6=Oct, 7=Nov, 8=Dec, 9=Jan, 10=Feb, 11=Mar
        $SESSION_MONTH_ORDER = [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3];
        
        // Determine Target Months
        $target_months = [];
        foreach ($SESSION_MONTH_ORDER as $m) {
            $target_months[] = $m;
            if ($m == $current_month_input) break; 
        }

        foreach ($students as $student) {
            $student_id = $student['id'];
            $student_uid = $student['uid'];
            $transport_id = $student['transport_id'];

            // --- A. PENDING FEES ---
            $stmt = $pdo->prepare("SELECT id, pending_amount, status, collection_id, particular_id, (SELECT particular FROM particulars WHERE id = pending_fees.particular_id) as particular_name FROM pending_fees WHERE student_uid = ?");
            $stmt->execute([$student_uid]);
            $pending_rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $total_pending_due = 0;
            $is_pending_cleared = true;
            $pending_collection_ids = [];

            foreach($pending_rows as $pr) {
                if($pr['status'] === 'pending') {
                    $total_pending_due += $pr['pending_amount'];
                    $is_pending_cleared = false;
                } else {
                    if($pr['collection_id']) {
                        $pending_collection_ids[] = $pr['collection_id'];
                    }
                }
            }

            // --- B. CALCULATE MONTHLY DUES MAP ---
            $monthly_dues_map = []; 
            foreach($SESSION_MONTH_ORDER as $m) $monthly_dues_map[$m] = 0;

            // Special Structure
            $stmt = $pdo->prepare("SELECT particular_id, fee_type, special_amount, discount_percentage FROM special_structure WHERE student_uid = ? AND status = 'active'");
            $stmt->execute([$student_uid]);
            $special_structures = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $special_academic_map = [];
            $special_transport = null;
            foreach ($special_structures as $ss) {
                if ($ss['fee_type'] === 'transport') $special_transport = $ss;
                else $special_academic_map[$ss['particular_id']] = $ss;
            }

            // 1. Process Academic Fees
            foreach ($class_fee_structure as $fee) {
                $pid = $fee['particular_id'];
                $amount = (float)$fee['amount'];

                // Apply Discounts
                if (isset($special_academic_map[$pid])) {
                    $ss = $special_academic_map[$pid];
                    $discount_amt = 0;
                    if ($ss['discount_percentage'] > 0) {
                        $discount_amt += ($amount * $ss['discount_percentage'] / 100);
                    }
                    if ($ss['special_amount'] > 0) {
                        $discount_amt += $ss['special_amount'];
                    }
                    $amount = max(0, $amount - $discount_amt);
                }

                // Distribute based on Frequency
                if ($fee['frequency'] === 'monthly') {
                    $months_to_apply = ($fee['applicable_months'] === 'all') 
                        ? $SESSION_MONTH_ORDER 
                        : array_map('intval', explode(',', $fee['applicable_months']));
                    
                    foreach ($months_to_apply as $m_id) {
                        if (isset($monthly_dues_map[$m_id])) $monthly_dues_map[$m_id] += $amount;
                    }
                } 
                elseif ($fee['frequency'] === 'annual') {
                    if (isset($monthly_dues_map[4])) $monthly_dues_map[4] += $amount;
                } 
                elseif ($fee['frequency'] === 'other') {
                    // --- UPDATED CUSTOM FREQUENCY LOGIC ---
                    // custom_frequency is the INTERVAL.
                    // Start from June (Index 2 in this specific file's array)
                    $interval = intval($fee['custom_frequency']);
                    
                    if ($interval > 0) {
                        // Start at index 2 (June). Loop until end of array.
                        for ($i = 2; $i < count($SESSION_MONTH_ORDER); $i += $interval) {
                             $m_id = $SESSION_MONTH_ORDER[$i];
                             if (isset($monthly_dues_map[$m_id])) {
                                 $monthly_dues_map[$m_id] += $amount;
                             }
                        }
                    } else {
                        // Fallback
                        if (!empty($fee['applicable_months']) && $fee['applicable_months'] !== 'all') {
                            $months_to_apply = array_map('intval', explode(',', $fee['applicable_months']));
                            foreach ($months_to_apply as $m_id) {
                                if (isset($monthly_dues_map[$m_id])) $monthly_dues_map[$m_id] += $amount;
                            }
                        } else {
                            if (isset($monthly_dues_map[4])) $monthly_dues_map[4] += $amount;
                        }
                    }
                }
            }

            // 2. Process Transport Fee
            $transport_monthly_rate = 0;
            if ($transport_id) {
                $stmt = $pdo->prepare("SELECT transport_fees FROM transport WHERE id = ? AND session = ?");
                $stmt->execute([$transport_id, $session]);
                $raw_transport = (float)$stmt->fetchColumn() ?: 0;

                if ($special_transport) {
                    $discount_amt = 0;
                    if ($special_transport['discount_percentage'] > 0) {
                        $discount_amt += ($raw_transport * $special_transport['discount_percentage'] / 100);
                    }
                    if ($special_transport['special_amount'] > 0) {
                         $discount_amt += $special_transport['special_amount']; 
                    }
                    $raw_transport = max(0, $raw_transport - $discount_amt);
                }
                $transport_monthly_rate = $raw_transport;
                
                foreach ($monthly_dues_map as $key => $val) {
                    $monthly_dues_map[$key] += $transport_monthly_rate;
                }
            }

            // --- C. FETCH PAYMENTS ---
            $stmt = $pdo->prepare("SELECT id, amount_collected, discount, payment_month FROM fee_collections WHERE student_id = ? AND session = ?");
            $stmt->execute([$student_id, $session]);
            $all_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $total_paid_available_for_months = 0;
            
            foreach($all_payments as $p) {
                $pay_val = $p['amount_collected'] + $p['discount'];
                if (in_array($p['id'], $pending_collection_ids) || $p['payment_month'] == '0') {
                    // Paid for pending fees
                } else {
                    $total_paid_available_for_months += $pay_val;
                }
            }

            // --- D. WATERFALL CALCULATION ---
            $slip_items = [];
            $total_slip_amount = 0;

            if ($total_pending_due > 0 && !$is_pending_cleared) {
                 $slip_items[] = [
                     'description' => 'Previous Session Dues',
                     'qty' => 1,
                     'amount' => floatval($total_pending_due)
                 ];
                 $total_slip_amount += $total_pending_due;
            }

            $cumulative_fee = 0;
            foreach ($SESSION_MONTH_ORDER as $month_id) {
                if ($month_id == 0) continue; 

                $month_fee = $monthly_dues_map[$month_id];
                $cumulative_fee += $month_fee;

                $previous_months_cost = $cumulative_fee - $month_fee;
                $paid_for_this_month = max(0, min($month_fee, $total_paid_available_for_months - $previous_months_cost));
                $due = $month_fee - $paid_for_this_month;

                if (in_array($month_id, $target_months) && $due > 0.1) {
                    $slip_items[] = [
                        'description' => 'Fees (' . getMonthName($month_id) . ')',
                        'qty' => 1,
                        'amount' => floatval($due)
                    ];
                    $total_slip_amount += $due;
                }
            }

            if ($total_slip_amount > 0) {
                $demand_slips[] = [
                    'student_id' => $student_id,
                    'student_name' => $student['full_name'],
                    'father_name' => $student['father_name'],
                    'class_name' => $class_name,
                    'roll_no' => $student['roll_no'],
                    'fees' => $slip_items,
                    'total_amount' => $total_slip_amount
                ];
            }
        }

        echo json_encode([
            'status' => 'success', 
            'school' => $settings, 
            'data' => $demand_slips
        ]);

    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
    exit;
}
?>