<?php
// Load database configuration
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

// Set headers for JSON API
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class SpecialDiscountController {
    private $pdo;
    private $logger;

    public function __construct() {
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;

        try {
            $this->pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $this->sendError(500, 'Database connection failed');
        }
    }

    private function validateInput(array $data, bool $isUpdate = false): array {
        $validData = [];
        $errors = [];

        // Common fields
        if ($isUpdate) {
            if (empty($data['id'])) $errors[] = "ID is required";
            $validData['id'] = intval($data['id']);
        } else {
            // Create only fields
            if (empty($data['student_id'])) $errors[] = "Student is required";
            $validData['student_id'] = intval($data['student_id']);

            if (empty($data['fee_type'])) $errors[] = "Fee Type is required";
            $validData['fee_type'] = $data['fee_type']; // academic or transport

            if ($validData['fee_type'] === 'academic' && empty($data['particular_id'])) {
                $errors[] = "Particular is required for Academic fees";
            }
            $validData['particular_id'] = !empty($data['particular_id']) ? intval($data['particular_id']) : 0;
        }

        $validData['discount_type'] = $data['discount_type'] ?? 'fixed';
        $validData['discount_value'] = floatval($data['discount_value'] ?? 0);
        $validData['reason'] = $data['reason'] ?? null;
        $validData['status'] = $data['status'] ?? 'active';
        
        // Applicable months
        if (!empty($data['applicable_months']) && is_array($data['applicable_months'])) {
            $validData['applicable_months'] = implode(',', $data['applicable_months']);
        } else {
            $validData['applicable_months'] = 'all';
        }

        // Special amount 
        $validData['special_amount'] = isset($data['special_amount']) ? floatval($data['special_amount']) : null;

        if (!empty($errors)) {
            $this->sendError(400, implode(', ', $errors));
        }

        return $validData;
    }

    public function get($request) {
        $conditions = [];
        $params = [];

        // Basic Filters
        if (!empty($request['class_id'])) {
            $conditions[] = 's.class = ?';
            $params[] = $request['class_id'];
        }
        if (!empty($request['fee_type'])) {
            $conditions[] = 'ss.fee_type = ?';
            $params[] = $request['fee_type'];
        }
        if (!empty($request['id'])) {
            $conditions[] = 'ss.id = ?';
            $params[] = $request['id'];
        }
        
        // Search Filter
        if (!empty($request['search'])) {
            $searchTerm = "%" . $request['search'] . "%";
            $conditions[] = "(s.full_name LIKE ? OR s.father_name LIKE ? OR c.class_name LIKE ?)";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }

        $whereClause = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

        // Pagination Logic
        $page = isset($request['page']) ? (int)$request['page'] : 1;
        $perPage = isset($request['perPage']) ? (int)$request['perPage'] : 10;
        $offset = ($page - 1) * $perPage;

        // 1. Get Total Count
        $countSql = "
            SELECT COUNT(*) 
            FROM special_structure ss
            JOIN students s ON ss.student_uid = s.uid
            JOIN class c ON s.class = c.id
            $whereClause
        ";
        $countStmt = $this->pdo->prepare($countSql);
        $countStmt->execute($params);
        $totalItems = $countStmt->fetchColumn();
        $totalPages = ceil($totalItems / $perPage);

        // 2. Get Data
        $sql = "
            SELECT ss.*, 
                   s.full_name as student_name, 
                   s.father_name,
                   c.class_name, 
                   CASE 
                       WHEN ss.fee_type = 'transport' THEN 'Transport Fee'
                       ELSE p.particular 
                   END as particular_name,
                   ss.fee_type,
                   CASE 
                       WHEN ss.fee_type = 'transport' THEN t.transport_fees
                       ELSE fs.amount
                   END as original_amount
            FROM special_structure ss
            JOIN students s ON ss.student_uid = s.uid
            JOIN class c ON s.class = c.id
            LEFT JOIN particulars p ON ss.particular_id = p.id
            LEFT JOIN transport t ON s.transport_id = t.id
            LEFT JOIN fee_structure fs ON fs.particular_id = ss.particular_id 
                                      AND fs.class_id = s.class 
                                      AND fs.status = 'active'
                                      AND fs.id = (
                                          SELECT MAX(id) FROM fee_structure fs2 
                                          WHERE fs2.particular_id = ss.particular_id 
                                          AND fs2.class_id = s.class 
                                          AND fs2.status = 'active'
                                      )
            $whereClause
            ORDER BY ss.created_on DESC
            LIMIT $perPage OFFSET $offset
        ";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        $data = $stmt->fetchAll();

        // Return data with meta for pagination
        $meta = [
            'page' => $page,
            'perPage' => $perPage,
            'totalPages' => $totalPages,
            'totalItems' => $totalItems
        ];

        $this->sendSuccess(200, 'Fetched successfully', ['data' => $data, 'meta' => $meta]);
    }

    public function post() {
        $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
        $validData = $this->validateInput($input);

        // 1. Fetch Student Info
        $stmt = $this->pdo->prepare("SELECT uid, class, transport_id FROM students WHERE id = ? AND status = 'active'");
        $stmt->execute([$validData['student_id']]);
        $student = $stmt->fetch();

        if (!$student) $this->sendError(404, 'Student not found');

        // 2. Determine Original Amount
        $original_amount = 0;

        if ($validData['fee_type'] === 'transport') {
            if (!$student['transport_id']) {
                $this->sendError(400, 'Student does not have a transport route assigned.');
            }
            $stmt = $this->pdo->prepare("SELECT transport_fees FROM transport WHERE id = ?");
            $stmt->execute([$student['transport_id']]);
            $original_amount = floatval($stmt->fetchColumn());
        } else {
            // Academic
            $stmt = $this->pdo->prepare("SELECT amount FROM fee_structure WHERE particular_id = ? AND class_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1");
            $stmt->execute([$validData['particular_id'], $student['class']]);
            $original_amount = floatval($stmt->fetchColumn());
        }

        if ($original_amount <= 0) {
            $this->sendError(400, 'Base fee amount is zero or not defined. Cannot apply discount.');
        }

        // 3. Calculate Discount
        $special_amount = 0;
        $discount_percentage = 0;

        if ($validData['discount_type'] === 'percentage') {
            $discount_percentage = $validData['discount_value'];
            $special_amount = $original_amount * (1 - ($discount_percentage / 100));
        } else {
            // Fixed Discount Amount provided in discount_value
            $discount_amt = $validData['discount_value'];
            $special_amount = max(0, $original_amount - $discount_amt);
            $discount_percentage = ($original_amount > 0) ? ($discount_amt / $original_amount) * 100 : 0;
        }

        // 4. Insert
        $stmt = $this->pdo->prepare("
            INSERT INTO special_structure 
            (student_uid, particular_id, fee_type, special_amount, discount_percentage, applicable_months, reason, status, created_on)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'active', NOW())
        ");

        $stmt->execute([
            $student['uid'],
            $validData['particular_id'], // 0 for transport
            $validData['fee_type'],
            $special_amount,
            $discount_percentage,
            $validData['applicable_months'],
            $validData['reason']
        ]);

        $this->sendSuccess(201, 'Special discount added successfully');
    }

    public function put() {
        $input = json_decode(file_get_contents('php://input'), true);
        $validData = $this->validateInput($input, true);

        $stmt = $this->pdo->prepare("
            UPDATE special_structure 
            SET special_amount = ?, reason = ?, status = ?, updated_on = NOW()
            WHERE id = ?
        ");
        
        $stmt->execute([
            $validData['special_amount'],
            $validData['reason'],
            $validData['status'],
            $validData['id']
        ]);

        $this->sendSuccess(200, 'Updated successfully');
    }

    public function delete($request) {
        if (empty($request['id']) && empty($request['ids'])) $this->sendError(400, 'ID required');
        
        if (!empty($request['ids'])) {
            // Bulk delete
            $ids = $request['ids']; // Assuming array
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $stmt = $this->pdo->prepare("DELETE FROM special_structure WHERE id IN ($placeholders)");
            $stmt->execute($ids);
        } else {
            // Single delete
            $stmt = $this->pdo->prepare("DELETE FROM special_structure WHERE id = ?");
            $stmt->execute([$request['id']]);
        }
        
        $this->sendSuccess(200, 'Deleted successfully');
    }

    // Helper to fetch original amount for UI Preview
    private function getOriginalAmount() {
        $student_id = $_GET['student_id'] ?? 0;
        $fee_type = $_GET['fee_type'] ?? 'academic';
        $particular_id = $_GET['particular_id'] ?? 0;

        if (!$student_id) $this->sendError(400, 'Student ID required');

        $stmt = $this->pdo->prepare("SELECT class, transport_id FROM students WHERE id = ?");
        $stmt->execute([$student_id]);
        $student = $stmt->fetch();

        if (!$student) $this->sendError(404, 'Student not found');

        $amount = 0;
        if ($fee_type === 'transport') {
            if ($student['transport_id']) {
                $stmt = $this->pdo->prepare("SELECT transport_fees FROM transport WHERE id = ?");
                $stmt->execute([$student['transport_id']]);
                $amount = $stmt->fetchColumn();
            }
        } else {
            if ($particular_id) {
                $stmt = $this->pdo->prepare("SELECT amount FROM fee_structure WHERE particular_id = ? AND class_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1");
                $stmt->execute([$particular_id, $student['class']]);
                $amount = $stmt->fetchColumn();
            }
        }

        $this->sendSuccess(200, 'Fetched', ['amount' => floatval($amount)]);
    }

    private function sendError($code, $msg) {
        http_response_code($code);
        echo json_encode(['status' => 'error', 'message' => $msg]);
        exit;
    }

    private function sendSuccess($code, $msg, $data = []) {
        http_response_code($code);
        // Flexible return structure to support both list (with meta) and single items
        if (isset($data['meta'])) {
            echo json_encode(['status' => 'success', 'message' => $msg, 'data' => $data['data'], 'meta' => $data['meta']]);
        } else {
            echo json_encode(['status' => 'success', 'message' => $msg, 'data' => $data]);
        }
        exit;
    }

    public function handleRequest() {
        if (isset($_GET['action']) && $_GET['action'] === 'get_original_amount') {
            $this->getOriginalAmount();
            return;
        }

        switch ($_SERVER['REQUEST_METHOD']) {
            case 'GET': $this->get($_GET); break;
            case 'POST': $this->post(); break;
            case 'PUT': $this->put(); break;
            case 'DELETE': 
                // Support bulk delete via JSON body or query params
                $input = json_decode(file_get_contents('php://input'), true);
                $this->delete($input ?? $_GET); 
                break;
        }
    }
}

$api = new SpecialDiscountController();
$api->handleRequest();
?>