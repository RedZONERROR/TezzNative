<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];

// Fetch License Key securely
$license_key = "";
try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'license_key' LIMIT 1");
    $stmt->execute();
    $license_key = $stmt->fetchColumn();
} catch (Exception $e) {
    // Handle error silently or log it
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">

<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <title>Training Videos - AI-ERP 2.0</title>
    
    <style>
        /* YouTube Style Card */
        .video-card {
            border: none;
            background: transparent;
            transition: transform 0.2s;
            cursor: pointer;
            height: 100%;
        }
        
        .video-card:hover .card-img-top {
            border-radius: 0;
        }
        
        .video-thumbnail-wrapper {
            position: relative;
            border-radius: 12px;
            overflow: hidden;
            aspect-ratio: 16/9;
            background-color: #e0e0e0;
        }
        
        .card-img-top {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s;
        }

        .video-card:hover .card-img-top {
            transform: scale(1.05);
        }

        .video-duration {
            position: absolute;
            bottom: 8px;
            right: 8px;
            background-color: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .video-details {
            display: flex;
            margin-top: 12px;
            gap: 12px;
        }

        .video-icon {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background-color: #6366f1;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            font-size: 1rem;
        }

        .video-meta {
            flex-grow: 1;
        }

        .video-title {
            font-size: 1rem;
            font-weight: 600;
            line-height: 1.4;
            color: #0f172a;
            margin-bottom: 4px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .video-info {
            font-size: 0.85rem;
            color: #64748b;
        }

        /* Skeleton Loading Animation */
        .skeleton {
            background: #e0e0e0;
            background: linear-gradient(90deg, #ececec 8%, #f5f5f5 18%, #ececec 33%);
            background-size: 200% 100%;
            animation: shimmer 1.5s infinite linear;
            border-radius: 4px;
        }

        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }

        .sk-thumb { width: 100%; aspect-ratio: 16/9; border-radius: 12px; margin-bottom: 12px; }
        .sk-avatar { width: 36px; height: 36px; border-radius: 50%; float: left; margin-right: 12px; }
        .sk-line { height: 14px; margin-bottom: 8px; margin-left: 48px; }
        .sk-line.short { width: 60%; }

        /* Modal Styling */
        .modal-content { background-color: #000; }
        .modal-body { padding: 0; }
        .btn-close-white { filter: invert(1) grayscale(100%) brightness(200%); position: absolute; top: 15px; right: 15px; z-index: 1056; }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    
    <div id="main-wrapper">
        <!-- Sidebar -->
        <?php include 'util/sidebar.php'; ?>
        
        <div class="page-wrapper">
            <!-- Header -->
            <?php include 'util/topbar.php'; ?>

            <div class="body-wrapper">
                <div class="container-fluid">
                    
                    <!-- Header -->
                    <div class="card card-body py-3 mb-4">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Training Center</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">Training Videos</span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- API Key Hidden Field -->
                    <input type="hidden" id="license_key" value="<?php echo htmlspecialchars($license_key); ?>">

                    <!-- Video Grid -->
                    <div class="row g-4" id="videoGrid">
                        <!-- Skeletons (Load 6 by default) -->
                        <?php for($i=0; $i<6; $i++): ?>
                        <div class="col-md-6 col-lg-4 col-xl-4 skeleton-item">
                            <div class="skeleton sk-thumb"></div>
                            <div class="skeleton sk-avatar"></div>
                            <div class="skeleton sk-line"></div>
                            <div class="skeleton sk-line short"></div>
                        </div>
                        <?php endfor; ?>
                    </div>

                    <!-- Error State -->
                    <div id="errorState" class="text-center py-5" style="display:none;">
                        <img src="../assets/images/error.png" alt="No Videos" width="200" class="mb-3">
                        <h5 class="text-danger" id="errorMsg">Unable to load training videos.</h5>
                        <p class="text-muted">Please check your license key or internet connection.</p>
                        <button class="btn btn-primary mt-2" onclick="location.reload()"><i class="ti ti-refresh"></i> Retry</button>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- Video Player Modal -->
    <div class="modal fade" id="videoModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                <div class="modal-body">
                    <div class="ratio ratio-16x9">
                        <iframe id="videoFrame" src="" title="YouTube video" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>

    <script>
        $(document).ready(function() {
            const licenseKey = $('#license_key').val();
            const apiUrl = 'https://api.tezzcorp.com/videos/get.php'; // Remote API

            if(!licenseKey) {
                showError('License key not found in system settings.');
                return;
            }

            // Fetch Videos
            $.ajax({
                url: apiUrl,
                method: 'GET',
                data: { license_key: licenseKey },
                dataType: 'json',
                success: function(response) {
                    if(response.status === 'success') {
                        renderVideos(response.data);
                    } else {
                        showError(response.message || 'Invalid License or No videos found.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error("API Error:", error);
                    showError('Failed to connect to video server. (CORS or Network Error)');
                }
            });

            function renderVideos(videos) {
                const grid = $('#videoGrid');
                grid.empty(); // Clear skeletons

                if(videos.length === 0) {
                    showError('No training videos available at the moment.');
                    return;
                }

                videos.forEach(video => {
                    const html = `
                        <div class="col-md-6 col-lg-4 col-xl-4 fade-in">
                            <div class="video-card" onclick="playVideo('${video.embed_url}')">
                                <div class="video-thumbnail-wrapper">
                                    <img src="${video.thumbnail}" class="card-img-top" alt="${video.title}">
                                    <span class="video-duration">${video.duration}</span>
                                </div>
                                <div class="video-details">
                                    <div class="video-icon">
                                        <i class="ti ti-brand-youtube"></i>
                                    </div>
                                    <div class="video-meta">
                                        <h5 class="video-title" title="${video.title}">${video.title}</h5>
                                        <div class="video-info">
                                            <span>${video.views || 'Admin'}</span> • 
                                            <span>${video.uploaded_date}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                    grid.append(html);
                });

                // Simple fade in animation
                $('.fade-in').each(function(i) {
                    $(this).hide().delay(i * 100).fadeIn(500);
                });
            }

            function showError(msg) {
                $('#videoGrid').hide();
                $('#errorMsg').text(msg);
                $('#errorState').fadeIn();
            }

            // Video Modal Logic
            window.playVideo = function(url) {
                $('#videoFrame').attr('src', url + "?autoplay=1&rel=0");
                $('#videoModal').modal('show');
            }

            // Stop video when modal closes
            $('#videoModal').on('hidden.bs.modal', function () {
                $('#videoFrame').attr('src', '');
            });
        });
    </script>
</body>
</html>