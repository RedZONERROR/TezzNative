<?php
session_start();

// Ensure this path exists or adjust accordingly
include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Report Card Generation - AI-ERP 2.0</title>
    <style>
        .btn-loading .spinner-border {
            display: inline-block;
        }
        .spinner-border {
            display: none;
            width: 1rem;
            height: 1rem;
        }
        .student-checkbox {
            margin-bottom: 10px;
        }
        .download-section {
            display: none;
            margin-top: 20px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #dee2e6;
        }
        .download-section.show {
            display: block;
        }
        .download-info {
            margin-bottom: 15px;
        }
        .download-info h6 {
            color: #28a745;
            margin-bottom: 10px;
        }
        .student-list {
            max-height: 200px;
            overflow-y: auto;
            background: white;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #e9ecef;
        }
        .signature-upload {
            margin-top: 20px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #dee2e6;
        }
        .file-upload-wrapper {
            position: relative;
            display: inline-block;
            width: 100%;
        }
        .file-upload-input {
            position: absolute;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        .file-upload-label {
            display: block;
            padding: 10px 15px;
            background-color: #fff;
            border: 2px dashed #dee2e6;
            border-radius: 4px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .file-upload-label:hover {
            border-color: #007bff;
            background-color: #f8f9ff;
        }
        .file-upload-label.has-file {
            border-color: #28a745;
            background-color: #f8fff8;
        }
    </style>
</head>
<body>
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <div id="main-wrapper">
        <?php include 'util/sidebar.php'; ?>
        <div class="page-wrapper">
            <?php include 'util/topbar.php'; ?>
            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">Generate Report Cards</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                                    Report Cards
                                                </span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card card-body">
                        <form id="reportCardForm" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="class_id" class="form-label">Select Class</label>
                                    <select id="class_id" name="class_id" class="form-control" required>
                                        <option value="">Select a class</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="session" class="form-label">Select Session</label>
                                    <select id="session" name="session" class="form-control" required>
                                        <option value="">Select a session</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="term" class="form-label">Select Term</label>
                                    <select id="term" name="term" class="form-control" required>
                                        <option value="">Select a Term</option>
                                    </select>
                                    <span class="validation-text text-danger"></span>
                                </div>
                            </div>

                            <div class="signature-upload">
                                <h5 class="mb-3">Upload Signatures (Optional)</h5>
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Dept. of Examination</label>
                                        <div class="file-upload-wrapper">
                                            <input type="file" id="dept_examination_signature" name="dept_examination_signature" class="file-upload-input" accept="image/*">
                                            <label for="dept_examination_signature" class="file-upload-label">
                                                <i class="ti ti-upload"></i>
                                                <span class="upload-text">Click to upload dept. of exam. sign.</span>
                                            </label>
                                        </div>
                                        <small class="text-muted">Supported formats: JPG, PNG, GIF (Max: 2MB)</small>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Class Teacher Signature</label>
                                        <div class="file-upload-wrapper">
                                            <input type="file" id="class_teacher_signature" name="class_teacher_signature" class="file-upload-input" accept="image/*">
                                            <label for="class_teacher_signature" class="file-upload-label">
                                                <i class="ti ti-upload"></i>
                                                <span class="upload-text">Click to upload class teacher's sign.</span>
                                            </label>
                                        </div>
                                        <small class="text-muted">Supported formats: JPG, PNG, GIF (Max: 2MB)</small>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Principal Signature</label>
                                        <div class="file-upload-wrapper">
                                            <input type="file" id="principal_signature" name="principal_signature" class="file-upload-input" accept="image/*">
                                            <label for="principal_signature" class="file-upload-label">
                                                <i class="ti ti-upload"></i>
                                                <span class="upload-text">Click to upload principal's sign.</span>
                                            </label>
                                        </div>
                                        <small class="text-muted">Supported formats: JPG, PNG, GIF (Max: 2MB)</small>
                                    </div>
                                </div>
                            </div>

                            <h5 class="mt-4 mb-3">Select Students</h5>
                            <div class="mb-3">
                                <button type="button" id="select-all-students" class="btn btn-primary">Select All</button>
                            </div>
                            <div id="student-checkboxes" class="row">
                                </div>
                            <div class="text-end mt-4">
                                <button type="submit" class="btn btn-success" id="generate-report-cards">Generate Report Cards
                                    <div class="spinner-border text-light btn-loading" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                </button>
                            </div>
                        </form>
                        
                        <div id="download-section" class="download-section">
                            <div class="download-info">
                                <h6><i class="ti ti-check-circle"></i> Report Cards Generated Successfully!</h6>
                                <p class="mb-2">Report cards have been generated for <span id="student-count">0</span> students.</p>
                                <div class="student-list" id="generated-students">
                                    </div>
                            </div>
                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-primary" id="download-pdf">
                                    <i class="ti ti-download"></i> Download PDF
                                </button>
                                <button type="button" class="btn btn-secondary" id="generate-new">
                                    <i class="ti ti-plus"></i> Generate New Report Cards
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="../assets/js/vendor.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/simplebar.min.js"></script>
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/highlight.min.js"></script>
    <script>
        $(document).ready(function() {
            let downloadUrl = null;
            let generatedData = null;

            // File upload handling UI
            $('.file-upload-input').on('change', function() {
                const file = this.files[0];
                const label = $(this).siblings('.file-upload-label');
                const uploadText = label.find('.upload-text');
                
                if (file) {
                    uploadText.text(file.name);
                    label.addClass('has-file');
                } else {
                    const inputId = $(this).attr('id');
                    let defaultText = '';
                    switch(inputId) {
                        case 'dept_examination_signature': defaultText = 'Click to upload dept. examination signature'; break;
                        case 'class_teacher_signature': defaultText = 'Click to upload class teacher signature'; break;
                        case 'principal_signature': defaultText = 'Click to upload principal signature'; break;
                    }
                    uploadText.text(defaultText);
                    label.removeClass('has-file');
                }
            });

            // --- DATA LOADING FUNCTIONS ---
            
            function loadClasses() {
                $.ajax({
                    url: 'api/class_master.php',
                    type: 'GET',
                    data: { perPage: 50, status: 'active' },
                    dataType: 'json',
                    success: function(response) {
                        const classes = response.data || [];
                        $('#class_id').empty().append('<option value="">Select a class</option>');
                        classes.forEach(cls => {
                            $('#class_id').append(`<option value="${cls.id}">${cls.class_name}</option>`);
                        });
                    },
                    error: function(xhr) { console.error('Error loading classes', xhr); }
                });
            }

            function loadSessions() {
                $.ajax({
                    url: 'api/get_sessions.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        const sessions = response.data || [];
                        $('#session').empty().append('<option value="">Select a session</option>');
                        sessions.forEach(session => {
                            $('#session').append(`<option value="${session.session}">${session.session}</option>`);
                        });
                    },
                    error: function(xhr) { console.error('Error loading sessions', xhr); }
                });
            }

            function loadTerms() {
                $.ajax({
                    url: 'api/get_terms.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        const terms = response.data || [];
                        $('#term').empty().append('<option value="">Select a Term</option>');
                        terms.forEach(term => {
                            $('#term').append(`<option value="${term.term}">${term.term}</option>`);
                        });
                    },
                    error: function(xhr) { console.error('Error loading terms', xhr); }
                });
            }

            function loadStudents(classId) {
                if (!classId) {
                    $('#student-checkboxes').empty();
                    return;
                }
                $.ajax({
                    url: 'api/student_master.php',
                    type: 'GET',
                    data: { perPage: 100, class: classId },
                    dataType: 'json',
                    success: function(response) {
                        const students = response.data || [];
                        $('#student-checkboxes').empty();
                        if(students.length === 0) {
                            $('#student-checkboxes').append('<div class="col-12 text-muted">No students found in this class.</div>');
                        } else {
                            students.forEach(student => {
                                $('#student-checkboxes').append(`
                                    <div class="col-md-4 student-checkbox">
                                        <label class="form-check-label">
                                            <input type="checkbox" name="students[]" value="${student.uid}" class="form-check-input">
                                            ${student.full_name} (Roll: ${student.roll_no})
                                        </label>
                                    </div>
                                `);
                            });
                        }
                    },
                    error: function(xhr) { console.error('Error loading students', xhr); }
                });
            }

            // --- EVENT HANDLERS ---

            $('#class_id').on('change', function() {
                loadStudents($(this).val());
                hideDownloadSection();
            });

            $('#select-all-students').on('click', function() {
                const checkboxes = $('#student-checkboxes input[type="checkbox"]');
                if(checkboxes.length === 0) return;
                const allChecked = checkboxes.length === checkboxes.filter(':checked').length;
                checkboxes.prop('checked', !allChecked);
                $(this).text(allChecked ? 'Select All' : 'Deselect All');
            });

            function showDownloadSection(data) {
                generatedData = data;
                downloadUrl = data.download_url;
                
                const reportCards = data.report_cards || [];
                $('#student-count').text(reportCards.length);
                
                const studentList = $('#generated-students');
                studentList.empty();
                
                reportCards.forEach(card => {
                    studentList.append(`
                        <div class="d-flex justify-content-between align-items-center py-1 border-bottom">
                            <span>${card.full_name} (Roll: ${card.roll_no})</span>
                            <small class="text-muted">${card.class_name}</small>
                        </div>
                    `);
                });
                
                $('#download-section').addClass('show');
                $('html, body').animate({
                    scrollTop: $('#download-section').offset().top - 100
                }, 500);
            }

            function hideDownloadSection() {
                $('#download-section').removeClass('show');
                downloadUrl = null;
                generatedData = null;
            }

            // Handle PDF Download
            $('#download-pdf').on('click', function() {
                if (!downloadUrl) {
                    Swal.fire('Error', 'No download URL available. Please generate report cards first.', 'error');
                    return;
                }

                const $btn = $(this);
                const originalText = $btn.html();
                $btn.html('<i class="ti ti-loader ti-spin"></i> Downloading...').prop('disabled', true);

                // Use window.open for GET request to download
                // The backend uses $_SESSION data set during generation to know what to download
                window.open(downloadUrl, '_blank');

                setTimeout(() => {
                    $btn.html(originalText).prop('disabled', false);
                    Swal.fire({
                        icon: 'success',
                        title: 'Download Started',
                        text: 'Your PDF is being generated and downloaded.',
                        timer: 2000,
                        showConfirmButton: false
                    });
                }, 1000);
            });

            $('#generate-new').on('click', function() {
                hideDownloadSection();
                $('#reportCardForm')[0].reset();
                $('#student-checkboxes').empty();
                $('#select-all-students').text('Select All');
                $('.file-upload-label').removeClass('has-file').find('.upload-text').each(function() {
                    const id = $(this).closest('.file-upload-label').attr('for');
                    if(id.includes('dept')) $(this).text('Click to upload dept. examination signature');
                    else if(id.includes('teacher')) $(this).text('Click to upload class teacher signature');
                    else $(this).text('Click to upload principal signature');
                });
                $('html, body').animate({ scrollTop: 0 }, 500);
            });

            // Form Submission
            $('#reportCardForm').on('submit', function(e) {
                e.preventDefault();
                
                if (!this.checkValidity()) {
                    this.reportValidity();
                    return;
                }
                
                const formData = new FormData(this);
                if (formData.getAll('students[]').length === 0) {
                    Swal.fire('Warning', 'Please select at least one student.', 'warning');
                    return;
                }
                
                $('#generate-report-cards').addClass('btn-loading').prop('disabled', true);
                hideDownloadSection();
                
                $.ajax({
                    url: 'api/generate-report-card.php', // Ensure this matches your backend filename
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(response) {
                        $('#generate-report-cards').removeClass('btn-loading').prop('disabled', false);
                        
                        if (response.success && response.data) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success!',
                                text: response.data.message,
                                timer: 1500,
                                showConfirmButton: false
                            });
                            showDownloadSection(response.data);
                        } else {
                            Swal.fire('Error', response.error || 'Unknown error occurred', 'error');
                        }
                    },
                    error: function(xhr) {
                        $('#generate-report-cards').removeClass('btn-loading').prop('disabled', false);
                        let msg = 'Failed to process request';
                        if(xhr.responseJSON && xhr.responseJSON.error) msg = xhr.responseJSON.error;
                        Swal.fire('Error', msg, 'error');
                    }
                });
            });

            // Initial Load
            loadClasses();
            loadSessions();
            loadTerms();
        });
    </script>
</body>
</html>