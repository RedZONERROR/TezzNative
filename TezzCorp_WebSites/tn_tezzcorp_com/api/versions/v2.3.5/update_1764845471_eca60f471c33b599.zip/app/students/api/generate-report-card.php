<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/fpdf/fpdf.php';

// Check if this is a download request
if (isset($_GET['download']) && $_GET['download'] === 'pdf') {
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="report_cards_' . date('Y-m-d_H-i-s') . '.pdf"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    
    $controller = new ReportCardController();
    $controller->downloadReportCard();
    exit;
}

// Regular JSON API headers
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

class ReportCardController {
    private $pdo;
    private $logger;

    public function __construct() {
        try {
            $this->pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            $this->logError('Database connection failed: ' . $e->getMessage());
            $this->sendError(500, 'Database connection failed');
        }

        $this->logger = function ($message) {
            $logMessage = date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL;
            if (!file_exists(__DIR__ . '/logs')) {
                 mkdir(__DIR__ . '/logs', 0755, true);
            }
            file_put_contents(__DIR__ . '/logs/api.log', $logMessage, FILE_APPEND);
        };
    }

    // --- HELPER METHODS ---

    private function getGrade($marks) {
        if ($marks === null || $marks === '') return '-';
        if ($marks >= 90) return 'A+';
        if ($marks >= 80) return 'A';
        if ($marks >= 70) return 'B+';
        if ($marks >= 60) return 'B';
        if ($marks >= 50) return 'C+';
        if ($marks >= 40) return 'C';
        return 'F';
    }

    private function validateAndProcessImage($imagePath) {
        if (!file_exists($imagePath) || !is_readable($imagePath) || filesize($imagePath) === 0) {
            return false;
        }
        $imageInfo = getimagesize($imagePath);
        if ($imageInfo === false) return false;
        
        $supportedTypes = [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF];
        return in_array($imageInfo[2], $supportedTypes);
    }

    private function logError(string $message): void { ($this->logger)('ERROR: ' . $message); }
    private function logInfo(string $message): void { ($this->logger)('INFO: ' . $message); }
    private function sendError(int $code, string $message): void {
        http_response_code($code); echo json_encode(['error' => $message]); exit;
    }
    private function sendSuccess(int $code, array $data): void {
        http_response_code($code); echo json_encode($data); exit;
    }

    // --- DATA HANDLING ---

    private function validateInput(array $data): array {
        $errors = [];
        $validData = [];

        if (!isset($data['class_id']) || !filter_var($data['class_id'], FILTER_VALIDATE_INT) || $data['class_id'] <= 0) $errors[] = 'Invalid class_id';
        else $validData['class_id'] = (int)$data['class_id'];

        if (empty(trim($data['session'] ?? ''))) $errors[] = 'Session required';
        else $validData['session'] = trim($data['session']);

        if (empty(trim($data['term'] ?? ''))) $errors[] = 'Term required';
        else $validData['term'] = trim($data['term']);

        if (empty($data['students']) || !is_array($data['students'])) $errors[] = 'Students required';
        else $validData['students'] = array_map('trim', $data['students']);

        $validData['dept_examination_signature'] = $data['dept_examination_signature'] ?? null;
        $validData['class_teacher_signature'] = $data['class_teacher_signature'] ?? null;
        $validData['principal_signature'] = $data['principal_signature'] ?? null;

        if ($errors) $this->sendError(400, implode('; ', $errors));
        return $validData;
    }

    private function handleFileUpload($file, $uploadDir = 'uploads/signatures/') {
        if (!$file || $file['error'] !== UPLOAD_ERR_OK) return null;
        
        $uploadPath = $_SERVER['DOCUMENT_ROOT'] . '/' . $uploadDir;
        if (!file_exists($uploadPath)) mkdir($uploadPath, 0755, true);

        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($file['type'], $allowedTypes)) throw new Exception('Invalid file type');
        if ($file['size'] > 2 * 1024 * 1024) throw new Exception('File too large');

        $filename = 'signature_' . uniqid() . '.' . pathinfo($file['name'], PATHINFO_EXTENSION);
        if (move_uploaded_file($file['tmp_name'], $uploadPath . $filename)) return $uploadDir . $filename;
        throw new Exception('Upload failed');
    }

    private function getTemplateFile() {
        try {
            $stmt = $this->pdo->prepare("SELECT template_file FROM templates WHERE template_type = ? AND status = ?");
            $stmt->execute(['marksheet', 'active']);
            $template = $stmt->fetch();
            return $template ? $template['template_file'] : '1.png';
        } catch (PDOException $e) { return '1.png'; }
    }

    private function calculateRank($class_id, $session, $term, $student_totals) {
        try {
            $sql = "SELECT r.uid, SUM(r.marks_obtained) as total_marks
                    FROM results r
                    JOIN subject s ON r.subject_id = s.id
                    WHERE r.class_id = ? AND r.session = ? AND r.term = ?
                    AND UPPER(s.subject) NOT IN ('MUSIC', 'SANITATION')
                    GROUP BY r.uid ORDER BY total_marks DESC";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$class_id, $session, $term]);
            $all = $stmt->fetchAll();

            $ranks = [];
            $cur_rank = 1; $prev_total = null; $pos = 1;
            foreach ($all as $s) {
                if ($s['total_marks'] !== $prev_total) $cur_rank = $pos;
                if (isset($student_totals[$s['uid']])) $ranks[$s['uid']] = $cur_rank;
                $prev_total = $s['total_marks']; $pos++;
            }
            return $ranks;
        } catch (PDOException $e) { return []; }
    }

    // --- MAIN PDF GENERATION LOGIC ---

    private function generatePDF($validData) {
        $template_file = $this->getTemplateFile();
        $placeholders = implode(',', array_fill(0, count($validData['students']), '?'));
        
        $sql = "SELECT r.uid, r.subject_id, r.marks_obtained, r.max_marks, s.subject, s.passing_marks,
                       sm.full_name, sm.father_name, sm.mother_name, sm.date_of_birth,
                       sm.roll_no, cm.class_name, d.student_photo,
                       t1.marks_obtained as term1_marks,
                       t2.marks_obtained as term2_marks
                FROM results r
                JOIN subject s ON r.subject_id = s.id
                JOIN students sm ON r.uid = sm.uid
                JOIN documents d ON sm.uid = d.uid
                JOIN class cm ON r.class_id = cm.id
                LEFT JOIN results t1 ON r.uid = t1.uid AND r.subject_id = t1.subject_id AND r.class_id = t1.class_id AND r.session = t1.session AND t1.term = 'FIRST TERMINAL'
                LEFT JOIN results t2 ON r.uid = t2.uid AND r.subject_id = t2.subject_id AND r.class_id = t2.class_id AND r.session = t2.session AND t2.term = 'SECOND TERMINAL'
                WHERE r.class_id = ? AND r.session = ? AND r.term = ? AND r.uid IN ($placeholders)";

        $stmt = $this->pdo->prepare($sql);
        $params = array_merge([$validData['class_id'], $validData['session'], $validData['term']], $validData['students']);
        $stmt->execute($params);

        $report_cards = [];
        $student_totals = [];

        $reqTerm = $validData['term'];

        while ($row = $stmt->fetch()) {
            $uid = $row['uid'];
            if (!isset($report_cards[$uid])) {
                $report_cards[$uid] = [
                    'full_name' => $row['full_name'], 'father_name' => $row['father_name'],
                    'mother_name' => $row['mother_name'], 'date_of_birth' => $row['date_of_birth'],
                    'roll_no' => $row['roll_no'], 'class_name' => $row['class_name'],
                    'student_photo' => $row['student_photo'], 'session' => $validData['session'],
                    'term' => $validData['term'], 'subjects' => []
                ];
                $student_totals[$uid] = 0;
            }

            $t1 = $row['term1_marks'];
            $t2 = $row['term2_marks'];
            $annual = null;
            $current = $row['marks_obtained'];

            if ($reqTerm === 'FIRST TERMINAL') { $t1 = $current; $t2 = null; }
            elseif ($reqTerm === 'SECOND TERMINAL') { $t2 = $current; }
            elseif ($reqTerm === 'ANNUAL') { $annual = $current; }

            $report_cards[$uid]['subjects'][] = [
                'subject' => $row['subject'],
                'marks_obtained' => $current, 
                'term1_marks' => $t1,
                'term2_marks' => $t2,
                'annual_marks' => $annual,
                'max_marks' => $row['max_marks'],
                'passing_marks' => $row['passing_marks']
            ];

            $student_totals[$uid] += $current;
        }

        if (empty($report_cards)) throw new Exception('No results found');

        $ranks = $this->calculateRank($validData['class_id'], $validData['session'], $validData['term'], $student_totals);
        
        $pdf = new FPDF();
        $image_path = $_SERVER['DOCUMENT_ROOT'] . '/app/settings/templates/marksheet/' . $template_file;
        if (!file_exists($image_path)) throw new Exception('Template missing');

        $genTerm = strtoupper(trim($validData['term']));
        $showFlags = [
            'term1' => true, 
            'term2' => ($genTerm == 'SECOND TERMINAL' || $genTerm == 'ANNUAL'),
            'annual' => ($genTerm == 'ANNUAL')
        ];

        $signatures = [
            'dept' => $validData['dept_examination_signature'],
            'teacher' => $validData['class_teacher_signature'],
            'principal' => $validData['principal_signature']
        ];

        foreach ($report_cards as $uid => &$card) {
            $total_max = array_sum(array_column($card['subjects'], 'max_marks'));
            $total_obt = array_sum(array_column($card['subjects'], 'marks_obtained'));
            $card['percentage'] = $total_max > 0 ? ($total_obt / $total_max) * 100 : 0;
            $card['rank'] = $ranks[$uid] ?? 'N/A';
            
            if ($template_file == '1.png') {
                $this->renderTemplate1($pdf, $image_path, $card, $showFlags, $signatures);
            } elseif ($template_file == '3.png') {
                $this->renderTemplate3($pdf, $image_path, $card, $showFlags, $signatures);
            } else {
                $this->renderDefaultTemplate($pdf, $image_path, $card, $showFlags, $signatures);
            }
        }

        return ['pdf' => $pdf, 'report_cards' => $report_cards];
    }

    // ==========================================
    // TEMPLATE 1 RENDERER (Swami Vivekanand)
    // ==========================================
    private function renderTemplate1($pdf, $bgImage, $card, $flags, $sigs) {
        $pdf->AddPage();
        $pdf->Image($bgImage, 0, 0, 210, 297);
        $this->drawCommonHeader($pdf, $card, 52, 72, true);

        // Split Subjects
        $normalSub = []; $gradeSub = [];
        foreach ($card['subjects'] as $s) {
            if (in_array(strtoupper($s['subject']), ['MUSIC', 'SANITATION'])) $gradeSub[] = $s;
            else $normalSub[] = $s;
        }

        $pdf->SetXY(15.3, 110);
        $w_max = 30; $w_pass = 30; $w_term = 20;
        
        $used = $w_max + $w_pass;
        if ($flags['term1']) $used += $w_term;
        if ($flags['term2']) $used += $w_term;
        if ($flags['annual']) $used += $w_term;
        
        $total_avail = 179.7;
        $w_subject = $total_avail - $used;

        // Header: Subject | Max | Pass | Term 1 | Term 2 | Annual
        $pdf->Cell($w_subject, 10, 'Subject', 1, 0, 'C');
        $pdf->Cell($w_max, 10, 'Max Marks', 1, 0, 'C');
        $pdf->Cell($w_pass, 10, 'Pass Marks', 1, 0, 'C');
        if ($flags['term1']) $pdf->Cell($w_term, 10, 'Term 1', 1, 0, 'C');
        if ($flags['term2']) $pdf->Cell($w_term, 10, 'Term 2', 1, 0, 'C');
        if ($flags['annual']) $pdf->Cell($w_term, 10, 'Annual', 1, 0, 'C');
        $pdf->Ln();

        $y_pos = 120;
        $sums = ['t1'=>0, 't2'=>0, 'ann'=>0, 'max'=>0, 'pass'=>0];

        foreach ($normalSub as $s) {
            $pdf->SetXY(15.3, $y_pos);
            $pdf->Cell($w_subject, 10, $s['subject'], 1, 0, 'L');
            $pdf->Cell($w_max, 10, $s['max_marks'], 1, 0, 'C');
            $pdf->Cell($w_pass, 10, $s['passing_marks'], 1, 0, 'C');
            
            if ($flags['term1']) {
                $pdf->Cell($w_term, 10, $s['term1_marks'] ?? '-', 1, 0, 'C');
                $sums['t1'] += (float)$s['term1_marks'];
            }
            if ($flags['term2']) {
                $pdf->Cell($w_term, 10, $s['term2_marks'] ?? '-', 1, 0, 'C');
                $sums['t2'] += (float)$s['term2_marks'];
            }
            if ($flags['annual']) {
                $pdf->Cell($w_term, 10, $s['annual_marks'] ?? '-', 1, 0, 'C');
                $sums['ann'] += (float)$s['annual_marks'];
            }
            
            $sums['max'] += $s['max_marks'];
            $sums['pass'] += $s['passing_marks'];
            $y_pos += 10;
        }

        // Total Row
        $pdf->SetXY(15.3, $y_pos);
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Cell($w_subject, 10, 'Total', 1, 0, 'C');
        $pdf->SetFont('Arial', 'B', 12);
        
        $pdf->Cell($w_max, 10, $sums['max'], 1, 0, 'C');
        $pdf->Cell($w_pass, 10, $sums['pass'], 1, 0, 'C');
        
        if ($flags['term1']) $pdf->Cell($w_term, 10, $sums['t1'], 1, 0, 'C');
        if ($flags['term2']) $pdf->Cell($w_term, 10, $sums['t2'], 1, 0, 'C');
        if ($flags['annual']) $pdf->Cell($w_term, 10, $sums['ann'], 1, 0, 'C');
        $y_pos += 10;

        // Grade Subjects
        foreach ($gradeSub as $s) {
            $pdf->SetXY(15.3, $y_pos);
            $pdf->Cell($w_subject, 10, $s['subject'], 1, 0, 'L');
            $pdf->Cell($w_max, 10, '', 1, 0, 'C'); 
            $pdf->Cell($w_pass, 10, '', 1, 0, 'C'); 
            
            if ($flags['term1']) $pdf->Cell($w_term, 10, $this->getGrade($s['term1_marks']), 1, 0, 'C');
            if ($flags['term2']) $pdf->Cell($w_term, 10, $this->getGrade($s['term2_marks']), 1, 0, 'C');
            if ($flags['annual']) $pdf->Cell($w_term, 10, $this->getGrade($s['annual_marks']), 1, 0, 'C');
            $y_pos += 10;
        }

        $this->drawSummaryAndSignatures($pdf, $card, $y_pos, $sigs, $normalSub);
    }

    // ==========================================
    // TEMPLATE 3 RENDERER (New Tech)
    // ==========================================
    private function renderTemplate3($pdf, $bgImage, $card, $flags, $sigs) {
        $pdf->AddPage();
        $pdf->Image($bgImage, 0, 0, 210, 297);
        $this->drawCommonHeader($pdf, $card, 52, 72, true);

        $pdf->SetXY(15.3, 110);
        $w_max = 25; $w_pass = 25; $w_term = 20; $w_grade = 15;
        
        $used = $w_max + $w_pass + $w_grade;
        if ($flags['term1']) $used += $w_term;
        if ($flags['term2']) $used += $w_term;
        if ($flags['annual']) $used += $w_term;
        
        $total_avail = 179.7;
        $w_subject = $total_avail - $used;

        // Header: Subject | Max | Pass | Terms... | Grade
        $pdf->Cell($w_subject, 10, 'Subject', 1, 0, 'C');
        $pdf->Cell($w_max, 10, 'Max Marks', 1, 0, 'C');
        $pdf->Cell($w_pass, 10, 'Pass Marks', 1, 0, 'C');
        if ($flags['term1']) $pdf->Cell($w_term, 10, 'Term 1', 1, 0, 'C');
        if ($flags['term2']) $pdf->Cell($w_term, 10, 'Term 2', 1, 0, 'C');
        if ($flags['annual']) $pdf->Cell($w_term, 10, 'Annual', 1, 0, 'C');
        $pdf->Cell($w_grade, 10, 'Grade', 1, 0, 'C');
        $pdf->Ln();

        $y_pos = 120;
        $sums = ['t1'=>0, 't2'=>0, 'ann'=>0, 'max'=>0, 'pass'=>0];

        foreach ($card['subjects'] as $s) {
            $pdf->SetXY(15.3, $y_pos);
            $pdf->Cell($w_subject, 10, strtoupper($s['subject']), 1, 0, 'L');
            $pdf->Cell($w_max, 10, $s['max_marks'], 1, 0, 'C');
            $pdf->Cell($w_pass, 10, $s['passing_marks'], 1, 0, 'C');
            
            if ($flags['term1']) {
                $pdf->Cell($w_term, 10, $s['term1_marks'] ?? '-', 1, 0, 'C');
                $sums['t1'] += (float)$s['term1_marks'];
            }
            if ($flags['term2']) {
                $pdf->Cell($w_term, 10, $s['term2_marks'] ?? '-', 1, 0, 'C');
                $sums['t2'] += (float)$s['term2_marks'];
            }
            if ($flags['annual']) {
                $pdf->Cell($w_term, 10, $s['annual_marks'] ?? '-', 1, 0, 'C');
                $sums['ann'] += (float)$s['annual_marks'];
            }
            
            $pdf->Cell($w_grade, 10, $this->getGrade($s['marks_obtained']), 1, 0, 'C');

            $sums['max'] += $s['max_marks'];
            $sums['pass'] += $s['passing_marks'];
            $y_pos += 10;
        }

        // Total
        $pdf->SetXY(15.3, $y_pos);
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Cell($w_subject, 10, 'Total', 1, 0, 'C');
        $pdf->SetFont('Arial', 'B', 12);
        
        $pdf->Cell($w_max, 10, $sums['max'], 1, 0, 'C');
        $pdf->Cell($w_pass, 10, $sums['pass'], 1, 0, 'C');
        
        if ($flags['term1']) $pdf->Cell($w_term, 10, $sums['t1'], 1, 0, 'C');
        if ($flags['term2']) $pdf->Cell($w_term, 10, $sums['t2'], 1, 0, 'C');
        if ($flags['annual']) $pdf->Cell($w_term, 10, $sums['ann'], 1, 0, 'C');
        
        $pdf->Cell($w_grade, 10, '', 1, 0, 'C');
        $y_pos += 10;

        $this->drawSummaryAndSignatures($pdf, $card, $y_pos, $sigs, $card['subjects']);
    }

    // ==========================================
    // DEFAULT RENDERER (MGO School)
    // ==========================================
    private function renderDefaultTemplate($pdf, $bgImage, $card, $flags, $sigs) {
        $pdf->AddPage();
        $pdf->Image($bgImage, 0, 0, 210, 297);
        
        // MGO Coords
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->SetXY(14.2, 63); $pdf->Cell(0, 10, "Date: " . date('d-m-Y'), 0, 1);
        $pdf->SetXY(154.8, 63); $pdf->Cell(0, 10, "Session: " . $card['session'], 0, 1);
        $pdf->SetXY(52, 72); $pdf->Cell(0, 10, $card['full_name'], 0, 1);
        $pdf->SetXY(52, 81); $pdf->Cell(0, 10, $card['father_name'], 0, 1);
        $pdf->SetXY(52, 90.5); $pdf->Cell(0, 10, $card['mother_name'], 0, 1);
        $pdf->SetXY(52, 99.8); $pdf->Cell(0, 10, $card['class_name'], 0, 1);
        $pdf->SetXY(41, 109.6); $pdf->Cell(0, 10, $card['roll_no'], 0, 1);
        $pdf->SetXY(136, 109.6); $pdf->Cell(0, 10, $card['date_of_birth'], 0, 1);
        $this->drawStudentPhoto($pdf, $card['student_photo']); 

        $pdf->SetXY(15.3, 120); 
        $w_max = 30; $w_pass = 30; $w_term = 23;
        
        $used = $w_max + $w_pass;
        if ($flags['term1']) $used += $w_term;
        if ($flags['term2']) $used += $w_term;
        if ($flags['annual']) $used += $w_term;
        
        $total_avail = 179.7;
        $w_subject = $total_avail - $used;

        // Header: Subject | Max | Pass | Terms...
        $pdf->Cell($w_subject, 10, 'Subject', 1, 0, 'C');
        $pdf->Cell($w_max, 10, 'Max Marks', 1, 0, 'C');
        $pdf->Cell($w_pass, 10, 'Pass Marks', 1, 0, 'C');
        if ($flags['term1']) $pdf->Cell($w_term, 10, 'Term 1', 1, 0, 'C');
        if ($flags['term2']) $pdf->Cell($w_term, 10, 'Term 2', 1, 0, 'C');
        if ($flags['annual']) $pdf->Cell($w_term, 10, 'Annual', 1, 0, 'C');
        $pdf->Ln();

        $y_pos = 130;
        $sums = ['t1'=>0, 't2'=>0, 'ann'=>0, 'max'=>0, 'pass'=>0];

        foreach ($card['subjects'] as $s) {
            $pdf->SetXY(15.3, $y_pos);
            $pdf->Cell($w_subject, 10, $s['subject'], 1, 0, 'L');
            $pdf->Cell($w_max, 10, $s['max_marks'], 1, 0, 'C');
            $pdf->Cell($w_pass, 10, number_format($s['passing_marks'], 2), 1, 0, 'C');
            
            if ($flags['term1']) {
                $pdf->Cell($w_term, 10, $s['term1_marks'] ?? '-', 1, 0, 'C');
                $sums['t1'] += (float)$s['term1_marks'];
            }
            if ($flags['term2']) {
                $pdf->Cell($w_term, 10, $s['term2_marks'] ?? '-', 1, 0, 'C');
                $sums['t2'] += (float)$s['term2_marks'];
            }
            if ($flags['annual']) {
                $pdf->Cell($w_term, 10, $s['annual_marks'] ?? '-', 1, 0, 'C');
                $sums['ann'] += (float)$s['annual_marks'];
            }
            
            $sums['max'] += $s['max_marks'];
            $sums['pass'] += $s['passing_marks'];
            $y_pos += 10;
        }

        // Totals
        $pdf->SetXY(15.3, $y_pos);
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Cell($w_subject, 10, 'Total', 1, 0, 'C');
        $pdf->SetFont('Arial', 'B', 12);
        
        $pdf->Cell($w_max, 10, $sums['max'], 1, 0, 'C');
        $pdf->Cell($w_pass, 10, $sums['pass'], 1, 0, 'C');
        
        if ($flags['term1']) $pdf->Cell($w_term, 10, $sums['t1'], 1, 0, 'C');
        if ($flags['term2']) $pdf->Cell($w_term, 10, $sums['t2'], 1, 0, 'C');
        if ($flags['annual']) $pdf->Cell($w_term, 10, $sums['ann'], 1, 0, 'C');
        $y_pos += 10;

        $this->drawSummaryAndSignatures($pdf, $card, $y_pos, $sigs, $card['subjects']);
    }

    // --- SHARED DRAWING HELPERS ---

    private function drawCommonHeader($pdf, $card, $x, $yStart, $withBox = true) {
        $this->drawStudentPhoto($pdf, $card['student_photo']);

        $pdf->SetFont('Arial', 'B', 12);
        
        if ($withBox) {
            if (!empty($card['session']) && preg_match('/^(\d{4})-(\d{4})$/', $card['session'], $matches)) {
                $sessionFormatted = $matches[1] . '-' . substr($matches[2], 2);
            } else {
                $sessionFormatted = $card['session']; 
            }
            $titleText = strtoupper($card['term'] . " Examination " . $sessionFormatted);
            $pdf->SetTextColor(255, 0, 0);
            $textWidth = $pdf->GetStringWidth($titleText);
            $rectWidth = $textWidth + 6;
            $rectHeight = 10;
            $bx = ($pdf->GetPageWidth() - $rectWidth) / 2;
            $by = 46;
            $pdf->Rect($bx, $by, $rectWidth, $rectHeight);
            $pdf->SetXY($bx + 3, $by + 2);
            $pdf->Cell($textWidth, 6, $titleText, 0, 0, 'C');
            $pdf->SetTextColor(0, 0, 0);
        }

        $pdf->SetFont('Arial', 'B', 12);
        $pdf->SetXY($x, $yStart); $pdf->Cell(0, 10, $card['full_name'], 0, 1);
        $pdf->SetXY($x, $yStart + 9); $pdf->Cell(0, 10, $card['father_name'], 0, 1);
        $pdf->SetXY($x, $yStart + 18.5); $pdf->Cell(0, 10, $card['mother_name'], 0, 1);
        $pdf->SetXY($x, $yStart + 27.8); $pdf->Cell(0, 10, $card['class_name'] . ' / ' . $card['roll_no'], 0, 1);
    }

    private function drawStudentPhoto($pdf, $path) {
        $fullPath = $_SERVER['DOCUMENT_ROOT'] . '/' . ltrim($path, '/');
        if ($this->validateAndProcessImage($fullPath)) {
            try { $pdf->Image($fullPath, 161, 72, 33.5, 37); } 
            catch (Exception $e) { /* err */ }
        } else {
            $pdf->SetXY(161, 72); $pdf->SetFont('Arial', '', 8);
            $pdf->Cell(33.5, 37, 'Photo N/A', 1, 0, 'C');
        }
    }

    private function drawSummaryAndSignatures($pdf, $card, $y_pos, $sigs, $gradingSubjects) {
        $hasFailed = false;
        foreach ($gradingSubjects as $s) {
            if (isset($s['marks_obtained']) && isset($s['passing_marks']) && $s['marks_obtained'] < $s['passing_marks']) {
                $hasFailed = true; break;
            }
        }
        
        $result = ($hasFailed || $card['percentage'] < 35) ? 'Fail' : 'Pass';
        $color = ($result == 'Pass') ? [0, 128, 0] : [255, 0, 0];
        
        $row_h = 10; $col_w = 29.95;
        $pdf->SetXY(15.3, $y_pos);
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell($col_w, $row_h, 'Percentage', 1, 0, 'C');
        $pdf->Cell($col_w, $row_h, number_format($card['percentage'], 2) . "%", 1, 0, 'C');
        $pdf->Cell($col_w, $row_h, 'Rank', 1, 0, 'C');
        $pdf->Cell($col_w, $row_h, $card['rank'], 1, 0, 'C');
        $pdf->Cell($col_w, $row_h, 'Result', 1, 0, 'C');
        
        $pdf->SetTextColor($color[0], $color[1], $color[2]);
        $pdf->Cell($col_w, $row_h, $result, 1, 0, 'C');
        $pdf->SetTextColor(0,0,0);
        
        // Signatures
        $sigY = 265;
        if ($sigs['dept'] && $this->validateAndProcessImage($_SERVER['DOCUMENT_ROOT'].'/'.$sigs['dept'])) 
            $pdf->Image($_SERVER['DOCUMENT_ROOT'].'/'.$sigs['dept'], 45, $sigY, 15, 8);
        
        if ($sigs['teacher'] && $this->validateAndProcessImage($_SERVER['DOCUMENT_ROOT'].'/'.$sigs['teacher'])) 
            $pdf->Image($_SERVER['DOCUMENT_ROOT'].'/'.$sigs['teacher'], 90, $sigY, 15, 8); 
            
        if ($sigs['principal'] && $this->validateAndProcessImage($_SERVER['DOCUMENT_ROOT'].'/'.$sigs['principal'])) 
            $pdf->Image($_SERVER['DOCUMENT_ROOT'].'/'.$sigs['principal'], 130, $sigY, 15, 8);
    }
    
    // --- END CLASS ---
    public function downloadReportCard() { $this->generateReportCard(true); }
    public function generateReportCard($isDownload = false) {
        if (!isset($_SESSION['uid'])) { $this->sendError(403, 'Unauthorized'); }
        
        $data = [];
        if ($isDownload) {
             $data['class_id'] = $_SESSION['download_class_id'] ?? '';
             $data['session'] = $_SESSION['download_session'] ?? '';
             $data['term'] = $_SESSION['download_term'] ?? '';
             $data['students'] = $_SESSION['download_students'] ?? [];
             $data['dept_examination_signature'] = $_SESSION['download_dept_examination_signature'] ?? null;
             $data['class_teacher_signature'] = $_SESSION['download_class_teacher_signature'] ?? null;
             $data['principal_signature'] = $_SESSION['download_principal_signature'] ?? null;
        } else {
             $dept = isset($_FILES['dept_examination_signature']) ? $this->handleFileUpload($_FILES['dept_examination_signature']) : null;
             $teacher = isset($_FILES['class_teacher_signature']) ? $this->handleFileUpload($_FILES['class_teacher_signature']) : null;
             $princ = isset($_FILES['principal_signature']) ? $this->handleFileUpload($_FILES['principal_signature']) : null;
             
             $data = $_POST;
             $data['dept_examination_signature'] = $dept;
             $data['class_teacher_signature'] = $teacher;
             $data['principal_signature'] = $princ;
        }
        
        try {
            $valid = $this->validateInput($data);
            
            if (!$isDownload) {
                $_SESSION['download_class_id'] = $valid['class_id'];
                $_SESSION['download_session'] = $valid['session'];
                $_SESSION['download_term'] = $valid['term'];
                $_SESSION['download_students'] = $valid['students'];
                $_SESSION['download_dept_examination_signature'] = $valid['dept_examination_signature'];
                $_SESSION['download_class_teacher_signature'] = $valid['class_teacher_signature'];
                $_SESSION['download_principal_signature'] = $valid['principal_signature'];
            }
            
            $result = $this->generatePDF($valid);
            
            if ($isDownload) {
                echo $result['pdf']->Output('S');
            } else {
                $url = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '?download=pdf';
                
                // --- THIS IS THE FIX ---
                // We are now sending the 'report_cards' array back to the frontend
                $this->sendSuccess(200, [
                    'success' => true, 
                    'data' => [
                        'report_cards' => array_values($result['report_cards']), // <--- This was missing
                        'download_url' => $url, 
                        'message' => 'Report cards generated successfully.'
                    ]
                ]);
            }
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            if ($isDownload) { http_response_code(500); echo 'Error: '.$e->getMessage(); }
            else $this->sendError(500, $e->getMessage());
        }
    }

    public function handleRequest() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') $this->generateReportCard();
        else $this->sendError(405, 'Method not allowed');
    }
}

if (!file_exists(__DIR__ . '/logs')) mkdir(__DIR__ . '/logs', 0755, true);

$controller = new ReportCardController();
$controller->handleRequest();
?>