<?php
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">

<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon icon-->
    <link rel="shortcut icon" href="assets/images/logos/favicon.svg" type="image/svg+xml">

    <!-- Core Css -->
    <link rel="stylesheet" href="assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">

    <title>AI-ERP 2.0</title>
</head>

<body>
    <!-- Preloader -->
    <!--<div class="preloader">-->
    <!--    <img src="assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />-->
    <!--</div>-->
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php include 'util/sidebar.php'; ?>
        <!-- Sidebar End -->
        <div class="page-wrapper">
            <!-- Header Start -->
            <?php include 'util/topbar.php'; ?>
            <!-- Header End -->

            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card card-body py-3">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="d-sm-flex align-items-center justify-space-between">
                                    <h4 class="mb-4 mb-sm-0 card-title">User Profile</h4>
                                    <nav aria-label="breadcrumb" class="ms-auto">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item d-flex align-items-center">
                                                <a class="text-muted text-decoration-none d-flex" href="/app">
                                                    <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                                </a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">
                                                <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">User Profile</span>
                                            </li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card overflow-hidden">
                        <div class="card-body p-0">
                            <img src="assets/images/backgrounds/profilebg.jpg" alt="ai-erp-2.0-img" class="img-fluid">
                            <div class="row align-items-center">
                                <div class="col-lg-4 order-lg-1 order-2">
                                    <div class="d-flex align-items-center justify-content-around m-4">
                                        <!-- Placeholder for stats (if needed later) -->
                                    </div>
                                </div>
                                <div class="col-lg-4 mt-n3 order-lg-2 order-1">
                                    <div class="mt-n5">
                                        <div class="d-flex align-items-center justify-content-center mb-2">
                                            <div class="d-flex align-items-center justify-content-center round-110">
                                                <div class="border border-4 border-white d-flex align-items-center justify-content-center rounded-circle overflow-hidden round-100">
                                                    <img src="<?php echo htmlspecialchars($photo); ?>" alt="ai-erp-2.0-img" class="w-100 h-100 profile-img-preview">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-center">
                                            <h5 class="mb-0 profile-name-display"><?php echo htmlspecialchars($name); ?></h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 order-last">
                                    <ul class="list-unstyled d-flex align-items-center justify-content-center justify-content-lg-end my-3 mx-4 pe-4 gap-3">
                                        <!-- Social media links (if needed later) -->
                                    </ul>
                                </div>
                            </div>
                            <ul class="nav nav-pills user-profile-tab justify-content-end mt-2 bg-primary-subtle rounded-2 rounded-top-0" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active hstack gap-2 rounded-0 fs-12 py-6" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="true">
                                        <i class="ti ti-user-circle fs-5"></i>
                                        <span class="d-none d-md-block">Profile</span>
                                    </button>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="card shadow-none border">
                                        <div class="card-body">
                                            <h4 class="mb-3">Update Profile</h4>
                                            <form id="updateProfileForm" enctype="multipart/form-data">
                                                <input type="hidden" name="action" value="update_info">
                                                <div class="mb-3">
                                                    <label for="name" class="form-label">Name</label>
                                                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="email" class="form-label">Email</label>
                                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="photo" class="form-label">Profile Photo</label>
                                                    <input type="file" class="form-control" id="photo" name="photo" accept="image/*">
                                                </div>
                                                <button type="submit" class="btn btn-primary">Update Info</button>
                                            </form>
                                            <div id="updateMessage" class="mt-3"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="card shadow-none border">
                                        <div class="card-body">
                                            <h4 class="mb-3">Change Password</h4>
                                            <form id="updatePasswordForm">
                                                <input type="hidden" name="action" value="update_password">
                                                <div class="mb-3">
                                                    <label for="old_password" class="form-label">Current Password</label>
                                                    <input type="password" class="form-control" id="old_password" name="old_password" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="new_password" class="form-label">New Password</label>
                                                    <input type="password" class="form-control" id="new_password" name="new_password" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="confirm_password" class="form-label">Confirm New Password</label>
                                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                                </div>
                                                <button type="submit" class="btn btn-primary">Update Password</button>
                                            </form>
                                            <div id="passwordMessage" class="mt-3"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="dark-transparent sidebartoggler"></div>
    
    <!-- Import Js Files (Correct Order: jQuery FIRST) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/simplebar.min.js"></script>
    <script src="assets/js/app.init.js"></script>
    <script src="assets/js/theme.js"></script>
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/sidebarmenu.js"></script>
    
    <!-- Solar icons -->
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@1.0.8/dist/iconify-icon.min.js"></script>
    
    <script>
        $(document).ready(function() {
            // Force hide preloader as a fail-safe
            $(".preloader").fadeOut();

            // 1. Handle Profile Info Update
            $('#updateProfileForm').on('submit', function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                const btn = $(this).find('button[type="submit"]');
                const msgDiv = $('#updateMessage');

                btn.prop('disabled', true).html('<i class="spinner-border spinner-border-sm"></i> Updating...');
                msgDiv.html('');

                $.ajax({
                    url: 'api/update_profile.php',
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            msgDiv.html('<div class="alert alert-success">' + response.message + '</div>');
                            // Update UI
                            if(response.data.name) $('.profile-name-display').text(response.data.name);
                            if (response.data.photo) {
                                $('.profile-img-preview').attr('src', response.data.photo);
                            }
                        } else {
                            msgDiv.html('<div class="alert alert-danger">' + response.error + '</div>');
                        }
                    },
                    error: function(xhr) {
                        msgDiv.html('<div class="alert alert-danger">Error: ' + (xhr.responseJSON?.error || 'Unknown error occurred') + '</div>');
                    },
                    complete: function() {
                        btn.prop('disabled', false).text('Update Info');
                    }
                });
            });

            // 2. Handle Password Update
            $('#updatePasswordForm').on('submit', function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                const btn = $(this).find('button[type="submit"]');
                const msgDiv = $('#passwordMessage');

                // Basic Client Validation
                const newPass = $('#new_password').val();
                const confPass = $('#confirm_password').val();
                
                if(newPass !== confPass) {
                    msgDiv.html('<div class="alert alert-danger">New passwords do not match!</div>');
                    return;
                }

                btn.prop('disabled', true).html('<i class="spinner-border spinner-border-sm"></i> Updating...');
                msgDiv.html('');

                $.ajax({
                    url: 'api/update_profile.php',
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            msgDiv.html('<div class="alert alert-success">' + response.message + '</div>');
                            $('#updatePasswordForm')[0].reset();
                        } else {
                            msgDiv.html('<div class="alert alert-danger">' + (response.error || response.message) + '</div>');
                        }
                    },
                    error: function(xhr) {
                        msgDiv.html('<div class="alert alert-danger">Error: ' + (xhr.responseJSON?.error || 'Unknown error occurred') + '</div>');
                    },
                    complete: function() {
                        btn.prop('disabled', false).text('Update Password');
                    }
                });
            });
        });
    </script>
</body>
</html>