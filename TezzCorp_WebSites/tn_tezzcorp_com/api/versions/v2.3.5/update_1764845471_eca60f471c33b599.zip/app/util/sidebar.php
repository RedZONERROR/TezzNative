<aside class="side-mini-panel with-vertical">
    <!-- ---------------------------------- -->
    <!-- Start Vertical Layout Sidebar -->
    <!-- ---------------------------------- -->
    <div class="iconbar">
        <div>
            <div class="mini-nav">
                <div class="brand-logo d-flex align-items-center justify-content-center">
                    <a class="nav-link sidebartoggler" id="headerCollapse" href="javascript:void(0)">
                        <iconify-icon icon="solar:hamburger-menu-line-duotone" class="fs-7"></iconify-icon>
                    </a>
                </div>
                <ul class="mini-nav-ul" data-simplebar>
                    <?php
                    // Check if any items in each section are permitted
                    $dashboard_permitted = isset($_SESSION['id']) && (
                        hasPermission($pdo, $_SESSION['id'], 'index') ||
                        hasPermission($pdo, $_SESSION['id'], 'profile')
                        );
                    $students_permitted = isset($_SESSION['id']) && (
                        hasPermission($pdo, $_SESSION['id'], 'admission') ||
                        hasPermission($pdo, $_SESSION['id'], 'students') ||
                        hasPermission($pdo, $_SESSION['id'], 'attendance') ||
                        hasPermission($pdo, $_SESSION['id'], 'set-results') ||
                        hasPermission($pdo, $_SESSION['id'], 'admit-card') ||
                        hasPermission($pdo, $_SESSION['id'], 'report-card') ||
                        hasPermission($pdo, $_SESSION['id'], 'attendance-report')
                    );
                    $staff_permitted = isset($_SESSION['id']) && (
                        hasPermission($pdo, $_SESSION['id'], 'registration') ||
                        hasPermission($pdo, $_SESSION['id'], 'staff') ||
                        hasPermission($pdo, $_SESSION['id'], 'attendance') ||
                        hasPermission($pdo, $_SESSION['id'], 'attendance-report')
                    );
                    $settings_permitted = isset($_SESSION['id']) && (
                        hasPermission($pdo, $_SESSION['id'], 'role-management') ||
                        hasPermission($pdo, $_SESSION['id'], 'timetable') ||
                        hasPermission($pdo, $_SESSION['id'], 'class') ||
                        hasPermission($pdo, $_SESSION['id'], 'class-teacher') ||
                        hasPermission($pdo, $_SESSION['id'], 'subject') ||
                        hasPermission($pdo, $_SESSION['id'], 'subject-teacher') ||
                        hasPermission($pdo, $_SESSION['id'], 'transport') ||
                        hasPermission($pdo, $_SESSION['id'], 'student-form') ||
                        hasPermission($pdo, $_SESSION['id'], 'staff-form') ||
                        hasPermission($pdo, $_SESSION['id'], 'site-settings') ||
                        hasPermission($pdo, $_SESSION['id'], 'gallery')
                    );
                    $fees_permitted = isset($_SESSION['id']) && (
                        hasPermission($pdo, $_SESSION['id'], 'particulars') ||
                        hasPermission($pdo, $_SESSION['id'], 'structure') ||
                        hasPermission($pdo, $_SESSION['id'], 'special-discount') ||
                        hasPermission($pdo, $_SESSION['id'], 'pending-fees') ||
                        hasPermission($pdo, $_SESSION['id'], 'collection') ||
                        hasPermission($pdo, $_SESSION['id'], 'collect') ||
                        hasPermission($pdo, $_SESSION['id'], 'demand-slip')
                    );
                    $reports_permitted = isset($_SESSION['id']) && hasPermission($pdo, $_SESSION['id'], 'fee-report');
                    $support_permitted = isset($_SESSION['id']) && hasPermission($pdo, $_SESSION['id'], 'maintenance');
                    $updates_permitted = isset($_SESSION['id']) && hasPermission($pdo, $_SESSION['id'], 'updater');
                    ?>

                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Dashboards -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <?php if ($dashboard_permitted): ?>
                    <li class="mini-nav-item" id="mini-1">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Dashboards">
                            <iconify-icon icon="solar:layers-line-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>
                    <?php endif; ?>

                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Students -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <?php if ($students_permitted): ?>
                    <li class="mini-nav-item" id="mini-2">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Students">
                            <iconify-icon icon="solar:users-group-two-rounded-outline" class="fs-7"></iconify-icon>
                        </a>
                    </li>
                    <?php endif; ?>

                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Staff -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <?php if ($staff_permitted): ?>
                    <li class="mini-nav-item" id="mini-3">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Staff">
                            <iconify-icon icon="solar:users-group-two-rounded-line-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if ($settings_permitted || $fees_permitted || $reports_permitted || $support_permitted || $updates_permitted): ?>
                    <li>
                        <span class="sidebar-divider lg"></span>
                    </li>
                    <?php endif; ?>

                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Settings -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <?php if ($settings_permitted): ?>
                    <li class="mini-nav-item" id="mini-4">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Settings">
                            <iconify-icon icon="solar:tuning-square-2-line-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>
                    <?php endif; ?>

                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Fees -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <?php if ($fees_permitted): ?>
                    <li class="mini-nav-item" id="mini-5">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Fees">
                            <iconify-icon icon="solar:wallet-money-line-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>
                    <?php endif; ?>

                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Messages -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Commented out as in original -->
                    <!--<li class="mini-nav-item" id="mini-6">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Messages">
                            <iconify-icon icon="solar:chat-square-code-line-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>-->

                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Reports -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <?php if ($reports_permitted): ?>
                    <li class="mini-nav-item" id="mini-7">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Reports">
                            <iconify-icon icon="solar:cardholder-line-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if ($support_permitted || $updates_permitted): ?>
                    <li>
                        <span class="sidebar-divider lg"></span>
                    </li>
                    <?php endif; ?>

                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Support -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <?php if ($support_permitted): ?>
                    <li class="mini-nav-item" id="mini-8">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Support">
                            <iconify-icon icon="solar:plain-bold-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>
                    <?php endif; ?>

                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <!-- Updates -->
                    <!-- --------------------------------------------------------------------------------------------------------- -->
                    <?php if ($updates_permitted): ?>
                    <li class="mini-nav-item" id="mini-9">
                        <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip"
                            data-bs-placement="right" data-bs-title="Updates">
                            <iconify-icon icon="solar:server-square-update-bold-duotone" class="fs-7"></iconify-icon>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="sidebarmenu">
                <div class="brand-logo d-flex align-items-center nav-logo">
                    <a href="/app/" class="text-nowrap logo-img">
                        <img src="assets/images/logos/logo.svg" alt="Logo" />
                    </a>
                </div>
                <!-- ---------------------------------- -->
                <!-- Dashboard -->
                <!-- ---------------------------------- -->
                <?php if ($dashboard_permitted): ?>
                <nav class="sidebar-nav" id="menu-right-mini-1" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'index')): ?>
                        <li class="nav-small-cap">
                            <span class="hide-menu">Dashboards</span>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="/app/" id="get-url" aria-expanded="false">
                                <iconify-icon icon="solar:screencast-2-line-duotone"></iconify-icon>
                                <span class="hide-menu">Dashboard</span>
                            </a>
                        </li>
                        <li>
                            <span class="sidebar-divider"></span>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'profile')): ?>
                        <li class="nav-small-cap">
                            <span class="hide-menu">Apps</span>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="/app/profile" aria-expanded="false">
                                <iconify-icon icon="solar:shield-user-line-duotone"></iconify-icon>
                                <span class="hide-menu">Profile</span>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <?php endif; ?>

                <!-- ---------------------------------- -->
                <!-- Students -->
                <!-- ---------------------------------- -->
                <?php if ($students_permitted): ?>
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-2" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <li class="nav-small-cap">
                            <span class="hide-menu">Students</span>
                        </li>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'admission')): ?>
                        <li class="sidebar-item">
                            <a href="/app/students/admission" class="sidebar-link">
                                <iconify-icon icon="solar:user-plus-rounded-line-duotone"></iconify-icon>
                                <span class="hide-menu">Admission</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'students')): ?>
                        <li class="sidebar-item">
                            <a href="/app/students/students" class="sidebar-link">
                                <iconify-icon icon="solar:users-group-two-rounded-line-duotone"></iconify-icon>
                                <span class="hide-menu">Students</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'attendance')): ?>
                        <li class="sidebar-item">
                            <a href="/app/students/attendance" class="sidebar-link">
                                <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Attendance</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'set-results')): ?>
                        <li class="sidebar-item">
                            <a href="/app/students/set-results" class="sidebar-link">
                                <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Set Results</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <li class="sidebar-item" style="display: none;">
                            <a href="/app/students/view-student.php" class="sidebar-link">
                                <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                <span class="hide-menu">View Student Details</span>
                            </a>
                        </li>
                        <li class="sidebar-item" style="display: none;">
                            <a href="/app/students/edit-student.php" class="sidebar-link">
                                <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Edit Student Details</span>
                            </a>
                        </li>
                        <li>
                            <span class="sidebar-divider lg"></span>
                        </li>
                        <li class="nav-small-cap">
                            <span class="hide-menu">Generate</span>
                        </li>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'admit-card')): ?>
                        <li class="sidebar-item">
                            <a href="/app/students/admit-card" class="sidebar-link">
                                <iconify-icon icon="solar:user-id-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Admit Card</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'report-card')): ?>
                        <li class="sidebar-item">
                            <a href="/app/students/report-card" class="sidebar-link">
                                <iconify-icon icon="solar:user-id-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Report Card</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <li>
                            <span class="sidebar-divider lg"></span>
                        </li>
                        <li class="nav-small-cap">
                            <span class="hide-menu">Reports</span>
                        </li>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'attendance-report')): ?>
                        <li class="sidebar-item">
                            <a href="/app/students/attendance-report" class="sidebar-link">
                                <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                <span class="hide-menu">Attendance</span>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <?php endif; ?>

                <!-- ---------------------------------- -->
                <!-- Staff -->
                <!-- ---------------------------------- -->
                <?php if ($staff_permitted): ?>
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-3" data-simplebar>
                    <div>
                        <ul class="sidebar-menu" id="sidebarnav">
                            <li class="nav-small-cap">
                                <span class="hide-menu">Staff</span>
                            </li>
                            <?php if (hasPermission($pdo, $_SESSION['id'], 'registration')): ?>
                            <li class="sidebar-item">
                                <a href="/app/staff/registration" class="sidebar-link">
                                    <iconify-icon icon="solar:user-plus-rounded-line-duotone"></iconify-icon>
                                    <span class="hide-menu">Registration</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if (hasPermission($pdo, $_SESSION['id'], 'staff')): ?>
                            <li class="sidebar-item">
                                <a href="/app/staff/staff" class="sidebar-link">
                                    <iconify-icon icon="solar:users-group-two-rounded-line-duotone"></iconify-icon>
                                    <span class="hide-menu">Staff</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            <li class="sidebar-item" style="display: none;">
                                <a href="/app/staff/edit_staff.php" class="sidebar-link">
                                    <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                    <span class="hide-menu">Edit Staff Details</span>
                                </a>
                            </li>
                            <?php if (hasPermission($pdo, $_SESSION['id'], 'attendance')): ?>
                            <li class="sidebar-item">
                                <a href="/app/staff/attendance" class="sidebar-link">
                                    <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                    <span class="hide-menu">Attendance</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            <li>
                                <span class="sidebar-divider lg"></span>
                            </li>
                            <li class="nav-small-cap">
                                <span class="hide-menu">Reports</span>
                            </li>
                            <?php if (hasPermission($pdo, $_SESSION['id'], 'attendance-report')): ?>
                            <li class="sidebar-item">
                                <a href="/app/staff/attendance-report" class="sidebar-link">
                                    <iconify-icon icon="solar:document-add-bold-duotone"></iconify-icon>
                                    <span class="hide-menu">Attendance</span>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </nav>
                <?php endif; ?>

                <!-- ---------------------------------- -->
                <!-- Settings -->
                <!-- ---------------------------------- -->
                <?php if ($settings_permitted): ?>
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-4" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <li class="nav-small-cap">
                            <span class="hide-menu">School Settings</span>
                        </li>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'role-management')): ?>
                        <li class="sidebar-item">
                            <a href="/app/settings/role-management" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Role Management</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'timetable')): ?>
                        <li class="sidebar-item">
                            <a href="/app/settings/timetable" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Timetable</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'class')): ?>
                        <li class="sidebar-item">
                            <a href="/app/settings/class" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Class</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'class-teacher')): ?>
                        <li class="sidebar-item">
                            <a href="/app/settings/class-teacher" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Class Teacher</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'subject')): ?>
                        <li class="sidebar-item">
                            <a href="/app/settings/subject" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Subject</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'subject-teacher')): ?>
                        <li class="sidebar-item">
                            <a href="/app/settings/subject-teacher" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Subject Teacher</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'transport')): ?>
                        <li class="sidebar-item">
                            <a href="/app/settings/transport" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Transport</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'student-form')): ?>
                        <li class="sidebar-item">
                            <a href="/app/settings/student-form" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Student Form</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'staff-form')): ?>
                        <li class="sidebar-item">
                            <a href="/app/settings/staff-form" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Staff Form</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'site-settings')): ?>
                        <li class="sidebar-item">
                            <a href="/app/settings/site-settings" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Site Settings</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'gallery')): ?>
                        <li class="sidebar-item">
                            <a href="/app/settings/gallery" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Gallery</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'school-bell')): ?>
                        <li class="sidebar-item">
                            <a href="/app/settings/school-bell" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">School Bell</span>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <?php endif; ?>

                <!-- ---------------------------------- -->
                <!-- Fees -->
                <!-- ---------------------------------- -->
                <?php if ($fees_permitted): ?>
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-5" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <li class="nav-small-cap">
                            <span class="hide-menu">Fees</span>
                        </li>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'particulars')): ?>
                        <li class="sidebar-item">
                            <a href="/app/fees/particulars" class="sidebar-link">
                                <iconify-icon icon="solar:money-bag-line-duotone"></iconify-icon>
                                <span class="hide-menu">Particulars</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'structure')): ?>
                        <li class="sidebar-item">
                            <a href="/app/fees/structure" class="sidebar-link">
                                <iconify-icon icon="solar:money-bag-line-duotone"></iconify-icon>
                                <span class="hide-menu">Structure</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'special-discount')): ?>
                        <li class="sidebar-item">
                            <a href="/app/fees/special-discount" class="sidebar-link">
                                <iconify-icon icon="solar:money-bag-line-duotone"></iconify-icon>
                                <span class="hide-menu">Special Discount</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'pending-fees')): ?>
                        <li class="sidebar-item">
                            <a href="/app/fees/pending-fees" class="sidebar-link">
                                <iconify-icon icon="solar:money-bag-line-duotone"></iconify-icon>
                                <span class="hide-menu">Pending Fees</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'collection')): ?>
                        <li class="sidebar-item">
                            <a href="/app/fees/collection" class="sidebar-link">
                                <iconify-icon icon="solar:money-bag-line-duotone"></iconify-icon>
                                <span class="hide-menu">Fee Collection</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'demand-slip')): ?>
                        <li class="sidebar-item">
                            <a href="/app/fees/demand-slip" class="sidebar-link">
                                <iconify-icon icon="solar:money-bag-line-duotone"></iconify-icon>
                                <span class="hide-menu">Demand Slip</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <li class="sidebar-item" style="display: none;">
                            <a href="/app/fees/collect" class="sidebar-link">
                                <iconify-icon icon="solar:money-bag-line-duotone"></iconify-icon>
                                <span class="hide-menu">Collect Fee</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <?php endif; ?>

                <!-- ---------------------------------- -->
                <!-- Messages -->
                <!-- ---------------------------------- -->
                <!-- Commented out as in original -->
                <!--<nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-6" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <li class="nav-small-cap">
                            <span class="hide-menu">Messages</span>
                        </li>
                        <li class="sidebar-item">
                            <a href="/app/messages/whatsapp-api" class="sidebar-link">
                                <iconify-icon icon="solar:chat-line-line-duotone"></iconify-icon>
                                <span class="hide-menu">WhatsApp API</span>
                            </a>
                        </li>
                    </ul>
                </nav>-->

                <!-- ---------------------------------- -->
                <!-- Reports -->
                <!-- ---------------------------------- -->
                <?php if ($reports_permitted): ?>
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-7" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <li class="nav-small-cap">
                            <span class="hide-menu">Reports</span>
                        </li>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'fee-report')): ?>
                        <li class="sidebar-item">
                            <a href="/app/reports/fee-report" class="sidebar-link">
                                <iconify-icon icon="solar:document-text-line-duotone"></iconify-icon>
                                <span class="hide-menu">Fee Report</span>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <?php endif; ?>

                <!-- ---------------------------------- -->
                <!-- Support -->
                <!-- ---------------------------------- -->
                <?php if ($support_permitted): ?>
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-8" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <li class="nav-small-cap">
                            <span class="hide-menu">Support</span>
                        </li>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'maintenance')): ?>
                        <li class="sidebar-item">
                            <a href="/app/support/maintenance" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Maintenance</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'training-videos')): ?>
                        <li class="sidebar-item">
                            <a href="/app/support/training-videos" class="sidebar-link">
                                <iconify-icon icon="solar:video-frame-play-horizontal-line-duotone"></iconify-icon>
                                <span class="hide-menu">Training Videos</span>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <?php endif; ?>

                <!-- ---------------------------------- -->
                <!-- Updates -->
                <!-- ---------------------------------- -->
                <?php if ($updates_permitted): ?>
                <nav class="sidebar-nav scroll-sidebar" id="menu-right-mini-9" data-simplebar>
                    <ul class="sidebar-menu" id="sidebarnav">
                        <li class="nav-small-cap">
                            <span class="hide-menu">Updates</span>
                        </li>
                        <?php if (hasPermission($pdo, $_SESSION['id'], 'updater')): ?>
                        <li class="sidebar-item">
                            <a href="/app/updates/updater" class="sidebar-link">
                                <iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
                                <span class="hide-menu">Updates</span>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>
</aside>