<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Allow Pi to access
header('Access-Control-Allow-Methods: GET, POST, DELETE');

class BellController {
    private $pdo;
    private $uploadDir;
    private $baseUrl;

    public function __construct() {
        $this->connectDB();
        $this->uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/uploads/sound/';
        // Adjust this protocol/domain logic if needed for your specific server setup
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
        $this->baseUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . '/uploads/sound/';
        
        if (!file_exists($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
    }

    private function connectDB() {
        try {
            $this->pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $this->sendResponse(500, 'Database Error');
        }
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        
        // Handle DELETE via query param for simplicity or POST override
        if (isset($_POST['_method']) && $_POST['_method'] === 'DELETE') $method = 'DELETE';

        switch ($method) {
            case 'GET':
                $this->getBells();
                break;
            case 'POST':
                $this->addBell();
                break;
            case 'DELETE':
                $this->deleteBell();
                break;
        }
    }

    private function getBells() {
        $stmt = $this->pdo->query("SELECT * FROM bell_schedule ORDER BY ring_time ASC");
        $data = $stmt->fetchAll();
        
        // Append full URL for the Pi to download
        foreach ($data as &$row) {
            $row['file_url'] = $this->baseUrl . $row['audio_file'];
        }
        
        $this->sendResponse(200, 'Success', $data);
    }

    private function addBell() {
        if (empty($_POST['title']) || empty($_POST['ring_time']) || empty($_FILES['audio_file'])) {
            $this->sendResponse(400, 'Missing required fields');
        }

        $file = $_FILES['audio_file'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($ext, ['mp3', 'wav', 'ogg'])) {
            $this->sendResponse(400, 'Only MP3, WAV, or OGG files are allowed');
        }

        $filename = uniqid('bell_') . '.' . $ext;
        
        if (move_uploaded_file($file['tmp_name'], $this->uploadDir . $filename)) {
            $stmt = $this->pdo->prepare("INSERT INTO bell_schedule (title, ring_time, audio_file) VALUES (?, ?, ?)");
            $stmt->execute([$_POST['title'], $_POST['ring_time'], $filename]);
            $this->sendResponse(201, 'Bell scheduled successfully');
        } else {
            $this->sendResponse(500, 'Failed to upload file');
        }
    }

    private function deleteBell() {
        $id = $_POST['id'] ?? $_GET['id'] ?? 0;
        
        if (!$id) $this->sendResponse(400, 'ID Required');

        // Get filename to delete
        $stmt = $this->pdo->prepare("SELECT audio_file FROM bell_schedule WHERE id = ?");
        $stmt->execute([$id]);
        $bell = $stmt->fetch();

        if ($bell) {
            $filePath = $this->uploadDir . $bell['audio_file'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
            
            $del = $this->pdo->prepare("DELETE FROM bell_schedule WHERE id = ?");
            $del->execute([$id]);
            $this->sendResponse(200, 'Deleted successfully');
        } else {
            $this->sendResponse(404, 'Bell not found');
        }
    }

    private function sendResponse($code, $msg, $data = null) {
        http_response_code($code);
        echo json_encode(['status' => $code === 200 || $code === 201 ? 'success' : 'error', 'message' => $msg, 'data' => $data]);
        exit;
    }
}

$api = new BellController();
$api->handleRequest();
?>