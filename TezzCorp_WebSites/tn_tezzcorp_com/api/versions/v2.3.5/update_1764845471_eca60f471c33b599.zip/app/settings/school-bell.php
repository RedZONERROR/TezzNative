<?php
session_start();
include($_SERVER['DOCUMENT_ROOT'] . '/app/util/access.php');

$role = $_SESSION['roles'];
$name = $_SESSION['name'];
$photo = $_SESSION['photo'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="../assets/images/logos/favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    
    <!-- JavaScript Dependencies -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/iconify-icon@2.1.0/dist/iconify-icon.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Automatic Bell System - AI-ERP 2.0</title>
    <style>
        .btn-loading .spinner-border { display: inline-block; }
        .spinner-border { display: none; width: 1rem; height: 1rem; }
        .loading-overlay {
            position: absolute; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(255, 255, 255, 0.8);
            display: flex; align-items: center; justify-content: center;
            z-index: 10; border-radius: 0.75rem;
        }
        audio { height: 30px; width: 200px; }
    </style>
</head>

<body>
    <div class="preloader">
        <img src="../assets/images/logos/favicon.svg" alt="loader" class="lds-ripple img-fluid" />
    </div>
    
    <div id="main-wrapper">
        <?php include 'util/sidebar.php'; ?>
        <div class="page-wrapper">
            <?php include 'util/topbar.php'; ?>

            <div class="body-wrapper">
                <div class="container-fluid">
                    
                    <!-- Header -->
                    <div class="card card-body py-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h4 class="mb-0 card-title">School Bell Automation</h4>
                                <span class="text-muted small">Manage ring times and sound files for Pi Zero</span>
                            </div>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addBellModal">
                                <i class="ti ti-plus me-2"></i> Add New Bell
                            </button>
                        </div>
                    </div>

                    <!-- List -->
                    <div class="card">
                        <div class="card-body position-relative">
                            <div id="tableLoader" class="loading-overlay" style="display:none;">
                                <div class="spinner-border text-primary" role="status"></div>
                            </div>
                            
                            <div class="table-responsive">
                                <table class="table table-hover align-middle" id="bellTable">
                                    <thead>
                                        <tr>
                                            <th>Time</th>
                                            <th>Description</th>
                                            <th>Audio Preview</th>
                                            <th>Status</th>
                                            <th class="text-end">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="addBellModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Schedule New Bell</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="bellForm" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Description (e.g., Lunch Break)</label>
                            <input type="text" class="form-control" name="title" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Ring Time (24h)</label>
                            <input type="time" class="form-control" name="ring_time" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Sound File (MP3/WAV)</label>
                            <input type="file" class="form-control" name="audio_file" accept="audio/*" required>
                            <small class="text-muted">File will be synced to Raspberry Pi automatically.</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="btn-save">Save Schedule</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    
    <script src="../assets/js/app.init.js"></script>
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>

    <script>
        $(document).ready(function() {
            let bellTable = $('#bellTable').DataTable({
                order: [[0, 'asc']],
                dom: 'tp'
            });

            loadBells();

            function loadBells() {
                $('#tableLoader').show();
                $.ajax({
                    url: 'api/school_bell_api.php',
                    method: 'GET',
                    dataType: 'json',
                    success: function(res) {
                        bellTable.clear();
                        if(res.status === 'success') {
                            res.data.forEach(item => {
                                const timeFormatted = new Date('1970-01-01T' + item.ring_time).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                                
                                bellTable.row.add([
                                    `<span class="fw-bold fs-4">${timeFormatted}</span>`,
                                    item.title,
                                    `<audio controls src="/uploads/sound/${item.audio_file}"></audio>`,
                                    `<span class="badge bg-success-subtle text-success">Active</span>`,
                                    `<button class="btn btn-sm btn-outline-danger" onclick="deleteBell(${item.id})"><i class="ti ti-trash"></i></button>`
                                ]);
                            });
                        }
                        bellTable.draw();
                    },
                    complete: () => $('#tableLoader').hide()
                });
            }

            $('#bellForm').on('submit', function(e) {
                e.preventDefault();
                const formData = new FormData(this);
                const btn = $('#btn-save');
                
                btn.prop('disabled', true).text('Uploading...');

                $.ajax({
                    url: 'api/school_bell_api.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(res) {
                        if(res.status === 'success') {
                            $('#addBellModal').modal('hide');
                            $('#bellForm')[0].reset();
                            loadBells();
                            Swal.fire('Success', 'Bell scheduled successfully', 'success');
                        } else {
                            Swal.fire('Error', res.message, 'error');
                        }
                    },
                    error: () => Swal.fire('Error', 'Upload failed', 'error'),
                    complete: () => btn.prop('disabled', false).text('Save Schedule')
                });
            });

            window.deleteBell = function(id) {
                Swal.fire({
                    title: 'Are you sure?',
                    text: "This will remove the schedule and delete the file.",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.post('api/school_bell_api.php', { _method: 'DELETE', id: id }, function(res) {
                            loadBells();
                            Swal.fire('Deleted!', 'Schedule removed.', 'success');
                        });
                    }
                });
            };
        });
    </script>
</body>
</html>