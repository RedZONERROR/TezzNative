<?php
require_once '../../includes/config.php';
require_once 'headers.php';

$input = json_decode(file_get_contents('php://input'), true);
$sid = $input['student_id'] ?? 0;

try {
    $pdo = getDBConnection();
    
    // Check if settings exist
    $check = $pdo->prepare("SELECT id FROM user_settings WHERE sid = ?");
    $check->execute([$sid]);
    
    if ($check->rowCount() > 0) {
        $sql = "UPDATE user_settings SET ";
        $params = [];
        
        if (isset($input['notifications'])) { $sql .= "notifications = ?, "; $params[] = $input['notifications']; }
        if (isset($input['dark_mode'])) { $sql .= "dark_mode = ?, "; $params[] = $input['dark_mode']; }
        if (isset($input['language'])) { $sql .= "language = ?, "; $params[] = $input['language']; }
        
        $sql = rtrim($sql, ", ") . " WHERE sid = ?";
        $params[] = $sid;
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
    } else {
        // Insert default
        $stmt = $pdo->prepare("INSERT INTO user_settings (sid, notifications, dark_mode, language) VALUES (?, ?, ?, ?)");
        $stmt->execute([
            $sid, 
            $input['notifications'] ?? 1, 
            $input['dark_mode'] ?? 0, 
            $input['language'] ?? 'en'
        ]);
    }

    echo json_encode(['status' => true, 'message' => 'Settings updated']);

} catch (Exception $e) {
    echo json_encode(['status' => false, 'message' => $e->getMessage()]);
}
?>