<?php
require_once '../../includes/config.php';
require_once 'headers.php';

$input = json_decode(file_get_contents('php://input'), true);
$className = $input['class_name'] ?? '';

try {
    $pdo = getDBConnection();
    
    // Fetch timetable for class
    $stmt = $pdo->prepare("SELECT * FROM timetable WHERE class = ? ORDER BY FIELD(day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), start_time");
    $stmt->execute([$className]);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['status' => true, 'data' => $data]);
} catch (Exception $e) {
    echo json_encode(['status' => false, 'message' => $e->getMessage()]);
}
?>