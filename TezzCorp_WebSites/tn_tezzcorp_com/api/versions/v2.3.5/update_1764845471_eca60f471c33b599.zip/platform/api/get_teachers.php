<?php
require_once '../../includes/config.php';
require_once 'headers.php';

$input = json_decode(file_get_contents('php://input'), true);
$className = $input['class_name'] ?? '';

if (empty($className)) {
    echo json_encode(['status' => false, 'message' => 'Class Name required']);
    exit;
}

try {
    $pdo = getDBConnection();

    // 1. Get Class ID from Name
    $stmt = $pdo->prepare("SELECT id FROM class WHERE class_name = ? LIMIT 1");
    $stmt->execute([$className]);
    $classId = $stmt->fetchColumn();

    if (!$classId) {
        echo json_encode(['status' => false, 'message' => 'Class not found']);
        exit;
    }

    // 2. Fetch Subjects and assigned Teachers
    $query = "
        SELECT 
            sub.subject as subject_name,
            s.name as teacher_name,
            s.mobile,
            s.email,
            s.photo
        FROM subject_teacher st
        JOIN subject sub ON st.subject = sub.id
        JOIN staff s ON st.tid = s.id
        WHERE st.class = ?
    ";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([$classId]);
    $teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fix photo URLs
    foreach ($teachers as &$t) {
        if (!empty($t['photo']) && !filter_var($t['photo'], FILTER_VALIDATE_URL)) {
            $t['photo'] = SITE_URL . $t['photo'];
        }
    }

    echo json_encode(['status' => true, 'data' => $teachers]);

} catch (Exception $e) {
    echo json_encode(['status' => false, 'message' => $e->getMessage()]);
}
?>