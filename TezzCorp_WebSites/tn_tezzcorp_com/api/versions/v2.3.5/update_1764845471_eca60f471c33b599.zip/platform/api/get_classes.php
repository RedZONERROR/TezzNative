<?php
require_once '../../includes/config.php';
require_once 'headers.php';

try {
    $pdo = getDBConnection();

    // Select active classes from the 'class' table
    $stmt = $pdo->prepare("SELECT id, class_name FROM class WHERE status = 'active' ORDER BY id ASC");
    $stmt->execute();
    $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'status' => true,
        'data' => $classes
    ]);

} catch (Exception $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Failed to fetch classes',
        'error' => $e->getMessage()
    ]);
}
?>