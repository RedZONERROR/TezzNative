<?php
require_once '../../includes/config.php';
require_once 'headers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => false, 'message' => 'Invalid Request Method']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$email = $input['email'] ?? '';
$password = $input['password'] ?? '';

if (empty($email) || empty($password)) {
    echo json_encode(['status' => false, 'message' => 'Email and Password are required']);
    exit;
}

try {
    $pdo = getDBConnection();

    // Query 'staff' table
    $stmt = $pdo->prepare("SELECT id, name, email, password, role, photo, status FROM staff WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($teacher) {
        // Verify Password (assuming standard PHP password_hash was used)
        if (password_verify($password, $teacher['password'])) {
            
            if ($teacher['status'] !== 'active') {
                echo json_encode(['status' => false, 'message' => 'Account is inactive']);
                exit;
            }

            // Generate Token
            $token = bin2hex(random_bytes(32));
            $expiry = date('Y-m-d H:i:s', strtotime('+7 days'));
            
            // Insert into sessions
            $sessStmt = $pdo->prepare("INSERT INTO sessions (user_id, user_type, session_token, expires_at) VALUES (?, 'teacher', ?, ?)");
            $sessStmt->execute([$teacher['id'], $token, $expiry]);

            // Handle Photo URL
            $photoUrl = $teacher['photo'];
            if (!empty($photoUrl) && !filter_var($photoUrl, FILTER_VALIDATE_URL)) {
                $photoUrl = SITE_URL . 'uploads/staff/' . $photoUrl;
            }

            echo json_encode([
                'status' => true,
                'message' => 'Login Successful',
                'token' => $token,
                'user' => [
                    'id' => $teacher['id'],
                    'name' => $teacher['name'],
                    'role' => $teacher['role'], // 'Teacher', 'Principal', etc.
                    'email' => $teacher['email'],
                    'photo' => $photoUrl
                ]
            ]);
        } else {
            echo json_encode(['status' => false, 'message' => 'Invalid Password']);
        }
    } else {
        echo json_encode(['status' => false, 'message' => 'Email not found']);
    }

} catch (Exception $e) {
    echo json_encode(['status' => false, 'message' => 'System Error']);
}
?>