<?php
require_once '../../includes/config.php';
require_once 'headers.php';

$input = json_decode(file_get_contents('php://input'), true);
$email = $input['email'] ?? '';

if (empty($email)) {
    echo json_encode(['status' => false, 'message' => 'Email is required']);
    exit;
}

try {
    $pdo = getDBConnection();

    // Check if staff exists
    $stmt = $pdo->prepare("SELECT id, name FROM staff WHERE email = ? AND status = 'active'");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $token = bin2hex(random_bytes(16)); // 32 chars
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        $domain = $_SERVER['HTTP_HOST'];

        // Insert into 'password_reset_tokens'
        $insert = $pdo->prepare("INSERT INTO password_reset_tokens (user_id, token, expires_at, domain) VALUES (?, ?, ?, ?)");
        $insert->execute([$user['id'], $token, $expiry, $domain]);

        // TODO: Integrate PHPMailer here to send the email
        // For now, we return success so the app UI updates
        
        // Example Mail Logic (Concept):
        // sendMail($email, "Reset Password", "Your OTP is $token");

        echo json_encode([
            'status' => true,
            'message' => 'Password reset link/OTP sent to your email.'
        ]);
    } else {
        echo json_encode(['status' => false, 'message' => 'Email not found in our records']);
    }

} catch (Exception $e) {
    echo json_encode(['status' => false, 'message' => 'Error processing request']);
}
?>