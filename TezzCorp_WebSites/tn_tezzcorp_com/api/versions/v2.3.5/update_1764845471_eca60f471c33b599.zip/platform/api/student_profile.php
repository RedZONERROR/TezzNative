<?php
require_once '../../includes/config.php';
require_once 'headers.php';

$input = json_decode(file_get_contents('php://input'), true);
$student_id = $input['student_id'] ?? '';

if (empty($student_id)) {
    echo json_encode(['status' => false, 'message' => 'Student ID required']);
    exit;
}

try {
    $pdo = getDBConnection();
    
    $stmt = $pdo->prepare("
        SELECT s.id, s.full_name, s.father_name, s.mother_name, 
            s.mobile_number, s.date_of_birth, s.residential_address,
            s.roll_no, c.class_name, d.student_photo
        FROM students s
        LEFT JOIN class c ON s.class = c.id
        LEFT JOIN documents d ON s.uid = d.uid
        WHERE s.id = ?
    ");
    $stmt->execute([$student_id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($data) {
        // --- FIX: SMART PHOTO URL ---
        $p = $data['student_photo'];
        if (!empty($p)) {
            $baseUrl = str_replace('www.', '', SITE_URL); // Force non-www

            if (filter_var($p, FILTER_VALIDATE_URL)) {
                $data['student_photo'] = $p;
            } elseif (strpos($p, 'uploads/') !== false) {
                $data['student_photo'] = $baseUrl . $p;
            } else {
                $data['student_photo'] = $baseUrl . 'uploads/documents/' . $p;
            }
        }
        // ----------------------------
        
        echo json_encode(['status' => true, 'data' => $data]);
    } else {
        echo json_encode(['status' => false, 'message' => 'Student not found']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => false, 'message' => $e->getMessage()]);
}
?>