<?php
require_once '../../includes/config.php';
require_once 'headers.php';

$input = json_decode(file_get_contents('php://input'), true);
$className = $input['class_name'] ?? '';

try {
    $pdo = getDBConnection();
    
    // Simple query matching class name (assuming homework table stores class name or handle ID similarly to teachers)
    $stmt = $pdo->prepare("SELECT * FROM homework WHERE class = ? ORDER BY date DESC LIMIT 20");
    $stmt->execute([$className]);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['status' => true, 'data' => $data]);
} catch (Exception $e) {
    echo json_encode(['status' => false, 'message' => $e->getMessage()]);
}
?>