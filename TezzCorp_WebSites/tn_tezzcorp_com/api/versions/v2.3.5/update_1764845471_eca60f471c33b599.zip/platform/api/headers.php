<?php
// --- FIX: Apply CORS headers to ALL requests, not just OPTIONS ---
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// Set JSON content type
header('Content-Type: application/json; charset=utf-8');
?>