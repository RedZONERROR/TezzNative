<?php
require_once '../../includes/config.php';
require_once 'headers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => false, 'message' => 'Invalid Request Method']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$mobile = $input['mobile_number'] ?? '';
$className = $input['class_name'] ?? '';

if (empty($mobile) || empty($className)) {
    echo json_encode(['status' => false, 'message' => 'Mobile number and Class are required']);
    exit;
}

try {
    $pdo = getDBConnection();

    // Fetch Student + Class Name + Photo
    $stmt = $pdo->prepare("
        SELECT 
            s.id, 
            s.uid, 
            s.full_name, 
            s.roll_no, 
            s.email_address, 
            s.mobile_number, 
            c.class_name, 
            d.student_photo, 
            s.status
        FROM students s
        LEFT JOIN class c ON s.class = c.id
        LEFT JOIN documents d ON s.uid = d.uid
        WHERE s.mobile_number = ? 
        AND c.class_name = ? 
        LIMIT 1
    ");

    $stmt->execute([$mobile, $className]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($student) {
        if ($student['status'] !== 'active' && $student['status'] !== 'approved') {
            echo json_encode(['status' => false, 'message' => 'Account is not active.']);
            exit;
        }

        // Generate Token
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+1 month'));
        $sessStmt = $pdo->prepare("INSERT INTO sessions (user_id, user_type, session_token, expires_at) VALUES (?, 'student', ?, ?)");
        $sessStmt->execute([$student['id'], $token, $expiry]);

        // --- FIX: SMART PHOTO URL ---
        $p = $student['student_photo'];
        $photoUrl = null;
        
        if (!empty($p)) {
            // 1. Determine Base URL (Strip 'www' to prevent DNS errors)
            $baseUrl = SITE_URL;
            
            // 2. Build URL
            if (filter_var($p, FILTER_VALIDATE_URL)) {
                $photoUrl = $p;
            } elseif (strpos($p, 'uploads/') !== false) {
                // DB has "uploads/students/doc..." -> Append Base
                $photoUrl = $baseUrl . $p;
            } else {
                // DB has "doc.png" -> Append Folder + Base
                $photoUrl = $baseUrl . 'uploads/documents/' . $p;
            }
        }
        // ----------------------------

        echo json_encode([
            'status' => true,
            'message' => 'Login Successful',
            'token' => $token,
            'user' => [
                'id' => $student['id'],
                'uid' => $student['uid'],
                'name' => $student['full_name'],
                'role' => 'student',
                'class' => $student['class_name'],
                'roll_no' => $student['roll_no'],
                'photo' => $photoUrl
            ]
        ]);
    } else {
        echo json_encode(['status' => false, 'message' => 'Invalid Mobile Number or Class']);
    }

} catch (Exception $e) {
    echo json_encode(['status' => false, 'message' => 'Database Error', 'error' => $e->getMessage()]);
}
?>