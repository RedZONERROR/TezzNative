<?php
// platform/api/student_fees.php
require_once '../../includes/config.php';
require_once 'headers.php';

$input = json_decode(file_get_contents('php://input'), true);
$student_id = $input['student_id'] ?? '';
$session = '2025-2026'; // Hardcoded for now, or pass from App input

if (empty($student_id)) {
    echo json_encode(['status' => false, 'message' => 'Student ID required']);
    exit;
}

// Helper to get Month Name
function getMonthName($m) {
    if ($m == 0) return "Arrears / Pending Dues";
    return date("F", mktime(0, 0, 0, $m, 10));
}

// Session Order: Pending(0), Apr(4) ... Mar(3)
$SESSION_MONTH_ORDER = [0, 4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3];

try {
    $pdo = getDBConnection();

    // 1. Get Student UID & Details
    $stmt = $pdo->prepare("SELECT id, class, transport_id, uid FROM students WHERE id = ?");
    $stmt->execute([$student_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        echo json_encode(['status' => false, 'message' => 'Student not found']);
        exit;
    }
    
    $student_uid = $student['uid'];
    $class_id = $student['class'];
    $transport_id = $student['transport_id'];

    // 2. Calculate Pending Fees (Previous Session Arrears)
    $stmt = $pdo->prepare("SELECT SUM(pending_amount) as total_pending FROM pending_fees WHERE student_uid = ? AND status = 'pending'");
    $stmt->execute([$student_uid]);
    $pending_arrears = $stmt->fetch(PDO::FETCH_ASSOC)['total_pending'] ?? 0;

    // 3. Fetch Active Fee Structure
    $stmt = $pdo->prepare("SELECT particular_id, amount, frequency, applicable_months FROM fee_structure WHERE class_id = ? AND session = ? AND status = 'active'");
    $stmt->execute([$class_id, $session]);
    $fee_structures = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 4. Fetch Special Structure (Discounts)
    $stmt = $pdo->prepare("SELECT particular_id, fee_type, special_amount, discount_percentage FROM special_structure WHERE student_uid = ? AND status = 'active'");
    $stmt->execute([$student_uid]);
    $special_structures = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Map Discounts
    $discounts_map = [];
    foreach ($special_structures as $ss) {
        $discounts_map[$ss['particular_id']] = $ss;
    }

    // 5. Calculate Monthly Fee Map (Month ID => Amount)
    $monthly_dues_map = [];
    foreach ($SESSION_MONTH_ORDER as $m) {
        if ($m !== 0) $monthly_dues_map[$m] = 0;
    }

    foreach ($fee_structures as $fee) {
        $pid = $fee['particular_id'];
        $amount = $fee['amount'];

        // Apply Discount
        if (isset($discounts_map[$pid])) {
            $d = $discounts_map[$pid];
            if ($d['discount_percentage'] > 0) $amount -= ($amount * $d['discount_percentage'] / 100);
            if ($d['special_amount'] > 0) $amount -= $d['special_amount']; // Assuming subtraction logic
        }
        $amount = max(0, $amount);

        // Distribute to Months
        if ($fee['frequency'] === 'monthly') {
            $months = ($fee['applicable_months'] === 'all') ? [4,5,6,7,8,9,10,11,12,1,2,3] : explode(',', $fee['applicable_months']);
            foreach ($months as $mid) {
                $mid = intval($mid);
                if (isset($monthly_dues_map[$mid])) $monthly_dues_map[$mid] += $amount;
            }
        } elseif ($fee['frequency'] === 'annual') {
            // Add annual fee to April (4)
            if (isset($monthly_dues_map[4])) $monthly_dues_map[4] += $amount;
        }
    }

    // 6. Calculate Total Paid
    $stmt = $pdo->prepare("SELECT SUM(amount_collected) as paid, SUM(discount) as disc FROM fee_collections WHERE student_id = ? AND session = ?");
    $stmt->execute([$student_id, $session]);
    $payment_data = $stmt->fetch(PDO::FETCH_ASSOC);
    $total_paid_cash = $payment_data['paid'] ?? 0;
    $total_discount_given = $payment_data['disc'] ?? 0;
    
    // Total Credit Available (Cash Paid + Discounts Given at checkout)
    $total_credit = $total_paid_cash + $total_discount_given;

    // 7. Calculate "Waterfalls" Logic
    // We pay off Pending Arrears first, then April, then May, etc.
    
    $breakdown_list = [];
    
    // Step A: Pay Pending Arrears
    $paid_for_arrears = min($pending_arrears, $total_credit);
    $due_arrears = $pending_arrears - $paid_for_arrears;
    $total_credit -= $paid_for_arrears; // Deduct used credit

    if ($pending_arrears > 0) {
        $breakdown_list[] = [
            'particular' => 'Pending Arrears (Old)',
            'due_months' => 'Previous Session',
            'pending_amount' => $due_arrears,
            'status' => ($due_arrears <= 0) ? 'Paid' : 'Unpaid'
        ];
    }

    // Step B: Pay Monthly Fees
    $total_session_fee = 0;
    foreach ($SESSION_MONTH_ORDER as $mid) {
        if ($mid == 0) continue;
        
        $month_cost = $monthly_dues_map[$mid] ?? 0;
        if ($month_cost > 0) {
            $total_session_fee += $month_cost;
            
            $paid_for_this_month = min($month_cost, $total_credit);
            $due_for_this_month = $month_cost - $paid_for_this_month;
            $total_credit -= $paid_for_this_month;

            $breakdown_list[] = [
                'particular' => 'School Fee - ' . getMonthName($mid),
                'due_months' => getMonthName($mid),
                'pending_amount' => $due_for_this_month,
                'status' => ($due_for_this_month <= 0) ? 'Paid' : 'Unpaid'
            ];
        }
    }

    $grand_total_fee = $pending_arrears + $total_session_fee;
    $total_collected_real = $payment_data['paid'] ?? 0; // Only real money collected
    $total_remaining = ($grand_total_fee - ($total_paid_cash + $total_discount_given));

    echo json_encode([
        'status' => true,
        'data' => [
            'total_fee' => $grand_total_fee,
            'total_collected' => $total_collected_real,
            'remaining_fee' => max(0, $total_remaining),
            'breakdown' => $breakdown_list
        ]
    ]);

} catch (Exception $e) {
    echo json_encode(['status' => false, 'message' => $e->getMessage()]);
}
?>