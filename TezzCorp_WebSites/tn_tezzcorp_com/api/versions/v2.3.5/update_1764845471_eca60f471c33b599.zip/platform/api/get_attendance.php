<?php
require_once '../../includes/config.php';
require_once 'headers.php';

$input = json_decode(file_get_contents('php://input'), true);
$student_id = $input['student_id'] ?? 0;
$month = $input['month'] ?? date('m');
$year = $input['year'] ?? date('Y');

try {
    $pdo = getDBConnection();
    // Fetch attendance for specific month
    $stmt = $pdo->prepare("
        SELECT date, status 
        FROM student_attendance 
        WHERE student_id = ? AND MONTH(date) = ? AND YEAR(date) = ?
    ");
    $stmt->execute([$student_id, $month, $year]);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['status' => true, 'data' => $data]);
} catch (Exception $e) {
    echo json_encode(['status' => false, 'message' => $e->getMessage()]);
}
?>