<?php
echo NOW();
?>
