<?php
require_once '../../includes/config.php';
require_once 'headers.php';

// Get Token from Header
$headers = getallheaders();
$authHeader = $headers['Authorization'] ?? '';
$token = str_replace('Bearer ', '', $authHeader);

if (empty($token)) {
    echo json_encode(['status' => false, 'message' => 'No token provided']);
    exit;
}

try {
    $pdo = getDBConnection();

    // 1. Check Session Validity
    $stmt = $pdo->prepare("SELECT user_id, user_type FROM sessions WHERE session_token = ? AND expires_at > NOW()");
    $stmt->execute([$token]);
    $session = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$session) {
        echo json_encode(['status' => false, 'message' => 'Session expired']);
        exit;
    }

    // 2. Fetch User Details (Student)
    if ($session['user_type'] === 'student') {
        $stmt = $pdo->prepare("
            SELECT s.id, s.uid, s.full_name as name, s.mobile_number, s.email_address, 
                   s.photo, c.class_name as class, s.roll_no
            FROM students s
            LEFT JOIN class c ON s.class = c.id
            WHERE s.id = ?
        ");
        $stmt->execute([$session['user_id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // 3. Fetch User Settings
        $setStmt = $pdo->prepare("SELECT notifications, dark_mode, language FROM user_settings WHERE sid = ?");
        $setStmt->execute([$session['user_id']]);
        $settings = $setStmt->fetch(PDO::FETCH_ASSOC) ?? ['notifications'=>1, 'dark_mode'=>0, 'language'=>'en'];

        echo json_encode([
            'status' => true,
            'user' => [
                'id' => $user['id'],
                'uid' => $user['uid'],
                'name' => $user['name'],
                'role' => 'student',
                'class' => $user['class'],
                'roll_no' => $user['roll_no'],
                'mobile_number' => $user['mobile_number']
            ],
            'settings' => $settings
        ]);
    } else {
        // Implement Teacher logic similarly if needed
        echo json_encode(['status' => false, 'message' => 'Teacher session not fully implemented in this check']);
    }

} catch (Exception $e) {
    echo json_encode(['status' => false, 'message' => $e->getMessage()]);
}
?>