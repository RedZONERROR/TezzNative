import os
import subprocess
import glob

def main():
    print("[*] Building TezzOS QEMU-Bootable Multiboot2 Image...")
    os.makedirs("build", exist_ok=True)

    # 1. Compile TezzNative Kernel Source to Freestanding Assembly
    kernel_tn = "examples/tezzos_kernel.tn"
    kernel_s = "build/tezzos_kernel.s"
    print(f"[*] Compiling {kernel_tn} -> {kernel_s} (--freestanding)...")
    subprocess.run([".\\tezzc.exe", "buildir", kernel_tn, kernel_s, "--freestanding"], check=True)

    # 2. Assemble Kernel Assembly to ELF Object
    kernel_o = "build/tezzos_kernel.o"
    print(f"[*] Assembling {kernel_s} -> {kernel_o}...")
    subprocess.run(["clang", "-c", "-target", "x86_64-unknown-none-elf", "-ffreestanding", "-fno-stack-protector", "-mno-red-zone", kernel_s, "-o", kernel_o], check=True)

    # 3. Compile Baremetal Boot Support Objects
    boot_dir = "TezzNative-language/runtime/boot/x86_64"
    c_files = glob.glob(f"{boot_dir}/*.c")
    s_files = glob.glob(f"{boot_dir}/*.S")
    obj_files = [kernel_o]

    for c in c_files:
        if "irq.c" in c:
            continue # tezzos_hal.c provides the safe standalone HAL
        obj = os.path.join("build", os.path.basename(c) + ".o")
        print(f"[*] Compiling {c} -> {obj}...")
        subprocess.run([
            "clang", "-c", "-target", "x86_64-unknown-none-elf",
            "-ffreestanding", "-fno-stack-protector", "-mno-red-zone", "-fno-builtin",
            "-DTN_WINABI",
            "-I", "TezzNative-language/runtime/boot/limine",
            "-I", boot_dir,
            c, "-o", obj
        ], check=True)
        obj_files.append(obj)

    for s in s_files:
        obj = os.path.join("build", os.path.basename(s) + ".o")
        print(f"[*] Assembling {s} -> {obj}...")
        subprocess.run([
            "clang", "-c", "-target", "x86_64-unknown-none-elf",
            "-ffreestanding", "-fno-stack-protector", "-mno-red-zone",
            s, "-o", obj
        ], check=True)
        obj_files.append(obj)

    # 4. Link with boot_grub.ld (PVH / Multiboot direct 1MB load for QEMU)
    linker_script = f"{boot_dir}/boot_grub.ld"
    kernel_elf = "build/tezzos_qemu.elf"
    print(f"[*] Linking TezzOS QEMU Kernel: {kernel_elf}...")

    ld_lld = "ld.lld"
    clang_dir = os.path.dirname(subprocess.check_output(["where", "clang"]).decode().splitlines()[0].strip())
    cand_lld = os.path.join(clang_dir, "ld.lld.exe")
    if os.path.exists(cand_lld):
        ld_lld = cand_lld

    link_cmd = [
        ld_lld,
        "-m", "elf_x86_64",
        "-T", linker_script,
        "-nostdlib", "-static",
        "-z", "max-page-size=0x1000",
        "-o", kernel_elf
    ] + obj_files

    subprocess.run(link_cmd, check=True)
    size_kb = os.path.getsize(kernel_elf) / 1024.0
    print(f"[SUCCESS] TezzOS QEMU ELF binary generated: {kernel_elf} ({size_kb:.1f} KB)")

if __name__ == "__main__":
    main()
