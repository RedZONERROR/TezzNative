with open(r'TezzNative-language/src/sema.c', 'r', encoding='utf-8') as f:
    text = f.read()

helper_code = """
static const char* type_mangle_suffix(TypeEnv* tenv, Type* t){
  if(!t) return "void";
  if(t == tenv->b.ty_i64 || t->k == TY_I64) return "i64";
  if(t == tenv->b.ty_f64 || t->k == TY_F64) return "f64";
  if(t == tenv->b.ty_u8 || t->k == TY_U8) return "u8";
  if(is_str_type(tenv, t)) return "str";
  if(t->k == TY_PTR) return "ptr";
  return "val";
}

static Type* substitute_type(TypeEnv* tenv, Type* t, const char* pname, int plen, Type* concrete_t){
  if(!t) return NULL;
  if(t->sname && t->sname_len == plen && strncmp(t->sname, pname, (size_t)plen)==0){
    return concrete_t;
  }
  if(t->k == TY_PTR) return type_ptr(tenv, substitute_type(tenv, t->elem, pname, plen, concrete_t));
  if(t->k == TY_ARRAY) return type_array(tenv, substitute_type(tenv, t->elem, pname, plen, concrete_t), t->len);
  return t;
}

static Stmt* clone_stmt_subst(TypeEnv* tenv, Stmt* s, const char* pname, int plen, Type* concrete_t);

static Expr* clone_expr_subst(TypeEnv* tenv, Expr* e, const char* pname, int plen, Type* concrete_t){
  if(!e) return NULL;
  Expr* ne = (Expr*)malloc(sizeof(Expr));
  if(!ne) die("out of memory");
  memcpy(ne, e, sizeof(Expr));
  ne->ty = substitute_type(tenv, e->ty, pname, plen, concrete_t);
  switch(e->k){
    case EX_BIN:
      ne->bin.a = clone_expr_subst(tenv, e->bin.a, pname, plen, concrete_t);
      ne->bin.b = clone_expr_subst(tenv, e->bin.b, pname, plen, concrete_t);
      break;
    case EX_UN:
      ne->un.e = clone_expr_subst(tenv, e->un.e, pname, plen, concrete_t);
      break;
    case EX_CALL:
      ne->call.callee = clone_expr_subst(tenv, e->call.callee, pname, plen, concrete_t);
      if(e->call.argc > 0){
        ne->call.args = (Expr**)malloc(sizeof(Expr*)*(size_t)e->call.argc);
        for(int i=0; i<e->call.argc; i++){
          ne->call.args[i] = clone_expr_subst(tenv, e->call.args[i], pname, plen, concrete_t);
        }
      }
      break;
    case EX_INDEX:
      ne->index.base = clone_expr_subst(tenv, e->index.base, pname, plen, concrete_t);
      ne->index.idx = clone_expr_subst(tenv, e->index.idx, pname, plen, concrete_t);
      break;
    case EX_DOT:
      ne->dot.base = clone_expr_subst(tenv, e->dot.base, pname, plen, concrete_t);
      break;
    case EX_CAST:
      ne->cast.e = clone_expr_subst(tenv, e->cast.e, pname, plen, concrete_t);
      ne->cast.to = substitute_type(tenv, e->cast.to, pname, plen, concrete_t);
      break;
    default:
      break;
  }
  return ne;
}

static Stmt* clone_stmt_subst(TypeEnv* tenv, Stmt* s, const char* pname, int plen, Type* concrete_t){
  if(!s) return NULL;
  Stmt* ns = (Stmt*)malloc(sizeof(Stmt));
  if(!ns) die("out of memory");
  memcpy(ns, s, sizeof(Stmt));
  switch(s->k){
    case ST_BLOCK:
      if(s->block.n > 0){
        ns->block.items = (Stmt**)malloc(sizeof(Stmt*)*(size_t)s->block.n);
        for(int i=0; i<s->block.n; i++){
          ns->block.items[i] = clone_stmt_subst(tenv, s->block.items[i], pname, plen, concrete_t);
        }
      }
      break;
    case ST_LET:
      ns->let.ty = substitute_type(tenv, s->let.ty, pname, plen, concrete_t);
      ns->let.init = clone_expr_subst(tenv, s->let.init, pname, plen, concrete_t);
      break;
    case ST_ASSIGN:
      ns->asg.lhs = clone_expr_subst(tenv, s->asg.lhs, pname, plen, concrete_t);
      ns->asg.rhs = clone_expr_subst(tenv, s->asg.rhs, pname, plen, concrete_t);
      break;
    case ST_EXPR:
      ns->expr.e = clone_expr_subst(tenv, s->expr.e, pname, plen, concrete_t);
      break;
    case ST_IF:
      ns->iff.cond = clone_expr_subst(tenv, s->iff.cond, pname, plen, concrete_t);
      ns->iff.thenb = clone_stmt_subst(tenv, s->iff.thenb, pname, plen, concrete_t);
      ns->iff.elseb = clone_stmt_subst(tenv, s->iff.elseb, pname, plen, concrete_t);
      break;
    case ST_WHILE:
      ns->wh.cond = clone_expr_subst(tenv, s->wh.cond, pname, plen, concrete_t);
      ns->wh.body = clone_stmt_subst(tenv, s->wh.body, pname, plen, concrete_t);
      break;
    case ST_RET:
      ns->ret.e = clone_expr_subst(tenv, s->ret.e, pname, plen, concrete_t);
      break;
    default:
      break;
  }
  return ns;
}
"""

monomorph_check = """    if(f->type_param_n > 0){
      Type* conc_type = tenv->b.ty_i64;
      if(call->call.argc > 0 && call->call.args[0] && call->call.args[0]->ty){
        conc_type = call->call.args[0]->ty;
      }
      const char* suf = type_mangle_suffix(tenv, conc_type);
      char mname[256];
      snprintf(mname, sizeof(mname), "%.*s__%s", f->len, f->name, suf);
      int mlen = (int)strlen(mname);
      FnDecl* spec = find_fn_in_module(curM, mname, mlen);
      if(!spec){
        spec = (FnDecl*)malloc(sizeof(FnDecl));
        if(!spec) die("out of memory");
        memcpy(spec, f, sizeof(FnDecl));
        char* heap_name = (char*)malloc(mlen + 1);
        memcpy(heap_name, mname, mlen + 1);
        spec->name = heap_name;
        spec->len = mlen;
        spec->type_param_n = 0;
        spec->type_params = NULL;

        if(f->arity > 0){
          spec->ptypes = (Type**)malloc(sizeof(Type*)*(size_t)f->arity);
          for(int p=0; p<f->arity; p++){
            spec->ptypes[p] = substitute_type(tenv, f->ptypes[p], f->type_params[0].name, f->type_params[0].len, conc_type);
          }
        }
        spec->ret = substitute_type(tenv, f->ret, f->type_params[0].name, f->type_params[0].len, conc_type);
        spec->body = clone_stmt_subst(tenv, f->body, f->type_params[0].name, f->type_params[0].len, conc_type);
        spec->fty = type_fn(tenv, spec->ret, spec->ptypes, spec->arity);

        curM->fns = (FnDecl**)realloc(curM->fns, sizeof(FnDecl*)*(size_t)(curM->fn_n + 1));
        curM->fns[curM->fn_n++] = spec;
        sema_fn(G, tenv, curM, spec);
      }
      cal->name.name = spec->name;
      cal->name.len  = spec->len;
      f = spec;
    }
"""

target_sema_call = "static void sema_call(ModuleGraph* G, TypeEnv* tenv, Module* curM, FnDecl* curF, TyEnv* venv, PtrEnv* penv, BorrowEnv* benv, Expr* call, int in_unsafe){"
target_local_fn = "if(!f) err_at(call->loc, \"unknown function (not builtin and not in this module)\");"

pos_call = text.find(target_sema_call)
if pos_call != -1:
    text = text[:pos_call] + helper_code + "\n" + text[pos_call:]

pos_fn = text.find(target_local_fn)
if pos_fn != -1:
    text = text[:pos_fn + len(target_local_fn)] + "\n" + monomorph_check + text[pos_fn + len(target_local_fn):]
    with open(r'TezzNative-language/src/sema.c', 'w', encoding='utf-8') as f:
        f.write(text)
    print("SUCCESS PATCHING SEMA GENERICS")
else:
    print("FAILED TO FIND TARGET IN SEMA")
