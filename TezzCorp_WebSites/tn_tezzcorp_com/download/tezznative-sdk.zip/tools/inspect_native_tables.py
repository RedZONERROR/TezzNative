import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from ssh_helper import run_remote

check_script = '''php -r '
$pdo = new PDO("mysql:host=localhost;dbname=u190073748_tezz_native_db;charset=utf8mb4", "u190073748_tezz_native_ur", "TezzNativeByRohit@9608");
$tables = ["tn_users", "tn_support_posts", "tn_install_events", "tn_release_versions"];
foreach ($tables as $t) {
    echo "=== SCHEMA FOR " . $t . " ===\\n";
    $stmt = $pdo->query("DESCRIBE " . $t);
    while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo $r["Field"] . " | " . $r["Type"] . " | " . $r["Null"] . " | " . $r["Key"] . " | " . $r["Default"] . "\\n";
    }
}
' '''

out, err = run_remote(check_script)
print("STDOUT:\n", out)
if err:
    print("STDERR:\n", err)
