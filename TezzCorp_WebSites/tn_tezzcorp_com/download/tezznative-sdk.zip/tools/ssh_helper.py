import paramiko
import time
import sys
import os

if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

HOST = '195.35.5.93'
PORT = 65002
USER = 'u190073748'
PASS = 'Rohit@8084'

def get_ssh(retries=5, delay=2):
    last_err = None
    for i in range(retries):
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(
                HOST,
                port=PORT,
                username=USER,
                password=PASS,
                look_for_keys=False,
                allow_agent=False,
                timeout=20
            )
            return ssh
        except Exception as e:
            last_err = e
            if i < retries - 1:
                time.sleep(delay)
    raise last_err



def get_sftp():
    ssh = get_ssh()
    return ssh, ssh.open_sftp()

def run_remote(cmd):
    ssh = get_ssh()
    try:
        stdin, stdout, stderr = ssh.exec_command(cmd)
        out = stdout.read().decode('utf-8', errors='replace')
        err = stderr.read().decode('utf-8', errors='replace')
        return out, err
    finally:
        ssh.close()

if __name__ == '__main__':
    if len(sys.argv) > 1:
        cmd = " ".join(sys.argv[1:])
        out, err = run_remote(cmd)
        if out:
            print("STDOUT:\n" + out)
        if err:
            print("STDERR:\n" + err)
    else:
        print("SSH helper ready.")

