import re

# 1. Patch ir_codegen_pe.h
with open(r'TezzNative-language/include/ir_codegen_pe.h', 'r', encoding='utf-8') as f:
    hdr = f.read()

hdr_additions = """  uint32_t iat_read_line;
  uint32_t iat_read_bytes;
  uint32_t iat_write_line;
  uint32_t iat_stdin;
  uint32_t iat_stdout;
  uint32_t iat_stderr;
  uint32_t iat_puts;
  uint32_t iat_printf;
  uint32_t iat_sqrt;
  uint32_t iat_sin;
  uint32_t iat_cos;
  uint32_t iat_pow;
  uint32_t iat_floor;
  uint32_t iat_ceil;
  uint32_t iat_fabs;
  // ws2_32.dll
  uint32_t iat_wsastartup;
  uint32_t iat_wsacleanup;
  uint32_t iat_socket;
  uint32_t iat_closesocket;
  uint32_t iat_bind;
  uint32_t iat_listen;
  uint32_t iat_accept;
  uint32_t iat_connect;
  uint32_t iat_send;
  uint32_t iat_recv;
  uint32_t iat_ioctlsocket;
  uint32_t iat_wsagetlasterror;
  uint32_t iat_htons;
  uint32_t iat_ntohs;
  uint32_t iat_inet_addr;
  // urlmon.dll
  uint32_t iat_urldownloadtofile;"""

hdr = hdr.replace("""  uint32_t iat_read_line;
  uint32_t iat_read_bytes;
  uint32_t iat_write_line;
  uint32_t iat_stdin;
  uint32_t iat_stdout;
  uint32_t iat_stderr;""", hdr_additions)

with open(r'TezzNative-language/include/ir_codegen_pe.h', 'w', encoding='utf-8') as f:
    f.write(hdr)

print("SUCCESS: Updated ir_codegen_pe.h")
