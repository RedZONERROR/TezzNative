import os
import subprocess

FTP_USER = "u190073748.tezzcorpcom"
FTP_PASS = "TezzMsngr@Api#2026$TezzCorp&9608"
FTP_HOST = "89.116.133.167"
REMOTE_BASE = f"ftp://{FTP_HOST}/tn.tezzcorp.com"
LOCAL_ROOT = r"C:\Acer\Code\TezzNative\TezzCorp_WebSites\tn_tezzcorp_com"

CORE_FOLDERS = ["assets", "includes", "docs", "download", "lib", "about", "community", "frameworks", "support", "versions"]

def upload_file(local_path, rel_path):
    rel_clean = rel_path.replace("\\", "/").lstrip("/")
    remote_url = f"{REMOTE_BASE}/{rel_clean}"
    cmd = [
        "curl.exe",
        "-s",
        "-u", f"{FTP_USER}:{FTP_PASS}",
        "--disable-epsv",
        "--ftp-create-dirs",
        "-T", local_path,
        remote_url
    ]
    res = subprocess.run(cmd)
    if res.returncode == 0:
        print(f"[OK] {rel_clean}", flush=True)
    else:
        print(f"[ERR] {rel_clean}", flush=True)

# 1. Root files
for f in os.listdir(LOCAL_ROOT):
    p = os.path.join(LOCAL_ROOT, f)
    if os.path.isfile(p):
        upload_file(p, f)

# 2. Core folders
for folder in CORE_FOLDERS:
    folder_path = os.path.join(LOCAL_ROOT, folder)
    if os.path.exists(folder_path):
        for root, _, files in os.walk(folder_path):
            for file in files:
                lp = os.path.join(root, file)
                rp = os.path.relpath(lp, LOCAL_ROOT)
                upload_file(lp, rp)

print("\n[COMPLETE] All core website & download assets uploaded to live server!", flush=True)
