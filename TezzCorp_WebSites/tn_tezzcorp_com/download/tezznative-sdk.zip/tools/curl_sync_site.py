import subprocess
import os

FTP_USER = "u190073748.tezzcorpcom"
FTP_PASS = "TezzMsngr@Api#2026$TezzCorp&9608"
BASE_URL = "ftp://89.116.133.167/tn.tezzcorp.com"
LOCAL_ROOT = r"C:\Acer\Code\TezzNative\TezzCorp_WebSites\tn_tezzcorp_com"

def get_dir_list(rel_path=""):
    url = f"{BASE_URL}/{rel_path}" if rel_path else f"{BASE_URL}/"
    if not url.endswith('/'):
        url += '/'
    cmd = ["curl.exe", "-s", "-u", f"{FTP_USER}:{FTP_PASS}", "--disable-epsv", url]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    items = []
    for line in res.stdout.splitlines():
        parts = line.split(maxsplit=8)
        if len(parts) >= 9:
            perms = parts[0]
            name = parts[8].strip()
            if name not in ('.', '..'):
                items.append((perms.startswith('d'), name))
    return items

def download_folder(rel_path=""):
    loc_dir = os.path.join(LOCAL_ROOT, rel_path)
    os.makedirs(loc_dir, exist_ok=True)
    
    entries = get_dir_list(rel_path)
    for is_dir, name in entries:
        child_rel = f"{rel_path}/{name}" if rel_path else name
        child_loc = os.path.join(LOCAL_ROOT, child_rel)
        if is_dir:
            print(f"[DIR]  {child_rel}")
            download_folder(child_rel)
        else:
            file_url = f"{BASE_URL}/{child_rel}"
            print(f"[FILE] {child_rel} -> {child_loc}")
            cmd = ["curl.exe", "-s", "-u", f"{FTP_USER}:{FTP_PASS}", "--disable-epsv", "-o", child_loc, file_url]
            subprocess.run(cmd)

print("Syncing all website files from Hostinger FTP...")
download_folder()
print("Sync complete!")
