#!/usr/bin/env python3
"""
deploy_mobile_updates.py — Fast deploy script for mobile responsive navbar,
sidebar drawer, and updated disaster recovery archive.
"""

import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from ssh_helper import get_sftp, run_remote

LOCAL_WEB_ROOT = Path(r"C:\Acer\Code\TezzNative\TezzCorp_WebSites\tn_tezzcorp_com")
REMOTE_TARGET_DIR = "/home/u190073748/domains/tezzcorp.com/public_html/tn.tezzcorp.com"

FILES_TO_UPLOAD = [
    "includes/nav.php",
    "includes/header.php",
    "includes/footer.php",
    "support.php",
    "index.php",
    "assets/app.css",
    "assets/app.js",
]

def main():
    print("=" * 60)
    print("Deploying Mobile Responsive Navbar, Sidebar & Updates")
    print("=" * 60)

    ssh, sftp = get_sftp()
    if ssh.get_transport():
        ssh.get_transport().set_keepalive(15)

    print("\n[1/2] Uploading core responsive portal files...")
    for rel in FILES_TO_UPLOAD:
        lfp = LOCAL_WEB_ROOT / rel
        rfp = f"{REMOTE_TARGET_DIR}/{rel.replace(os.sep, '/')}"
        print(f"  Uploading {rel} ({lfp.stat().st_size / 1024:.1f} KB)...", end="", flush=True)
        try:
            sftp.put(str(lfp), rfp)
            print(" [OK]", flush=True)
        except Exception as e:
            print(f" [ERR: {e}]", flush=True)

    print("\n[2/2] Uploading updated disaster recovery archive...")
    tar_fp = LOCAL_WEB_ROOT / "tezznative_source_backup.tar.gz"
    if tar_fp.exists():
        tar_size = tar_fp.stat().st_size / (1024 * 1024)
        print(f"  Uploading {tar_fp.name} ({tar_size:.2f} MB)...", flush=True)
        rfp_tar = f"{REMOTE_TARGET_DIR}/tezznative_source_backup.tar.gz"
        last_mb = [0]
        def cb(trans, total):
            mb = trans / (1024 * 1024)
            if mb - last_mb[0] >= 5 or trans == total:
                last_mb[0] = mb
                print(f"    Progress: {mb:.1f} / {total/(1024*1024):.1f} MB ({(trans/total)*100:.1f}%)", flush=True)
        sftp.put(str(tar_fp), rfp_tar, callback=cb)
        print("  Archive upload [OK]!", flush=True)

    sftp.close()
    ssh.close()
    print("\n" + "=" * 60)
    print("DEPLOYMENT TO PRODUCTION COMPLETE!")
    print("=" * 60)

if __name__ == "__main__":
    main()
