# tools/sign_binary.ps1 - Sign TezzNative binaries with Authenticode Certificate

$cert = Get-ChildItem -Path Cert:\CurrentUser\My -CodeSigningCert | Where-Object { $_.Subject -match "TezzCorp" } | Select-Object -First 1

if (-not $cert) {
    Write-Host "[*] Generating new Authenticode Code Signing Certificate for TezzCorp Pvt Ltd..." -ForegroundColor Yellow
    $cert = New-SelfSignedCertificate -Type CodeSigningCert `
        -Subject "CN=TezzCorp Pvt Ltd., O=TezzCorp Pvt Ltd., OU=TezzNative Development, C=IN" `
        -CertStoreLocation "Cert:\CurrentUser\My" `
        -NotAfter (Get-Date).AddYears(5)
    
    # Also trust in Root and TrustedPublisher for current user
    $rootStore = New-Object System.Security.Cryptography.X509Certificates.X509Store("TrustedPublisher", "CurrentUser")
    $rootStore.Open("ReadWrite")
    $rootStore.Add($cert)
    $rootStore.Close()

    $rootStore2 = New-Object System.Security.Cryptography.X509Certificates.X509Store("Root", "CurrentUser")
    $rootStore2.Open("ReadWrite")
    $rootStore2.Add($cert)
    $rootStore2.Close()
}

$targets = @(
    "TezzNativeInstaller.exe",
    "tools\installer\TezzNativeInstaller.exe",
    "TezzCorp_WebSites\tn_tezzcorp_com\download\TezzNativeInstaller.exe",
    "tezz.exe",
    "tezzc.exe",
    "bin\tezz.exe",
    "bin\tezzc.exe"
)

foreach ($target in $targets) {
    if (Test-Path $target) {
        Write-Host "[+] Signing $target..." -ForegroundColor Cyan
        Set-AuthenticodeSignature -FilePath $target -Certificate $cert -HashAlgorithm SHA256 | Out-Null
        $sig = Get-AuthenticodeSignature $target
        Write-Host "    Status: $($sig.Status) | Signer: $($sig.SignerCertificate.Subject)" -ForegroundColor Green
    }
}
