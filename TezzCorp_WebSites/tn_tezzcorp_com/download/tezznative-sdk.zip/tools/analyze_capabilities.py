import os
import subprocess

# List all .tn files in tests/ and lib/
files_to_check = []
for root, dirs, files in os.walk(r'c:\Acer\Code\TezzNative'):
    if '.git' in root or '.gemini' in root or 'dist' in root or 'TezzCorp_WebSites' in root:
        continue
    for f in files:
        if f.endswith('.tn'):
            files_to_check.append(os.path.join(root, f))

print(f"Total .tn files found: {len(files_to_check)}")

failures_check = []
failures_buildexe = []

for f in files_to_check:
    # 1. Check
    res = subprocess.run([r'c:\Acer\Code\TezzNative\tezzc.exe', 'check', f], capture_output=True, text=True)
    if res.returncode != 0:
        failures_check.append((f, res.stderr.strip() or res.stdout.strip()))
        continue
    
    # 2. Buildexe (if it contains fn main)
    with open(f, 'r', encoding='utf-8', errors='ignore') as srcf:
        src = srcf.read()
    if 'fn main(' in src or 'fn main ()' in src:
        out_bin = os.path.join(r'c:\Acer\Code\TezzNative', 'test_tmp.exe')
        res2 = subprocess.run([r'c:\Acer\Code\TezzNative\tezzc.exe', 'buildexe', f, out_bin], capture_output=True, text=True)
        if res2.returncode != 0:
            failures_buildexe.append((f, res2.stderr.strip() or res2.stdout.strip()))
        if os.path.exists(out_bin):
            os.remove(out_bin)

print(f"\n--- Check Failures: {len(failures_check)} ---")
for f, err in failures_check:
    print(f"FAIL CHECK: {f}\n  -> {err[:200]}")

print(f"\n--- Buildexe Failures: {len(failures_buildexe)} ---")
for f, err in failures_buildexe:
    print(f"FAIL BUILDEXE: {f}\n  -> {err[:300]}")
