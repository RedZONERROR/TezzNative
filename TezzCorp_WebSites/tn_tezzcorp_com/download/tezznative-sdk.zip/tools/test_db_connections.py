import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from ssh_helper import run_remote

test_code = '''php -r '
try {
    $p1 = new PDO("mysql:host=localhost;dbname=u190073748_tezz_native_db;charset=utf8mb4", "u190073748_tezz_native_ur", "TezzNativeByRohit@9608");
    echo "P1 (tezz_native_db): CONNECTED SUCCESS\\n";
} catch (Exception $e) {
    echo "P1 (tezz_native_db) FAILED: " . $e->getMessage() . "\\n";
}

try {
    $p2 = new PDO("mysql:host=localhost;dbname=u190073748_tezz_official_;charset=utf8mb4", "u190073748_tezz_usr__vr__", "TezzCorpOfficial#@2026");
    echo "P2 (tezz_official_): CONNECTED SUCCESS\\n";
} catch (Exception $e) {
    echo "P2 (tezz_official_) FAILED: " . $e->getMessage() . "\\n";
}
' '''

out, err = run_remote(test_code)
print("STDOUT:\n", out)
if err:
    print("STDERR:\n", err)
