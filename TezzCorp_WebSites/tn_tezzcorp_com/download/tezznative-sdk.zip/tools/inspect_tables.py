import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from ssh_helper import run_remote

check_script = """php -r '
$pdo = new PDO("mysql:host=localhost;dbname=u190073748_tezz_official_;charset=utf8mb4", "u190073748_tezz_usr__vr__", "TezzCorpOfficial#@2026");
$tables = ["tezz_community_users", "tezz_community_posts", "tezz_community_replies", "tezz_community_likes", "tezz_package_registry"];
foreach ($tables as $t) {
    echo "=== SCHEMA FOR " . $t . " ===\n";
    try {
        $stmt = $pdo->query("DESCRIBE " . $t);
        while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo $r["Field"] . " | " . $r["Type"] . " | " . $r["Null"] . " | " . $r["Key"] . "\n";
        }
    } catch (Exception $e) {
        echo "TABLE NOT FOUND OR ERROR: " . $e->getMessage() . "\n";
    }
}
'"""

out, err = run_remote(check_script)
print(out)
if err:
    print("ERR:", err)
