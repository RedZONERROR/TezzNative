import re

with open(r'TezzNative-language/src/tnrt.c', 'r', encoding='utf-8') as f:
    code = f.read()

tnrt_additions = """
// ------------------------------
// HTTP Download and Networking Aliases
// ------------------------------
#ifdef _WIN32
#include <windows.h>
typedef HRESULT (WINAPI *URLDownloadToFileAFn)(LPUNKNOWN, LPCSTR, LPCSTR, DWORD, LPVOID);

TN_EXPORT long long tn_http_download(unsigned char* url, unsigned char* out_path){
  if(!url || !out_path) return -1;
  HMODULE hUrlmon = LoadLibraryA("urlmon.dll");
  if(hUrlmon){
    URLDownloadToFileAFn pfn = (URLDownloadToFileAFn)GetProcAddress(hUrlmon, "URLDownloadToFileA");
    if(pfn){
      HRESULT hr = pfn(NULL, (const char*)url, (const char*)out_path, 0, NULL);
      FreeLibrary(hUrlmon);
      return (hr == S_OK) ? 0 : -1;
    }
    FreeLibrary(hUrlmon);
  }
  return -1;
}
#else
TN_EXPORT long long tn_http_download(unsigned char* url, unsigned char* out_path){
  if(!url || !out_path) return -1;
  char cmd[2048];
  snprintf(cmd, sizeof(cmd), "curl -s -L -o \\"%s\\" \\"%s\\"", (const char*)out_path, (const char*)url);
  int rc = system(cmd);
  return (rc == 0) ? 0 : -1;
}
#endif

TN_EXPORT long long http_download(unsigned char* url, unsigned char* out_path){
  return tn_http_download(url, out_path);
}

TN_EXPORT long long net_af_inet(void){ return tn_net_af_inet(); }
TN_EXPORT long long net_af_inet6(void){ return tn_net_af_inet6(); }
TN_EXPORT long long net_sock_stream(void){ return tn_net_sock_stream(); }
TN_EXPORT long long net_sock_dgram(void){ return tn_net_sock_dgram(); }
TN_EXPORT long long net_ipproto_tcp(void){ return tn_net_ipproto_tcp(); }
TN_EXPORT long long net_ipproto_udp(void){ return tn_net_ipproto_udp(); }
TN_EXPORT long long net_init(void){ return tn_net_init(); }
TN_EXPORT long long net_cleanup(void){ return tn_net_cleanup(); }
TN_EXPORT long long net_socket(long long fam, long long type, long long proto){ return tn_net_socket(fam, type, proto); }
TN_EXPORT long long net_close(long long sock){ return tn_net_close(sock); }
TN_EXPORT long long net_connect(long long sock, unsigned char* host, long long port){ return tn_net_connect(sock, host, port); }
TN_EXPORT long long net_bind(long long sock, unsigned char* host, long long port){ return tn_net_bind(sock, host, port); }
TN_EXPORT long long net_listen(long long sock, long long backlog){ return tn_net_listen(sock, backlog); }
TN_EXPORT long long net_accept(long long sock){ return tn_net_accept(sock); }
TN_EXPORT long long net_send(long long sock, unsigned char* buf, long long len){ return tn_net_send(sock, buf, len); }
TN_EXPORT long long net_recv(long long sock, unsigned char* buf, long long len){ return tn_net_recv(sock, buf, len); }
TN_EXPORT long long net_set_blocking(long long sock, long long on){ return tn_net_set_blocking(sock, on); }
TN_EXPORT long long net_set_timeout(long long sock, long long ms){ return tn_net_set_timeout(sock, ms); }
TN_EXPORT long long net_last_error(void){ return tn_net_last_error(); }

TN_EXPORT long long tls_connect(unsigned char* host, long long port){ return tn_tls_connect(host, port); }
TN_EXPORT long long tls_send(long long handle, unsigned char* buf, long long len){ return tn_tls_send(handle, buf, len); }
TN_EXPORT long long tls_recv(long long handle, unsigned char* buf, long long len){ return tn_tls_recv(handle, buf, len); }
TN_EXPORT long long tls_close(long long handle){ return tn_tls_close(handle); }
"""

code = code.replace("TN_EXPORT long long tn_net_last_error(void){\n  return tn_net_last_error_impl();\n}",
                    "TN_EXPORT long long tn_net_last_error(void){\n  return tn_net_last_error_impl();\n}" + tnrt_additions)

with open(r'TezzNative-language/src/tnrt.c', 'w', encoding='utf-8') as f:
    f.write(code)

print("SUCCESS: Updated tnrt.c with http_download and net/tls aliases")
