import subprocess
import os

FTP_USER = "u190073748.tezzcorpcom"
FTP_PASS = "TezzMsngr@Api#2026$TezzCorp&9608"
REMOTE_BASE = "ftp://89.116.133.167/tn.tezzcorp.com"
LOCAL_ROOT = r"C:\Acer\Code\TezzNative\TezzCorp_WebSites\tn_tezzcorp_com"

def list_remote(path):
    url = f"{REMOTE_BASE}/{path}" if path else f"{REMOTE_BASE}/"
    cmd = ["curl.exe", "-s", "-u", f"{FTP_USER}:{FTP_PASS}", "--disable-epsv", url]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    lines = res.stdout.strip().splitlines()
    entries = []
    for l in lines:
        parts = l.split(maxsplit=8)
        if len(parts) >= 9:
            perms = parts[0]
            name = parts[8].strip()
            if name not in ('.', '..'):
                entries.append((perms.startswith('d'), name))
    return entries

def download_tree(rel_dir=""):
    loc_dir = os.path.join(LOCAL_ROOT, rel_dir)
    os.makedirs(loc_dir, exist_ok=True)
    entries = list_remote(rel_dir)
    for is_dir, name in entries:
        sub_rel = f"{rel_dir}/{name}" if rel_dir else name
        sub_loc = os.path.join(LOCAL_ROOT, sub_rel)
        if is_dir:
            download_tree(sub_rel)
        else:
            url = f"{REMOTE_BASE}/{sub_rel}"
            print(f"Downloading: {sub_rel}")
            cmd = ["curl.exe", "-s", "-u", f"{FTP_USER}:{FTP_PASS}", "--disable-epsv", "-o", sub_loc, url]
            subprocess.run(cmd)

print("Starting curl sync of tn.tezzcorp.com...")
download_tree()
print("Download finished!")
