import ftplib
import os

host = "tn.tezzcorp.com"
user = "u190073748.tezzcorpcom"
pw = "TezzMsngr@Api#2026$TezzCorp&9608"

dest_dir = r"C:\Acer\Code\TezzNative\TezzCorp_WebSites\tn_tezzcorp_com"

def download_dir(ftp, remote_dir, local_dir):
    os.makedirs(local_dir, exist_ok=True)
    items = []
    ftp.retrlines(f"LIST {remote_dir}", items.append)
    
    for item in items:
        parts = item.split(maxsplit=8)
        if len(parts) < 9:
            continue
        perms = parts[0]
        name = parts[8]
        if name in ('.', '..'):
            continue
        
        rem_path = f"{remote_dir}/{name}" if remote_dir != "." else name
        loc_path = os.path.join(local_dir, name)
        
        if perms.startswith('d'):
            download_dir(ftp, rem_path, loc_path)
        else:
            print(f"Downloading: {rem_path} -> {loc_path}")
            with open(loc_path, 'wb') as f:
                ftp.retrbinary(f"RETR {rem_path}", f.write)

print("Connecting to FTP...")
ftp = ftplib.FTP(host, timeout=30)
ftp.login(user, pw)
ftp.set_pasv(True)
print("Connected! Listing and downloading...")

# Check if public_html or root
lines = []
ftp.dir(lines.append)
for l in lines:
    print("ROOT:", l)

# Download all
download_dir(ftp, ".", dest_dir)
ftp.quit()
print("All files synced successfully from live server!")
