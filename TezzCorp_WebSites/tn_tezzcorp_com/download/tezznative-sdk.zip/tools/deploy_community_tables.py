import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from ssh_helper import get_sftp, run_remote

sql_content = """<?php
declare(strict_types=1);

function setup_db($name, $user, $pass) {
    echo "=== Provisioning Database: $name ===\\n";
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=$name;charset=utf8mb4", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
        
        $pdo->exec("CREATE TABLE IF NOT EXISTS tn_community_users (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            display_name VARCHAR(100) NOT NULL,
            email VARCHAR(190) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            bio TEXT DEFAULT NULL,
            github_url VARCHAR(255) DEFAULT NULL,
            role ENUM('developer','contributor','tester','founder','moderator') DEFAULT 'developer',
            reputation INT NOT NULL DEFAULT 10,
            is_verified TINYINT(1) NOT NULL DEFAULT 0,
            join_date DATE NOT NULL DEFAULT (CURDATE()),
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_email (email),
            INDEX idx_created (created_at),
            INDEX idx_role (role)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS tn_community_posts (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NOT NULL,
            title VARCHAR(255) NOT NULL,
            body TEXT NOT NULL,
            category ENUM('showcase','question','bug-report','announcement','general') DEFAULT 'general',
            tags VARCHAR(255) DEFAULT NULL,
            upvotes INT UNSIGNED NOT NULL DEFAULT 0,
            reply_count INT UNSIGNED NOT NULL DEFAULT 0,
            status ENUM('published','pinned','locked','deleted') DEFAULT 'published',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_category (category),
            INDEX idx_created (created_at),
            INDEX idx_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS tn_community_replies (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            post_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL,
            body TEXT NOT NULL,
            upvotes INT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_post (post_id),
            INDEX idx_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS tn_community_likes (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NOT NULL,
            target_type ENUM('post','reply') NOT NULL,
            target_id INT UNSIGNED NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_user_target (user_id, target_type, target_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS tn_package_registry (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL UNIQUE,
            version VARCHAR(50) NOT NULL,
            description TEXT,
            author_id INT UNSIGNED DEFAULT NULL,
            repository_url VARCHAR(255) DEFAULT NULL,
            downloads INT UNSIGNED NOT NULL DEFAULT 0,
            checksum VARCHAR(128) DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_name (name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Compatible copies
        $pdo->exec("CREATE TABLE IF NOT EXISTS tezz_community_users LIKE tn_community_users");
        $pdo->exec("CREATE TABLE IF NOT EXISTS tezz_community_posts LIKE tn_community_posts");
        $pdo->exec("CREATE TABLE IF NOT EXISTS tezz_community_replies LIKE tn_community_replies");
        $pdo->exec("CREATE TABLE IF NOT EXISTS tezz_community_likes LIKE tn_community_likes");
        $pdo->exec("CREATE TABLE IF NOT EXISTS tezz_package_registry LIKE tn_package_registry");

        // Seed initial founding members
        $cnt = (int)$pdo->query("SELECT COUNT(*) FROM tn_community_users")->fetchColumn();
        if ($cnt === 0) {
            $stmt = $pdo->prepare("INSERT INTO tn_community_users (display_name, email, password_hash, bio, github_url, role, reputation, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?, 1)");
            $seedUsers = [
                ["Rohit Sharma", "rohit@tezzcorp.com", password_hash("TezzNativeFounder@2026", PASSWORD_BCRYPT), "Founder & Chief Architect of TezzNative. Building high-performance native systems and distributed compilers.", "https://github.com/Rohit9608", "founder", 500],
                ["TezzCore Dev Team", "core@tezzcorp.com", password_hash("TezzCoreDev#2026", PASSWORD_BCRYPT), "Official TezzNative compiler and runtime development engineering team.", "https://github.com/TezzCorp", "developer", 350],
                ["Aryaa S.", "community@tezzcorp.com", password_hash("CommunityDev@2026", PASSWORD_BCRYPT), "Core contributor, standard library maintainer and ecosystem architect.", "https://github.com/TezzCorp/TezzNative", "contributor", 220]
            ];
            foreach ($seedUsers as $u) {
                $stmt->execute($u);
            }
            echo "Seeded " . count($seedUsers) . " initial community members in tn_community_users.\\n";
        } else {
            echo "tn_community_users already has $cnt members.\\n";
        }

        echo "SUCCESS: All community tables verified in $name.\\n";
    } catch (Exception $e) {
        echo "ERROR in $name: " . $e->getMessage() . "\\n";
    }
}

setup_db("u190073748_tezz_native_db", "u190073748_tezz_native_ur", "TezzNativeByRohit@9608");
setup_db("u190073748_tezz_official_", "u190073748_tezz_usr__vr__", "TezzCorpOfficial#@2026");
"""

ssh, sftp = get_sftp()
try:
    with sftp.file('setup_community_tables.php', 'w') as f:
        f.write(sql_content)
    print("Uploaded setup_community_tables.php via SFTP.")
finally:
    sftp.close()
    ssh.close()

out, err = run_remote('php setup_community_tables.php && rm -f setup_community_tables.php')
print("STDOUT:\n", out)
if err:
    print("STDERR:\n", err)
