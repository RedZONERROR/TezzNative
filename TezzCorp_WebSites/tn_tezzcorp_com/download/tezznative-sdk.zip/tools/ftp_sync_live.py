import os
import ftplib
from ftplib import FTP

FTP_HOST = "89.116.133.167"
FTP_USER = "u190073748.tezzcorpcom"
FTP_PASS = "TezzMsngr@Api#2026$TezzCorp&9608"
BASE_DIR = "tn.tezzcorp.com"

def ensure_ftp_dirs(ftp, remote_path):
    parts = remote_path.strip("/").split("/")
    curr = ""
    for part in parts:
        curr += "/" + part
        try:
            ftp.mkd(curr)
            print(f"[+] Created remote dir: {curr}")
        except Exception:
            pass

def upload_file(ftp, local_path, remote_path):
    remote_dir = os.path.dirname(remote_path).replace("\\", "/")
    if remote_dir:
        ensure_ftp_dirs(ftp, remote_dir)
    filename = os.path.basename(local_path)
    print(f"[*] Uploading {filename} -> {remote_path} ({os.path.getsize(local_path):,} bytes)...")
    with open(local_path, "rb") as f:
        ftp.storbinary(f"STOR {remote_path}", f, blocksize=65536)
    print(f"[+] Success: {filename}")

def main():
    print(f"[*] Connecting to {FTP_HOST}...")
    ftp = FTP()
    ftp.connect(FTP_HOST, 21, timeout=30)
    ftp.login(FTP_USER, FTP_PASS)
    print("[+] Logged into FTP successfully.")

    files_to_sync = [
        ("TezzNativeInstaller.exe", f"{BASE_DIR}/download/TezzNativeInstaller.exe"),
        ("TezzCorp_WebSites/tn_tezzcorp_com/download/tezznative-sdk.zip", f"{BASE_DIR}/download/tezznative-sdk.zip"),
        ("tezz.exe", f"{BASE_DIR}/download/tezz.exe"),
        ("tezzc.exe", f"{BASE_DIR}/download/tezzc.exe"),
    ]

    for local, remote in files_to_sync:
        if os.path.exists(local):
            upload_file(ftp, local, remote)
        else:
            print(f"[!] Warning: local file {local} not found.")

    ftp.quit()
    print("[SUCCESS] Live deployment synchronization finished!")

if __name__ == "__main__":
    main()
