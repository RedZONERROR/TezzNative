with open(r'TezzNative-language/src/ir_codegen_pe.c', 'r', encoding='utf-8') as f:
    text = f.read()

# Fix write_pe_stub32 data directory
dir32_old = """    } else if(i == 6 && debug_size){
      write_u32(f, debug_rva);
      write_u32(f, debug_size);"""

# Replace the second occurrence (in write_pe_stub32)
idx1 = text.find(dir32_old)
if idx1 != -1:
    idx2 = text.find(dir32_old, idx1 + 1)
    if idx2 != -1:
        text = text[:idx2] + text[idx2 + len(dir32_old):]

# Fix ARM64 call
text = text.replace(
    "int r = write_pe_stub64(f, text, text_size, rdata, rdata_size, data, data_size, reloc, 12, rdata_rva, rdata_rva, imp.import_size, debug_dir_rva, debug_dir_size, 0xAA64);",
    "int r = write_pe_stub64(f, text, text_size, rdata, rdata_size, data, data_size, reloc, 12, rdata_rva, rdata_rva, imp.import_size, 0, 0, 0xAA64);"
)

with open(r'TezzNative-language/src/ir_codegen_pe.c', 'w', encoding='utf-8') as f:
    f.write(text)

print("SUCCESS FIXING PE DEBUG")
