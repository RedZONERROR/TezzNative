import os, shutil, zipfile, tempfile, subprocess, time
from pathlib import Path

repo_root = Path("c:/Acer/Code/TezzNative")
zip_path = repo_root / "TezzCorp_WebSites" / "tn_tezzcorp_com" / "download" / "tezznative-sdk.zip"

print(f"Testing clean installation from {zip_path} ...")
with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmpdir:
    install_dir = Path(tmpdir) / "TezzNative"
    install_dir.mkdir()
    
    # Extract zip (simulating installer)
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(install_dir)
    print("Extracted archive successfully.")
    
    bin_dir = install_dir / "bin"
    tezzc = bin_dir / "tezzc.exe"
    assert tezzc.exists(), "tezzc.exe not found in extracted bin/"
    
    r = subprocess.run([str(tezzc)], capture_output=True, text=True)
    print("tezzc output:", r.stdout.strip()[:60])
    
    # Create test source file
    src = install_dir / "probe.tn"
    exe = install_dir / "probe.exe"
    src.write_text("""
import "io"
import "math"
import "tensor"

fn main() -> int:
  d:TensorDesc = tensor.tensor_desc(4, 4, tensor.tensor_dtype_f32(), tensor.tensor_device_cpu(), 16)
  unsafe:
    if tensor.tensor_desc_valid_p(&d) == 0:
      ret 1
  ret 42
""", encoding="ascii")

    # Set up environment like install.ps1 does
    env = os.environ.copy()
    env["TEZZ_SDK_ROOT"] = str(install_dir)
    env["PATH"] = str(bin_dir) + os.pathsep + env.get("PATH", "")
    
    print("Compiling probe.tn with extracted distributed build...")
    r = subprocess.run([str(tezzc), "buildexe", str(src), str(exe)], env=env, capture_output=True, text=True)
    print("Compiler stdout:", r.stdout.strip())
    if r.returncode != 0:
        print("Compiler stderr:", r.stderr)
        raise RuntimeError("Compilation failed!")
    
    assert exe.exists(), "Output binary probe.exe was not created!"
    print("Executing probe.exe in clean environment...")
    r = subprocess.run([str(exe)], env=env, capture_output=True, text=True)
    print(f"probe.exe exit code: {r.returncode}")
    assert r.returncode == 42, f"Expected returncode 42, got {r.returncode}!"

print("\n=======================================================")
print("DISTRIBUTED BUILD INSTALL & RUN TEST: 100% PASSED!")
print("=======================================================")
