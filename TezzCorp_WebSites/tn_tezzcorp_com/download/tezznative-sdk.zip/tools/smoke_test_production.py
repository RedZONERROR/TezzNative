#!/usr/bin/env python3
"""
smoke_test_production.py — Validates live deployment of tn.tezzcorp.com:
1. Root homepage (200 OK)
2. Community portal (200 OK)
3. Security check: Disaster recovery archive must return 403 Forbidden via public HTTP
4. Public download: tezznative-sdk.zip must return 200 OK
5. SSH disaster recovery verification: test archive readability on remote server
"""

import urllib.request
import urllib.error
import ssl
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from ssh_helper import run_remote

ctx = ssl.create_default_context()
# Ignore self-signed if intermediate cert is missing
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def test_url(url, expected_code=200):
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) TezzNative-Validator/1.0"}
    )
    try:
        with urllib.request.urlopen(req, context=ctx, timeout=15) as resp:
            code = resp.getcode()
            body = resp.read().decode('utf-8', errors='replace')
            status = "PASS" if code == expected_code else f"FAIL (got {code})"
            print(f"[{status}] {url} -> HTTP {code} (Length: {len(body)})")
            return code == expected_code, body
    except urllib.error.HTTPError as e:
        status = "PASS" if e.code == expected_code else f"FAIL (got {e.code})"
        print(f"[{status}] {url} -> HTTP {e.code} (Expected {expected_code})")
        return e.code == expected_code, ""
    except Exception as e:
        print(f"[FAIL] {url} -> Error: {e}")
        return False, ""

def main():
    print("=" * 60)
    print("Smoke Testing Production Portal: tn.tezzcorp.com")
    print("=" * 60)

    all_ok = True

    # 1. Homepage
    ok, body = test_url("https://tn.tezzcorp.com/", 200)
    if ok and "TezzNative" in body:
        print("  ✓ Homepage contains 'TezzNative'")
    else:
        all_ok = False

    # 2. Community page
    ok, body = test_url("https://tn.tezzcorp.com/community/", 200)
    if ok and "Community" in body:
        print("  ✓ Community portal loaded with DB integration")
    else:
        all_ok = False

    # 3. Security: Disaster recovery archive must be blocked from HTTP
    ok, _ = test_url("https://tn.tezzcorp.com/tezznative_source_backup.tar.gz", 403)
    if ok:
        print("  ✓ Disaster recovery archive is protected (HTTP 403 Forbidden)")
    else:
        all_ok = False

    # 4. Public release download
    ok, _ = test_url("https://tn.tezzcorp.com/download/release_manifest.json", 200)
    if ok:
        print("  ✓ Public release manifest is accessible (HTTP 200)")
    else:
        all_ok = False

    # 5. Remote SSH Recovery Verification
    print("\n[SSH Verification] Testing Disaster Recovery Archive readability via SSH...")
    out, err = run_remote("tar -tzf /home/u190073748/domains/tezzcorp.com/public_html/tn.tezzcorp.com/tezznative_source_backup.tar.gz | head -n 15")
    if "TezzNative/lib" in out or "TezzNative/tools" in out or "TezzNative" in out:
        print("  ✓ Remote archive is valid tar.gz and readable via SSH!")
        print("Sample files inside recovery archive on server:")
        for line in out.strip().split("\n")[:8]:
            print(f"    - {line}")
    else:
        print(f"  ✗ SSH archive check failed: {out} | {err}")
        all_ok = False

    print("\n" + "=" * 60)
    if all_ok:
        print("ALL PRODUCTION SMOKE TESTS PASSED (5/5)!")
    else:
        print("SOME SMOKE TESTS FAILED!")
    print("=" * 60)

if __name__ == "__main__":
    main()
