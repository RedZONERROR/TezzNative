with open(r'TezzNative-language/src/ir_codegen_pe.c', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Update write_pe_stub64 signature and data directory
stub_sig_old = """static int write_pe_stub64(FILE* f, const unsigned char* text, uint32_t text_size,
                           const unsigned char* rdata, uint32_t rdata_size,
                           const unsigned char* data, uint32_t data_size,
                           const unsigned char* reloc, uint32_t reloc_size,
                           uint32_t rdata_rva, uint32_t import_rva, uint32_t import_size,
                           uint16_t machine){"""

stub_sig_new = """static int write_pe_stub64(FILE* f, const unsigned char* text, uint32_t text_size,
                           const unsigned char* rdata, uint32_t rdata_size,
                           const unsigned char* data, uint32_t data_size,
                           const unsigned char* reloc, uint32_t reloc_size,
                           uint32_t rdata_rva, uint32_t import_rva, uint32_t import_size,
                           uint32_t debug_rva, uint32_t debug_size,
                           uint16_t machine){"""

text = text.replace(stub_sig_old, stub_sig_new)

# 2. Update directory table loop
dir_old = """    } else if(i == 5 && reloc_size){
      write_u32(f, reloc_rva);
      write_u32(f, reloc_size);
    } else {"""

dir_new = """    } else if(i == 5 && reloc_size){
      write_u32(f, reloc_rva);
      write_u32(f, reloc_size);
    } else if(i == 6 && debug_size){
      write_u32(f, debug_rva);
      write_u32(f, debug_size);
    } else {"""

text = text.replace(dir_old, dir_new)

# 3. Add debug info generation before rdata_size = off
rdata_target = """    uint32_t sp_rva = rdata_rva + off;
    memcpy(rdata + off, sp, strlen(sp) + 1);
    off += (uint32_t)strlen(sp) + 1;"""

debug_gen = """    uint32_t sp_rva = rdata_rva + off;
    memcpy(rdata + off, sp, strlen(sp) + 1);
    off += (uint32_t)strlen(sp) + 1;

    // CodeView RSDS Debug Directory (Entry 6)
    uint32_t debug_dir_rva = rdata_rva + off;
    uint32_t debug_dir_size = 28;
    off += debug_dir_size;
    uint32_t cv_info_rva = rdata_rva + off;
    const char* pdb_path = "app.pdb";
    uint32_t pdb_path_len = (uint32_t)strlen(pdb_path) + 1;
    uint32_t cv_info_size = 4 + 16 + 4 + pdb_path_len;

    unsigned char* pdbg = rdata + (debug_dir_rva - rdata_rva);
    put_u32_le(pdbg + 0, 0);
    put_u32_le(pdbg + 4, 0x69AB0000);
    pdbg[8] = 0; pdbg[9] = 0; pdbg[10] = 0; pdbg[11] = 0;
    put_u32_le(pdbg + 12, 2); // IMAGE_DEBUG_TYPE_CODEVIEW
    put_u32_le(pdbg + 16, cv_info_size);
    put_u32_le(pdbg + 20, cv_info_rva);
    put_u32_le(pdbg + 24, cv_info_rva);

    unsigned char* pcv = rdata + (cv_info_rva - rdata_rva);
    memcpy(pcv, "RSDS", 4);
    const unsigned char guid[16] = {0x54,0x65,0x7A,0x7A,0x4E,0x61,0x74,0x69,0x76,0x65,0x50,0x44,0x42,0x30,0x30,0x31};
    memcpy(pcv + 4, guid, 16);
    put_u32_le(pcv + 20, 1);
    memcpy(pcv + 24, pdb_path, pdb_path_len);
    off += cv_info_size;"""

text = text.replace(rdata_target, debug_gen)

# 4. Update caller write_pe_stub64 in arm64 & x86_64
text = text.replace(
    "int r = write_pe_stub64(f, text, text_size, rdata, rdata_size, data, data_size, reloc, 12, rdata_rva, rdata_rva, imp.import_size, 0xAA64);",
    "int r = write_pe_stub64(f, text, text_size, rdata, rdata_size, data, data_size, reloc, 12, rdata_rva, rdata_rva, imp.import_size, debug_dir_rva, debug_dir_size, 0xAA64);"
)

text = text.replace(
    "int r = write_pe_stub64(f, text, text_size, rdata, rdata_size, data, data_size, NULL, 0, rdata_rva, rdata_rva, imp.import_size, 0x8664);",
    "int r = write_pe_stub64(f, text, text_size, rdata, rdata_size, data, data_size, NULL, 0, rdata_rva, rdata_rva, imp.import_size, debug_dir_rva, debug_dir_size, 0x8664);"
)

with open(r'TezzNative-language/src/ir_codegen_pe.c', 'w', encoding='utf-8') as f:
    f.write(text)

print("SUCCESS PATCHING CODEVIEW PDB SYMBOLS")
