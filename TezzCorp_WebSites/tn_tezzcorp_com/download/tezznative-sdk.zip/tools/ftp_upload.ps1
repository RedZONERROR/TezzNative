#!/usr/bin/env pwsh
$ErrorActionPreference = "Continue"
$user = "u190073748.tezzcorpcom"
$pass = "Tezz@2026"
$base = "ftp://89.116.133.167/tn.tezzcorp.com"
$root = "c:\Users\TezzCorp\Code\TezzNative"
$lang = "c:\Users\TezzCorp\Code\TezzNative\TezzNative-language"

function Ftp-MkDir($url) {
    try {
        $req = [System.Net.WebRequest]::Create($url)
        $req.Credentials = New-Object System.Net.NetworkCredential($user, $pass)
        $req.Method = [System.Net.WebRequestMethods+Ftp]::MakeDirectory
        $res = $req.GetResponse(); $res.Close()
    } catch { }
}

function Ftp-Upload($localPath, $remoteUrl) {
    $name = ($remoteUrl -split "/")[-1]
    try {
        $req = [System.Net.WebRequest]::Create($remoteUrl)
        $req.Credentials = New-Object System.Net.NetworkCredential($user, $pass)
        $req.Method = [System.Net.WebRequestMethods+Ftp]::UploadFile
        $req.UseBinary = $true
        $bytes = [System.IO.File]::ReadAllBytes($localPath)
        $req.ContentLength = $bytes.Length
        $stream = $req.GetRequestStream()
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Close()
        $res = $req.GetResponse(); $res.Close()
        $kb = [Math]::Round($bytes.Length/1KB, 1)
        Write-Host "  OK  $name  ($kb KB)" -ForegroundColor Green
    } catch {
        Write-Host "  FAIL $name  $_" -ForegroundColor Red
    }
}

Write-Host "Creating remote directories..." -ForegroundColor Cyan
Ftp-MkDir "$base/community"
Ftp-MkDir "$base/versions"
Ftp-MkDir "$base/support"
Ftp-MkDir "$base/frameworks/tezzui"
Ftp-MkDir "$base/frameworks/tezzdb"
Ftp-MkDir "$base/frameworks/tezzserve"
Ftp-MkDir "$base/frameworks/tezzapi"
Ftp-MkDir "$base/frameworks/tsm"

Write-Host "Uploading files..." -ForegroundColor Cyan
Ftp-Upload "$root\community\index.php"                 "$base/community/index.php"
Ftp-Upload "$root\versions\index.php"                  "$base/versions/index.php"
Ftp-Upload "$root\support\index.php"                   "$base/support/index.php"
Ftp-Upload "$root\frameworks\_fw_template.php"         "$base/frameworks/_fw_template.php"
Ftp-Upload "$root\frameworks\tezzui\index.php"         "$base/frameworks/tezzui/index.php"
Ftp-Upload "$root\frameworks\tezzdb\index.php"         "$base/frameworks/tezzdb/index.php"
Ftp-Upload "$root\frameworks\tezzserve\index.php"      "$base/frameworks/tezzserve/index.php"
Ftp-Upload "$root\frameworks\tezzapi\index.php"        "$base/frameworks/tezzapi/index.php"
Ftp-Upload "$root\frameworks\tsm\index.php"            "$base/frameworks/tsm/index.php"
Ftp-Upload "$lang\TezzNativeSetup.exe"                 "$base/dist/TezzNativeSetup.exe"
Ftp-Upload "$lang\bin\Release\tezz.exe"                "$base/dist/tezz.exe"
Ftp-Upload "$lang\bin\Release\tezzc.exe"               "$base/dist/tezzc.exe"

Write-Host ""
Write-Host "Done!" -ForegroundColor Cyan
