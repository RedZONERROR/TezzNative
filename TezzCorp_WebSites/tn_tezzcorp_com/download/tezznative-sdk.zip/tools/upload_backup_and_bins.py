#!/usr/bin/env python3
"""
upload_backup_and_bins.py — Uploads top-level download/ binaries and the disaster recovery archive,
then remotely unpacks download/sdk/ in 1 second.
"""

import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from ssh_helper import get_sftp, run_remote

LOCAL_WEB_ROOT = Path(r"C:\Acer\Code\TezzNative\TezzCorp_WebSites\tn_tezzcorp_com")
REMOTE_TARGET_DIR = "/home/u190073748/domains/tezzcorp.com/public_html/tn.tezzcorp.com"

def main():
    print("=" * 60)
    print("Fast Deployment: Binaries + Disaster Recovery Archive")
    print("=" * 60)

    ssh, sftp = get_sftp()
    if ssh.get_transport():
        ssh.get_transport().set_keepalive(15)

    # 1. Direct files in download/
    dl_local = LOCAL_WEB_ROOT / "download"
    dl_remote = f"{REMOTE_TARGET_DIR}/download"
    
    print("\n[1/3] Uploading top-level download/ artifacts...")
    for item in dl_local.iterdir():
        if item.is_file():
            rfp = f"{dl_remote}/{item.name}"
            print(f"  Uploading {item.name} ({item.stat().st_size / 1024:.1f} KB)...", end="", flush=True)
            try:
                sftp.put(str(item), rfp)
                print(" [OK]", flush=True)
            except Exception as e:
                print(f" [ERR: {e}]", flush=True)

    # 2. Disaster Recovery Archive
    backup_tar = LOCAL_WEB_ROOT / "tezznative_source_backup.tar.gz"
    print(f"\n[2/3] Uploading Disaster Recovery Archive ({backup_tar.stat().st_size / (1024*1024):.2f} MB)...")
    last_mb = [0]
    def cb(transferred, total):
        mb = transferred / (1024 * 1024)
        if mb - last_mb[0] >= 4 or transferred == total:
            last_mb[0] = mb
            print(f"  Uploaded {mb:.1f} / {total / (1024*1024):.1f} MB ({(transferred/total)*100:.1f}%)", flush=True)

    rfp_tar = f"{REMOTE_TARGET_DIR}/tezznative_source_backup.tar.gz"
    sftp.put(str(backup_tar), rfp_tar, callback=cb)
    print("  Disaster Recovery Archive upload [OK]!", flush=True)

    sftp.close()
    ssh.close()

    # 3. Server-side unzip of sdk mirror
    print("\n[3/3] Synchronizing server-side download/sdk/ mirror...")
    out, err = run_remote(f"cd '{REMOTE_TARGET_DIR}/download' && mkdir -p sdk && unzip -qo tezznative-sdk.zip -d sdk/ && ls -la sdk/bin")
    print("Remote SDK sync output:\n" + out)
    if err:
        print("Remote STDERR:\n" + err)

    print("\n" + "=" * 60)
    print("FAST DEPLOYMENT COMPLETE!")
    print("=" * 60)

if __name__ == "__main__":
    main()
