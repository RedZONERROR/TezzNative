import os
import subprocess
import sys

FTP_USER = "u190073748.tezzcorpcom"
FTP_PASS = "TezzMsngr@Api#2026$TezzCorp&9608"
FTP_HOST = "89.116.133.167"
REMOTE_BASE = f"ftp://{FTP_HOST}/tn.tezzcorp.com"
LOCAL_ROOT = r"C:\Acer\Code\TezzNative\TezzCorp_WebSites\tn_tezzcorp_com"

def upload_file(local_path, rel_path):
    rel_clean = rel_path.replace("\\", "/").lstrip("/")
    remote_url = f"{REMOTE_BASE}/{rel_clean}"
    
    cmd = [
        "curl.exe",
        "-u", f"{FTP_USER}:{FTP_PASS}",
        "--disable-epsv",
        "--ftp-create-dirs",
        "-T", local_path,
        remote_url
    ]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if res.returncode == 0:
        print(f"[OK]   {rel_clean}", flush=True)
        return True
    else:
        print(f"[ERR]  {rel_clean} -> {res.stderr.strip() or res.stdout.strip()}", flush=True)
        return False

print(f"[*] Uploading updated site files from {LOCAL_ROOT} to {REMOTE_BASE} ...", flush=True)

uploaded = 0
failed = 0

for root, dirs, files in os.walk(LOCAL_ROOT):
    dirs[:] = [d for d in dirs if d not in ['.git', '.gemini', 'cache', 'temp', '__pycache__']]
    for f in files:
        if f.endswith('.tmp') or f.endswith('.bak') or f in ['Thumbs.db', '.DS_Store']:
            continue
        local_fp = os.path.join(root, f)
        rel_fp = os.path.relpath(local_fp, LOCAL_ROOT)
        
        if upload_file(local_fp, rel_fp):
            uploaded += 1
        else:
            failed += 1

print(f"\n[DONE] Finished FTP upload! Successfully uploaded: {uploaded} files, Failed: {failed} files.")
