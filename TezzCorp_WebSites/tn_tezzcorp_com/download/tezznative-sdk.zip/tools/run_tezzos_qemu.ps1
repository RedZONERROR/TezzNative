# Run TezzOS Kernel in QEMU CLI Mode
param(
    [switch]$Interactive,
    [switch]$Gfx
)

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "         Launching TezzOS Kernel in QEMU (CLI Mode)         " -ForegroundColor Yellow
Write-Host "============================================================" -ForegroundColor Cyan

# Ensure kernel is built
python tools/build_tezzos_qemu.py
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Kernel build failed." -ForegroundColor Red
    exit 1
}

Write-Host "`n[*] Starting QEMU with TezzOS..." -ForegroundColor Green

if ($Gfx) {
    # Launch in Graphical VGA window mode
    qemu-system-x86_64 -kernel build/tezzos_qemu.elf -serial stdio -vga std -m 256M
} else {
    # Launch in CLI Headless / Console Mode with auto debug-exit
    qemu-system-x86_64 -kernel build/tezzos_qemu.elf -serial stdio -display none -no-reboot -device isa-debug-exit,iobase=0xf4,iosize=0x04 -m 256M
}
