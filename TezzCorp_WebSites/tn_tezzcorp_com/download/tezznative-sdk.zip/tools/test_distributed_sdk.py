import subprocess, os, tempfile, shutil
from pathlib import Path

repo_root = Path("c:/Acer/Code/TezzNative")
dl_dir = repo_root / "TezzCorp_WebSites" / "tn_tezzcorp_com" / "download"
tezzc = dl_dir / "tezzc.exe"

print(f"Testing distributed tezzc: {tezzc}")
r = subprocess.run([str(tezzc), "--version"], capture_output=True, text=True)
print("Version:", r.stdout.strip())
assert r.returncode == 0, f"tezzc --version failed: {r.stderr}"

# Test compilation and execution
with tempfile.TemporaryDirectory() as tmpdir:
    src = Path(tmpdir) / "test.tn"
    exe = Path(tmpdir) / "test.exe"
    src.write_text("fn main() -> int:\n  ret 42\n", encoding="ascii")
    
    r = subprocess.run([str(tezzc), "buildexe", str(src), str(exe)], capture_output=True, text=True)
    print("buildexe out:", r.stdout.strip())
    if r.returncode != 0:
        print("buildexe err:", r.stderr)
        raise RuntimeError("buildexe failed")
    
    assert exe.exists(), "Output exe was not created"
    r = subprocess.run([str(exe)], capture_output=True, text=True)
    print("test.exe exit code:", r.returncode)
    assert r.returncode == 42, f"Expected 42, got {r.returncode}"

print("Smoke test: PASSED successfully!")
