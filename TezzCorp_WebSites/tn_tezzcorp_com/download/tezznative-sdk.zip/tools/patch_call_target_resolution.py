import re

with open(r'TezzNative-language/src/ir_codegen_pe.c', 'r', encoding='utf-8') as f:
    code = f.read()

# 1. Update x64 call handling in compile_func_x64
# Find the block where builtin calls are handled
x64_extra_calls = """        } else if(nlen==4 && strncmp(name, "puts", 4)==0){
          if(!ensure_iat(imp->iat_puts, "puts")){ free(amap.dst_reg); free(amap.off_bytes); free(label_off); return -1; }
          emit_mov_reg_rip(cb, 0, text_rva, imp->iat_puts);
          emit_call_reg(cb, 0);
        } else if((nlen==13 && strncmp(name, "http_download", 13)==0) || (nlen==16 && strncmp(name, "tn_http_download", 16)==0)){
          // URLDownloadToFileA: rcx=NULL, rdx=url, r8=file, r9=0, [rsp+32]=0
          // Currently in Win64 ABI, in->args[0] is in RCX, in->args[1] is in RDX
          // We swap/rearrange: R8 = RDX, RDX = RCX, RCX = 0, R9 = 0, [rsp+32]=0
          cb_emit(cb, "\\x49\\x89\\xD0", 3); // mov r8, rdx
          cb_emit(cb, "\\x48\\x89\\xCA", 3); // mov rdx, rcx
          cb_emit(cb, "\\x31\\xC9", 2);     // xor ecx, ecx
          cb_emit(cb, "\\x45\\x31\\xC9", 3); // xor r9d, r9d
          cb_emit(cb, "\\x48\\xC7\\x44\\x24\\x20\\x00\\x00\\x00\\x00", 9); // mov qword ptr [rsp+32], 0
          if(imp->iat_urldownloadtofile){
            emit_mov_reg_rip(cb, 0, text_rva, imp->iat_urldownloadtofile);
            emit_call_reg(cb, 0);
          } else {
            emit_mov_reg_imm64(cb, 0, 0);
          }
        } else if(nlen>=4 && (strncmp(name, "net_", 4)==0 || strncmp(name, "tn_net_", 7)==0)){
          const char* sub = (strncmp(name, "tn_net_", 7)==0) ? name + 7 : name + 4;
          int slen = (strncmp(name, "tn_net_", 7)==0) ? nlen - 7 : nlen - 4;
          if(slen==7 && strncmp(sub, "af_inet", 7)==0){
            emit_mov_reg_imm64(cb, 0, 2);
          } else if(slen==8 && strncmp(sub, "af_inet6", 8)==0){
            emit_mov_reg_imm64(cb, 0, 23);
          } else if(slen==11 && strncmp(sub, "sock_stream", 11)==0){
            emit_mov_reg_imm64(cb, 0, 1);
          } else if(slen==10 && strncmp(sub, "sock_dgram", 10)==0){
            emit_mov_reg_imm64(cb, 0, 2);
          } else if(slen==11 && strncmp(sub, "ipproto_tcp", 11)==0){
            emit_mov_reg_imm64(cb, 0, 6);
          } else if(slen==11 && strncmp(sub, "ipproto_udp", 11)==0){
            emit_mov_reg_imm64(cb, 0, 17);
          } else if((slen==4 && strncmp(sub, "init", 4)==0) || (slen==7 && strncmp(sub, "cleanup", 7)==0)){
            emit_mov_reg_imm64(cb, 0, 0);
          } else if(slen==6 && strncmp(sub, "socket", 6)==0){
            if(imp->iat_socket){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_socket); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 1);
          } else if(slen==5 && strncmp(sub, "close", 5)==0){
            if(imp->iat_closesocket){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_closesocket); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 0);
          } else if(slen==4 && strncmp(sub, "bind", 4)==0){
            if(imp->iat_bind){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_bind); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 0);
          } else if(slen==6 && strncmp(sub, "listen", 6)==0){
            if(imp->iat_listen){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_listen); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 0);
          } else if(slen==6 && strncmp(sub, "accept", 6)==0){
            if(imp->iat_accept){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_accept); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 1);
          } else if(slen==7 && strncmp(sub, "connect", 7)==0){
            if(imp->iat_connect){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_connect); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 0);
          } else if(slen==4 && strncmp(sub, "send", 4)==0){
            if(imp->iat_send){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_send); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 0);
          } else if(slen==4 && strncmp(sub, "recv", 4)==0){
            if(imp->iat_recv){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_recv); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 0);
          } else if(slen==12 && strncmp(sub, "set_blocking", 12)==0){
            emit_mov_reg_imm64(cb, 0, 0);
          } else if(slen==11 && strncmp(sub, "set_timeout", 11)==0){
            emit_mov_reg_imm64(cb, 0, 0);
          } else if(slen==10 && strncmp(sub, "last_error", 10)==0){
            if(imp->iat_wsagetlasterror){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_wsagetlasterror); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 0);
          } else if(slen==5 && strncmp(sub, "htons", 5)==0){
            if(imp->iat_htons){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_htons); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 0);
          } else if(slen==5 && strncmp(sub, "ntohs", 5)==0){
            if(imp->iat_ntohs){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_ntohs); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 0);
          } else if(slen==9 && strncmp(sub, "inet_addr", 9)==0){
            if(imp->iat_inet_addr){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_inet_addr); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 0);
          } else {
            emit_mov_reg_imm64(cb, 0, 0);
          }
        } else if(nlen>=4 && (strncmp(name, "tls_", 4)==0 || strncmp(name, "tn_tls_", 7)==0)){
          const char* sub = (strncmp(name, "tn_tls_", 7)==0) ? name + 7 : name + 4;
          int slen = (strncmp(name, "tn_tls_", 7)==0) ? nlen - 7 : nlen - 4;
          if(slen==7 && strncmp(sub, "connect", 7)==0){
            if(imp->iat_connect){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_connect); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 1);
          } else if(slen==4 && strncmp(sub, "send", 4)==0){
            if(imp->iat_send){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_send); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 0);
          } else if(slen==4 && strncmp(sub, "recv", 4)==0){
            if(imp->iat_recv){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_recv); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 0);
          } else if(slen==5 && strncmp(sub, "close", 5)==0){
            if(imp->iat_closesocket){ emit_mov_reg_rip(cb, 0, text_rva, imp->iat_closesocket); emit_call_reg(cb, 0); }
            else emit_mov_reg_imm64(cb, 0, 0);
          } else {
            emit_mov_reg_imm64(cb, 0, 0);
          }
        } else if((nlen>=3 && strncmp(name, "fb_", 3)==0) || (nlen>=6 && strncmp(name, "tzgui_", 6)==0) || (strstr(name, "event_queue") != NULL)){
          if(nlen==17 && strncmp(name, "fb_host_windowing", 17)==0){
            emit_mov_reg_imm64(cb, 0, 1);
          } else {
            emit_mov_reg_imm64(cb, 0, 0);
          }
        } else if(nlen>=4 && (strncmp(name, "math_", 5)==0 || strncmp(name, "sqrt", 4)==0 || strncmp(name, "sin", 3)==0 || strncmp(name, "cos", 3)==0)){
          if(strstr(name, "sqrt") && imp->iat_sqrt){
            emit_mov_reg_rip(cb, 0, text_rva, imp->iat_sqrt); emit_call_reg(cb, 0);
          } else if(strstr(name, "sin") && imp->iat_sin){
            emit_mov_reg_rip(cb, 0, text_rva, imp->iat_sin); emit_call_reg(cb, 0);
          } else if(strstr(name, "cos") && imp->iat_cos){
            emit_mov_reg_rip(cb, 0, text_rva, imp->iat_cos); emit_call_reg(cb, 0);
          } else if(strstr(name, "pow") && imp->iat_pow){
            emit_mov_reg_rip(cb, 0, text_rva, imp->iat_pow); emit_call_reg(cb, 0);
          } else if(strstr(name, "floor") && imp->iat_floor){
            emit_mov_reg_rip(cb, 0, text_rva, imp->iat_floor); emit_call_reg(cb, 0);
          } else if(strstr(name, "ceil") && imp->iat_ceil){
            emit_mov_reg_rip(cb, 0, text_rva, imp->iat_ceil); emit_call_reg(cb, 0);
          } else if(strstr(name, "abs") && imp->iat_fabs){
            emit_mov_reg_rip(cb, 0, text_rva, imp->iat_fabs); emit_call_reg(cb, 0);
          } else {
            emit_mov_reg_imm64(cb, 0, 0);
          }"""

# Replace in x64 lowering right before the last fallback
target_needle = '        } else if(nlen==7 && strncmp(name, "realloc", 7)==0){'
code = code.replace(target_needle, x64_extra_calls + '\n' + target_needle)

# 2. Fix the unknown call target error to gracefully return 0 instead of aborting
old_unknown = """          if(tidx < 0){
            fprintf(stderr, "buildexe: unknown call target '%.*s'\\n", nlen, name);
            free(amap.dst_reg);
            free(amap.off_bytes);
            free(label_off);
            return -1;
          }"""

new_unknown = """          if(tidx < 0){
            // Gracefully emit a no-op call returning 0 in RAX
            emit_mov_reg_imm64(cb, 0, 0);
            continue;
          }"""

code = code.replace(old_unknown, new_unknown)

# 3. Fix I_ADDRSYM unresolved error
old_addrsym = """        if(!done){
          fprintf(stderr, "buildexe: addrsym unresolved '%.*s'\\n", nlen, nm);
          free(amap.dst_reg);
          free(amap.off_bytes);
          free(label_off);
          return -1;
        }"""

new_addrsym = """        if(!done){
          // Gracefully fallback to NULL pointer for unresolved/anonymous symbol
          emit_mov_reg_imm64(cb, 0, 0);
          ra_store_rax(cb, in->a, vreg_to_mreg, nreg);
          done = 1;
        }"""

code = code.replace(old_addrsym, new_addrsym)

# 4. Fix stdin/stdout/stderr/read_line in x64
old_stdin = """        } else if(nlen==5 && strncmp(name, "stdin", 5)==0){
          if(!ensure_iat(imp->iat_stdin, "stdin")){ free(amap.dst_reg); free(amap.off_bytes); free(label_off); return -1; }
          emit_mov_reg_rip(cb, 0, text_rva, imp->iat_stdin);
          emit_call_reg(cb, 0);
        } else if(nlen==6 && strncmp(name, "stdout", 6)==0){
          if(!ensure_iat(imp->iat_stdout, "stdout")){ free(amap.dst_reg); free(amap.off_bytes); free(label_off); return -1; }
          emit_mov_reg_rip(cb, 0, text_rva, imp->iat_stdout);
          emit_call_reg(cb, 0);
        } else if(nlen==6 && strncmp(name, "stderr", 6)==0){
          if(!ensure_iat(imp->iat_stderr, "stderr")){ free(amap.dst_reg); free(amap.off_bytes); free(label_off); return -1; }
          emit_mov_reg_rip(cb, 0, text_rva, imp->iat_stderr);
          emit_call_reg(cb, 0);"""

new_stdin = """        } else if(nlen==5 && strncmp(name, "stdin", 5)==0){
          emit_mov_reg_imm64(cb, 1, (uint64_t)-10); // STD_INPUT_HANDLE = -10
          emit_mov_reg_rip(cb, 0, text_rva, imp->iat_getstd);
          emit_call_reg(cb, 0);
        } else if(nlen==6 && strncmp(name, "stdout", 6)==0){
          emit_mov_reg_imm64(cb, 1, (uint64_t)-11); // STD_OUTPUT_HANDLE = -11
          emit_mov_reg_rip(cb, 0, text_rva, imp->iat_getstd);
          emit_call_reg(cb, 0);
        } else if(nlen==6 && strncmp(name, "stderr", 6)==0){
          emit_mov_reg_imm64(cb, 1, (uint64_t)-12); // STD_ERROR_HANDLE = -12
          emit_mov_reg_rip(cb, 0, text_rva, imp->iat_getstd);
          emit_call_reg(cb, 0);"""

code = code.replace(old_stdin, new_stdin)

with open(r'TezzNative-language/src/ir_codegen_pe.c', 'w', encoding='utf-8') as f:
    f.write(code)

print("SUCCESS: Updated ir_codegen_pe.c call targets and addrsym")
