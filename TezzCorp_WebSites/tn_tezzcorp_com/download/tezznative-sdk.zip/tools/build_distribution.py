import os
import shutil
import subprocess
import zipfile

print("[*] Starting TezzNative Production Distribution Build...")

DIST_DIR = r"c:\Acer\Code\TezzNative\dist\tezznative-sdk"
ZIP_OUTPUT = r"c:\Acer\Code\TezzNative\TezzCorp_WebSites\tn_tezzcorp_com\download\tezznative-sdk.zip"
SITE_DOWNLOAD = r"c:\Acer\Code\TezzNative\TezzCorp_WebSites\tn_tezzcorp_com\download"

if os.path.exists(DIST_DIR):
    shutil.rmtree(DIST_DIR)
os.makedirs(os.path.join(DIST_DIR, "bin"), exist_ok=True)
os.makedirs(os.path.join(DIST_DIR, "lib"), exist_ok=True)
os.makedirs(os.path.join(DIST_DIR, "include"), exist_ok=True)
os.makedirs(SITE_DOWNLOAD, exist_ok=True)

# 1. Copy binaries (tezz.exe = self-hosted compiler CLI, tezzc.exe = native core compiler)
shutil.copy2(r"c:\Acer\Code\TezzNative\tezz.exe", os.path.join(DIST_DIR, "bin", "tezz.exe"))
shutil.copy2(r"c:\Acer\Code\TezzNative\tezzc.exe", os.path.join(DIST_DIR, "bin", "tezzc.exe"))
if os.path.exists(r"c:\Acer\Code\TezzNative\tzgui.dll"):
    shutil.copy2(r"c:\Acer\Code\TezzNative\tzgui.dll", os.path.join(DIST_DIR, "bin", "tzgui.dll"))

# 2. Copy standard library
for f in os.listdir(r"c:\Acer\Code\TezzNative\lib"):
    if f.endswith(".tn"):
        shutil.copy2(os.path.join(r"c:\Acer\Code\TezzNative\lib", f), os.path.join(DIST_DIR, "lib", f))

# 3. Create manifest fingerprint
with open(os.path.join(DIST_DIR, ".tezz_install_manifest"), "w") as mf:
    mf.write("version=2.2.1\nproduct=TezzNative\nvendor=TezzCorp\nauthor=Rohit Pathak\n")

# 4. Zip SDK
print(f"[*] Packaging {ZIP_OUTPUT} ...")
with zipfile.ZipFile(ZIP_OUTPUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(DIST_DIR):
        for file in files:
            fp = os.path.join(root, file)
            arcname = os.path.relpath(fp, DIST_DIR)
            z.write(fp, arcname)

print(f"[+] SDK Zip created: {round(os.path.getsize(ZIP_OUTPUT)/(1024*1024), 2)} MB")

# 5. Build Win32 Installer
print("[*] Compiling TezzNativeInstaller.exe...")
cmd = 'clang++ -O3 -municode -mwindows tools/installer/installer_win32.cpp -o TezzNativeInstaller.exe -luser32 -lgdi32 -lcomctl32 -lshell32 -lwinhttp -lurlmon -ladvapi32 -lole32 -luuid'
subprocess.run(cmd, shell=True, check=True)
shutil.copy2("TezzNativeInstaller.exe", os.path.join(SITE_DOWNLOAD, "TezzNativeInstaller.exe"))

# 6. Sign binaries with Authenticode Certificate
print("[*] Signing Installer and SDK binaries...")
subprocess.run(["powershell", "-ExecutionPolicy", "Bypass", "-File", r"c:\Acer\Code\TezzNative\tools\sign_binary.ps1"], check=True)

print("[SUCCESS] All distribution assets compiled, signed, and ready for deployment!")
