with open(r'TezzNative-language/src/ir.c', 'r', encoding='utf-8') as f:
    text = f.read()

replacement = """        if(e->ty && e->ty->k==TY_PTR && e->ty->elem && e->ty->elem->k==TY_FN){
          return addr;
        }
        if(gty && (gty->k==TY_ARRAY || gty->k==TY_STRUCT)){
          return addr;
        }
        if(e->ty && (e->ty->k==TY_ARRAY || e->ty->k==TY_STRUCT)){
          return addr;
        }
        int sz = gty ? type_size(gty) : 8;
        return ir_load(F, addr, sz);
      }
      int addr = F->vaddr[idx];
      Type* ty  = F->vty[idx];

      if(ty && (ty->k==TY_ARRAY || ty->k==TY_STRUCT)){
        return addr; // aggregates are addresses
      }
      int sz = ty ? type_size(ty) : 8;
      return ir_load(F, addr, sz);
    }

    case EX_BIN: {
      Type* ta = e->bin.a ? e->bin.a->ty : NULL;
      Type* tb = e->bin.b ? e->bin.b->ty : NULL;
      if(e->bin.op==OP_ADD && ta && tb && is_str_type(tenv, ta) && is_str_type(tenv, tb)){
        int ra = gen_expr(M, tenv, F, ctx, e->bin.a, NULL);
        int rb = gen_expr(M, tenv, F, ctx, e->bin.b, NULL);
        int dst = new_reg(F);
        IRIns call; memset(&call, 0, sizeof(call));
        call.op = I_CALL;
        call.a = dst;
        call.name = "str_concat";
        call.nlen = 10;
        call.argc = 2;
        call.args = (int*)malloc(sizeof(int)*2);
        call.args[0] = ra;
        call.args[1] = rb;
        ir_emit(F, call);
        return dst;
      }
      int pa = ta && (is_ptr(ta) || is_array(ta));
      int pb = tb && (is_ptr(tb) || is_array(tb));

      if((e->bin.op==OP_ADD || e->bin.op==OP_SUB) && (pa || pb)){
        // pointer arithmetic
        Expr* pexpr = pa ? e->bin.a : e->bin.b;
        Expr* iexpr = pa ? e->bin.b : e->bin.a;
        Type* pt = pexpr->ty;
        Type* et = NULL;
        if(pt && pt->k==TY_PTR) et = pt->elem;
        if(pt && pt->k==TY_ARRAY) et = pt->elem;
        int esz = et ? type_size(et) : 1;

        int base = gen_expr(M, tenv, F, ctx, pexpr, NULL);
        int idx  = gen_expr(M, tenv, F, ctx, iexpr, tenv->b.ty_i64);

        if(pa && pb && e->bin.op==OP_SUB){
          int dst = new_reg(F);
          IRIns sub; memset(&sub,0,sizeof(sub));
          sub.op=I_BIN; sub.a=dst; sub.b=base; sub.c=idx; sub.binop=B_SUB;
          ir_emit(F,sub);
          if(esz > 1){
            int c = new_reg(F);
            IRIns ic; memset(&ic,0,sizeof(ic));
            ic.op=I_ICONST; ic.a=c; ic.imm=esz;
            ir_emit(F,ic);
            int q = new_reg(F);
            IRIns div; memset(&div,0,sizeof(div));
            div.op=I_BIN; div.a=q; div.b=dst; div.c=c; div.binop=B_DIV;
            ir_emit(F,div);
            return q;
          }
          return dst;
        }

        int scale = idx;
        if(esz != 1){
          int c = new_reg(F);
          IRIns ic; memset(&ic,0,sizeof(ic));
          ic.op=I_ICONST; ic.a=c; ic.imm=esz;
          ir_emit(F,ic);
          int mulr = new_reg(F);
          IRIns mul; memset(&mul,0,sizeof(mul));
          mul.op=I_BIN; mul.a=mulr; mul.b=idx; mul.c=c; mul.binop=B_MUL;
          ir_emit(F,mul);
          scale = mulr;
        }

        int dst = new_reg(F);
        IRIns bin; memset(&bin,0,sizeof(bin));
        bin.op=I_BIN; bin.a=dst; bin.b=base; bin.c=scale;
        bin.binop = (e->bin.op==OP_ADD) ? B_ADD : B_SUB;
        ir_emit(F,bin);
        return dst;
      }"""

idx1 = text.find('if(e->ty && e->ty->k==TY_PTR && e->ty->elem && e->ty->elem->k==TY_FN){')
idx2 = text.find('int use_f = (e->bin.a && is_f64(e->bin.a->ty))')
if idx1 != -1 and idx2 != -1:
    new_text = text[:idx1] + replacement + '\n\n      ' + text[idx2:]
    with open(r'TezzNative-language/src/ir.c', 'w', encoding='utf-8') as f:
        f.write(new_text)
    print('SUCCESS PATCHING IR')
else:
    print(f'FAILED: idx1={idx1}, idx2={idx2}')
