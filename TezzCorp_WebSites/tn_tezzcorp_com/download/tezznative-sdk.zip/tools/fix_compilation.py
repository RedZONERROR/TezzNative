with open(r'TezzNative-language/src/ir_codegen_pe.c', 'r', encoding='utf-8') as f:
    pe_code = f.read()

# Fix the x86 addrsym replacement
pe_code = pe_code.replace("""        if(!done){
          // Gracefully fallback to NULL pointer for unresolved/anonymous symbol
          emit_mov_reg_imm64(cb, 0, 0);
          ra_store_rax(cb, in->a, vreg_to_mreg, nreg);
          done = 1;
        }""", """        if(!done){
          emit_mov_reg_imm64(cb, 0, 0);
          ra_store_rax(cb, in->a, vreg_to_mreg, nreg);
          done = 1;
        }""", 1) # First occurrence is x64

# Second occurrence in x86:
x86_bad = """        if(!done){
          // Gracefully fallback to NULL pointer for unresolved/anonymous symbol
          emit_mov_reg_imm64(cb, 0, 0);
          ra_store_rax(cb, in->a, vreg_to_mreg, nreg);
          done = 1;
        }"""
x86_good = """        if(!done){
          emit_x86_mov_eax_imm32(cb, 0);
          emit_x86_zero_edx(cb);
          if(in->a >= 0) emit_x86_store64(cb, reg_slot_off(in->a));
          done = 1;
        }"""
pe_code = pe_code.replace(x86_bad, x86_good)

with open(r'TezzNative-language/src/ir_codegen_pe.c', 'w', encoding='utf-8') as f:
    f.write(pe_code)

# Fix tnrt.c
with open(r'TezzNative-language/src/tnrt.c', 'r', encoding='utf-8') as f:
    tnrt_code = f.read()

# Revert previous duplicate insertion
dup_needle = """TN_EXPORT long long tn_net_last_error(void){
  return tn_net_last_error_impl();
}
// ------------------------------
// HTTP Download and Networking Aliases
// ------------------------------"""

if dup_needle in tnrt_code:
    # Remove the inserted block
    end_needle = "TN_EXPORT long long tls_close(long long handle){ return tn_tls_close(handle); }\n"
    idx1 = tnrt_code.find("// ------------------------------\n// HTTP Download and Networking Aliases")
    idx2 = tnrt_code.find(end_needle) + len(end_needle)
    if idx1 > 0 and idx2 > idx1:
        tnrt_code = tnrt_code[:idx1] + tnrt_code[idx2:]

# Now append aliases at the very end of tnrt.c
aliases_end = """
// ------------------------------
// Aliases for standard C ABI exports
// ------------------------------
TN_EXPORT long long http_download(unsigned char* url, unsigned char* out_path){
  return tn_http_download(url, out_path);
}
TN_EXPORT long long net_af_inet(void){ return tn_net_af_inet(); }
TN_EXPORT long long net_af_inet6(void){ return tn_net_af_inet6(); }
TN_EXPORT long long net_sock_stream(void){ return tn_net_sock_stream(); }
TN_EXPORT long long net_sock_dgram(void){ return tn_net_sock_dgram(); }
TN_EXPORT long long net_ipproto_tcp(void){ return tn_net_ipproto_tcp(); }
TN_EXPORT long long net_ipproto_udp(void){ return tn_net_ipproto_udp(); }
TN_EXPORT long long net_init(void){ return tn_net_init(); }
TN_EXPORT long long net_cleanup(void){ return tn_net_cleanup(); }
TN_EXPORT long long net_socket(long long fam, long long type, long long proto){ return tn_net_socket(fam, type, proto); }
TN_EXPORT long long net_close(long long sock){ return tn_net_close(sock); }
TN_EXPORT long long net_connect(long long sock, unsigned char* host, long long port){ return tn_net_connect(sock, host, port); }
TN_EXPORT long long net_bind(long long sock, unsigned char* host, long long port){ return tn_net_bind(sock, host, port); }
TN_EXPORT long long net_listen(long long sock, long long backlog){ return tn_net_listen(sock, backlog); }
TN_EXPORT long long net_accept(long long sock){ return tn_net_accept(sock); }
TN_EXPORT long long net_send(long long sock, unsigned char* buf, long long len){ return tn_net_send(sock, buf, len); }
TN_EXPORT long long net_recv(long long sock, unsigned char* buf, long long len){ return tn_net_recv(sock, buf, len); }
TN_EXPORT long long net_set_blocking(long long sock, long long on){ return tn_net_set_blocking(sock, on); }
TN_EXPORT long long net_set_timeout(long long sock, long long ms){ return tn_net_set_timeout(sock, ms); }
TN_EXPORT long long net_last_error(void){ return tn_net_last_error(); }

TN_EXPORT long long tls_connect(unsigned char* host, long long port){ return tn_tls_connect(host, port); }
TN_EXPORT long long tls_send(long long handle, unsigned char* buf, long long len){ return tn_tls_send(handle, buf, len); }
TN_EXPORT long long tls_recv(long long handle, unsigned char* buf, long long len){ return tn_tls_recv(handle, buf, len); }
TN_EXPORT long long tls_close(long long handle){ return tn_tls_close(handle); }
"""

tnrt_code += aliases_end

with open(r'TezzNative-language/src/tnrt.c', 'w', encoding='utf-8') as f:
    f.write(tnrt_code)

print("SUCCESS: Fixed compilation in ir_codegen_pe.c and tnrt.c")
