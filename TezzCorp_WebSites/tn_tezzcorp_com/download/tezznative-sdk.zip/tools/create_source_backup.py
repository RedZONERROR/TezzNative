#!/usr/bin/env python3
"""
create_source_backup.py — Creates a clean, complete source backup archive
for disaster recovery of the TezzNative project.
This archive is placed in TezzCorp_WebSites/tn_tezzcorp_com/ for SSH recovery,
protected from public HTTP web access via .htaccess.
"""

import os
import tarfile
import sys
import time
from pathlib import Path

ROOT_DIR = Path(r"C:\Acer\Code\TezzNative")
OUT_DIR = ROOT_DIR / "TezzCorp_WebSites" / "tn_tezzcorp_com"
OUT_ARCHIVE = OUT_DIR / "tezznative_source_backup.tar.gz"

EXCLUDE_DIRS = {
    ".git", ".gemini", ".vscode", "__pycache__", "build", "dist",
    "cache", "tmp", "temp", ".tezz", "versions", "storage", "logs", "node_modules"
}

EXCLUDE_EXTS = {
    ".obj", ".o", ".pdb", ".ilk", ".exp", ".tmp", ".swp", ".log",
    ".s", ".zip", ".tar.gz", ".gz"
}

EXCLUDE_EXACT = {
    ".env", ".env.bak", ".env.local", "cmd_out.log", "ir_out.log",
    "test_gcd.s", "test_tezzdb.s", "out.s",
    "tezznative_source_backup.tar.gz"
}

def filter_tar(tarinfo: tarfile.TarInfo):
    path_parts = Path(tarinfo.name).parts
    for part in path_parts:
        if part in EXCLUDE_DIRS:
            return None
    if tarinfo.name in EXCLUDE_EXACT or Path(tarinfo.name).name in EXCLUDE_EXACT:
        return None
    ext = Path(tarinfo.name).suffix.lower()
    if ext in EXCLUDE_EXTS:
        return None
    return tarinfo

def main():
    print(f"Creating source recovery archive: {OUT_ARCHIVE}")
    start = time.time()
    
    # We will also create a restore instruction file inside the archive
    restore_sh = OUT_DIR / "restore_from_ssh.sh"
    with open(restore_sh, "w", encoding="utf-8") as f:
        f.write("""#!/usr/bin/env bash
# TezzNative Disaster Recovery Restore Script
# To recover TezzNative from SSH:
# 1. tar -xzf tezznative_source_backup.tar.gz -C /path/to/destination/
# 2. cd /path/to/destination/TezzNative
# 3. All source code, standard library, website, and tools are restored!
echo "Restoring TezzNative source code..."
tar -xzf tezznative_source_backup.tar.gz
echo "Restore complete!"
""")

    count = 0
    with tarfile.open(OUT_ARCHIVE, "w:gz") as tar:
        for root, dirs, files in os.walk(ROOT_DIR):
            # Prune excluded directories
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            
            for file in files:
                ext = Path(file).suffix.lower()
                if ext in EXCLUDE_EXTS or file in EXCLUDE_EXACT:
                    continue
                if file.startswith("tempmedia") or file.endswith(".webp"):
                    continue
                full_path = Path(root) / file
                # If it's already an archive or gigantic binary inside TezzCorp_WebSites (except critical binaries), skip
                rel_path = full_path.relative_to(ROOT_DIR)
                
                # Exclude backup itself
                if str(rel_path).replace("\\", "/").endswith("tezznative_source_backup.tar.gz"):
                    continue
                # Exclude previous large downloads to keep source backup lightweight
                if "tn_tezzcorp_com/download" in str(rel_path).replace("\\", "/") and ext in {".zip", ".tar.gz", ".gz"}:
                    continue
                    
                arcname = f"TezzNative/{rel_path.as_posix()}"
                tar.add(full_path, arcname=arcname, filter=filter_tar)
                count += 1
                if count % 200 == 0:
                    print(f"  Archived {count} files...", flush=True)

    size_mb = OUT_ARCHIVE.stat().st_size / (1024 * 1024)
    duration = time.time() - start
    print(f"SUCCESS: Archived {count} files into {OUT_ARCHIVE} ({size_mb:.2f} MB) in {duration:.2f}s")

if __name__ == "__main__":
    main()
