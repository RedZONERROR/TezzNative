import ftplib
import os

FTP_HOST = "89.116.133.167"
FTP_USER = "u190073748.tezzcorpcom"
FTP_PASS = "TezzMsngr@Api#2026$TezzCorp&9608"

LOCAL_DIR = r"C:\Acer\Code\TezzNative\TezzCorp_WebSites\tn_tezzcorp_com"

def sync_remote_dir(ftp, remote_path, local_path):
    os.makedirs(local_path, exist_ok=True)
    items = []
    ftp.retrlines(f"LIST {remote_path}", items.append)
    
    for line in items:
        parts = line.split(maxsplit=8)
        if len(parts) < 9:
            continue
        perms = parts[0]
        fname = parts[8]
        if fname in ('.', '..'):
            continue
        
        rem_item = f"{remote_path}/{fname}"
        loc_item = os.path.join(local_path, fname)
        
        if perms.startswith('d'):
            sync_remote_dir(ftp, rem_item, loc_item)
        else:
            print(f"Downloading {rem_item} -> {loc_item}")
            with open(loc_item, 'wb') as f:
                ftp.retrbinary(f"RETR {rem_item}", f.write)

print("Connecting to FTP host:", FTP_HOST)
ftp = ftplib.FTP(FTP_HOST, timeout=30)
ftp.login(FTP_USER, FTP_PASS)
ftp.set_pasv(True)
print("Syncing tn.tezzcorp.com to", LOCAL_DIR)
sync_remote_dir(ftp, "tn.tezzcorp.com", LOCAL_DIR)
ftp.quit()
print("Website files synced completely!")
