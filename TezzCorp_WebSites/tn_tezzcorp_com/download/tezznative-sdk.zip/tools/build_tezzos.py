import os
import subprocess
import glob

def main():
    print("[*] Building TezzOS Kernel 100% in TezzNative Language...")
    os.makedirs("build", exist_ok=True)

    # 1. Compile TezzNative Kernel Source to Freestanding Assembly
    kernel_tn = "examples/tezzos_kernel.tn"
    kernel_s = "build/tezzos_kernel.s"
    print(f"[*] Compiling {kernel_tn} -> {kernel_s} (--freestanding)...")
    subprocess.run([".\\tezzc.exe", "buildir", kernel_tn, kernel_s, "--freestanding"], check=True)

    # 2. Assemble Kernel Assembly to ELF Object
    kernel_o = "build/tezzos_kernel.o"
    print(f"[*] Assembling {kernel_s} -> {kernel_o}...")
    subprocess.run(["clang", "-c", "-target", "x86_64-unknown-none-elf", "-ffreestanding", "-fno-stack-protector", "-mno-red-zone", "-mcmodel=large", kernel_s, "-o", kernel_o], check=True)

    # 3. Compile Limine / Baremetal Boot Support Objects
    boot_dir = "TezzNative-language/runtime/boot/x86_64"
    c_files = glob.glob(f"{boot_dir}/*.c")
    s_files = glob.glob(f"{boot_dir}/*.S")
    obj_files = [kernel_o]

    for c in c_files:
        obj = os.path.join("build", os.path.basename(c) + ".o")
        print(f"[*] Compiling {c} -> {obj}...")
        subprocess.run([
            "clang", "-c", "-target", "x86_64-unknown-none-elf",
            "-ffreestanding", "-fno-stack-protector", "-mno-red-zone", "-fno-builtin",
            "-mcmodel=large",
            "-I", "TezzNative-language/runtime/boot/limine",
            "-I", boot_dir,
            c, "-o", obj
        ], check=True)
        obj_files.append(obj)

    for s in s_files:
        if "grub_mb2" in s:
            continue # GRUB multiboot2 is only for 32-bit boot_grub.ld
        obj = os.path.join("build", os.path.basename(s) + ".o")
        print(f"[*] Assembling {s} -> {obj}...")
        subprocess.run([
            "clang", "-c", "-target", "x86_64-unknown-none-elf",
            "-ffreestanding", "-fno-stack-protector", "-mno-red-zone",
            "-mcmodel=large",
            s, "-o", obj
        ], check=True)
        obj_files.append(obj)

    # 4. Link into TezzOS ELF Kernel
    linker_script = f"{boot_dir}/boot.ld"
    kernel_elf = "build/tezzos.elf"
    print(f"[*] Linking TezzOS Kernel binary: {kernel_elf}...")

    # Locate ld.lld
    ld_lld = "ld.lld"
    clang_dir = os.path.dirname(subprocess.check_output(["where", "clang"]).decode().splitlines()[0].strip())
    cand_lld = os.path.join(clang_dir, "ld.lld.exe")
    if os.path.exists(cand_lld):
        ld_lld = cand_lld

    link_cmd = [
        ld_lld,
        "-m", "elf_x86_64",
        "-T", linker_script,
        "-nostdlib", "-static",
        "-z", "max-page-size=0x1000",
        "-o", kernel_elf
    ] + obj_files

    subprocess.run(link_cmd, check=True)
    size_kb = os.path.getsize(kernel_elf) / 1024.0
    print(f"[SUCCESS] TezzOS Kernel binary generated: {kernel_elf} ({size_kb:.1f} KB)")
    print("[+] TezzOS is fully buildable directly from TezzNative language in 100% freestanding mode!")

if __name__ == "__main__":
    main()
