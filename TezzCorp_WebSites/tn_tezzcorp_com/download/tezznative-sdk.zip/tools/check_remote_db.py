import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from ssh_helper import run_remote

check_script = """php -r '
try {
    $pdo = new PDO("mysql:host=localhost;dbname=u190073748_tezz_official_;charset=utf8mb4", "u190073748_tezz_usr__vr__", "TezzCorpOfficial#@2026", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    echo "DB_CONNECTION_SUCCESS\\n";
    $stmt = $pdo->query("SHOW TABLES");
    while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
        echo "TABLE: " . $row[0] . "\\n";
    }
} catch (Exception $e) {
    echo "DB_ERROR: " . $e->getMessage() . "\\n";
}
'"""

out, err = run_remote(check_script)
print("OUTPUT:\n", out)
if err:
    print("ERROR:\n", err)
