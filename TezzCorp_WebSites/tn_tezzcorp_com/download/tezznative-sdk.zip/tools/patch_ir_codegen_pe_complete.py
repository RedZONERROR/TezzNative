import re

with open(r'TezzNative-language/src/ir_codegen_pe.c', 'r', encoding='utf-8') as f:
    code = f.read()

# 1. Update build_pe_imports implementation
old_build_pe_imports = """static int build_pe_imports(unsigned char* rdata, uint32_t rdata_rva, uint32_t ptr_size,
                            PeImportInfo* out){
  if(!rdata || !out) return -1;
  if(ptr_size != 4 && ptr_size != 8) return -1;

  const char* k_dll = "kernel32.dll";
  const char* k_funcs[] = {
    "ExitProcess",                          // 0
    "GetStdHandle",                         // 1
    "WriteFile",                            // 2
    "lstrlenA",                             // 3
    "lstrcmpA",                             // 4
    "GetSystemTimePreciseAsFileTime",        // 5
    "VirtualAlloc",                         // 6
    "VirtualFree",                          // 7
    "CreateFileA",                          // 8
    "CloseHandle",                          // 9
    "DeleteFileA",                          // 10
    "MoveFileA",                            // 11
    "GetFileSizeEx",                        // 12
    "ReadFile",                             // 13
    "Sleep",                                // 14
    "GetFileAttributesA",                   // 15
    "CreateDirectoryA",                     // 16
    "RemoveDirectoryA",                     // 17
    "GetCurrentDirectoryA",                 // 18
    "CreateFileMappingA",                   // 19
    "MapViewOfFile",                        // 20
    "UnmapViewOfFile",                      // 21
    "CreateThread",                         // 22
    "WaitForSingleObject"                   // 23
  };
  const int k_n = 24;
  const char* u_dll = "user32.dll";
  const char* u_funcs[] = {"wsprintfA"};
  const int u_n = 1;
  const char* m_dll = "msvcrt.dll";
  const char* m_funcs[] = {
    "sprintf",
    "memcpy",
    "memmove",
    "memcmp",
    "system",
    "putchar",
    "getchar",
    "realloc"
  };
  const int m_n = 8;
  // UCRT: file I/O needed by io module
  const char* c_dll = "ucrtbase.dll";
  const char* c_funcs[] = {
    "fopen",        // 0
    "fclose",       // 1
    "fread",        // 2
    "fwrite",       // 3
    "fseek",        // 4
    "ftell",        // 5
    "fflush",       // 6
    "remove",       // 7
    "rename",       // 8
    "fgets",        // 9
    "ferror",       // 10
    "feof",         // 11
    "getenv"        // 12
  };
  const int c_n = 13;

  const int ndll = 4;
  const uint32_t desc_size = 20u * (uint32_t)(ndll + 1);
  uint32_t cur = desc_size;

  uint32_t ilt_off[4];
  uint32_t iat_off[4];
  uint32_t dll_off[4];
  uint32_t hint_off_k[24];
  uint32_t hint_off_u[1];
  uint32_t hint_off_m[8];
  uint32_t hint_off_c[13];

  ilt_off[0] = cur; cur += (uint32_t)ptr_size * (uint32_t)(k_n + 1);
  ilt_off[1] = cur; cur += (uint32_t)ptr_size * (uint32_t)(u_n + 1);
  ilt_off[2] = cur; cur += (uint32_t)ptr_size * (uint32_t)(m_n + 1);
  ilt_off[3] = cur; cur += (uint32_t)ptr_size * (uint32_t)(c_n + 1);

  iat_off[0] = cur; cur += (uint32_t)ptr_size * (uint32_t)(k_n + 1);
  iat_off[1] = cur; cur += (uint32_t)ptr_size * (uint32_t)(u_n + 1);
  iat_off[2] = cur; cur += (uint32_t)ptr_size * (uint32_t)(m_n + 1);
  iat_off[3] = cur; cur += (uint32_t)ptr_size * (uint32_t)(c_n + 1);

  for(int i=0;i<k_n;i++){
    if(cur & 1u) cur++;
    hint_off_k[i] = cur;
    cur += 2 + (uint32_t)strlen(k_funcs[i]) + 1;
  }
  for(int i=0;i<u_n;i++){
    if(cur & 1u) cur++;
    hint_off_u[i] = cur;
    cur += 2 + (uint32_t)strlen(u_funcs[i]) + 1;
  }
  for(int i=0;i<m_n;i++){
    if(cur & 1u) cur++;
    hint_off_m[i] = cur;
    cur += 2 + (uint32_t)strlen(m_funcs[i]) + 1;
  }
  for(int i=0;i<c_n;i++){
    if(cur & 1u) cur++;
    hint_off_c[i] = cur;
    cur += 2 + (uint32_t)strlen(c_funcs[i]) + 1;
  }

  if(cur & 1u) cur++;
  dll_off[0] = cur; cur += (uint32_t)strlen(k_dll) + 1;
  if(cur & 1u) cur++;
  dll_off[1] = cur; cur += (uint32_t)strlen(u_dll) + 1;
  if(cur & 1u) cur++;
  dll_off[2] = cur; cur += (uint32_t)strlen(m_dll) + 1;
  if(cur & 1u) cur++;
  dll_off[3] = cur; cur += (uint32_t)strlen(c_dll) + 1;

  memset(rdata, 0, cur);

  // Descriptor 0: kernel32
  put_u32_le(rdata + 0 + 0, rdata_rva + ilt_off[0]);
  put_u32_le(rdata + 0 + 12, rdata_rva + dll_off[0]);
  put_u32_le(rdata + 0 + 16, rdata_rva + iat_off[0]);
  // Descriptor 1: user32
  put_u32_le(rdata + 20 + 0, rdata_rva + ilt_off[1]);
  put_u32_le(rdata + 20 + 12, rdata_rva + dll_off[1]);
  put_u32_le(rdata + 20 + 16, rdata_rva + iat_off[1]);
  // Descriptor 2: msvcrt
  put_u32_le(rdata + 40 + 0, rdata_rva + ilt_off[2]);
  put_u32_le(rdata + 40 + 12, rdata_rva + dll_off[2]);
  put_u32_le(rdata + 40 + 16, rdata_rva + iat_off[2]);
  // Descriptor 3: ucrtbase
  put_u32_le(rdata + 60 + 0, rdata_rva + ilt_off[3]);
  put_u32_le(rdata + 60 + 12, rdata_rva + dll_off[3]);
  put_u32_le(rdata + 60 + 16, rdata_rva + iat_off[3]);

  // ILT/IAT kernel32
  for(int i=0;i<k_n;i++){
    uint32_t hrva = rdata_rva + hint_off_k[i];
    if(ptr_size == 8){
      put_u64_le(rdata + ilt_off[0] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
      put_u64_le(rdata + iat_off[0] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
    } else {
      put_u32_le(rdata + ilt_off[0] + (uint32_t)ptr_size * (uint32_t)i, hrva);
      put_u32_le(rdata + iat_off[0] + (uint32_t)ptr_size * (uint32_t)i, hrva);
    }
  }
  // ILT/IAT user32
  for(int i=0;i<u_n;i++){
    uint32_t hrva = rdata_rva + hint_off_u[i];
    if(ptr_size == 8){
      put_u64_le(rdata + ilt_off[1] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
      put_u64_le(rdata + iat_off[1] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
    } else {
      put_u32_le(rdata + ilt_off[1] + (uint32_t)ptr_size * (uint32_t)i, hrva);
      put_u32_le(rdata + iat_off[1] + (uint32_t)ptr_size * (uint32_t)i, hrva);
    }
  }
  // ILT/IAT msvcrt
  for(int i=0;i<m_n;i++){
    uint32_t hrva = rdata_rva + hint_off_m[i];
    if(ptr_size == 8){
      put_u64_le(rdata + ilt_off[2] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
      put_u64_le(rdata + iat_off[2] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
    } else {
      put_u32_le(rdata + ilt_off[2] + (uint32_t)ptr_size * (uint32_t)i, hrva);
      put_u32_le(rdata + iat_off[2] + (uint32_t)ptr_size * (uint32_t)i, hrva);
    }
  }
  // ILT/IAT ucrtbase
  for(int i=0;i<c_n;i++){
    uint32_t hrva = rdata_rva + hint_off_c[i];
    if(ptr_size == 8){
      put_u64_le(rdata + ilt_off[3] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
      put_u64_le(rdata + iat_off[3] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
    } else {
      put_u32_le(rdata + ilt_off[3] + (uint32_t)ptr_size * (uint32_t)i, hrva);
      put_u32_le(rdata + iat_off[3] + (uint32_t)ptr_size * (uint32_t)i, hrva);
    }
  }

  // Hint/name strings
  for(int i=0;i<k_n;i++){
    rdata[hint_off_k[i] + 0] = 0;
    rdata[hint_off_k[i] + 1] = 0;
    memcpy(rdata + hint_off_k[i] + 2, k_funcs[i], strlen(k_funcs[i]) + 1);
  }
  for(int i=0;i<u_n;i++){
    rdata[hint_off_u[i] + 0] = 0;
    rdata[hint_off_u[i] + 1] = 0;
    memcpy(rdata + hint_off_u[i] + 2, u_funcs[i], strlen(u_funcs[i]) + 1);
  }
  for(int i=0;i<m_n;i++){
    rdata[hint_off_m[i] + 0] = 0;
    rdata[hint_off_m[i] + 1] = 0;
    memcpy(rdata + hint_off_m[i] + 2, m_funcs[i], strlen(m_funcs[i]) + 1);
  }
  for(int i=0;i<c_n;i++){
    rdata[hint_off_c[i] + 0] = 0;
    rdata[hint_off_c[i] + 1] = 0;
    memcpy(rdata + hint_off_c[i] + 2, c_funcs[i], strlen(c_funcs[i]) + 1);
  }
  memcpy(rdata + dll_off[0], k_dll, strlen(k_dll) + 1);
  memcpy(rdata + dll_off[1], u_dll, strlen(u_dll) + 1);
  memcpy(rdata + dll_off[2], m_dll, strlen(m_dll) + 1);
  memcpy(rdata + dll_off[3], c_dll, strlen(c_dll) + 1);
  out->import_size = cur;
  out->iat_exit    = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 0u;
  out->iat_getstd  = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 1u;
  out->iat_write   = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 2u;
  out->iat_lstrlen = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 3u;
  out->iat_lstrcmp = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 4u;
  out->iat_gettime = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 5u;
  out->iat_valloc  = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 6u;
  out->iat_vfree   = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 7u;
  out->iat_createfile = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 8u;
  out->iat_closehandle= rdata_rva + iat_off[0] + (uint32_t)ptr_size * 9u;
  out->iat_deletefile = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 10u;
  out->iat_movefile   = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 11u;
  out->iat_getfilesize= rdata_rva + iat_off[0] + (uint32_t)ptr_size * 12u;
  out->iat_readfile   = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 13u;
  out->iat_sleep      = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 14u;
  out->iat_getfileattr= rdata_rva + iat_off[0] + (uint32_t)ptr_size * 15u;
  out->iat_createdir  = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 16u;
  out->iat_removedir  = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 17u;
  out->iat_getcurdir  = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 18u;
  out->iat_createfilemap = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 19u;
  out->iat_mapview       = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 20u;
  out->iat_unmapview     = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 21u;
  out->iat_createthread   = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 22u;
  out->iat_waitforsingleobject = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 23u;
  out->iat_wsprintf   = rdata_rva + iat_off[1] + (uint32_t)ptr_size * 0u;
  out->iat_sprintf = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 0u;
  out->iat_memcpy  = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 1u;
  out->iat_memmove = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 2u;
  out->iat_memcmp  = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 3u;
  out->iat_system  = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 4u;
  out->iat_putchar = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 5u;
  out->iat_getchar = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 6u;
  out->iat_realloc = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 7u;
  out->iat_getenv  = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 12u;
  // ucrtbase.dll: fopen=0,fclose=1,fread=2,fwrite=3,fseek=4,ftell=5,fflush=6,remove=7,rename=8,__iob_func=9,ferror=10,feof=11
  out->iat_fopen  = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 0u;
  out->iat_fclose = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 1u;
  out->iat_fread  = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 2u;
  out->iat_fwrite = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 3u;
  out->iat_fseek  = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 4u;
  out->iat_ftell  = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 5u;
  out->iat_fflush = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 6u;
  out->iat_io_err  = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 10u; // ferror
  out->iat_io_eof  = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 11u; // feof
  // read_line/write_line/stdin/stdout/stderr not directly in IAT (handled via runtime)
  out->iat_read_line  = 0;
  out->iat_read_bytes = 0;
  out->iat_write_line = 0;
  out->iat_stdin  = 0;
  out->iat_stdout = 0;
  out->iat_stderr = 0;
  return (int)cur;
}"""

new_build_pe_imports = """static int build_pe_imports(unsigned char* rdata, uint32_t rdata_rva, uint32_t ptr_size,
                            PeImportInfo* out){
  if(!rdata || !out) return -1;
  if(ptr_size != 4 && ptr_size != 8) return -1;

  const char* k_dll = "kernel32.dll";
  const char* k_funcs[] = {
    "ExitProcess",                          // 0
    "GetStdHandle",                         // 1
    "WriteFile",                            // 2
    "lstrlenA",                             // 3
    "lstrcmpA",                             // 4
    "GetSystemTimePreciseAsFileTime",        // 5
    "VirtualAlloc",                         // 6
    "VirtualFree",                          // 7
    "CreateFileA",                          // 8
    "CloseHandle",                          // 9
    "DeleteFileA",                          // 10
    "MoveFileA",                            // 11
    "GetFileSizeEx",                        // 12
    "ReadFile",                             // 13
    "Sleep",                                // 14
    "GetFileAttributesA",                   // 15
    "CreateDirectoryA",                     // 16
    "RemoveDirectoryA",                     // 17
    "GetCurrentDirectoryA",                 // 18
    "CreateFileMappingA",                   // 19
    "MapViewOfFile",                        // 20
    "UnmapViewOfFile",                      // 21
    "CreateThread",                         // 22
    "WaitForSingleObject"                   // 23
  };
  const int k_n = 24;
  const char* u_dll = "user32.dll";
  const char* u_funcs[] = {"wsprintfA"};
  const int u_n = 1;
  const char* m_dll = "msvcrt.dll";
  const char* m_funcs[] = {
    "sprintf",     // 0
    "memcpy",      // 1
    "memmove",     // 2
    "memcmp",      // 3
    "system",      // 4
    "putchar",     // 5
    "getchar",     // 6
    "realloc",     // 7
    "puts",        // 8
    "printf",      // 9
    "sqrt",        // 10
    "sin",         // 11
    "cos",         // 12
    "pow",         // 13
    "floor",       // 14
    "ceil",        // 15
    "fabs"         // 16
  };
  const int m_n = 17;
  // UCRT: file I/O needed by io module
  const char* c_dll = "ucrtbase.dll";
  const char* c_funcs[] = {
    "fopen",        // 0
    "fclose",       // 1
    "fread",        // 2
    "fwrite",       // 3
    "fseek",        // 4
    "ftell",        // 5
    "fflush",       // 6
    "remove",       // 7
    "rename",       // 8
    "fgets",        // 9
    "ferror",       // 10
    "feof",         // 11
    "getenv"        // 12
  };
  const int c_n = 13;

  const char* w_dll = "ws2_32.dll";
  const char* w_funcs[] = {
    "WSAStartup",        // 0
    "WSACleanup",        // 1
    "socket",            // 2
    "closesocket",       // 3
    "bind",              // 4
    "listen",            // 5
    "accept",            // 6
    "connect",           // 7
    "send",              // 8
    "recv",              // 9
    "ioctlsocket",       // 10
    "WSAGetLastError",   // 11
    "htons",             // 12
    "ntohs",             // 13
    "inet_addr"          // 14
  };
  const int w_n = 15;

  const char* url_dll = "urlmon.dll";
  const char* url_funcs[] = {
    "URLDownloadToFileA" // 0
  };
  const int url_n = 1;

  const int ndll = 6;
  const uint32_t desc_size = 20u * (uint32_t)(ndll + 1);
  uint32_t cur = desc_size;

  uint32_t ilt_off[6];
  uint32_t iat_off[6];
  uint32_t dll_off[6];
  uint32_t hint_off_k[24];
  uint32_t hint_off_u[1];
  uint32_t hint_off_m[17];
  uint32_t hint_off_c[13];
  uint32_t hint_off_w[15];
  uint32_t hint_off_url[1];

  ilt_off[0] = cur; cur += (uint32_t)ptr_size * (uint32_t)(k_n + 1);
  ilt_off[1] = cur; cur += (uint32_t)ptr_size * (uint32_t)(u_n + 1);
  ilt_off[2] = cur; cur += (uint32_t)ptr_size * (uint32_t)(m_n + 1);
  ilt_off[3] = cur; cur += (uint32_t)ptr_size * (uint32_t)(c_n + 1);
  ilt_off[4] = cur; cur += (uint32_t)ptr_size * (uint32_t)(w_n + 1);
  ilt_off[5] = cur; cur += (uint32_t)ptr_size * (uint32_t)(url_n + 1);

  iat_off[0] = cur; cur += (uint32_t)ptr_size * (uint32_t)(k_n + 1);
  iat_off[1] = cur; cur += (uint32_t)ptr_size * (uint32_t)(u_n + 1);
  iat_off[2] = cur; cur += (uint32_t)ptr_size * (uint32_t)(m_n + 1);
  iat_off[3] = cur; cur += (uint32_t)ptr_size * (uint32_t)(c_n + 1);
  iat_off[4] = cur; cur += (uint32_t)ptr_size * (uint32_t)(w_n + 1);
  iat_off[5] = cur; cur += (uint32_t)ptr_size * (uint32_t)(url_n + 1);

  for(int i=0;i<k_n;i++){
    if(cur & 1u) cur++;
    hint_off_k[i] = cur;
    cur += 2 + (uint32_t)strlen(k_funcs[i]) + 1;
  }
  for(int i=0;i<u_n;i++){
    if(cur & 1u) cur++;
    hint_off_u[i] = cur;
    cur += 2 + (uint32_t)strlen(u_funcs[i]) + 1;
  }
  for(int i=0;i<m_n;i++){
    if(cur & 1u) cur++;
    hint_off_m[i] = cur;
    cur += 2 + (uint32_t)strlen(m_funcs[i]) + 1;
  }
  for(int i=0;i<c_n;i++){
    if(cur & 1u) cur++;
    hint_off_c[i] = cur;
    cur += 2 + (uint32_t)strlen(c_funcs[i]) + 1;
  }
  for(int i=0;i<w_n;i++){
    if(cur & 1u) cur++;
    hint_off_w[i] = cur;
    cur += 2 + (uint32_t)strlen(w_funcs[i]) + 1;
  }
  for(int i=0;i<url_n;i++){
    if(cur & 1u) cur++;
    hint_off_url[i] = cur;
    cur += 2 + (uint32_t)strlen(url_funcs[i]) + 1;
  }

  if(cur & 1u) cur++;
  dll_off[0] = cur; cur += (uint32_t)strlen(k_dll) + 1;
  if(cur & 1u) cur++;
  dll_off[1] = cur; cur += (uint32_t)strlen(u_dll) + 1;
  if(cur & 1u) cur++;
  dll_off[2] = cur; cur += (uint32_t)strlen(m_dll) + 1;
  if(cur & 1u) cur++;
  dll_off[3] = cur; cur += (uint32_t)strlen(c_dll) + 1;
  if(cur & 1u) cur++;
  dll_off[4] = cur; cur += (uint32_t)strlen(w_dll) + 1;
  if(cur & 1u) cur++;
  dll_off[5] = cur; cur += (uint32_t)strlen(url_dll) + 1;

  memset(rdata, 0, cur);

  // Descriptor 0: kernel32
  put_u32_le(rdata + 0 + 0, rdata_rva + ilt_off[0]);
  put_u32_le(rdata + 0 + 12, rdata_rva + dll_off[0]);
  put_u32_le(rdata + 0 + 16, rdata_rva + iat_off[0]);
  // Descriptor 1: user32
  put_u32_le(rdata + 20 + 0, rdata_rva + ilt_off[1]);
  put_u32_le(rdata + 20 + 12, rdata_rva + dll_off[1]);
  put_u32_le(rdata + 20 + 16, rdata_rva + iat_off[1]);
  // Descriptor 2: msvcrt
  put_u32_le(rdata + 40 + 0, rdata_rva + ilt_off[2]);
  put_u32_le(rdata + 40 + 12, rdata_rva + dll_off[2]);
  put_u32_le(rdata + 40 + 16, rdata_rva + iat_off[2]);
  // Descriptor 3: ucrtbase
  put_u32_le(rdata + 60 + 0, rdata_rva + ilt_off[3]);
  put_u32_le(rdata + 60 + 12, rdata_rva + dll_off[3]);
  put_u32_le(rdata + 60 + 16, rdata_rva + iat_off[3]);
  // Descriptor 4: ws2_32
  put_u32_le(rdata + 80 + 0, rdata_rva + ilt_off[4]);
  put_u32_le(rdata + 80 + 12, rdata_rva + dll_off[4]);
  put_u32_le(rdata + 80 + 16, rdata_rva + iat_off[4]);
  // Descriptor 5: urlmon
  put_u32_le(rdata + 100 + 0, rdata_rva + ilt_off[5]);
  put_u32_le(rdata + 100 + 12, rdata_rva + dll_off[5]);
  put_u32_le(rdata + 100 + 16, rdata_rva + iat_off[5]);

  // ILT/IAT kernel32
  for(int i=0;i<k_n;i++){
    uint32_t hrva = rdata_rva + hint_off_k[i];
    if(ptr_size == 8){
      put_u64_le(rdata + ilt_off[0] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
      put_u64_le(rdata + iat_off[0] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
    } else {
      put_u32_le(rdata + ilt_off[0] + (uint32_t)ptr_size * (uint32_t)i, hrva);
      put_u32_le(rdata + iat_off[0] + (uint32_t)ptr_size * (uint32_t)i, hrva);
    }
  }
  // ILT/IAT user32
  for(int i=0;i<u_n;i++){
    uint32_t hrva = rdata_rva + hint_off_u[i];
    if(ptr_size == 8){
      put_u64_le(rdata + ilt_off[1] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
      put_u64_le(rdata + iat_off[1] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
    } else {
      put_u32_le(rdata + ilt_off[1] + (uint32_t)ptr_size * (uint32_t)i, hrva);
      put_u32_le(rdata + iat_off[1] + (uint32_t)ptr_size * (uint32_t)i, hrva);
    }
  }
  // ILT/IAT msvcrt
  for(int i=0;i<m_n;i++){
    uint32_t hrva = rdata_rva + hint_off_m[i];
    if(ptr_size == 8){
      put_u64_le(rdata + ilt_off[2] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
      put_u64_le(rdata + iat_off[2] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
    } else {
      put_u32_le(rdata + ilt_off[2] + (uint32_t)ptr_size * (uint32_t)i, hrva);
      put_u32_le(rdata + iat_off[2] + (uint32_t)ptr_size * (uint32_t)i, hrva);
    }
  }
  // ILT/IAT ucrtbase
  for(int i=0;i<c_n;i++){
    uint32_t hrva = rdata_rva + hint_off_c[i];
    if(ptr_size == 8){
      put_u64_le(rdata + ilt_off[3] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
      put_u64_le(rdata + iat_off[3] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
    } else {
      put_u32_le(rdata + ilt_off[3] + (uint32_t)ptr_size * (uint32_t)i, hrva);
      put_u32_le(rdata + iat_off[3] + (uint32_t)ptr_size * (uint32_t)i, hrva);
    }
  }
  // ILT/IAT ws2_32
  for(int i=0;i<w_n;i++){
    uint32_t hrva = rdata_rva + hint_off_w[i];
    if(ptr_size == 8){
      put_u64_le(rdata + ilt_off[4] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
      put_u64_le(rdata + iat_off[4] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
    } else {
      put_u32_le(rdata + ilt_off[4] + (uint32_t)ptr_size * (uint32_t)i, hrva);
      put_u32_le(rdata + iat_off[4] + (uint32_t)ptr_size * (uint32_t)i, hrva);
    }
  }
  // ILT/IAT urlmon
  for(int i=0;i<url_n;i++){
    uint32_t hrva = rdata_rva + hint_off_url[i];
    if(ptr_size == 8){
      put_u64_le(rdata + ilt_off[5] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
      put_u64_le(rdata + iat_off[5] + (uint32_t)ptr_size * (uint32_t)i, (uint64_t)hrva);
    } else {
      put_u32_le(rdata + ilt_off[5] + (uint32_t)ptr_size * (uint32_t)i, hrva);
      put_u32_le(rdata + iat_off[5] + (uint32_t)ptr_size * (uint32_t)i, hrva);
    }
  }

  // Hint/name strings
  for(int i=0;i<k_n;i++){
    rdata[hint_off_k[i] + 0] = 0;
    rdata[hint_off_k[i] + 1] = 0;
    memcpy(rdata + hint_off_k[i] + 2, k_funcs[i], strlen(k_funcs[i]) + 1);
  }
  for(int i=0;i<u_n;i++){
    rdata[hint_off_u[i] + 0] = 0;
    rdata[hint_off_u[i] + 1] = 0;
    memcpy(rdata + hint_off_u[i] + 2, u_funcs[i], strlen(u_funcs[i]) + 1);
  }
  for(int i=0;i<m_n;i++){
    rdata[hint_off_m[i] + 0] = 0;
    rdata[hint_off_m[i] + 1] = 0;
    memcpy(rdata + hint_off_m[i] + 2, m_funcs[i], strlen(m_funcs[i]) + 1);
  }
  for(int i=0;i<c_n;i++){
    rdata[hint_off_c[i] + 0] = 0;
    rdata[hint_off_c[i] + 1] = 0;
    memcpy(rdata + hint_off_c[i] + 2, c_funcs[i], strlen(c_funcs[i]) + 1);
  }
  for(int i=0;i<w_n;i++){
    rdata[hint_off_w[i] + 0] = 0;
    rdata[hint_off_w[i] + 1] = 0;
    memcpy(rdata + hint_off_w[i] + 2, w_funcs[i], strlen(w_funcs[i]) + 1);
  }
  for(int i=0;i<url_n;i++){
    rdata[hint_off_url[i] + 0] = 0;
    rdata[hint_off_url[i] + 1] = 0;
    memcpy(rdata + hint_off_url[i] + 2, url_funcs[i], strlen(url_funcs[i]) + 1);
  }
  memcpy(rdata + dll_off[0], k_dll, strlen(k_dll) + 1);
  memcpy(rdata + dll_off[1], u_dll, strlen(u_dll) + 1);
  memcpy(rdata + dll_off[2], m_dll, strlen(m_dll) + 1);
  memcpy(rdata + dll_off[3], c_dll, strlen(c_dll) + 1);
  memcpy(rdata + dll_off[4], w_dll, strlen(w_dll) + 1);
  memcpy(rdata + dll_off[5], url_dll, strlen(url_dll) + 1);

  out->import_size = cur;
  out->iat_exit    = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 0u;
  out->iat_getstd  = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 1u;
  out->iat_write   = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 2u;
  out->iat_lstrlen = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 3u;
  out->iat_lstrcmp = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 4u;
  out->iat_gettime = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 5u;
  out->iat_valloc  = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 6u;
  out->iat_vfree   = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 7u;
  out->iat_createfile = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 8u;
  out->iat_closehandle= rdata_rva + iat_off[0] + (uint32_t)ptr_size * 9u;
  out->iat_deletefile = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 10u;
  out->iat_movefile   = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 11u;
  out->iat_getfilesize= rdata_rva + iat_off[0] + (uint32_t)ptr_size * 12u;
  out->iat_readfile   = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 13u;
  out->iat_sleep      = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 14u;
  out->iat_getfileattr= rdata_rva + iat_off[0] + (uint32_t)ptr_size * 15u;
  out->iat_createdir  = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 16u;
  out->iat_removedir  = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 17u;
  out->iat_getcurdir  = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 18u;
  out->iat_createfilemap = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 19u;
  out->iat_mapview       = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 20u;
  out->iat_unmapview     = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 21u;
  out->iat_createthread   = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 22u;
  out->iat_waitforsingleobject = rdata_rva + iat_off[0] + (uint32_t)ptr_size * 23u;
  out->iat_wsprintf   = rdata_rva + iat_off[1] + (uint32_t)ptr_size * 0u;

  out->iat_sprintf = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 0u;
  out->iat_memcpy  = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 1u;
  out->iat_memmove = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 2u;
  out->iat_memcmp  = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 3u;
  out->iat_system  = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 4u;
  out->iat_putchar = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 5u;
  out->iat_getchar = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 6u;
  out->iat_realloc = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 7u;
  out->iat_puts    = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 8u;
  out->iat_printf  = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 9u;
  out->iat_sqrt    = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 10u;
  out->iat_sin     = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 11u;
  out->iat_cos     = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 12u;
  out->iat_pow     = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 13u;
  out->iat_floor   = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 14u;
  out->iat_ceil    = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 15u;
  out->iat_fabs    = rdata_rva + iat_off[2] + (uint32_t)ptr_size * 16u;

  out->iat_fopen   = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 0u;
  out->iat_fclose  = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 1u;
  out->iat_fread   = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 2u;
  out->iat_fwrite  = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 3u;
  out->iat_fseek   = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 4u;
  out->iat_ftell   = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 5u;
  out->iat_fflush  = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 6u;
  out->iat_io_err  = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 10u; // ferror
  out->iat_io_eof  = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 11u; // feof
  out->iat_getenv  = rdata_rva + iat_off[3] + (uint32_t)ptr_size * 12u;

  out->iat_wsastartup     = rdata_rva + iat_off[4] + (uint32_t)ptr_size * 0u;
  out->iat_wsacleanup     = rdata_rva + iat_off[4] + (uint32_t)ptr_size * 1u;
  out->iat_socket         = rdata_rva + iat_off[4] + (uint32_t)ptr_size * 2u;
  out->iat_closesocket    = rdata_rva + iat_off[4] + (uint32_t)ptr_size * 3u;
  out->iat_bind           = rdata_rva + iat_off[4] + (uint32_t)ptr_size * 4u;
  out->iat_listen         = rdata_rva + iat_off[4] + (uint32_t)ptr_size * 5u;
  out->iat_accept         = rdata_rva + iat_off[4] + (uint32_t)ptr_size * 6u;
  out->iat_connect        = rdata_rva + iat_off[4] + (uint32_t)ptr_size * 7u;
  out->iat_send           = rdata_rva + iat_off[4] + (uint32_t)ptr_size * 8u;
  out->iat_recv           = rdata_rva + iat_off[4] + (uint32_t)ptr_size * 9u;
  out->iat_ioctlsocket    = rdata_rva + iat_off[4] + (uint32_t)ptr_size * 10u;
  out->iat_wsagetlasterror= rdata_rva + iat_off[4] + (uint32_t)ptr_size * 11u;
  out->iat_htons          = rdata_rva + iat_off[4] + (uint32_t)ptr_size * 12u;
  out->iat_ntohs          = rdata_rva + iat_off[4] + (uint32_t)ptr_size * 13u;
  out->iat_inet_addr      = rdata_rva + iat_off[4] + (uint32_t)ptr_size * 14u;

  out->iat_urldownloadtofile = rdata_rva + iat_off[5] + (uint32_t)ptr_size * 0u;

  out->iat_read_line  = out->iat_fread;
  out->iat_read_bytes = out->iat_fread;
  out->iat_write_line = out->iat_puts;
  out->iat_stdin  = out->iat_getstd;
  out->iat_stdout = out->iat_getstd;
  out->iat_stderr = out->iat_getstd;
  return (int)cur;
}"""

code = code.replace(old_build_pe_imports, new_build_pe_imports)

with open(r'TezzNative-language/src/ir_codegen_pe.c', 'w', encoding='utf-8') as f:
    f.write(code)

print("SUCCESS: Updated build_pe_imports in ir_codegen_pe.c")
