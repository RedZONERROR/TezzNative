#!/usr/bin/env python3
"""
deploy_portal_and_backup.py — SFTP deployment script to Hostinger server.
Uploads:
1. All updated web portal files (PHP, CSS, JS, .htaccess, navigation, community portal)
2. All updated release artifacts in download/ (SDK zip, installer, DLLs, manifest)
3. The complete disaster recovery source archive (tezznative_source_backup.tar.gz)
Uses tools/ssh_helper.py Paramiko SFTP connection for maximum reliability.
"""

import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from ssh_helper import get_sftp, run_remote

LOCAL_WEB_ROOT = Path(r"C:\Acer\Code\TezzNative\TezzCorp_WebSites\tn_tezzcorp_com")
REMOTE_TARGET_DIR = "/home/u190073748/domains/tezzcorp.com/public_html/tn.tezzcorp.com"

# Crucial security: NEVER overwrite remote .env file with local template
SKIP_FILES = {".env", ".env.bak", ".git", ".DS_Store", "Thumbs.db"}
SKIP_DIRS = {".git", "__pycache__", "logs", "storage", ".vscode"}

def ensure_remote_dir(sftp, remote_dir):
    parts = remote_dir.strip("/").split("/")
    cur = ""
    for p in parts:
        cur += "/" + p
        try:
            sftp.stat(cur)
        except IOError:
            try:
                sftp.mkdir(cur)
            except IOError:
                pass

def upload_file(sftp, local_fp: Path, remote_fp: str, show_progress=False):
    remote_parent = remote_fp.rsplit("/", 1)[0]
    ensure_remote_dir(sftp, remote_parent)
    try:
        last_logged = [0]
        def cb(transferred, total):
            if show_progress and total > 0:
                percent = transferred / total * 100
                mb_trans = transferred / (1024 * 1024)
                mb_total = total / (1024 * 1024)
                if mb_trans - last_logged[0] >= 5 or transferred == total:
                    last_logged[0] = mb_trans
                    print(f"    Progress: {percent:.1f}% ({mb_trans:.1f} / {mb_total:.1f} MB)", flush=True)

        sftp.put(str(local_fp), remote_fp, callback=cb if show_progress else None)
        return True, None
    except Exception as e:
        return False, str(e)

def main():
    print("=" * 65)
    print("TezzNative Production Portal & Disaster Recovery Deployment")
    print(f"Target: {REMOTE_TARGET_DIR}")
    print("=" * 65)

    # 1. Connect via SFTP
    print("[1/4] Establishing SFTP connection via SSH...")
    ssh, sftp = get_sftp()
    if ssh.get_transport():
        ssh.get_transport().set_keepalive(15)
    print("SFTP connection established successfully.")

    # 2. Priority Files
    priority_rel_files = [
        ".htaccess",
        "install.ps1",
        "install.sh",
        "install.cmd",
        "registry.tnx",
        "tezz.mod",
        "tezz.lock",
        "config/db.php",
        "config/community_db.php",
        "community.php",
        "community/index.php",
        "support.php",
        "versions.php",
        "docs/getting-started.php",
        "docs/lsp.php",
        "assets/app.css",
        "assets/app.js",
        "includes/nav.php",
        "includes/header.php",
        "includes/footer.php",
        "index.php",
        ".env.example",
        "restore_from_ssh.sh"
    ]

    print(f"\n[2/4] Deploying {len(priority_rel_files)} priority web portal files...")
    for rel in priority_rel_files:
        lfp = LOCAL_WEB_ROOT / rel
        if not lfp.exists():
            print(f"  [WARN] Not found: {rel}")
            continue
        rfp = f"{REMOTE_TARGET_DIR}/{rel.replace(os.sep, '/')}"
        ok, err = upload_file(sftp, lfp, rfp)
        if ok:
            print(f"  [OK]  {rel}")
        else:
            print(f"  [ERR] {rel} -> {err}")

    # Remove deprecated GUI installers from remote server
    gui_remotes = [
        f"{REMOTE_TARGET_DIR}/download/TezzNativeInstaller.exe",
        f"{REMOTE_TARGET_DIR}/download/install_gui.cmd",
        f"{REMOTE_TARGET_DIR}/download/install_gui.ps1",
        f"{REMOTE_TARGET_DIR}/download/sdk/bin/TezzNativeInstaller.exe",
    ]
    for gr in gui_remotes:
        try:
            sftp.remove(gr)
            print(f"  [PURGED] Remote GUI installer: {gr.rsplit('/', 1)[-1]}")
        except Exception:
            pass

    # 3. Release & Distributed Build Artifacts in download/
    print("\n[3/4] Deploying updated release artifacts in download/...")
    dl_dir = LOCAL_WEB_ROOT / "download"
    dl_count = 0
    for root, dirs, files in os.walk(dl_dir):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            if f in SKIP_FILES:
                continue
            lfp = Path(root) / f
            rel = lfp.relative_to(LOCAL_WEB_ROOT)
            rfp = f"{REMOTE_TARGET_DIR}/{rel.as_posix()}"
            ok, err = upload_file(sftp, lfp, rfp)
            if ok:
                dl_count += 1
                if dl_count % 5 == 0 or lfp.name.endswith(('.zip', '.tar.gz', '.json')):
                    print(f"  [OK]  {rel.as_posix()} ({lfp.stat().st_size / 1024:.1f} KB)")
            else:
                print(f"  [ERR] {rel.as_posix()} -> {err}")
    print(f"Release artifacts deployed: {dl_count} files.")

    # 4. Disaster Recovery Backup Archive
    print("\n[4/4] Deploying Disaster Recovery Source Archive...")
    backup_tar = LOCAL_WEB_ROOT / "tezznative_source_backup.tar.gz"
    if backup_tar.exists():
        tar_size_mb = backup_tar.stat().st_size / (1024 * 1024)
        print(f"  Uploading {backup_tar.name} ({tar_size_mb:.2f} MB)...")
        rfp = f"{REMOTE_TARGET_DIR}/tezznative_source_backup.tar.gz"
        ok, err = upload_file(sftp, backup_tar, rfp, show_progress=True)
        if ok:
            print(f"  [OK] Disaster Recovery Source Archive deployed successfully to {rfp}")
        else:
            print(f"  [ERR] Failed to deploy backup archive: {err}")
    else:
        print("  [WARN] tezznative_source_backup.tar.gz not found locally yet.")

    sftp.close()
    ssh.close()
    print("\n" + "=" * 65)
    print("DEPLOYMENT COMPLETE!")
    print("=" * 65)

if __name__ == "__main__":
    main()
