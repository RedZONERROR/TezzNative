#!/usr/bin/env python3
"""
deploy_portal_and_backup.py — SFTP deployment script to Hostinger server.
Target Domain: https://tezznative.org (Primary)
Mirror Domain: https://tn.tezzcorp.com (Legacy virtual host)

Performs:
1. Purge of all legacy tuition, fee, payment, and academy files from remote server.
2. Deployment of priority web portal files:
   - i18n localization engine (includes/i18n.php) supporting 8 languages
   - Clean SEO suite (.htaccess, robots.txt, sitemap.xml, header, nav, footer)
   - CLI installer scripts (install.ps1, install.sh, install.cmd)
   - Registry and module lock files (tezz.mod, tezz.lock, registry.tnx)
3. Deployment of distributed SDK artifacts (tezznative-sdk.zip, manifest, DLLs).
"""

import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from ssh_helper import get_sftp, run_remote

LOCAL_WEB_ROOT = Path(r"C:\Acer\Code\TezzNative\TezzCorp_WebSites\tn_tezzcorp_com")
PRIMARY_TARGET_DIR = "/home/u190073748/domains/tezznative.org/public_html"
LEGACY_TARGET_DIR = "/home/u190073748/domains/tezzcorp.com/public_html/tn.tezzcorp.com"

SKIP_FILES = {".env", ".env.bak", ".git", ".DS_Store", "Thumbs.db"}
SKIP_DIRS = {".git", "__pycache__", "logs", "storage", ".vscode"}

PURGE_FILES = [
    "academy_diag.php",
    "callback.php",
    "careers.php",
    "check-monthly-payments.php",
    "checkout.php",
    "fee-receipt.php",
    "phpinfo_test2.php",
    "portfolio.php",
    "services.php",
    "software.php",
    "paypal.webp",
    "secure-payment-badge.svg",
    "restore_from_ssh.sh",
    "tezznative_source_backup.tar.gz",
    "download/TezzNativeInstaller.exe",
    "download/install_gui.cmd",
    "download/install_gui.ps1",
    "download/sdk/bin/TezzNativeInstaller.exe",
    "includes/school_erp.php",
    "includes/school_erp_agreements.php",
    "includes/crm_ops.php",
    "includes/crm_worker.php",
    "includes/pay_tezzcorp.php",
    "includes/website_content.php",
    "api/music.php",
    "api/music_proxy.php",
    "api/payments.php",
    "api/clients.php",
    "api/employees.php",
    "api/accept_agreement.php",
]

PURGE_DIRS = [
    "api/agreement_letter",
    "api/tezzerp",
    "api/zego",
]

def ensure_remote_dir(sftp, remote_dir):
    parts = remote_dir.strip("/").split("/")
    cur = ""
    for p in parts:
        cur += "/" + p
        try:
            sftp.stat(cur)
        except IOError:
            try:
                sftp.mkdir(cur)
            except IOError:
                pass

def upload_file(sftp, local_fp: Path, remote_fp: str, show_progress=False):
    remote_parent = remote_fp.rsplit("/", 1)[0]
    ensure_remote_dir(sftp, remote_parent)
    try:
        last_logged = [0]
        def cb(transferred, total):
            if show_progress and total > 0:
                percent = transferred / total * 100
                mb_trans = transferred / (1024 * 1024)
                mb_total = total / (1024 * 1024)
                if mb_trans - last_logged[0] >= 5 or transferred == total:
                    last_logged[0] = mb_trans
                    print(f"    Progress: {percent:.1f}% ({mb_trans:.1f} / {mb_total:.1f} MB)", flush=True)

        sftp.put(str(local_fp), remote_fp, callback=cb if show_progress else None)
        return True, None
    except Exception as e:
        return False, str(e)

def purge_unwanted_files(sftp, target_dir):
    print(f"\nPurging unwanted legacy files from {target_dir}...")
    purged_count = 0
    for rel in PURGE_FILES:
        rfp = f"{target_dir}/{rel}"
        try:
            sftp.remove(rfp)
            print(f"  [PURGED] {rel}")
            purged_count += 1
        except Exception:
            pass
    for d in PURGE_DIRS:
        rfp = f"{target_dir}/{d}"
        try:
            run_remote(f"rm -rf {rfp}")
            print(f"  [PURGED DIR] {d}")
        except Exception:
            pass
    print(f"Remote purge complete: {purged_count} files removed.")

def deploy_to_target(sftp, target_dir):
    print(f"\nDeploying to target: {target_dir}")

    # 1. Priority Files
    priority_rel_files = [
        ".htaccess",
        "robots.txt",
        "sitemap.xml",
        "install.ps1",
        "install.sh",
        "install.cmd",
        "registry.tnx",
        "tezz.mod",
        "tezz.lock",
        "includes/i18n.php",
        "includes/nav.php",
        "includes/header.php",
        "includes/footer.php",
        "index.php",
        "community.php",
        "community/index.php",
        "support.php",
        "versions.php",
        "frameworks.php",
        "news.php",
        "about.php",
        "privacy.php",
        "terms.php",
        "api-docs.php",
        "config/db.php",
        "config/community_db.php",
        "assets/app.css",
        "assets/app.js",
        "download/index.php",
        "download/install.ps1",
        "download/install.sh",
        "download/install.cmd",
        "download/release_manifest.json",
        "download/release_manifest.json.sha256",
        "download/tezznative-sdk.zip.sha256",
        "download/tezznative-sdk-linux.tar.gz.sha256",
    ]

    print(f"Uploading {len(priority_rel_files)} priority web portal files...")
    for rel in priority_rel_files:
        lfp = LOCAL_WEB_ROOT / rel
        if not lfp.exists():
            print(f"  [WARN] Local file not found: {rel}")
            continue
        rfp = f"{target_dir}/{rel.replace(os.sep, '/')}"
        ok, err = upload_file(sftp, lfp, rfp)
        if ok:
            print(f"  [OK]  {rel}")
        else:
            print(f"  [ERR] {rel} -> {err}")

    # 2. Upload tezznative-sdk.zip with progress
    sdk_zip = LOCAL_WEB_ROOT / "download" / "tezznative-sdk.zip"
    if sdk_zip.exists():
        rfp = f"{target_dir}/download/tezznative-sdk.zip"
        print(f"\nUploading complete SDK bundle {sdk_zip.name} ({sdk_zip.stat().st_size / (1024*1024):.2f} MB)...")
        ok, err = upload_file(sftp, sdk_zip, rfp, show_progress=True)
        if ok:
            print(f"  [OK] tezznative-sdk.zip uploaded successfully!")
        else:
            print(f"  [ERR] Failed to upload tezznative-sdk.zip: {err}")

    # 3. Synchronize remaining download assets (DLLs, Linux tarball, etc.)
    print(f"\nSynchronizing download/ directory assets...")
    dl_dir = LOCAL_WEB_ROOT / "download"
    dl_count = 0
    for root, dirs, files in os.walk(dl_dir):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            if f in SKIP_FILES:
                continue
            lfp = Path(root) / f
            # Skip the large zip we already uploaded
            if lfp.name == "tezznative-sdk.zip":
                continue
            rel = lfp.relative_to(LOCAL_WEB_ROOT)
            rfp = f"{target_dir}/{rel.as_posix()}"
            ok, err = upload_file(sftp, lfp, rfp)
            if ok:
                dl_count += 1
                if dl_count % 10 == 0 or lfp.name.endswith(('.tar.gz', '.json', '.exe')):
                    print(f"  [OK]  {rel.as_posix()} ({lfp.stat().st_size / 1024:.1f} KB)")
            else:
                print(f"  [ERR] {rel.as_posix()} -> {err}")
    print(f"Download assets synchronized: {dl_count} files.")

def main():
    print("=" * 70)
    print(" TezzNative Official Portal Deployment — tezznative.org")
    print("=" * 70)

    # 1. Connect via SFTP
    print("[1/3] Establishing SFTP connection via SSH...")
    ssh, sftp = get_sftp()
    if ssh.get_transport():
        ssh.get_transport().set_keepalive(15)
    print("SFTP connection established successfully.")

    # 2. Deploy to Primary Domain (tezznative.org)
    print("\n[2/3] Deploying to PRIMARY domain: tezznative.org...")
    purge_unwanted_files(sftp, PRIMARY_TARGET_DIR)
    deploy_to_target(sftp, PRIMARY_TARGET_DIR)

    # 3. Deploy to Legacy Mirror (tn.tezzcorp.com)
    print("\n[3/3] Deploying to LEGACY mirror: tn.tezzcorp.com...")
    purge_unwanted_files(sftp, LEGACY_TARGET_DIR)
    deploy_to_target(sftp, LEGACY_TARGET_DIR)

    sftp.close()
    ssh.close()
    print("\n" + "=" * 70)
    print(" PRODUCTION DEPLOYMENT COMPLETE TO TEZZNATIVE.ORG!")
    print("=" * 70)

if __name__ == "__main__":
    main()
