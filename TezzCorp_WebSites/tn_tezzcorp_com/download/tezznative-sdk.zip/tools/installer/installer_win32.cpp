// tools/installer/installer_win32.cpp
// Native Win32 GUI Installer for TezzNative SDK v2.2.1
// TezzCorp Pvt Ltd. | Created by Rohit Pathak

#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE

#include <windows.h>
#include <commctrl.h>
#include <shlobj.h>
#include <winhttp.h>
#include <urlmon.h>
#include <stdio.h>
#include <stdlib.h>
#include <process.h>

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "urlmon.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "ole32.lib")

#define ID_BTN_INSTALL    1001
#define ID_BTN_CANCEL     1002
#define ID_BTN_BROWSE     1003
#define ID_CHK_PATH       1004
#define ID_CHK_SDKROOT    1005
#define ID_RADIO_USER     1006
#define ID_RADIO_SYSTEM   1007
#define ID_PROGRESS       1008
#define ID_STATUS_TXT     1009
#define ID_EDIT_DIR       1010
#define ID_BTN_FINISH     1011

#define WM_INSTALL_PROGRESS (WM_USER + 1)
#define WM_INSTALL_COMPLETE (WM_USER + 2)
#define WM_INSTALL_ERROR    (WM_USER + 3)

static HWND g_hWnd = NULL;
static HWND g_hProgress = NULL;
static HWND g_hStatus = NULL;
static HWND g_hEditDir = NULL;
static HWND g_hBtnInstall = NULL;
static HWND g_hBtnCancel = NULL;
static HWND g_hChkPath = NULL;
static HWND g_hChkSdkRoot = NULL;
static HWND g_hRadioUser = NULL;
static HWND g_hRadioSystem = NULL;

static wchar_t g_installDir[MAX_PATH] = {0};
static int g_addPath = 1;
static int g_setSdkRoot = 1;
static int g_isSystemScope = 0;
static int g_isInstalling = 0;

class CDownloadCallback : public IBindStatusCallback {
public:
    CDownloadCallback() : m_ref(1) {}
    STDMETHODIMP QueryInterface(REFIID riid, void** ppv) {
        if (riid == IID_IUnknown || riid == IID_IBindStatusCallback) {
            *ppv = static_cast<IBindStatusCallback*>(this);
            AddRef();
            return S_OK;
        }
        *ppv = NULL;
        return E_NOINTERFACE;
    }
    STDMETHODIMP_(ULONG) AddRef() { return InterlockedIncrement(&m_ref); }
    STDMETHODIMP_(ULONG) Release() {
        ULONG r = InterlockedDecrement(&m_ref);
        if (r == 0) delete this;
        return r;
    }
    STDMETHODIMP OnStartBinding(DWORD, IBinding*) { return S_OK; }
    STDMETHODIMP GetPriority(LONG*) { return S_OK; }
    STDMETHODIMP OnLowResource(DWORD) { return S_OK; }
    STDMETHODIMP OnProgress(ULONG ulProgress, ULONG ulProgressMax, ULONG, LPCWSTR) {
        if (ulProgressMax > 0) {
            int pct = (int)((ulProgress * 60) / ulProgressMax);
            PostMessage(g_hWnd, WM_INSTALL_PROGRESS, (WPARAM)pct, 0);
        }
        return S_OK;
    }
    STDMETHODIMP OnStopBinding(HRESULT, LPCWSTR) { return S_OK; }
    STDMETHODIMP GetBindInfo(DWORD*, BINDINFO*) { return S_OK; }
    STDMETHODIMP OnDataAvailable(DWORD, DWORD, FORMATETC*, STGMEDIUM*) { return S_OK; }
    STDMETHODIMP OnObjectAvailable(REFIID, IUnknown*) { return S_OK; }
private:
    LONG m_ref;
};

static void AddPathToEnv(const wchar_t* binDir, int isSystem) {
    HKEY hKey;
    const wchar_t* subKey = isSystem ? L"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment" : L"Environment";
    HKEY rootKey = isSystem ? HKEY_LOCAL_MACHINE : HKEY_CURRENT_USER;

    if (RegOpenKeyExW(rootKey, subKey, 0, KEY_READ | KEY_WRITE, &hKey) == ERROR_SUCCESS) {
        wchar_t currentPath[32768] = {0};
        DWORD bufSize = sizeof(currentPath);
        DWORD type = REG_EXPAND_SZ;
        if (RegQueryValueExW(hKey, L"Path", NULL, &type, (LPBYTE)currentPath, &bufSize) != ERROR_SUCCESS) {
            currentPath[0] = L'\0';
        }
        if (wcsstr(currentPath, binDir) == NULL) {
            wchar_t newPath[32768] = {0};
            if (wcslen(currentPath) > 0) {
                swprintf(newPath, 32768, L"%s;%s", currentPath, binDir);
            } else {
                swprintf(newPath, 32768, L"%s", binDir);
            }
            RegSetValueExW(hKey, L"Path", 0, REG_EXPAND_SZ, (const BYTE*)newPath, (DWORD)((wcslen(newPath) + 1) * sizeof(wchar_t)));
        }
        RegCloseKey(hKey);
        DWORD_PTR res;
        SendMessageTimeoutW(HWND_BROADCAST, WM_SETTINGCHANGE, 0, (LPARAM)L"Environment", SMTO_ABORTIFHUNG, 2000, &res);
    }
}

static void SetSdkRootEnv(const wchar_t* sdkDir, int isSystem) {
    HKEY hKey;
    const wchar_t* subKey = isSystem ? L"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment" : L"Environment";
    HKEY rootKey = isSystem ? HKEY_LOCAL_MACHINE : HKEY_CURRENT_USER;

    if (RegOpenKeyExW(rootKey, subKey, 0, KEY_WRITE, &hKey) == ERROR_SUCCESS) {
        RegSetValueExW(hKey, L"TEZZ_SDK_ROOT", 0, REG_SZ, (const BYTE*)sdkDir, (DWORD)((wcslen(sdkDir) + 1) * sizeof(wchar_t)));
        RegCloseKey(hKey);
    }
}

static void RegisterUninstallEntry(const wchar_t* installDir, int isSystem) {
    HKEY hKey;
    const wchar_t* subKey = L"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\TezzNative";
    HKEY rootKey = isSystem ? HKEY_LOCAL_MACHINE : HKEY_CURRENT_USER;

    if (RegCreateKeyExW(rootKey, subKey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL) == ERROR_SUCCESS) {
        const wchar_t* displayName = L"TezzNative Programming Language SDK v2.2.1";
        const wchar_t* displayVersion = L"2.2.1";
        const wchar_t* publisher = L"TezzCorp Pvt Ltd. (Created by Rohit Pathak)";
        const wchar_t* url = L"https://tn.tezzcorp.com";
        const wchar_t* docsUrl = L"https://tn.tezzcorp.com/docs/";

        wchar_t iconPath[MAX_PATH];
        swprintf(iconPath, MAX_PATH, L"%s\\bin\\tezzc.exe,0", installDir);

        // Safe uninstaller: verifies .tezz_install_manifest exists and .git does NOT exist before deleting
        wchar_t uninstallCmd[MAX_PATH * 3];
        swprintf(uninstallCmd, MAX_PATH * 3, L"powershell.exe -NoProfile -ExecutionPolicy Bypass -Command \"if (Test-Path '%s\\.tezz_install_manifest') { [System.Environment]::SetEnvironmentVariable('TEZZ_SDK_ROOT', $null, 'User'); Remove-Item -Recurse -Force '%s' -ErrorAction SilentlyContinue; Remove-Item -Recurse -Force 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\TezzNative' -ErrorAction SilentlyContinue }\"", installDir, installDir);

        DWORD estimatedSize = 120000;
        DWORD dwordOne = 1;

        RegSetValueExW(hKey, L"DisplayName", 0, REG_SZ, (const BYTE*)displayName, (DWORD)((wcslen(displayName) + 1) * sizeof(wchar_t)));
        RegSetValueExW(hKey, L"DisplayVersion", 0, REG_SZ, (const BYTE*)displayVersion, (DWORD)((wcslen(displayVersion) + 1) * sizeof(wchar_t)));
        RegSetValueExW(hKey, L"Publisher", 0, REG_SZ, (const BYTE*)publisher, (DWORD)((wcslen(publisher) + 1) * sizeof(wchar_t)));
        RegSetValueExW(hKey, L"InstallLocation", 0, REG_SZ, (const BYTE*)installDir, (DWORD)((wcslen(installDir) + 1) * sizeof(wchar_t)));
        RegSetValueExW(hKey, L"DisplayIcon", 0, REG_SZ, (const BYTE*)iconPath, (DWORD)((wcslen(iconPath) + 1) * sizeof(wchar_t)));
        RegSetValueExW(hKey, L"UninstallString", 0, REG_SZ, (const BYTE*)uninstallCmd, (DWORD)((wcslen(uninstallCmd) + 1) * sizeof(wchar_t)));
        RegSetValueExW(hKey, L"URLInfoAbout", 0, REG_SZ, (const BYTE*)url, (DWORD)((wcslen(url) + 1) * sizeof(wchar_t)));
        RegSetValueExW(hKey, L"HelpLink", 0, REG_SZ, (const BYTE*)docsUrl, (DWORD)((wcslen(docsUrl) + 1) * sizeof(wchar_t)));
        RegSetValueExW(hKey, L"EstimatedSize", 0, REG_DWORD, (const BYTE*)&estimatedSize, sizeof(DWORD));
        RegSetValueExW(hKey, L"NoModify", 0, REG_DWORD, (const BYTE*)&dwordOne, sizeof(DWORD));
        RegSetValueExW(hKey, L"NoRepair", 0, REG_DWORD, (const BYTE*)&dwordOne, sizeof(DWORD));

        RegCloseKey(hKey);
    }
}

static void RegisterFileAssociation(const wchar_t* installDir, int isSystem) {
    HKEY rootKey = isSystem ? HKEY_LOCAL_MACHINE : HKEY_CURRENT_USER;
    HKEY hKey;

    if (RegCreateKeyExW(rootKey, L"Software\\Classes\\.tn", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL) == ERROR_SUCCESS) {
        const wchar_t* progId = L"TezzNativeSource";
        RegSetValueExW(hKey, NULL, 0, REG_SZ, (const BYTE*)progId, (DWORD)((wcslen(progId) + 1) * sizeof(wchar_t)));
        RegCloseKey(hKey);
    }

    if (RegCreateKeyExW(rootKey, L"Software\\Classes\\TezzNativeSource", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL) == ERROR_SUCCESS) {
        const wchar_t* desc = L"TezzNative Source File";
        RegSetValueExW(hKey, NULL, 0, REG_SZ, (const BYTE*)desc, (DWORD)((wcslen(desc) + 1) * sizeof(wchar_t)));
        RegCloseKey(hKey);
    }

    if (RegCreateKeyExW(rootKey, L"Software\\Classes\\TezzNativeSource\\shell\\open\\command", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL) == ERROR_SUCCESS) {
        wchar_t openCmd[MAX_PATH * 2];
        swprintf(openCmd, MAX_PATH * 2, L"\"%s\\bin\\tezz.exe\" run \"%%1\"", installDir);
        RegSetValueExW(hKey, NULL, 0, REG_SZ, (const BYTE*)openCmd, (DWORD)((wcslen(openCmd) + 1) * sizeof(wchar_t)));
        RegCloseKey(hKey);
    }
}

static unsigned __stdcall InstallThread(void*) {
    PostMessage(g_hWnd, WM_INSTALL_PROGRESS, 5, (LPARAM)L"Preparing installation directory...");
    CreateDirectoryW(g_installDir, NULL);

    // Write installation fingerprint marker
    wchar_t markerPath[MAX_PATH];
    swprintf(markerPath, MAX_PATH, L"%s\\.tezz_install_manifest", g_installDir);
    FILE* mf = _wfopen(markerPath, L"w");
    if (mf) {
        fputs("version=2.2.1\nproduct=TezzNative\nvendor=TezzCorp\n", mf);
        fclose(mf);
    }

    // Download URL
    const wchar_t* downloadUrl = L"https://tn.tezzcorp.com/download/tezznative-sdk.zip";
    wchar_t tempZip[MAX_PATH];
    GetTempPathW(MAX_PATH, tempZip);
    wcscat_s(tempZip, MAX_PATH, L"tezznative-sdk.zip");

    PostMessage(g_hWnd, WM_INSTALL_PROGRESS, 10, (LPARAM)L"Downloading TezzNative SDK v2.2.1 from tn.tezzcorp.com...");

    CDownloadCallback* cb = new CDownloadCallback();
    HRESULT hr = URLDownloadToFileW(NULL, downloadUrl, tempZip, 0, cb);
    cb->Release();

    if (FAILED(hr)) {
        PostMessage(g_hWnd, WM_INSTALL_ERROR, 0, (LPARAM)L"Failed to download TezzNative SDK archive. Please check internet connection.");
        return 1;
    }

    PostMessage(g_hWnd, WM_INSTALL_PROGRESS, 70, (LPARAM)L"Extracting TezzNative SDK files...");

    // Extract using tar.exe (built-in Windows 10/11)
    wchar_t cmd[MAX_PATH * 3];
    swprintf(cmd, MAX_PATH * 3, L"tar.exe -xf \"%s\" -C \"%s\"", tempZip, g_installDir);

    STARTUPINFOW si = {sizeof(si)};
    PROCESS_INFORMATION pi = {0};
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    if (CreateProcessW(NULL, cmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        WaitForSingleObject(pi.hProcess, INFINITE);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    } else {
        // Fallback to powershell Expand-Archive
        swprintf(cmd, MAX_PATH * 3, L"powershell.exe -NoProfile -NonInteractive -Command \"Expand-Archive -Path '%s' -DestinationPath '%s' -Force\"", tempZip, g_installDir);
        if (CreateProcessW(NULL, cmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
            WaitForSingleObject(pi.hProcess, INFINITE);
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
        }
    }
    DeleteFileW(tempZip);

    PostMessage(g_hWnd, WM_INSTALL_PROGRESS, 90, (LPARAM)L"Configuring system PATH and environment variables...");

    wchar_t binDir[MAX_PATH];
    swprintf(binDir, MAX_PATH, L"%s\\bin", g_installDir);

    if (g_addPath) {
        AddPathToEnv(binDir, g_isSystemScope);
    }
    if (g_setSdkRoot) {
        SetSdkRootEnv(g_installDir, g_isSystemScope);
    }

    // Register in Windows Control Panel Programs / Installed Apps
    RegisterUninstallEntry(g_installDir, g_isSystemScope);
    RegisterFileAssociation(g_installDir, g_isSystemScope);

    PostMessage(g_hWnd, WM_INSTALL_PROGRESS, 100, (LPARAM)L"Installation completed successfully!");
    PostMessage(g_hWnd, WM_INSTALL_COMPLETE, 0, 0);
    return 0;
}

static LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE: {
        HFONT hFontSegoe = CreateFontW(17, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");

        // Safe Default path: %USERPROFILE%\.tezznative
        wchar_t userProfile[MAX_PATH];
        GetEnvironmentVariableW(L"USERPROFILE", userProfile, MAX_PATH);
        swprintf(g_installDir, MAX_PATH, L"%s\\.tezznative", userProfile);

        // Edit box for install directory
        CreateWindowW(L"STATIC", L"Install Directory:", WS_CHILD | WS_VISIBLE, 30, 95, 150, 20, hWnd, NULL, NULL, NULL);
        g_hEditDir = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", g_installDir, WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 30, 120, 480, 26, hWnd, (HMENU)ID_EDIT_DIR, NULL, NULL);
        HWND hBtnBrowse = CreateWindowW(L"BUTTON", L"Browse...", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 520, 120, 90, 26, hWnd, (HMENU)ID_BTN_BROWSE, NULL, NULL);

        // Scope radios
        g_hRadioUser = CreateWindowW(L"BUTTON", L"Current User (%USERPROFILE%\\.tezznative) [Recommended]", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 30, 160, 480, 22, hWnd, (HMENU)ID_RADIO_USER, NULL, NULL);
        g_hRadioSystem = CreateWindowW(L"BUTTON", L"All Users (%ProgramFiles%\\TezzNative)", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 30, 185, 480, 22, hWnd, (HMENU)ID_RADIO_SYSTEM, NULL, NULL);
        SendMessageW(g_hRadioUser, BM_SETCHECK, BST_CHECKED, 0);

        // Checkboxes
        g_hChkPath = CreateWindowW(L"BUTTON", L"Add TezzNative binary directory (bin) to user PATH", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 30, 220, 480, 22, hWnd, (HMENU)ID_CHK_PATH, NULL, NULL);
        g_hChkSdkRoot = CreateWindowW(L"BUTTON", L"Set TEZZ_SDK_ROOT environment variable", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 30, 245, 480, 22, hWnd, (HMENU)ID_CHK_SDKROOT, NULL, NULL);
        SendMessageW(g_hChkPath, BM_SETCHECK, BST_CHECKED, 0);
        SendMessageW(g_hChkSdkRoot, BM_SETCHECK, BST_CHECKED, 0);

        // Progress bar
        g_hProgress = CreateWindowExW(0, PROGRESS_CLASSW, NULL, WS_CHILD | WS_VISIBLE | PBS_SMOOTH, 30, 280, 580, 20, hWnd, (HMENU)ID_PROGRESS, NULL, NULL);
        SendMessageW(g_hProgress, PBM_SETRANGE, 0, MAKELPARAM(0, 100));
        SendMessageW(g_hProgress, PBM_SETPOS, 0, 0);

        // Status text
        g_hStatus = CreateWindowW(L"STATIC", L"Ready to install TezzNative v2.2.1 SDK.", WS_CHILD | WS_VISIBLE | SS_LEFTNOWORDWRAP, 30, 308, 580, 20, hWnd, (HMENU)ID_STATUS_TXT, NULL, NULL);

        // Buttons
        g_hBtnInstall = CreateWindowW(L"BUTTON", L"Install Now", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON, 400, 345, 120, 32, hWnd, (HMENU)ID_BTN_INSTALL, NULL, NULL);
        g_hBtnCancel = CreateWindowW(L"BUTTON", L"Cancel", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 530, 345, 80, 32, hWnd, (HMENU)ID_BTN_CANCEL, NULL, NULL);

        // Apply fonts
        SendMessageW(g_hEditDir, WM_SETFONT, (WPARAM)hFontSegoe, TRUE);
        SendMessageW(hBtnBrowse, WM_SETFONT, (WPARAM)hFontSegoe, TRUE);
        SendMessageW(g_hRadioUser, WM_SETFONT, (WPARAM)hFontSegoe, TRUE);
        SendMessageW(g_hRadioSystem, WM_SETFONT, (WPARAM)hFontSegoe, TRUE);
        SendMessageW(g_hChkPath, WM_SETFONT, (WPARAM)hFontSegoe, TRUE);
        SendMessageW(g_hChkSdkRoot, WM_SETFONT, (WPARAM)hFontSegoe, TRUE);
        SendMessageW(g_hStatus, WM_SETFONT, (WPARAM)hFontSegoe, TRUE);
        SendMessageW(g_hBtnInstall, WM_SETFONT, (WPARAM)hFontSegoe, TRUE);
        SendMessageW(g_hBtnCancel, WM_SETFONT, (WPARAM)hFontSegoe, TRUE);
        break;
    }

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);

        // Header Background
        RECT rHeader = {0, 0, 660, 80};
        HBRUSH hBrushHead = CreateSolidBrush(RGB(15, 20, 34));
        FillRect(hdc, &rHeader, hBrushHead);
        DeleteObject(hBrushHead);

        // Indian Saffron Accent Line
        RECT rAccent = {0, 78, 660, 80};
        HBRUSH hBrushAcc = CreateSolidBrush(RGB(255, 153, 51)); // Indian Saffron #FF9933
        FillRect(hdc, &rAccent, hBrushAcc);
        DeleteObject(hBrushAcc);

        // Header Text
        SetBkMode(hdc, TRANSPARENT);
        SetTextColor(hdc, RGB(255, 255, 255));
        HFONT hFontHead = CreateFontW(22, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
        HFONT hOldFont = (HFONT)SelectObject(hdc, hFontHead);
        TextOutW(hdc, 30, 16, L"TezzNative SDK v2.2.1 Setup", 27);

        SetTextColor(hdc, RGB(255, 153, 51));
        HFONT hFontSub = CreateFontW(14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
        SelectObject(hdc, hFontSub);
        TextOutW(hdc, 30, 44, L"Engineered by TezzCorp Pvt Ltd. | Created by Rohit Pathak", 57);

        SelectObject(hdc, hOldFont);
        DeleteObject(hFontHead);
        DeleteObject(hFontSub);
        EndPaint(hWnd, &ps);
        break;
    }

    case WM_COMMAND: {
        int wmId = LOWORD(wParam);
        if (wmId == ID_BTN_CANCEL) {
            DestroyWindow(hWnd);
        } else if (wmId == ID_RADIO_USER) {
            wchar_t userProfile[MAX_PATH];
            GetEnvironmentVariableW(L"USERPROFILE", userProfile, MAX_PATH);
            swprintf(g_installDir, MAX_PATH, L"%s\\.tezznative", userProfile);
            SetWindowTextW(g_hEditDir, g_installDir);
            g_isSystemScope = 0;
        } else if (wmId == ID_RADIO_SYSTEM) {
            wchar_t progFiles[MAX_PATH];
            GetEnvironmentVariableW(L"ProgramFiles", progFiles, MAX_PATH);
            swprintf(g_installDir, MAX_PATH, L"%s\\TezzNative", progFiles);
            SetWindowTextW(g_hEditDir, g_installDir);
            g_isSystemScope = 1;
        } else if (wmId == ID_BTN_BROWSE) {
            BROWSEINFOW bi = {0};
            bi.hwndOwner = hWnd;
            bi.lpszTitle = L"Select Installation Directory for TezzNative SDK:";
            bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
            PIDLIST_ABSOLUTE pidl = SHBrowseForFolderW(&bi);
            if (pidl) {
                SHGetPathFromIDListW(pidl, g_installDir);
                SetWindowTextW(g_hEditDir, g_installDir);
                CoTaskMemFree(pidl);
            }
        } else if (wmId == ID_BTN_INSTALL) {
            if (g_isInstalling) return 0;
            g_isInstalling = 1;

            GetWindowTextW(g_hEditDir, g_installDir, MAX_PATH);
            g_addPath = (SendMessageW(g_hChkPath, BM_GETCHECK, 0, 0) == BST_CHECKED);
            g_setSdkRoot = (SendMessageW(g_hChkSdkRoot, BM_GETCHECK, 0, 0) == BST_CHECKED);

            EnableWindow(g_hEditDir, FALSE);
            EnableWindow(g_hRadioUser, FALSE);
            EnableWindow(g_hRadioSystem, FALSE);
            EnableWindow(g_hChkPath, FALSE);
            EnableWindow(g_hChkSdkRoot, FALSE);
            EnableWindow(g_hBtnInstall, FALSE);

            _beginthreadex(NULL, 0, InstallThread, NULL, 0, NULL);
        } else if (wmId == ID_BTN_FINISH) {
            DestroyWindow(hWnd);
        }
        break;
    }

    case WM_INSTALL_PROGRESS: {
        int pct = (int)wParam;
        SendMessageW(g_hProgress, PBM_SETPOS, pct, 0);
        if (lParam) {
            SetWindowTextW(g_hStatus, (const wchar_t*)lParam);
        }
        break;
    }

    case WM_INSTALL_COMPLETE: {
        SendMessageW(g_hProgress, PBM_SETPOS, 100, 0);
        SetWindowTextW(g_hStatus, L"Installation completed successfully! TezzNative is ready to use.");
        SetWindowTextW(g_hBtnCancel, L"Close");
        SetWindowLongPtrW(g_hBtnCancel, GWLP_ID, ID_BTN_FINISH);
        EnableWindow(g_hBtnCancel, TRUE);
        MessageBoxW(hWnd, L"TezzNative SDK v2.2.1 has been installed successfully!\n\nYou can now open any terminal and run:\n  tezz --version\n  tezzc --help", L"Installation Complete — TezzCorp Pvt Ltd.", MB_OK | MB_ICONINFORMATION);
        break;
    }

    case WM_INSTALL_ERROR: {
        SetWindowTextW(g_hStatus, (const wchar_t*)lParam);
        EnableWindow(g_hBtnCancel, TRUE);
        EnableWindow(g_hBtnInstall, TRUE);
        g_isInstalling = 0;
        MessageBoxW(hWnd, (const wchar_t*)lParam, L"Installation Error", MB_OK | MB_ICONERROR);
        break;
    }

    case WM_DESTROY:
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProcW(hWnd, msg, wParam, lParam);
    }
    return 0;
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, PWSTR, int nCmdShow) {
    INITCOMMONCONTROLSEX icex;
    icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
    icex.dwICC = ICC_PROGRESS_CLASS | ICC_STANDARD_CLASSES;
    InitCommonControlsEx(&icex);
    CoInitialize(NULL);

    WNDCLASSEXW wc = {0};
    wc.cbSize = sizeof(WNDCLASSEXW);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursorW(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = L"TezzNativeInstallerClass";
    RegisterClassExW(&wc);

    int w = 660, h = 430;
    int x = (GetSystemMetrics(SM_CXSCREEN) - w) / 2;
    int y = (GetSystemMetrics(SM_CYSCREEN) - h) / 2;

    g_hWnd = CreateWindowExW(
        WS_EX_APPWINDOW,
        wc.lpszClassName,
        L"TezzNative SDK v2.2.1 Setup — TezzCorp Pvt Ltd.",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        x, y, w, h,
        NULL, NULL, hInstance, NULL
    );

    ShowWindow(g_hWnd, nCmdShow);
    UpdateWindow(g_hWnd);

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    CoUninitialize();
    return (int)msg.wParam;
}
