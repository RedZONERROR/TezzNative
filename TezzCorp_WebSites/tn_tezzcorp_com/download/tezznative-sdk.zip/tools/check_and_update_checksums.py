import os, hashlib
from pathlib import Path

dl_dir = Path("c:/Acer/Code/TezzNative/TezzCorp_WebSites/tn_tezzcorp_com/download")

def sha256_file(filepath):
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

print("Checking and updating checksum sidecars:")
for item in dl_dir.iterdir():
    if item.name.endswith(".sha256"):
        target_name = item.name[:-7]
        target_path = dl_dir / target_name
        if target_path.exists():
            actual = sha256_file(target_path).lower()
            old_content = item.read_text(encoding="utf-8").strip()
            old_hash = old_content.split()[0].lower() if old_content else ""
            if actual != old_hash:
                print(f"MISMATCH in {item.name}: old={old_hash} -> actual={actual}")
                item.write_text(f"{actual}  {target_name}\n", encoding="utf-8")
                print(f"  Updated {item.name}")
            else:
                print(f"MATCH: {item.name} -> {actual}")
