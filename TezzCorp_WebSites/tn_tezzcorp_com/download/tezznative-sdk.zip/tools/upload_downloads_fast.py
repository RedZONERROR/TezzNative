import os
import subprocess

FTP_USER = "u190073748.tezzcorpcom"
FTP_PASS = "TezzMsngr@Api#2026$TezzCorp&9608"
FTP_HOST = "89.116.133.167"
REMOTE_BASE = f"ftp://{FTP_HOST}/tn.tezzcorp.com"
LOCAL_ROOT = r"C:\Acer\Code\TezzNative\TezzCorp_WebSites\tn_tezzcorp_com"

files_to_sync = [
    r"download\TezzNativeInstaller.exe",
    r"download\tezznative-sdk.zip",
    r"index.php",
    r"software.php",
    r"services.php",
    r"api-docs.php",
    r"versions.php"
]

for rel_path in files_to_sync:
    local_path = os.path.join(LOCAL_ROOT, rel_path)
    if not os.path.exists(local_path):
        continue
    rel_clean = rel_path.replace("\\", "/").lstrip("/")
    remote_url = f"{REMOTE_BASE}/{rel_clean}"
    print(f"[*] Uploading {rel_clean} ({round(os.path.getsize(local_path)/(1024*1024),2)} MB) ...")
    cmd = [
        "curl.exe",
        "-u", f"{FTP_USER}:{FTP_PASS}",
        "--disable-epsv",
        "--ftp-create-dirs",
        "-T", local_path,
        remote_url
    ]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if res.returncode == 0:
        print(f"[OK] {rel_clean}")
    else:
        print(f"[ERR] {rel_clean} -> {res.stderr.strip()}")

print("[DONE] Core download & website assets synchronized to live server!")
