# Build TezzOS Kernel from TezzNative source
param(
    [string]$Source = "examples/tezzos_kernel.tn",
    [string]$Output = "build/tezzos.elf"
)

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "       Building TezzOS Kernel from TezzNative Language      " -ForegroundColor Yellow
Write-Host "============================================================" -ForegroundColor Cyan

python tools/build_tezzos.py
if ($LASTEXITCODE -eq 0) {
    Write-Host "[SUCCESS] TezzOS Kernel binary ready at $Output" -ForegroundColor Green
} else {
    Write-Host "[ERROR] TezzOS build failed" -ForegroundColor Red
    exit 1
}
