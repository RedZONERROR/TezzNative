with open(r'TezzNative-language/src/parser.c', 'r', encoding='utf-8') as f:
    text = f.read()

target_fn = """static FnDecl* parse_fn(Parser* P, int is_extern, int is_unsafe, int is_kernel, AttrList attrs){"""
target_mod = """  Module* M=(Module*)xmalloc(sizeof(Module));"""

new_block = """static FnDecl* parse_fn(Parser* P, int is_extern, int is_unsafe, int is_kernel, AttrList attrs){
  SrcLoc loc=tok_loc(&P->lex);
  eat(P,TK_FN,"");

  if(!tok_is_name(P)) perr(P,"expected function name");
  Token nm=P->lex.cur; lex_next(&P->lex);

  TypeParam* tparams = NULL;
  int tparam_n = 0;
  if(tok_is(P, TK_LBRACKET)){
    lex_next(&P->lex);
    while(!tok_is(P, TK_RBRACKET) && !tok_is(P, TK_EOF)){
      if(!tok_is_name(P)) perr(P, "expected type parameter name");
      Token tp = P->lex.cur; lex_next(&P->lex);
      tparams = (TypeParam*)xrealloc(tparams, sizeof(TypeParam)*(size_t)(tparam_n+1));
      tparams[tparam_n].name = tp.start;
      tparams[tparam_n].len = tp.len;
      tparam_n++;
      if(!tenv_find_alias(P->tenv, tp.start, tp.len) && !tenv_find_struct(P->tenv, tp.start, tp.len)){
        tenv_add_alias(P->tenv, tp.start, tp.len, P->tenv->b.ty_i64, loc);
      }
      if(tok_is(P, TK_COMMA)){ lex_next(&P->lex); continue; }
      break;
    }
    eat(P, TK_RBRACKET, "expected ']' after type parameters");
  }

  const char** pnames=NULL;
  int*  plens=NULL;
  Type** ptypes=NULL;
  int ar=0;

  /* params: (a,b) OR none */
  if(tok_is(P, TK_LPAREN)){
    lex_next(&P->lex);

    if(!tok_is(P, TK_RPAREN)){
      for(;;){
        if(!tok_is_name(P)) perr(P,"expected parameter name");
        Token pn=P->lex.cur; lex_next(&P->lex);

        Type* pt = parse_opt_type(P);

        pnames=(const char**)xrealloc((void*)pnames,sizeof(char*)*(size_t)(ar+1));
        plens =(int*) xrealloc(plens, sizeof(int)*(size_t)(ar+1));
        ptypes=(Type**)xrealloc(ptypes,sizeof(Type*)*(size_t)(ar+1));
        pnames[ar]=pn.start; plens[ar]=pn.len; ptypes[ar]=pt;
        ar++;

        if(tok_is(P,TK_COMMA)){ lex_next(&P->lex); continue; }
        break;
      }
    }
    eat(P,TK_RPAREN,"expected ')' after params");
  }

  /* return type: default i64; optional -> T */
  Type* ret = P->tenv->b.ty_i64;
  if(tok_is(P,TK_ARROW)){
    lex_next(&P->lex);
    ret = parse_type(P);
  }

  Stmt* body=NULL;
  if(is_extern){
    eat_stmt_end(P,"expected end of line after extern fn declaration");
  } else {
    body=parse_block(P);
  }

  FnDecl* fn=(FnDecl*)xmalloc(sizeof(FnDecl));
  memset(fn,0,sizeof(*fn));
  fn->name=nm.start; fn->len=nm.len;
  fn->pnames=pnames; fn->plens=plens; fn->ptypes=ptypes; fn->arity=ar;
  fn->ret=ret;
  fn->body=body;
  fn->loc=loc;
  fn->is_extern=is_extern;
  fn->is_unsafe=is_unsafe;
  fn->is_kernel=is_kernel;
  fn->fty = type_fn(P->tenv, ret, ptypes, ar);
  fn->attrs = attrs.attrs;
  fn->attr_n = attrs.n;
  fn->type_params = tparams;
  fn->type_param_n = tparam_n;
  return fn;
}

Module* parse_module(TypeEnv* tenv, const char* src, const char* path){
  Parser P;
  memset(&P,0,sizeof(P));
  P.tenv=tenv;
  P.src=src;
  P.path=path;
  lex_init(&P.lex, src, path);

  Module* M=(Module*)xmalloc(sizeof(Module));"""

idx1 = text.find(target_fn)
idx2 = text.find(target_mod)
if idx1 != -1 and idx2 != -1:
    new_text = text[:idx1] + new_block + text[idx2 + len(target_mod):]
    with open(r'TezzNative-language/src/parser.c', 'w', encoding='utf-8') as f:
        f.write(new_text)
    print("SUCCESS PATCHING PARSER")
else:
    print(f"FAILED: idx1={idx1}, idx2={idx2}")
