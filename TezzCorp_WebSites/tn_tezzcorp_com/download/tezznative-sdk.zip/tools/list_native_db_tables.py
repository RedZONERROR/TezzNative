import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from ssh_helper import run_remote

check_script = '''php -r '
$pdo = new PDO("mysql:host=localhost;dbname=u190073748_tezz_native_db;charset=utf8mb4", "u190073748_tezz_native_ur", "TezzNativeByRohit@9608");
$stmt = $pdo->query("SHOW TABLES");
while ($r = $stmt->fetch(PDO::FETCH_NUM)) {
    echo "NATIVE_DB TABLE: " . $r[0] . "\\n";
}
' '''

out, err = run_remote(check_script)
print("STDOUT:\n", out)
if err:
    print("STDERR:\n", err)
