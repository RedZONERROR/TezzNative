# TezzNative Language Specification

TezzNative ships two CLI execution surfaces:
- `systems` mode is the compatibility-first default.
- `simple` mode is a script-first surface layered on top of the same parser, sema, and runtime.

## Lexical Structure
- Source files are UTF-8 text; production fixtures in this repo stay ASCII by convention.
- Significant indentation is used for blocks after `:` in the same style as existing `.tn` sources.
- Line comments use `//` and block comments use `/* ... */`.
- String literals use double quotes. Integer literals are parsed as signed machine integers unless cast.
- Identifiers are case-sensitive. Module names are resolved from import paths and file basenames.

## Declarations
- Top-level declarations include `import`, `fn`, `struct`, `enum`, `typedef`, `let`, `extern`, and `static` forms supported by the parser.
- Attributes are written on their own line before a declaration, for example `@abi("c")`.
- `fn main() -> int:` is the required entry point for `check`, `run`, `buildir`, `buildexe`, `abidump`, and release-lane fixtures.

## Types
- Primitive scalar types in the v1 surface include `int`, `float`, `char`, and `void`.
- Pointer-like values include `str`, explicit pointer types such as `*char`, and function-pointer types.
- Aggregate types include fixed-size arrays `[T;N]` and `struct` declarations.
- Type checking is enforced before IR lowering. Production lanes require type errors to stop the build with stable diagnostics.
- Extern and ABI declarations must use ABI-safe signatures; invalid ABI usage is a hard error.

## Control Flow
- The supported structured control-flow forms in production are `if`, `while`, `for`, `switch`, `ret`, `break`, `continue`, and `unsafe` blocks.
- The formatter canonicalizes spacing, keyword placement, and type spellings for AST snapshot tests.
- IR generation must preserve source-level control flow without silently replacing user code with stubs.

## Attributes
- `@abi("c")` is only valid on `extern fn` declarations.
- `@inline` is only valid on non-extern functions.
- Pointer-borrowing attributes such as `@mut` participate in sema diagnostics and must fail with actionable messages when aliasing rules are violated.
- Unsupported or misplaced attributes are production-blocking diagnostics.

## Imports And Modules
- Imports are resolved relative to the entry file and repo stdlib layout.
- Freestanding builds may not import hosted modules such as `io`, `net`, `time`, `tls`, `gpu`, or `npu`.
- Hosted lanes in this repo exercise parser, sema, formatter, IR, BC-VM execution, and native build paths against real manifests instead of placeholder single-file smoke tests.

## Production Contract
- A release candidate may only be promoted after Linux, Windows, and macOS source builds pass in CI and native SDK archives are produced for each host lane.
- `buildexe` must fail honestly: no PE stub fallback, no placeholder GPU output, and no silent success on unsupported lowering paths.
- Production manifests must contain substantive coverage for lexer/parser, sema, IR snapshots, formatter stability, runtime hardening, buildexe verification, and freestanding checks.
- Direct diagnostics, release-policy checks, runtime IO smoke, and reproducible-build checks are part of the supported release surface.
