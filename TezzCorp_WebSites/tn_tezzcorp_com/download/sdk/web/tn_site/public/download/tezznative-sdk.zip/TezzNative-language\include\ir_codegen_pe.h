// include/ir_codegen_pe.h
#pragma once
#include "ir.h"
#include <stddef.h>
#include <stdint.h>

typedef struct {
  uint32_t import_size;
  uint32_t iat_exit;
  uint32_t iat_getstd;
  uint32_t iat_write;
  uint32_t iat_lstrlen;
  uint32_t iat_lstrcmp;
  uint32_t iat_gettime;
  uint32_t iat_valloc;
  uint32_t iat_vfree;
  uint32_t iat_wsprintf;
  uint32_t iat_sprintf;
  uint32_t iat_memcpy;
  uint32_t iat_memmove;
  uint32_t iat_memcmp;
  uint32_t iat_fopen;
  uint32_t iat_fclose;
  uint32_t iat_fread;
  uint32_t iat_fwrite;
  uint32_t iat_fseek;
  uint32_t iat_ftell;
  uint32_t iat_fflush;
  uint32_t iat_io_err;
  uint32_t iat_io_eof;
  uint32_t iat_read_line;
  uint32_t iat_read_bytes;
  uint32_t iat_write_line;
  uint32_t iat_stdin;
  uint32_t iat_stdout;
  uint32_t iat_stderr;
} PeImportInfo;

typedef struct {
  const char* name;
  int len;
  int is_extern;
  uint32_t rva;
} GlobalInfo;

// Minimal PE/COFF emitter (Windows). Returns 0 on success.
int ir_compile_to_pe_exe(IRModule* m, const char* out_exe, const char* target);
// Verify PE layout/imports. Returns 0 on success.
int ir_verify_pe_exe(const char* path);

// Shared x86_64 lowering (Windows ABI), returns text buffer + entry offset.
int ir_x64_codegen(IRModule* m, uint32_t text_rva,
                   const uint32_t* str_rva, int str_n,
                   uint32_t fmt_rva, uint32_t fmtf_rva, uint32_t nl_rva, uint32_t sp_rva,
                   const PeImportInfo* imp,
                   GlobalInfo* ginfo, int gcount,
                   unsigned char** out_text, uint32_t* out_text_size,
                   size_t* out_entry_off);
