#include "lexer.h"
#include "../include/util.h"
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>

static int is_ident_start(char c){ return isalpha((unsigned char)c) || c=='_'; }
static int is_ident(char c){ return isalnum((unsigned char)c) || c=='_'; }

static void bump(Lexer* L){
  char c = L->src[L->pos];
  if (!c) return;
  L->pos++;
  if (c == '\n'){ L->line++; L->col = 1; }
  else L->col++;
}

static void skip_ws_no_nl(Lexer* L) {
  for (;;) {
    char c = L->src[L->pos];
    if (c==' '||c=='\t'||c=='\r'){ bump(L); continue; }

    if (c=='/' && L->src[L->pos+1]=='/') {
      bump(L); bump(L);
      while (L->src[L->pos] && L->src[L->pos] != '\n') bump(L);
      continue;
    }
    if (c=='/' && L->src[L->pos+1]=='*') {
      bump(L); bump(L);
      while (L->src[L->pos] && !(L->src[L->pos]=='*' && L->src[L->pos+1]=='/')) bump(L);
      if (!L->src[L->pos]) die("unterminated block comment");
      bump(L); bump(L);
      continue;
    }
    break;
  }
}

static char* unescape_string(const char* s, int len) {
  char* out = (char*)malloc((size_t)len + 1);
  if (!out) die("out of memory");
  int j=0;
  for (int i=0;i<len;i++){
    char c=s[i];
    if (c=='\\' && i+1<len){
      char n=s[i+1];
      if (n=='n'){ out[j++]='\n'; i++; continue; }
      if (n=='r'){ out[j++]='\r'; i++; continue; }
      if (n=='t'){ out[j++]='\t'; i++; continue; }
      if (n=='0'){ out[j++]=0; i++; continue; }
      if (n=='\\'){ out[j++]='\\'; i++; continue; }
      if (n=='"'){ out[j++]='"'; i++; continue; }
      if (n=='\''){ out[j++]='\''; i++; continue; }
      out[j++]=n; i++; continue;
    }
    out[j++]=c;
  }
  out[j]=0;
  return out;
}

static int tok_text_eq(Token* t, const char* lit) {
  int n = (int)strlen(lit);
  return t->len==n && strncmp(t->start, lit, (size_t)n)==0;
}

void lex_init(Lexer* L, const char* src, const char* path) {
  memset(L, 0, sizeof(*L));
  L->src = src;
  L->path = path ? path : "<mem>";
  L->pos = 0;
  L->line = 1;
  L->col = 1;
  L->at_line_start = 1;
  L->indent_top = 1;
  L->indent_stack[0] = 0;
  L->pending_dedents = 0;
  L->cur.kind = TK_EOF;
  L->cur.str = NULL;
  lex_next(L);
}

void lex_next(Lexer* L) {
  if (L->cur.kind == TK_STRING && L->cur.str) {
    free(L->cur.str);
    L->cur.str = NULL;
  }

  if (L->pending_dedents > 0) {
    L->pending_dedents--;
    L->cur.kind = TK_DEDENT;
    L->cur.start = L->src + L->pos;
    L->cur.len = 0;
    L->cur.line = L->line;
    L->cur.col = L->col;
    return;
  }

  if (L->at_line_start) {
    // compute indentation (ignore blank/comment-only lines)
    for (;;) {
      size_t p = L->pos;
      int col = L->col;
      int indent = 0;

      while (L->src[p]==' ' || L->src[p]=='\t') {
        if (L->src[p]==' ') { indent++; }
        else { indent += 4 - (indent % 4); }
        p++; col++;
      }

      char c0 = L->src[p];
      // blank line: let NEWLINE handle it
      if (c0=='\n' || c0=='\r') {
        L->pos = p;
        L->col = col;
        break;
      }
      // comment-only line: treat as blank
      if (c0=='/' && L->src[p+1]=='/') {
        L->pos = p;
        L->col = col;
        break;
      }
      if (c0=='/' && L->src[p+1]=='*') {
        L->pos = p;
        L->col = col;
        break;
      }

      // non-blank line: apply indentation
      L->pos = p;
      L->col = col;
      L->at_line_start = 0;

      int cur = L->indent_stack[L->indent_top-1];
      if (indent > cur) {
        if (L->indent_top >= (int)(sizeof(L->indent_stack)/sizeof(L->indent_stack[0]))) {
          die("indentation too deep");
        }
        L->indent_stack[L->indent_top++] = indent;
        L->cur.kind = TK_INDENT;
        L->cur.start = L->src + L->pos;
        L->cur.len = 0;
        L->cur.line = L->line;
        L->cur.col = L->col;
        return;
      }
      if (indent < cur) {
        int pops = 0;
        while (L->indent_top > 1 && indent < L->indent_stack[L->indent_top-1]) {
          L->indent_top--;
          pops++;
        }
        if (indent != L->indent_stack[L->indent_top-1]) {
          die("inconsistent indentation");
        }
        if (pops > 0) {
          L->pending_dedents = pops - 1;
          L->cur.kind = TK_DEDENT;
          L->cur.start = L->src + L->pos;
          L->cur.len = 0;
          L->cur.line = L->line;
          L->cur.col = L->col;
          return;
        }
      }
      break;
    }
  }

  skip_ws_no_nl(L);

  const char* s = L->src + L->pos;
  char c = *s;

  L->cur.start = s;
  L->cur.len = 0;
  L->cur.line = L->line;
  L->cur.col = L->col;

  if (!c) {
    if (L->indent_top > 1) {
      L->indent_top--;
      L->cur.kind = TK_DEDENT;
      return;
    }
    L->cur.kind = TK_EOF;
    return;
  }

  if (c=='\n') {
    L->cur.kind = TK_NEWLINE;
    L->cur.len = 1;
    bump(L);
    L->at_line_start = 1;
    return;
  }

  // punctuation
  if (c=='('){ L->cur.kind=TK_LPAREN; L->cur.len=1; bump(L); return; }
  if (c==')'){ L->cur.kind=TK_RPAREN; L->cur.len=1; bump(L); return; }
  if (c=='{'){ L->cur.kind=TK_LBRACE; L->cur.len=1; bump(L); return; }
  if (c=='}'){ L->cur.kind=TK_RBRACE; L->cur.len=1; bump(L); return; }
  if (c=='['){ L->cur.kind=TK_LBRACKET; L->cur.len=1; bump(L); return; }
  if (c==']'){ L->cur.kind=TK_RBRACKET; L->cur.len=1; bump(L); return; }
  if (c==';'){ L->cur.kind=TK_SEMI; L->cur.len=1; bump(L); return; }
  if (c==','){ L->cur.kind=TK_COMMA; L->cur.len=1; bump(L); return; }
  if (c=='?'){ L->cur.kind=TK_QUESTION; L->cur.len=1; bump(L); return; }
  if (c==':'){ L->cur.kind=TK_COLON; L->cur.len=1; bump(L); return; }
  if (c=='.'){ L->cur.kind=TK_DOT; L->cur.len=1; bump(L); return; }
  if (c=='@'){ L->cur.kind=TK_AT; L->cur.len=1; bump(L); return; }

  // 3-char operators
  if (c=='<' && L->src[L->pos+1]=='<' && L->src[L->pos+2]=='='){ L->cur.kind=TK_SHLEQ; L->cur.len=3; bump(L); bump(L); bump(L); return; }
  if (c=='>' && L->src[L->pos+1]=='>' && L->src[L->pos+2]=='='){ L->cur.kind=TK_SHREQ; L->cur.len=3; bump(L); bump(L); bump(L); return; }

  // 2-char operators
  if (c=='+' && L->src[L->pos+1]=='+'){ L->cur.kind=TK_PLUSPLUS; L->cur.len=2; bump(L); bump(L); return; }
  if (c=='-' && L->src[L->pos+1]=='-'){ L->cur.kind=TK_MINUSMINUS; L->cur.len=2; bump(L); bump(L); return; }
  if (c=='&' && L->src[L->pos+1]=='&'){ L->cur.kind=TK_LAND; L->cur.len=2; bump(L); bump(L); return; }
  if (c=='|' && L->src[L->pos+1]=='|'){ L->cur.kind=TK_LOR;  L->cur.len=2; bump(L); bump(L); return; }
  if (c=='<' && L->src[L->pos+1]=='<'){ L->cur.kind=TK_SHL; L->cur.len=2; bump(L); bump(L); return; }
  if (c=='>' && L->src[L->pos+1]=='>'){ L->cur.kind=TK_SHR; L->cur.len=2; bump(L); bump(L); return; }
  if (c=='=' && L->src[L->pos+1]=='='){ L->cur.kind=TK_EQ;  L->cur.len=2; bump(L); bump(L); return; }
  if (c=='!' && L->src[L->pos+1]=='='){ L->cur.kind=TK_NEQ; L->cur.len=2; bump(L); bump(L); return; }
  if (c=='<' && L->src[L->pos+1]=='='){ L->cur.kind=TK_LTE; L->cur.len=2; bump(L); bump(L); return; }
  if (c=='>' && L->src[L->pos+1]=='='){ L->cur.kind=TK_GTE; L->cur.len=2; bump(L); bump(L); return; }

  if (c=='+' && L->src[L->pos+1]=='='){ L->cur.kind=TK_PLUSEQ; L->cur.len=2; bump(L); bump(L); return; }
  if (c=='-' && L->src[L->pos+1]=='='){ L->cur.kind=TK_MINUSEQ; L->cur.len=2; bump(L); bump(L); return; }
  if (c=='-' && L->src[L->pos+1]=='>'){ L->cur.kind=TK_ARROW; L->cur.len=2; bump(L); bump(L); return; }
  if (c=='*' && L->src[L->pos+1]=='='){ L->cur.kind=TK_STAREQ; L->cur.len=2; bump(L); bump(L); return; }
  if (c=='/' && L->src[L->pos+1]=='='){ L->cur.kind=TK_SLASHEQ; L->cur.len=2; bump(L); bump(L); return; }
  if (c=='%' && L->src[L->pos+1]=='='){ L->cur.kind=TK_PERCENTEQ; L->cur.len=2; bump(L); bump(L); return; }

  if (c=='&' && L->src[L->pos+1]=='='){ L->cur.kind=TK_ANDEQ; L->cur.len=2; bump(L); bump(L); return; }
  if (c=='|' && L->src[L->pos+1]=='='){ L->cur.kind=TK_OREQ;  L->cur.len=2; bump(L); bump(L); return; }
  if (c=='^' && L->src[L->pos+1]=='='){ L->cur.kind=TK_XOREQ; L->cur.len=2; bump(L); bump(L); return; }

  // 1-char operators
  if (c=='='){ L->cur.kind=TK_ASSIGN;  L->cur.len=1; bump(L); return; }
  if (c=='+'){ L->cur.kind=TK_PLUS;    L->cur.len=1; bump(L); return; }
  if (c=='-'){ L->cur.kind=TK_MINUS;   L->cur.len=1; bump(L); return; }
  if (c=='*'){ L->cur.kind=TK_STAR;    L->cur.len=1; bump(L); return; }
  if (c=='/'){ L->cur.kind=TK_SLASH;   L->cur.len=1; bump(L); return; }
  if (c=='%'){ L->cur.kind=TK_PERCENT; L->cur.len=1; bump(L); return; }

  if (c=='!'){ L->cur.kind=TK_LNOT;    L->cur.len=1; bump(L); return; }
  if (c=='~'){ L->cur.kind=TK_BNOT;    L->cur.len=1; bump(L); return; }

  if (c=='&'){ L->cur.kind=TK_BAND;    L->cur.len=1; bump(L); return; }
  if (c=='|'){ L->cur.kind=TK_BOR;     L->cur.len=1; bump(L); return; }
  if (c=='^'){ L->cur.kind=TK_BXOR;    L->cur.len=1; bump(L); return; }

  if (c=='<'){ L->cur.kind=TK_LT;      L->cur.len=1; bump(L); return; }
  if (c=='>'){ L->cur.kind=TK_GT;      L->cur.len=1; bump(L); return; }

  // number / float
  if (isdigit((unsigned char)c)) {
    size_t p=L->pos;
    long long v=0;
    while (isdigit((unsigned char)L->src[p])) { v = v*10 + (L->src[p]-'0'); p++; }
    int is_float = 0;
    if (L->src[p]=='.' && isdigit((unsigned char)L->src[p+1])) {
      is_float = 1;
      p++;
      while (isdigit((unsigned char)L->src[p])) p++;
    }
    L->cur.start=L->src+L->pos;
    L->cur.len=(int)(p-L->pos);
    if(is_float){
      char tmp[128];
      int n = L->cur.len < (int)(sizeof(tmp)-1) ? L->cur.len : (int)(sizeof(tmp)-1);
      memcpy(tmp, L->cur.start, (size_t)n);
      tmp[n]=0;
      L->cur.kind=TK_FLOAT;
      L->cur.f=strtod(tmp, NULL);
    } else {
      L->cur.kind=TK_NUMBER;
      L->cur.num=v;
    }
    // advance with bump to keep line/col sane (digits are same line)
    while (L->pos < p) bump(L);
    return;
  }

  // string
  if (c=='"') {
    size_t p=L->pos+1;
    while (L->src[p] && L->src[p]!='"') {
      if (L->src[p]=='\\' && L->src[p+1]) p+=2;
      else p++;
    }
    if (L->src[p] != '"') die("unterminated string literal");
    int raw_len = (int)(p - (L->pos+1));
    const char* raw = L->src + L->pos + 1;

    L->cur.kind=TK_STRING;
    L->cur.start=L->src+L->pos;
    L->cur.len=(int)(p-L->pos+1);
    L->cur.str=unescape_string(raw, raw_len);

    // move pos past closing "
    bump(L); // opening "
    while (L->src[L->pos] && L->pos < p) bump(L);
    bump(L); // closing "
    return;
  }

  // ident / keywords
  if (is_ident_start(c)) {
    size_t p=L->pos+1;
    while (is_ident(L->src[p])) p++;
    L->cur.kind=TK_IDENT;
    L->cur.start=L->src+L->pos;
    L->cur.len=(int)(p-L->pos);

    if (tok_text_eq(&L->cur, "fn")) L->cur.kind=TK_FN;
    else if (tok_text_eq(&L->cur, "struct")) L->cur.kind=TK_STRUCT;
    else if (tok_text_eq(&L->cur, "import")) L->cur.kind=TK_IMPORT;
    else if (tok_text_eq(&L->cur, "let")) L->cur.kind=TK_LET;
    else if (tok_text_eq(&L->cur, "enum")) L->cur.kind=TK_ENUM;
    else if (tok_text_eq(&L->cur, "typedef")) L->cur.kind=TK_TYPEDEF;
    else if (tok_text_eq(&L->cur, "switch")) L->cur.kind=TK_SWITCH;
    else if (tok_text_eq(&L->cur, "case")) L->cur.kind=TK_CASE;
    else if (tok_text_eq(&L->cur, "default")) L->cur.kind=TK_DEFAULT;
    else if (tok_text_eq(&L->cur, "as")) L->cur.kind=TK_AS;
    else if (tok_text_eq(&L->cur, "fallthrough")) L->cur.kind=TK_FALLTHROUGH;
    else if (tok_text_eq(&L->cur, "sizeof")) L->cur.kind=TK_SIZEOF;
    else if (tok_text_eq(&L->cur, "alignof")) L->cur.kind=TK_ALIGNOF;
    else if (tok_text_eq(&L->cur, "const")) L->cur.kind=TK_CONST;
    else if (tok_text_eq(&L->cur, "unsafe")) L->cur.kind=TK_UNSAFE;
    else if (tok_text_eq(&L->cur, "kernel")) L->cur.kind=TK_KERNEL;
    else if (tok_text_eq(&L->cur, "static")) L->cur.kind=TK_STATIC;
    else if (tok_text_eq(&L->cur, "extern")) L->cur.kind=TK_EXTERN;
    else if (tok_text_eq(&L->cur, "ret")) L->cur.kind=TK_RET;
    else if (tok_text_eq(&L->cur, "if")) L->cur.kind=TK_IF;
    else if (tok_text_eq(&L->cur, "else")) L->cur.kind=TK_ELSE;
    else if (tok_text_eq(&L->cur, "while")) L->cur.kind=TK_WHILE;
    else if (tok_text_eq(&L->cur, "for")) L->cur.kind=TK_FOR;
    else if (tok_text_eq(&L->cur, "break")) L->cur.kind=TK_BREAK;
    else if (tok_text_eq(&L->cur, "continue")) L->cur.kind=TK_CONTINUE;
    else if (tok_text_eq(&L->cur, "say")) L->cur.kind=TK_SAY;
    else if (tok_text_eq(&L->cur, "say_str")) L->cur.kind=TK_SAYSTR;
    else if (tok_text_eq(&L->cur, "malloc")) L->cur.kind=TK_MALLOC;
    else if (tok_text_eq(&L->cur, "free")) L->cur.kind=TK_FREE;
    else if (tok_text_eq(&L->cur, "input_line")) L->cur.kind=TK_INPUT_LINE;
    else if (tok_text_eq(&L->cur, "input_i64")) L->cur.kind=TK_INPUT_I64;

    // advance
    while (L->pos < p) bump(L);
    return;
  }
  {
  char msg[128];
  snprintf(msg, sizeof(msg), "unexpected character '%c' (%d)", c, (int)(unsigned char)c);
  die(msg);
  }
}
